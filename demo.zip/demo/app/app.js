define(['require', 'constants', 'masterService', 'utility'],
    function(r, constants, masterService, utility) {
        'use strict';
        return function(environmentConfig, appStateConfig, meta) {
            var app = angular.module('chola.web', ['common', 'common.shared', 'common.menu', 'common.notification', 'common.auth']);

            angular.module('common').constant('environmentConfig', environmentConfig);
            app.value('globalData', {});
            app.filter('currencyFormat', function() {
                return utility.currencyFormatter;
            });

            app.filter('ISTDate', function() {
                return utility.getDateISTFormat;
            });

            app.filter('UCFirst', function() {
                return utility.capitaliseFirstLetter;
            });

            app.filter('CCToRegular', function() {
                return utility.camelCaseToRegularCase;
            });

            app.filter('valueCheck', function() {
                return utility.checkValue;
            });

            app.filter('padZero', function() {
                return utility.padZero;
            });
            app.filter('RegularToCamel', function() {
                return utility.RegularToCamel;
            });

            app.filter('camelCase', function() {
                return utility.regularCaseToCamelCase;
            });
            
            app.filter('toArray', function() {
              return utility.toArray;
			});
			app.filter('detailedDate', function() {
                return utility.showDetailDate;
            });
            app.filter('parseData', function() {
                return utility.parseData;
            });
            app.filter('underscoreLess', function () {
                return utility.underscoreless;
            });
            app.service('masterService', masterService);


            if (environmentConfig.APPLICATION_MODULE != 'SSO') {
                window.onbeforeunload = function() {
                    return constants.MESSAGES.APP_CLOSE_ALERT;
                };
            }

            var defineConfigPhase = function(app, lazyStates) {
                // Lazy loading modules
                app.config(['lazyLoadConfigurationProvider', '$controllerProvider',
                    '$compileProvider', '$filterProvider', '$provide', '$injector', '$urlRouterProvider',
                    '$sceDelegateProvider', '$httpProvider',
                    function(lazyLoadConfigurationProvider, $controllerProvider, $compileProvider,
                        $filterProvider, $provide, $injector, $urlRouterProvider, $sceDelegateProvider,
                        $httpProvider) {


                        //Release VERSION based caching for htmls
                        $httpProvider.interceptors.unshift(['$q',
                            function($q) {
                                return {
                                    request: function(config) {
                                        if (!config.url) {
                                            return false;
                                        }
                                        if (config.url.indexOf('.html') > -1 && config.url.indexOf('template/') !== 0) {
                                            if (config.url.indexOf('?') > -1) {
                                                config.url = config.url + '&v=' + environmentConfig.VERSION ;//+ '&authorization=' + getCookie("token");
                                            } else {
                                                config.url = config.url + '?v=' + environmentConfig.VERSION ;//+ '&authorization=' + getCookie("token");
                                            }
                                            //config.headers.Authorization = window.sessionStorage.token;
                                        }
                                        return config || $q.when(config);
                                    }
                                };
                            }
                        ]);
                        if (environmentConfig.APPLICATION_MODULE === 'sales_HEHL') {
                            $provide.decorator('selectDirective', ['$parse', '$delegate', '$compile',
                                function($parse, $delegate, $compile) {
                                    var oldCompile = $delegate[0].compile;
                                    var newSelectCompile = function(tElement, tAttrs, transclude) {
                                        var compile = oldCompile ? oldCompile.apply(this, arguments) : {};
                                        //var oldPre = compile.pre;
                                        var oldPost = compile;
                                        var newPostLink = function($scope, element, attrs, $ctrl) {

                                            var selectCtrl = $ctrl[0];
                                            var ngModelCtrl = $ctrl[1];

                                            var oldaddOption = selectCtrl.addOption;
                                            var olength = element.find("option").length;
                                            selectCtrl.addOption = function() {
                                                oldaddOption.apply(this, arguments);
                                                var options = element.find("option");
                                                if (olength !== options.length) {
                                                    olength = options.length;
                                                    for (var o = 0; o < options.length; o++) {
                                                        var l = options[o].getAttribute("label");
                                                        if (l && l.toUpperCase)
                                                            options[o].setAttribute("label", l.toUpperCase());
                                                    }
                                                }
                                            };
                                            var oldhasOption = selectCtrl.hasOption;
                                            selectCtrl.hasOption = function(value) {
                                                var uvalue = typeof value === "string" ? value.toUpperCase() : value;
                                                return oldhasOption(value) || optionsMap.hasOwnProperty(uvalue);
                                            };

                                            var optionsExp = attrs.ngOptions;
                                            var selectArguments = arguments;
                                            if (optionsExp) {
                                                var match;
                                                var NG_OPTIONS_REGEXP = /^\s*([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+group\s+by\s+([\s\S]+?))?\s+for\s+(?:([\$\w][\$\w]*)|(?:\(\s*([\$\w][\$\w]*)\s*,\s*([\$\w][\$\w]*)\s*\)))\s+in\s+([\s\S]+?)(?:\s+track\s+by\s+([\s\S]+?))?$/;
                                                if (!(match = optionsExp.match(NG_OPTIONS_REGEXP))) {
                                                    throw ngOptionsMinErr('iexp',
                                                        "Expected expression in form of " +
                                                        "'_select_ (as _label_)? for (_key_,)?_value_ in _collection_'" +
                                                        " but got '{0}'. Element: {1}",
                                                        optionsExp);
                                                }

                                                var displayFn = $parse(match[2] || match[1]),
                                                    valueName = match[4] || match[6],
                                                    selectAs = / as /.test(match[0]) && match[1],
                                                    selectAsFn = selectAs ? $parse(selectAs) : null,
                                                    keyName = match[5],
                                                    groupByFn = $parse(match[3] || ''),
                                                    valueFn = $parse(match[2] ? match[1] : valueName),
                                                    valuesFn = $parse(match[7]),
                                                    track = match[8],
                                                    trackFn = track ? $parse(match[8]) : null,
                                                    trackKeysCache = {};

                                                // if (selectAs.split('.')[1]) {
                                                //     var sorter = angular.element('<span class="fa fa-sort pull-right" tooltip="Change order" style="margin-top: -20px;margin-right: -10px;"></span>');
                                                //     element.after($compile(sorter)($scope));
                                                //     var isSorted = false;
                                                //     sorter.on('click', function(e) {
                                                //         $scope.$apply(function() {
                                                //             element.removeAttr('data-ng-options');
                                                //             element.removeAttr('ng-options');
                                                //             attrs.ngOptions = optionsExp + " | orderBy:'" + (isSorted ? '- ' : '') + selectAs.split('.')[1] + "'";
                                                //             element.attr('data-ng-options', attrs.ngOptions);
                                                //             isSorted = !isSorted;
                                                //             if (oldPost) {
                                                //                 oldPost.apply(this, selectArguments);
                                                //             }
                                                //         });
                                                //     });
                                                // }
                                                //** once stable check this later
                                                // var isSorted = false;
                                                // var displayKey = match[2] || match[1];
                                                // var listKey = match[7].split('.');
                                                // var dSplit = displayKey.indexOf('.') > -1 ? displayKey.split('.') : [listKey[listKey.length - 1]];
                                                // if (dSplit.length && !attrs.noSort) {
                                                //     var ngOptions = optionsExp + " | orderBy:'" + (isSorted ? '- ' : '') + (dSplit[dSplit.length - 1]) + "'";
                                                //     attrs.ngOptions = ngOptions;
                                                //     element.removeAttr('ng-options');
                                                //     element.removeAttr('data-ng-options');
                                                //     element.attr('data-ng-options', attrs.ngOptions);
                                                // }
                                            } else {
                                                var opts = element.find("option");
                                                for (var o = opts.length - 1; o >= 0; o--) {
                                                    var l = opts[o].getAttribute("label");
                                                    if (l && l.toUpperCase) {
                                                        opts[o].setAttribute("label", l.toUpperCase());
                                                        opts[o].text = l.toUpperCase();
                                                    } else {
                                                        var t = opts[o].text != "Select" ? opts[o].text : "";
                                                        if (t && t.toUpperCase) {
                                                            opts[o].setAttribute("label", t.toUpperCase());
                                                        }
                                                    }
                                                }
                                            }
                                            if (oldPost) {
                                                oldPost.apply(this, selectArguments);
                                            }
                                        };
                                        //compile.post = newPostLink;
                                        return newPostLink;
                                    };
                                    $delegate[0].compile = newSelectCompile;
                                    return $delegate;
                                }
                            ]);
                        }

                        var providers = {
                            $controllerProvider: $controllerProvider,
                            $compileProvider: $compileProvider,
                            $filterProvider: $filterProvider,
                            $provide: $provide, // other things
                            $injector: $injector
                        };
                        $sceDelegateProvider.resourceUrlWhitelist([
                            'self',
                            /blob:*/
                        ]);
                        lazyLoadConfigurationProvider.configure(app, lazyStates, providers);

                        $urlRouterProvider.otherwise(function($injector, $location) {
                            var lazyModuleLoader = $injector.get('lazyModuleLoader');
                            var $state = $injector.get('$state');
                            if (!$location.$$path) {
                                if ($location.$$path.indexOf('token') === -1) {
                                    $state.go('common.auth.login');
                                } else {
                                    lazyModuleLoader.loadState(appStateConfig.defaultState, appStateConfig.params);
                                }
                            } else {

                                lazyModuleLoader.loadStateHash($location.$$path, function(lazyState) {
                                    if (lazyState) {
                                        $injector.invoke(['$state',
                                            function($state) {
                                                $state.go(lazyState.stateName, lazyState.stateParams);
                                            }
                                        ]);
                                    } else {
                                        if ($location.$$path.indexOf('token') === -1) {
                                            $state.go('common.auth.login');
                                        } else {
                                            lazyModuleLoader.loadState(appStateConfig.defaultState, appStateConfig.params);
                                        }
                                    }
                                });
                            }
                            console.log('inside ui router otherwise handler..');
                        });

                    }
                ]);
            };
            
            var logStatePerformance = function(fromState,statePerformance){
                /*try{
                    if(statePerformance[fromState.name] && statePerformance[fromState.name].timelapse>500){
                        console.warn("State Performance Warning!!!",fromState.name,statePerformance);
                        localStorage.setItem('UIStateLog_'+new Date().toGMTString(),fromState.name+' : '+JSON.stringify(statePerformance));
                    }
                }
                catch(e){
                    
                }*/
            };

            var defineRunPhase = function(app, defaultState) {

                // Running phase [When user enters URL in browser]
                app.run(['$rootScope', '$location', '$state', 'messageBus', 'authService', 'lazyModuleLoader', 'globalData',
                    '$modalStack', 'appFactory', '$globalScope',
                    function($rootScope, $location, $state, messageBus, authService, lazyModuleLoader, globalData,
                        $modalStack, appFactory, $globalScope) {
                        $globalScope.stateStack = [];
                        $rootScope.fdcDisabled = false; //for salesHEHL form dirtyCheck
                        $rootScope.currentUrl = '';
                        $rootScope.dateFormat = 'dd-MM-yyyy';
                        $rootScope.timeFormat = 'HH:mm:ss';
                        $rootScope.fractionSize = 2;
                        globalData.applicationModule = environmentConfig.APPLICATION_MODULE;
                        $rootScope.appVersion = environmentConfig.VERSION;
                        $rootScope.environmentConfig = environmentConfig;
                        $rootScope.enablePrint = environmentConfig.enablePrint;
                        $rootScope.miniSOACharge = environmentConfig.miniSOACharge;
                        $rootScope.regExs = {
                            floatTyper: '^[-]?(([0-9]*)(\.)([0-9]*)|([0-9]*)(\.)([0-9])|([0-9]))$'
                        };

                        if (!$location.$$path || !lazyModuleLoader.loadStateHash($location.$$path)) {
                            if (meta && meta.token) {
                                lazyModuleLoader.loadState(defaultState, appStateConfig.params);
                            } else {
                                lazyModuleLoader.loadState('common.auth.login');
                            }
                        }

                        messageBus.onMsg('LOGIN_SUCCESS', function(data) {
                            if (meta && meta.redirectURL) {
                                location.replace(meta.redirectURL);
                            } else {
                                $rootScope.newlyLoggedUser = true;
                                lazyModuleLoader.loadState(defaultState, appStateConfig.params);
                            }
                        });

                        messageBus.onMsg("SSO_SUCCESS", function() {
                            lazyModuleLoader.loadState(defaultState, appStateConfig.params);
                        });
                        // if (!$rootScope.applicationModule) {
                        //     $rootScope.applicationModule = window.sessionStorage.applicationModule;
                        //     if (window.sessionStorage.userId && $location.$$path !== '/login'){
                        //         authService.authorize();
                        //     }
                        // }
                        var statePerformance = {};

                        //On refresh no specfic module is loaded,
                        //In order to load the module based the url accessed
                        $rootScope.$on('$stateChangeStart',
                            function(event, toState, toParams, fromState, fromParams) {
                                if(!statePerformance[toState.name]){
                                    statePerformance[toState.name]={};
                                }
                                statePerformance[toState.name].startDate = new Date();
                                toState.statePerformance=statePerformance;
                                //Check access to page
                                if (toState.data && toState.data.stateActivity && !appFactory.getActivityAccess(toState.data.stateActivity, true)) {
                                    window.statePrevented = true;
                                    event.preventDefault();
                                    return;
                                }
                                if (!fromState.forceReload) {
                                    if (window.prevLocationHash && window.location.hash && window.location.hash === window.prevLocationHash && (fromState === toState || fromState.url === "^")) {
                                        var param = {};
                                        if (lazyModuleLoader.checkHashUrl((toState.fullUrl || toState.url), $location.$$path, param)) {
                                            if (utility.checkIfParamsEqual(window.prevParams, param)) {
                                                window.prevParams = param;
                                                window.statePrevented = true;
                                                event.preventDefault();
                                                return;
                                            }
                                        }
                                    }
                                    if (toState === fromState && utility.checkIfParamsEqual(toParams, fromParams)) {
                                        window.statePrevented = true;
                                        event.preventDefault();
                                        return;
                                    }
                                }
                                console.log('state change started', toState);
                                $rootScope.toState = toState;
                                window.prevParams = angular.copy(toParams);
                                //window.prevLocation = angular.copy(window.location);
                                window.prevLocationHash = angular.copy(window.location.hash);
                            });
                            $rootScope.$on('$stateChangeError',
                            function(event, toState, toParams, fromState, fromParams) {
                                if(statePerformance[toState.name]){
                                    statePerformance[toState.name].endDate = new Date();
                                    statePerformance[toState.name].timelapse = statePerformance[toState.name].endDate - statePerformance[toState.name].startDate;
                                    logStatePerformance(fromState,statePerformance);
                                }
                            });

                        $rootScope.$on('$stateChangeSuccess',
                            function(event, toState, toParams, fromState, fromParams) {
                                if(statePerformance[toState.name]){
                                    statePerformance[toState.name].endDate = new Date();
                                    statePerformance[toState.name].timelapse = statePerformance[toState.name].endDate - statePerformance[toState.name].startDate;
                                    logStatePerformance(fromState.name,statePerformance);
                                }
                                statePerformance[toState.name].startDate = new Date();
                                $rootScope.currentUrl = $location.$$path;
                                $rootScope.currentState = toState;
                                $rootScope.toParams = toParams;
                                $rootScope.previousState = fromState;
                                $rootScope.previousParams = fromParams;
                                $modalStack.dismissAll('state changed');
                                if ($globalScope.stateStack.length && angular.toJson($globalScope.stateStack[$globalScope.stateStack.length - 1].name) === angular.toJson(toState)) {
                                	if(angular.toJson($globalScope.stateStack[$globalScope.stateStack.length - 1].params !==  angular.toJson(toParams))){
                                		$globalScope.stateStack[$globalScope.stateStack.length - 1].params = toParams;
                                	}
                                    return;
                                }
                                $globalScope.stateStack.push({
                                    name: toState,
                                    params: toParams
                                });
                            });

                        $rootScope.$on('$locationChangeStart',
                            function(event, toUrl, fromUrl) {
                                if (window.statePrevented) {
                                    window.statePrevented = false;
                                    return false;
                                }
                                // if ($location.$$path && $rootScope.currentUrl !== $location.$$path) {
                                //     // TODO Check for path authorization here
                                //     var isStateLoaded = lazyModuleLoader.loadStateHash($location.$$path, true);
                                // }
                            });
                        console.log('app loaded');

                    }
                ]);
            };

            app.directive('autoFocus',['$timeout',function($timeout){
            	return {
                    restrict: 'A',
                    link: function($scope, $elem, $attrs, $ctrl) {
                    	$timeout(function() {
                    		$elem[0].focus();
                    	},200);
                    }
                };
            }]);
            defineConfigPhase(app, appStateConfig.states);
            defineRunPhase(app, appStateConfig.defaultState);
            requirejs(["imageCategoryConstants"], function(imageCategoryConstants) {
                app.constant('imageCategoryConstant', imageCategoryConstants);
                angular.bootstrap(document, ['chola.web']);
            });
            return app;
        };
    });
