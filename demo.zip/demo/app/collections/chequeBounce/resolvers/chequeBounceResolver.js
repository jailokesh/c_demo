define([], function() {
	'use strict';

	/**
	 * Represents a chequeBounce Resolver. Dependency injection
	 * chequeBounceService. Return the hold agreement list response data.
	 */

	return {
		getBounceReason : [ 'masterService', function(masterService) {
			return masterService.getPDCReason().then(function(data) {
				return _.where(data,{reasonFlag:"B"});
			});
		} ]

	};

});