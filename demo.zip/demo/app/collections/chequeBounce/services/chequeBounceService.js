define(
		[ 'require', 'chequeBounce', 'collectionServiceURLs', 'utility' ],
		function(r, chequeBounce, collectionsServiceURL, utility) {
			'use strict';
			var chequeBounceService = function($q, $rootScope, restProxy) {				
				this.getReceiptDetails = function(keyVal,receiptNo) {
					var receiptObj = {};
					receiptObj.view = "summary";
					receiptObj.userrole = $rootScope.identity.hierarchyName;
					receiptObj.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
					receiptObj[keyVal] = receiptNo;
					collectionsServiceURL.batchingServices.GET_RECEIPTDETAILS.queryParams = receiptObj;
					return restProxy.get(collectionsServiceURL.batchingServices.GET_RECEIPTDETAILS).then(function(data) {
								if(data.status === 'success'){
									data.data.totalCount = (data.meta && data.meta[0]&&data.meta[0].totalCount) ?data.meta[0].totalCount:0;
								}
								return data.data;
							});
				};

				this.updateChequeDetails = function(bounceDetails) {
					var receiptNo = bounceDetails.receiptDetails.receiptNo;
					delete bounceDetails.receiptDetails.instrumentDetail.instrumentNo;
					var receiptDetails = {
							instrumentDetail : bounceDetails.receiptDetails.instrumentDetail,
							majorVersion : bounceDetails.receiptDetails.majorVersion,
							minorVersion : bounceDetails.receiptDetails.minorVersion					
					};
					var urlParams = {
						receiptNo : receiptNo
					};
					var queryParams = {
						userrole : $rootScope.identity.hierarchyName,
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						view:"bounceCheque"
					};
					collectionsServiceURL.receiptingServices.MODIFY_RECEIPT.queryParams = queryParams;
					collectionsServiceURL.receiptingServices.MODIFY_RECEIPT.urlParams = urlParams;
					return restProxy.save('PUT',collectionsServiceURL.receiptingServices.MODIFY_RECEIPT,receiptDetails).then(function(response) {
									return response;
							});
				};

				this.getOnHoldCheques = function(limit,offset,sort) {
					var queryParams = {
							view : "onHoldAgreements",
							limit : limit,
							offset:offset,
							sort:sort,
							userbranch : JSON.parse(getCookie('selectedBranch')).branchID
							
						};
					collectionsServiceURL.receiptingServices.GET_ONHOLD_AGREEMENT.queryParams = queryParams;
					return restProxy.get(collectionsServiceURL.receiptingServices.GET_ONHOLD_AGREEMENT).then(function(data) {
								if(data.status === 'success'&& data.meta[0]){
									data.data.totalCount = (data.meta && data.meta[0] && data.meta[0].count) ? data.meta[0].count:0;
									}
								if(data.data){
									_.each(data.data,function(item){
										item.cheque = item.isChequeCollectionOnHold ? item.isChequeCollectionOnHold : false;
										item.dd = item.isDDCollectionOnHold ? item.isDDCollectionOnHold : false;
										item.isChequeCollectionOnHold = item.isChequeCollectionOnHold ? item.isChequeCollectionOnHold : true;
										item.isDDCollectionOnHold = item.isDDCollectionOnHold ? item.isDDCollectionOnHold : true;
									});
								}
								return data.data;
							});
				};
				this.unHoldAgreement = function(agreementList) {
					return restProxy
							.save('PUT',collectionsServiceURL.receiptingServices.UPDATE_ONHOLD_AGREEMENT,agreementList).then(function(response) {
								if (response.status === 'success') {
									return response;
								} else {
									return utility.getFailureResult();
								}
							});
				};
				};

			chequeBounce.service('chequeBounceService', [ '$q', '$rootScope',
					'restProxy', chequeBounceService ]);
			return chequeBounceService;
		});