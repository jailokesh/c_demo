define([ 'require', 'chequeBounce', 'constants', 'utility', 'DatePickerConfig', 'collectionConstants' ], function(r, chequeBounce, constants, utility, DatePickerConfig, collectionConstants) {
	'use strict';
	var chequeBounceController = function($scope, $globalScope, chequeBounceService, $state, dialogService, getBounceReason, appFactory) {
		var categoryList = _.findWhere($globalScope.imageCategories, {
			subCategory : 'bounced cheque'
		});
		$scope.categoryDetails = categoryList ? categoryList : {};
		$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
		$scope.maxSize = constants.PAGINATION_CONFIG.MAX_SIZE_TEN;
		$scope.data = {
			currentPage : 1,
			receiptNo:"",
			reason:""
		};
		$scope.isSort = true;
		$scope.serviceParams = {};
		$scope.serviceParams.sort = "asc";
		$scope.searchType = [ {
			type : "Select",
			value : "select"
		}, {
			type : "Receipt No",
			value : "receiptNo"
		}, {
			type : "Instrument No",
			value : "instrumentNo"
		} ];
		var today = new Date();
		today.setHours(0, 0, 0, 0);
		$scope.bounceDate = $scope.presentedDate = today;
		var bounce = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CHEQUE_BOUNCE.BOUNCE);
		var cheque,DD;
		$scope.isEnable = false;
		$scope.bounceDateConfig = new DatePickerConfig({
			dateValue : new Date(),
			readonly : true,
			maxDate : new Date(),
			onchange : function(val) {
				$scope.presentedConfig.setDateVal(val);
				$scope.presentedConfig.maxDate = val;
				$scope.bounceDate = val;
				$scope.presentedDate = val;
			}
		});
		
		$scope.presentedConfig = new DatePickerConfig({
			dateValue : $scope.presentedDate,
			readonly : true,
			minDate : new Date(),
			maxDate : new Date(),
			onchange : function(val) {
				$scope.bounceDateConfig.minDate = val;
				$scope.presentedDate = val;
			}
		});
		
		$scope.currentSearch = {
			type : "Select",
			value : "select"
		};
		/**
		 * set place holder content
		 */
		$scope.setPlaceHolderContent = function(searchBy) {
			$scope.data.receiptNo = "";
			$scope.receiptDetails = [];
			$scope.placeHolderAndMaxLength = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, {
				type : searchBy
			});
		};
		$scope.validateChequeDetails = function(receiptNo){
			if ($scope.currentSearch.value === "instrumentNo" && (receiptNo.length < 6 || receiptNo.length > 9)) {
				return {message:collectionConstants.ERROR_MSG.CHEQUE_LENGTH};
			}
			return {status:"success"};
		};
		$scope.getChequeDetails = function(receiptNo,searchForm) {
			$scope.searchForm = searchForm;
			if ($scope.currentSearch.value === "select") {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.SELECT_OPTION);
				return;
			}
			
			if (!receiptNo) {
				return;
			}
			chequeBounceService.getReceiptDetails(($scope.currentSearch.value === 'instrumentNo'?'chequeNo':$scope.currentSearch.value), receiptNo).then(function(data) {
				if (!data || !data.length) {
					$scope.noRecordFound = true;
					$scope.receiptDetails = [];
				} else {
					$scope.noRecordFound = false;
					$scope.receiptDetails = [];
					if (data[0] && data[0].productType === 'DEALER') {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, constants.ERROR_MSG.taBounceError);
					} else if (data[0] && (data[0].modeOfPayment.toUpperCase().indexOf("CH") === -1)&&(data[0].modeOfPayment.toUpperCase().indexOf("DD") === -1)) {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_RECEIPT_CHEQUE_NO).result.then(function() {
						}, function() {
							return;
						});
					} else if (data[0] && data[0].status.toUpperCase() !== 'CHALLANED') {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, constants.ERROR_MSG.bounceChallanError);
					} else if (data[0] && data[0].instrumentDetail.status.toUpperCase() === 'BOUNCED') {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, constants.ERROR_MSG.bounceError);
					} else {
						$scope.receiptDetails = data[0];
						if (new Date($scope.receiptDetails.receiptEnteredTime) > new Date($scope.receiptDetails.instrumentDetail.instrumentDate)) {
							$scope.presentedConfig.minDate = $scope.bounceDateConfig.minDate = new Date($scope.receiptDetails.receiptEnteredTime);
						} else {
							$scope.presentedConfig.minDate = $scope.bounceDateConfig.minDate = new Date($scope.receiptDetails.instrumentDetail.instrumentDate);
						}
					}
				}
				$scope.totalRecord = data.totalCount ? data.totalCount : 0;
			});
		};
		$scope.updateChequeDetails = function(reasonId) {
			$scope.receiptDetails.instrumentDetail.bouncedReasonID = reasonId;
			$scope.receiptDetails.instrumentDetail.bouncedDate = $scope.bounceDateConfig.dateValue.toISOString();
			$scope.receiptDetails.instrumentDetail.presentedDate = $scope.presentedConfig.dateValue.toISOString();
			var param = {
				receiptDetails : angular.copy($scope.receiptDetails)
			};

			chequeBounceService.updateChequeDetails(param).then(function(data) {
				if (data.status === "success") {
					dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.SUCCESS_UPDATE).result.then(function() {
					}, function() {
						$scope.data.reason = '';
						$scope.data.receiptNo = '';
						$scope.receiptDetails = [];
					});

				} else {
						$scope.data.reason = '';
						$scope.data.receiptNo = '';
						$scope.receiptDetails = [];
				}
				$scope.currentSearch = {
					type : "Select",
					value : "select"
				};
				$scope.placeHolderAndMaxLength = "";
			});
		};
		$scope.getHoldCheques = function() {
			chequeBounceService.getOnHoldCheques($scope.maxRecordPerPage, $scope.data.currentPage, $scope.serviceParams.sort).then(function(data) {
				if (!data || !data.length) {
					$scope.noRecordFound = true;
					$scope.holdChequeDetails = [];
				} else {
					$scope.noRecordFound = false;
					$scope.holdChequeDetails = data;
				}
				$scope.totalRecord = data.totalCount ? data.totalCount : 0;
			});
		};

		if (bounce) {
			$scope.isManager = false;
			$state.$current.data.headerText = "Cheque/DD Bounce - Initiate";
			$scope.bounceReason = (!getBounceReason) ? {} : getBounceReason;
		} else {
			$state.$current.data.headerText = "Cheque/DD Bounce- Mark Unhold";
			$scope.isManager = true;
			$scope.getHoldCheques();
		}

		$scope.getUnHoldConfirmation = function() {
			dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.UNHOLD_CONFIRM).result.then(function() {
				$scope.unHoldAgreements();
			}, function() {
			});
		};

		$scope.unHoldAgreements = function() {
			var agreementList = [],isChequeDD = true;
			_.each($scope.holdChequeDetails, function(item) {
				if (item.selected && item.agreementNo) {
					if(item.cheque || item.dd){
						var data = {
								agreementNo:item.agreementNo,
								cheque : item.cheque ? item.cheque : false,
								DD : item.dd ? item.dd : false,
						};
						agreementList.push(data);
					}else{
						isChequeDD = false;
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.CHEQUE_DD_SELECT);
						return;
					}
				}
			});
		if(isChequeDD){
			chequeBounceService.unHoldAgreement(agreementList).then(function(data) {
					if (data.status === "success") {
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.SUCCESS_UPDATE).result.then(function() {
						}, function() {
							$scope.checkAll = false;
							$scope.isEnable = false;
							$scope.getHoldCheques();
						});
					} else {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.ERROR_MESSAGE);
					}
			});
			}
		};
		$scope.selectAll = function(event) {
			$scope.isEnable = event.target.checked;
			$scope.checkAll = event.target.checked;
			_.each($scope.holdChequeDetails, function(item) {
				item.selected = event.target.checked;
				if(item.isChequeCollectionOnHold && item.cheque)
					item.isChequeCollectionOnHold = false;
				if(item.isDDCollectionOnHold && item.dd)
					item.isDDCollectionOnHold = false;
				if(!item.selected){
					item.isChequeCollectionOnHold = true;
					item.isDDCollectionOnHold = true;
					item.cheque = cheque;
					item.dd = DD ;
				}else{
					cheque = item.cheque;
					DD = item.dd;
				}
			});
		};

		$scope.cancelAll = function(event) {
			$scope.checkAll = event;
			$scope.isEnable = event;
			_.each($scope.holdChequeDetails, function(item) {
				item.selected = event;
				if(item.isChequeCollectionOnHold && item.cheque)
					item.isChequeCollectionOnHold = false;
				if(item.isDDCollectionOnHold && item.dd)
					item.isDDCollectionOnHold = false;
				if(!item.selected){
					item.isChequeCollectionOnHold = true;
					item.isDDCollectionOnHold = true;
					item.cheque = cheque;
					item.dd = DD ;
				}else{
					cheque = item.cheque;
					DD = item.dd;
				}
			});
		};
		$scope.setCheckboxState = function(item) {
			$scope.checkAll = true;
			$scope.isEnable = false;
			_.each($scope.holdChequeDetails, function(item) {
				if (!item.selected) {
					$scope.checkAll = false;
				} else {
					$scope.isEnable = true;
				}
			});
			if(item.isChequeCollectionOnHold && item.cheque)
				item.isChequeCollectionOnHold = false;
			if(item.isDDCollectionOnHold && item.dd)
				item.isDDCollectionOnHold = false;
			if(!item.selected){
				item.isChequeCollectionOnHold = true;
				item.isDDCollectionOnHold = true;
				item.cheque = cheque;
				item.dd = DD ;
			}else{
				cheque = item.cheque;
				DD = item.dd;
			}
		};
		$scope.sortHandler = function() {
			$scope.isSort = !$scope.isSort;
			if (!$scope.isSort) {
				$scope.serviceParams.sort = "dsc";
			} else {
				$scope.serviceParams.sort = "asc";
			}
			chequeBounceService.getOnHoldCheques($scope.maxRecordPerPage, $scope.data.currentPage, $scope.serviceParams.sort).then(function(data) {
				$scope.holdChequeDetails = data;
			});
		};
		$scope.paginationHandler = function(pageNum) {
			$scope.data.currentPage = pageNum;
			$scope.getHoldCheques();
		};
		$scope.cancel = function() {
			dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.CHEQUEBOUNCE_CONFIRM).result.then(function() {
			$scope.data.reason = '';
				$scope.data.receiptNo = '';
				$scope.receiptDetails = [];
				$scope.currentSearch = {
					type : "Select",
					value : "select"
				};
				$scope.placeHolderAndMaxLength = "";
				$scope.searchForm.resetSubmited(true);
			}, function() {
		});
	};
	};
	chequeBounce.controller('chequeBounceController', [ '$scope', '$globalScope', 'chequeBounceService', '$state', 'dialogService', 'getBounceReason', 'appFactory', chequeBounceController ]);
	return chequeBounceController;
});