define([ 'require', 'collectionsApp', 'chequeBounceResolver' ], function(r, collectionsApp, chequeBounceResolver) {
	'use strict';
	var baseViewUrl = 'app/collections/chequeBounce/';
	var app = angular.module('chequeBounce', [ 'common', 'ui.router', 'collections' ]);

	var chequeBounce = function($stateProvider) {
		$stateProvider.state('collections.chequeBounce', {
			url : 'chequeBounce',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'chequeBounce.html',
					controller : 'chequeBounceController',
					resolve : chequeBounceResolver
				}
			},
			data : {
				'headerText' : 'Cheque Bounce',
				'stateActivity' : [ 'COL_MARKING_A_CHEQUE_BOUNCE', 'COL_HEHL_REMOVE_HOLD_ON_CHEQUE' ]
			}
		});
	};
	app.config([ '$stateProvider', chequeBounce ]);
	return app;
});
