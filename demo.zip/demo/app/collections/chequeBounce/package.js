define([], function() {
'use strict';
   require.config({//baseUrl:'/sales.chola.com/',
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'chequeBounce': 'app/collections/chequeBounce/chequeBounce',
          'chequeBounceController': 'app/collections/chequeBounce/controllers/chequeBounceController',
          'chequeBounceService': 'app/collections/chequeBounce/services/chequeBounceService',
          'chequeBounceResolver' : 'app/collections/chequeBounce/resolvers/chequeBounceResolver',
          'sharedPackage' : 'app/common/shared/package'
      },
      shim: {
    	  'chequeBounce': ['angular', 'angular-ui-router','chequeBounceResolver'],
          'chequeBounceController': ['chequeBounce','chequeBounceService']
      }
   });
   return function(callback){
	   requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs([ 'chequeBounceController' ], callback);
			});
		});
   };
});