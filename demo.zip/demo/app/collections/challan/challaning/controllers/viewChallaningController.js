/**
* Represents a Challaning Controller (for pop ups).
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challaning'],function(require,challaning){
	'use strict';
	/** Challaning Controller for pop ups
	* Pop up controller function for Challaning .
	* Dependency injection $scope,$modalInstance,data as parameters.
	*/
	var viewChallaningController = function($scope,$modalInstance,data,lazyModuleLoader){
		$scope.viewChallanModel = data.viewData;
		$scope.noRecords = $scope.viewChallanModel&&$scope.viewChallanModel.length?false:true;
		$scope.viewSelData = data.selectedValue;
		/**
		* Method to close the modal pop up
		*/
		$scope.close = function() {
			$modalInstance.dismiss();
		};
		
		$scope.modifyReceipts = function(item){
			lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:item.receiptNo,type:'offline'});
		};
	};
	challaning.controller('viewChallaningController',['$scope','$modalInstance','data','lazyModuleLoader',viewChallaningController]);
	return viewChallaningController;
});