/**
* Represents a Challaning List Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challaning','constants','collectionConstants'],function(r,challaning,constants,collectionConstants){
	'use strict';
	/**
	* Controller function for Teller challaning .
	* Dependency injection $scope,$modal,$rootScope,getTellerChallaningList,challaningService,
	* dialogService,lazyModuleLoader as parameters.
	*/
	var challaningListController = function($scope,$globalScope,$modal,$state,$rootScope,challaningService,dialogService,lazyModuleLoader){
					
		$scope.challanModel = challaningService.getchallanModel();//$scope.$parent.challanModel;
		var batches = [];
		$scope.searchParams = {};		
		$scope.paymentMode = constants.PAYMENT_MODES;
		$scope.agreementTypes = constants.AGREEMEMT_TYPES;
		$scope.productTypes = $rootScope.identity.productDetails;
		$scope.searchParams.selectedMode = 'CASH';
		$scope.searchParams.typeOfagr = 'Agreement';
		
		var totalChallan = function(){		
			if(!$scope.challanModel || !$scope.challanModel.length){
				$scope.noRecords = true;
				$scope.isHeadSelected = false;
				$scope.isDisabled = true;
			}		
			else{
				$scope.noRecords = false;
				$scope.isHeadSelected = true;
				$scope.selectHeadCheck(true);
			}		
			$scope.total = 0;
			_.each($scope.challanModel,function(element){
				if(!isNaN(element.batchAmount)){
					$scope.total += parseInt(element.batchAmount);
				}
			});
		};
		
		$scope.selectHeadCheck = function(state){
			if(typeof state === 'object'){
				state = state.target.checked;
			}
			$scope.isDisabled = !state;
			_.each($scope.challanModel,function(item){
				item.isSelected = state;
			});
		};
		
		$scope.setCheckboxState = function(){
			$scope.isHeadSelected = false;
			$scope.isDisabled = true;
			//data.isSelected = !data.isSelected;
			_.each($scope.challanModel, function(item){
				if(item.isSelected)
				{
					$scope.isDisabled = false;
					return;
				}
			});
		};
		
		totalChallan();
		
		/** View teller challaning Pop up click handler */
		$scope.viewChallaning = function(value){
			var selRowValue = value;
			challaningService.viewSelTellerChallan(selRowValue.batchID,selRowValue.mode,selRowValue.product).then(function(response){
				var viewList = response; 
				$modal.open({
					templateUrl: 'app/collections/challan/challaning/partials/viewChallaning.html',
					controller: 'viewChallaningController',
					size: 'lg',
					backdrop: 'static',
					windowClass: 'modal-custom',
					resolve: {
						data: function(){
							return {
								viewData: viewList,
								selectedValue: selRowValue
							};
						}
					}
				});
			});
		};

		var navigateToList = function(response){
			if(response.data && response.data[0].challanNo){
				var tempChallanArr = [];
				_.each($scope.challanModel,function(batch){
					if(response.data[0].batchIDs.indexOf(batch.batchID) === -1){
						tempChallanArr.push(batch);
					}						
				});
				challaningService.setchallanModel(angular.copy(tempChallanArr));
				dialogService.confirm(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,"Generated Challan Id is '"+response.data[0].challanNo+"'. Do you want to proceed with challan image upload?").result.then(function(){
					lazyModuleLoader.loadState('collections.challanGeneration',{challanId:response.data[0].challanNo});
				},function(){
					lazyModuleLoader.loadState('collections.challaning');
				});
			}
		};
		var proceedToChallan = function(){
			batches = [];
			var productType;
			_.each($scope.challanModel,function(item){
				if(item.isSelected){
					productType = item.product;
					batches.push(item.batchID);
				}
			});
			challaningService.generateChallan(batches).then(function(response){
				if (response && response.status === 'failed'){
					if(response.message.errors[0].errorCode === 'DCR-1009'){
						dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
							challaningService.deleteCashReceipt(productType).then(function(response){
								if(response){
									dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
										proceedToChallan();
									});
								}
							});
						}, function() {});						
					}
					else if(response.message.errors[0].errorCode === 'DCR-1010'){
						dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
							lazyModuleLoader.loadState('collections.dailyCashReport');					
						}, function() {});
					}else if(response.message.errors[0].errorCode === 'DCR-1013'){
						dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
					}else{
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,response.message.errors[0].message).result.then(function() {}, function() {});
					}
				}else if(response.data && response.data[0]){
					if(response.data[0].workflow.length && response.data[0].workflow[response.data[0].workflow.length-1].requestType === 'BACKDATEDCHALLANING' && response.data[0].workflow[response.data[0].workflow.length-1].workStatus === 'INITIATED'){
						dialogService.showAlert('Alert','Alert','Approval has been initiated for back dated challaning').result.then(function(){},function(){
							lazyModuleLoader.loadState('collections.challaning');
						});
					}
					else{
						navigateToList(response);
					}
				}
			});
		};
		
		/** GENERATE CHALLAN ID for selected list of batch ID's */
		$scope.generateChallan = function(){			
			// var selectedBatch = _.where($scope.challanModel,{isSelected:true});
			// var receiptNosArr = _.flatten(_.pluck(selectedBatch, 'referenceNo'));			
			// challaningService.getDelayNoticationDetails(receiptNosArr).then(function(response){
			// 	if(response.length>0){				
			// 		notifyDelay(response);
			// 	}else{
					checkPendingMemo();
				// }
			// });	
		};
		var notifyDelay = function(delayedReceipts){			
			$modal.open({
				templateUrl: 'app/collections/challan/challaning/partials/delayNotificationPopup.html',
				controller: 'delayNotificationController',
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {
					data: function(){
						return {
							delayedReceipts: delayedReceipts
						};
					}
				}
				}).result.then(function () {}, function (value) {
					if(value && value!="escape key press"){
						dialogService.showAlert(collectionConstants.REPO_MSG.SUCCESS, collectionConstants.REPO_MSG.SUCCESS, "Reason and Remarks successfully updated").result.then(function () {}, function () {
							checkPendingMemo();
						});
					}																					
				});	
		};
		var checkPendingMemo = function(){
			challaningService.getPendingMemo().then(function(response){
				if(response && response.length){
					var memoDetails = { initiatedMemo:[], approvedMemo:[], rejectedMemo:[], noMemo:[] };
					_.each(response,function(challan){
						var challanIndex = -1;
						if(challan.workflow.workStatus === 'APPROVED' && challan.workflow.requestType === 'NOMEMOUPLOAD'){
							memoDetails.approvedMemo.push(challan.physicalChallanNo);
						}else if(challan.workflow.workStatus === 'REJECTED' && challan.workflow.requestType === 'NOMEMOUPLOAD'){
							memoDetails.rejectedMemo.push(challan.physicalChallanNo);
						}else if(challan.workflow.workStatus === 'INITIATED' && challan.workflow.requestType === 'NOMEMOUPLOAD'){
							memoDetails.initiatedMemo.push(challan.physicalChallanNo);
						}else{
							memoDetails.noMemo.push(challan.physicalChallanNo);
						}
					});
					if(memoDetails.approvedMemo.length===response.length){						
						proceedToChallan();
						return;						
					}
					else if(memoDetails.noMemo.length){
						dialogService.confirm(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,'<div class="word-break-all">Memo not uploaded for the following challans - </br>'+memoDetails.noMemo.toString()+'. </br> Do you want to upload? </div>',false,true).result.then(function(){
							$globalScope.isPendingMemo = true;
							lazyModuleLoader.loadState('collections.imageUpload',{challanId:memoDetails.noMemo[0]});
						});
					}
					else if(memoDetails.rejectedMemo.length){
						dialogService.confirm(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,'<div class="word-break-all">Memo not uploaded for the following challans - </br>'+memoDetails.rejectedMemo.toString()+'. </br> Do you want to upload? </div>',false,true).result.then(function(){
							$globalScope.isPendingMemo = true;
							lazyModuleLoader.loadState('collections.imageUpload',{challanId:memoDetails.rejectedMemo[0]});
						});
					}
					else{
						dialogService.showAlert('Error','Error','<div class="word-break-all">No Memo Upload approval is pending for the following challan number(s) - </br>'+memoDetails.initiatedMemo.toString()+'</div>',true);
						return;
					}
					/*else if(memoDetails.approvedMemo.length && memoDetails.approvedMemo.length!=response.length){
						if(memoDetails.rejectedMemo.length){
							dialogService.confirm(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,'Memo not uploaded for the following challans - '+memoDetails.rejectedMemo.toString()+'. Do you want to upload?').result.then(function(){
								$globalScope.isPendingMemo = true;
								lazyModuleLoader.loadState('collections.imageUpload',{challanId:memoDetails.rejectedMemo[0]});
							});
						}
						else{
							dialogService.showAlert('Error','Error','Approval is pending for the following challans - '+memoDetails.initiatedMemo.toString());
							return;
						}
					}
					else{
						dialogService.confirm(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,'Memo not uploaded for the following challans - '+memoDetails.noMemo.toString()+'. Do you want to upload?').result.then(function(){
							$globalScope.isPendingMemo = true;
							lazyModuleLoader.loadState('collections.imageUpload',{challanId:memoDetails.noMemo[0]});
						});
					}*/
						
				}else{					
					proceedToChallan();					
				}
			});
		};
	};
	challaning.controller('challaningListController',['$scope','$globalScope','$modal','$state','$rootScope','challaningService','dialogService','lazyModuleLoader','authService',challaningListController]);
	return challaningListController;
});