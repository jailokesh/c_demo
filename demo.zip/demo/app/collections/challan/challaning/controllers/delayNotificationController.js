define(['require', 'challaning', 'constants', 'utility'], function(r, challaning, constants, utility) {
    'use strict';

    var delayNotificationController = function($scope, $state,challaningService, messageBus, dialogService, $modal, $modalInstance,data,$rootScope) {

        $scope.notification = {reason:'',remarks:''};
        $scope.remarksConstants = constants.DELAY_NOTIFICATION_REMARKS;       
        var delayReceipts = data.delayedReceipts;
        $scope.notificationData = _.pluck(delayReceipts,'receiptNo');
               
        $scope.close = function(val) {
            $modalInstance.dismiss(val);
        };
        $scope.handleRequest = function(notification){
            if ($scope.notification.remarks && $scope.notification.reason) {
                var postReqObj=[];
                _.each(data.delayedReceipts,function(item){
                    postReqObj.push(
                    {
                    "pendingWith": $rootScope.identity.userID,
                    "remarksData": [
                      {
                        "remarks": $scope.notification.remarks,
                        "reason": $scope.notification.reason,
                        "approvalType": "TELLER_CHALLANING",
                        "numberOfDays": item.numberOfDays,
                        "checkDate": new Date().toISOString()
                      }
                    ],
                    "branchID": JSON.parse(getCookie('selectedBranch')).branchID,
                    "pendingReceiptAmount": item.amountPaid,
                    "receiptNo": item.receiptNo
                  }
                  );
                });
                challaningService.updateDelayNotification(postReqObj).then(function(data){
                    if(data){
                        $scope.close(data);
                    }
                });
            } else {
                dialogService.showAlert('Error', "Error", "Enter Reason/Remarks for Dealy");
                return;
            }
        };       
    };

    challaning.controller('delayNotificationController', ['$scope', '$state', 'challaningService', 'messageBus', 'dialogService','$modal', '$modalInstance','data','$rootScope', delayNotificationController]);
    return delayNotificationController;
});
