/**
* Represents a Challaning Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challaning','collectionConstants'],function(r,challaning,collectionConstants){
	'use strict';
	/**
	* Controller function for Teller challaning .
	* Dependency injection $scope,$modal,$rootScope,getTellerChallaningList,challaningService,
	* dialogService,lazyModuleLoader as parameters.
	*/
	var challaningController = function($scope,$modal,$state,$rootScope,getTellerChallaningList,challaningService,appFactory){
		
		var groupReceipts = [];
		var checkPervious ;
		var checkUpdate;
		var mode;
		$scope.productTypes = angular.copy($rootScope.identity.productDetails);
		if(appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.TA_RECEIPT))
			$scope.productTypes.push({value:"DEALER"});
		$scope.productType = $rootScope.productType;
		if(!$rootScope.isClickedViaMenu)
		{
			if($rootScope.filterValue==='chequesForDisposition'){
				mode = 'CHEQUE,CHEQUE-NON-MICR';
			}
			$rootScope.isClickedViaMenu = true;
		}			
		var updateGroupArray = function(item)
		{
			var getGroupChallen = [];
			getGroupChallen.push(item);
			var obj = {};
			obj.mode = item.mode;
			obj.agreement = item.hasAgreementReceipts ? "Agreement":"Non Agreement";
			obj.batches = 1;
			obj.receipts = item.referenceNo.length;
			obj.totalAmount = item.batchAmount;			
			obj.pushData = getGroupChallen;
			groupReceipts.push(obj);
		};
		var init = function(challaningList){
			_.each(challaningList.data,function(item){
				checkPervious = _.findWhere(groupReceipts,{mode:item.mode});			
				if(!checkPervious){
					updateGroupArray(item);
				}
				else
				{				
					checkUpdate = _.where(groupReceipts,{mode: item.mode, agreement: item.hasAgreementReceipts ? "Agreement":"Non Agreement"});//_.findWhere(groupReceipts,{mode:item.mode});
					if(checkUpdate.length > 0)
					{
						var check = checkUpdate[0].pushData;
						check.push(item);
						checkUpdate[0].batches = checkUpdate[0].batches+1;
						checkUpdate[0].receipts = checkUpdate[0].receipts+item.referenceNo.length;
						checkUpdate[0].totalAmount = checkUpdate[0].totalAmount+item.batchAmount;
						checkUpdate[0].pushData = check;
					}
					else{
						updateGroupArray(item);				
					}
				}
			});
			$scope.headerCount = challaningList.meta;
			$scope.groupChallen = _.sortBy(groupReceipts, 'mode') ? _.sortBy(groupReceipts, 'mode') : [] ;		
		};		
		init(getTellerChallaningList);				
		
		$scope.rowClickedHandler = function(item){			
			//$scope.challanModel = item?item : [];
			var data = item?item : [];
			challaningService.setchallanModel(data);
			$state.go('collections.challaningList');
		};
		
		$scope.pendingReceipts = function(type){
			$scope.productType = type;
			if(type !== 'DEALER'){
				$rootScope.productType = type;
			}
			challaningService.getFilterTellerChallaningList(type,mode).then(function(response){
				groupReceipts = [];
				init(response?response:[]);				
			});
		};					
	};
	challaning.controller('challaningController',['$scope','$modal','$state','$rootScope','getTellerChallaningList','challaningService','appFactory',challaningController]);
	return challaningController;
});