/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','challaning'], function(r,challaning) {
	'use strict';
	
	/**
	 * Pop up controller for My eReceiopt Swap .
	*/
     var backDatedChallanApproval = function($scope,$modalInstance,data,challaningService,$state) {
    	$scope.data = {
    		challanNo : data.challanNo
    	};
 		
    	$scope.close = function(){
    		$modalInstance.dismiss();
    		$state.go('collections.challaning');
    	};
    	
    	$scope.reInitiate = function(remarks){
    		challaningService.reInitiateBDChallanApproval(data.challanNo,remarks).then(function(response){
    			if(response){
    				$scope.close();
    			}
    		});
    	};
     };
     challaning.controller('backDatedChallanApproval',['$scope','$modalInstance','data','challaningService','$state',backDatedChallanApproval]);
	return backDatedChallanApproval;
	});