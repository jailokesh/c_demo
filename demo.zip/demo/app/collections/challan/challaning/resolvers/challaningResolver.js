define([],function(){
	'use strict';
	/**
	 * Represents a Challaning Resolver. 
	 * Dependency injection challaningservice,$rootScope as parameters.
	 */
	return {
		/**
		 * Returns the teller challaning list
		 */
		getTellerChallaningList:['challaningService','$rootScope',function(challaningService,$rootScope){
			var mode;
			if(!$rootScope.isClickedViaMenu&&$rootScope.filterValue==='chequesForDisposition'){
				mode='CHEQUE,CHEQUE-NON-MICR';
			}
			return challaningService.getFilterTellerChallaningList($rootScope.productType,mode).then(function(data){
				return data;
			});
		}]		
	};
});