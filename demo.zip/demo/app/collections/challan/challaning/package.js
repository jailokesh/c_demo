define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'challaning': 'app/collections/challan/challaning/challaning',
			'challaningService': 'app/collections/challan/challaning/services/challaningService',
			'challaningController': 'app/collections/challan/challaning/controllers/challaningController',
			'challaningListController': 'app/collections/challan/challaning/controllers/challaningListController',
			'challaningResolver': 'app/collections/challan/challaning/resolvers/challaningResolver',
			'viewChallaningController': 'app/collections/challan/challaning/controllers/viewChallaningController',
			'backDatedChallanApproval': 'app/collections/challan/challaning/controllers/backDatedChallanApproval',
			'delayNotificationController' :'app/collections/challan/challaning/controllers/delayNotificationController' 	
		},
		shim: {
			'challaning': ['angular', 'angular-ui-router','challaningResolver'],
			'challaningController': ['challaningService'],
			'challaningListController': ['challaningService'],
			'viewChallaningController': ['challaningService'],
			'backDatedChallanApproval': ['challaningService'],
			'challaningService' : ['challaning'],
			'delayNotificationController':['challaningService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['challaningController','viewChallaningController','challaningListController','backDatedChallanApproval','delayNotificationController'],callback);
			});
		});
	};
});