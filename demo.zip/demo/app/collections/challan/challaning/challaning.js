define(['require','collectionsApp','challaningResolver'],function(require,collectionsApp,challaningResolver){
	'use strict';
	/**
	* Contains the Challaning routing information.
	* Create and return the Challaning module.
	*/
	var baseViewUrl = 'app/collections/challan/challaning/';
	var challaningQueue = {
		name: 'collections.challaning',
		url: '/challaning',
		views: {
			'mainContent': {
				templateUrl: baseViewUrl + 'challaning.html',
				controller: 'challaningController',
				resolve: challaningResolver
			}
		},
		data: {'headerText' : 'Challaning',
				'stateActivity' : ['COL_TELLER_CHALLANING','COL_VIEW_PENDING_BATCHES']
			  }
	};
	var challaningList = {
			name: 'collections.challaningList',
			url: '/challaningList',
			views: {
				'mainContent': {
					templateUrl: baseViewUrl + 'partials/challaningList.html',
					controller: 'challaningListController'				
				}
			},
			data: {'headerText' : 'Challaning',
				   'backState': 'collections.challaning',
				   'stateActivity' : ['COL_TELLER_CHALLANING','COL_VIEW_PENDING_BATCHES']
				  }
		};
	/**
	* Contains the challaning configuration details.
	*/
	var challaningConfiguration = function($stateProvider){
		$stateProvider.state(challaningQueue).state(challaningList);
	};		
	
	return angular.module('challaning',['ui.router','collections']).config(['$stateProvider','$urlRouterProvider', challaningConfiguration]);
});
