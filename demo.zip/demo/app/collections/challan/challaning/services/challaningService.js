/**
 * Represents a challaning Service.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','challaning','collectionServiceURLs'], function(require,challaning, collectionServiceURLs) {
'use strict';

/**
 * Represents a challaning Service.
 * challaning Service function
 * Dependency injection $q,restAngularProxy,restProxy as a parameter.
 */
var challaningService = function($q,restProxy,$rootScope,$modal,environmentConfig){
	/** Returns getTellerchallaningList
	 *  on select of paymenttype, product type, agreement type */
	this.getFilterTellerChallaningList = function(prodType,mode){
		var queryParams = {
			//	mode:mode.toUpperCase(),
				product:prodType,
			//	agreement:agreement,
				view:'getPendingBatches',
				userrole:$rootScope.identity.hierarchyName,
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID
		};
		if(mode){
			queryParams.mode = mode;
		}
		collectionServiceURLs.challanServices.GET_FILTER_TELLER_CHALLANING.queryParams = queryParams;
		collectionServiceURLs.challanServices.GET_FILTER_TELLER_CHALLANING.urlParams = {};
		return restProxy.get(collectionServiceURLs.challanServices.GET_FILTER_TELLER_CHALLANING).then(function(data){ 
			return data;
		});	
	};
	
	
	/** Returns view teller challan on select of payment */
	this.viewSelTellerChallan = function(batchId,mode,product){
		collectionServiceURLs.batchingServices.GET_BATCHDETAILS.queryParams = {
				userrole:($rootScope.identity.hierarchyName),
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
				mode:mode,
				product:product
		};
		collectionServiceURLs.batchingServices.GET_BATCHDETAILS.urlParams = {
				batchID:batchId
		};
		return restProxy.get(collectionServiceURLs.batchingServices.GET_BATCHDETAILS).then(function(data){
			return data.data;    					
		});  	
	};
	
	/** GENERATE CHALLAN ID for selected list of batch ID's */
	this.generateChallan = function(batchIDs){
		collectionServiceURLs.challanServices.GENERATE_CHALLAN.queryParams = {
				userrole:($rootScope.identity.hierarchyName).toUpperCase(),
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
				view:'generateChallan',			
				source:'browser'
		};

		if($rootScope.identity.standByTeller){
			collectionServiceURLs.challanServices.GENERATE_CHALLAN.queryParams.tellerID = ($rootScope.identity.standByTeller.tellerID) ? $rootScope.identity.standByTeller.tellerID  :  $rootScope.identity.standByTeller.standByTellerID;
		}

		if(environmentConfig.isDCR){
			collectionServiceURLs.challanServices.GENERATE_CHALLAN.queryParams.dcr = true;
		}
		collectionServiceURLs.challanServices.GENERATE_CHALLAN.notify = false;
		collectionServiceURLs.challanServices.GENERATE_CHALLAN.urlParams = {};
		return restProxy.save('POST',collectionServiceURLs.challanServices.GENERATE_CHALLAN,{batchIDs:batchIDs}).then(function(data){ 
			if(data.status === "failed" && data.message.errors[0].errorCode === "CHALN-1022"){
				$modal.open({
					templateUrl: 'app/collections/challan/challaning/partials/reInitiateApproval.html',
					controller: 'backDatedChallanApproval',
					size : 'md',
					backdrop : 'static' ,
					windowClass : 'modal-custom',
					resolve: {
						data: function() {
		                    return  {challanNo:data.message.errors[0].data.value};
		                }
					}
				});
			}else if(data.status === "failed"){
				return data;
			}
			if(data && data.data){
				return data;
			}
			else{
				return [];
			}
		});	
	};
	
	this.getPendingMemo = function(){
		collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.queryParams = {
				userrole:($rootScope.identity.hierarchyName).toUpperCase(),
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
				view:'getPendingChallansForMemo'
		};
		collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.urlParams = {};
		return restProxy.get(collectionServiceURLs.challanServices.GET_PENDINGCHALLANS).then(function(data){
			return data.data;    					
		}); 
	};
	
	this.deleteCashReceipt = function(productType){
		var queryParams = {
				'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
				'product' : productType
		};
		
		collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
		return restProxy.save('DELETE',collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
			return response.data;
		});	
	};
	
	this.reInitiateBDChallanApproval = function(challanNo,comments){
		collectionServiceURLs.challanServices.SUBMIT_CHALLAN.urlParams = {challanNo:challanNo};
		collectionServiceURLs.challanServices.SUBMIT_CHALLAN.queryParams = {
				view : "initiateApproval",
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
		};
		
		return restProxy.save('PUT',collectionServiceURLs.challanServices.SUBMIT_CHALLAN,{comments:comments}).then(function(data){
			return data.data;
		});
	};
	
	var challanModel;
	this.setchallanModel = function(obj){
		challanModel =  obj;
	};
	this.getchallanModel = function(){
		return challanModel;
	};
	this.getDelayNoticationDetails = function(receiptArray){
		collectionServiceURLs.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS.queryParams={
			'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
			'view':"BROWSERRECEIPTSCHECK"
		};
		return restProxy.save('POST',collectionServiceURLs.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS,{"receiptNos":receiptArray}).then(function(data){
			return data.data;
		});
	};
	this.updateDelayNotification = function(receiptArray){
		collectionServiceURLs.challanServices.POST_DELAY_REASON.queryParams={
			'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
			'view':"POSTRECEIPTSREASON"
		};
		return restProxy.save('POST',collectionServiceURLs.challanServices.POST_DELAY_REASON,receiptArray).then(function(data){
			return data.data;
		});
	};
};

challaning.service('challaningService',['$q','restProxy','$rootScope','$modal','environmentConfig',challaningService]);
return challaningService;
});