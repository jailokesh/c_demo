/**
* Represents Batching Lost Tablet Service.
* Dependency injection $q,restProxy,authService as parameters.
*/
define(['require','batchingLostTablet','collectionServiceURLs'],function(require,batchingLostTablet,collectionServiceURL){
	'use strict';
	var batchingLostTabletService = function($q,$rootScope,restProxy){
		/**
		* Method to batch the receipts of CFE
		*/
		this.batchAll = function(cfeId,product,reqObj,selectedreceipts){
			var url = {};
			var method = '';
			if(reqObj){
				method = 'PUT';
				url = collectionServiceURL.batchingServices.HANDSOFF_BATCHES;
				url.queryParams = {
						view : 'handsOffBatches'
				};
			}
			else{
				method = 'POST';
				url = collectionServiceURL.batchingServices.BATCHALL_RECEIPTS;				
				reqObj = {
							collectionAgentID : cfeId,
							product : product,
							receiptNos : selectedreceipts
					};
				url.queryParams = {
						source : 'lostTablets'
				};
			}
			url.queryParams.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			url.queryParams.userrole = ($rootScope.identity.hierarchyName);
			return restProxy.save(method,url,reqObj).then(function(data){
				return data.data;    					
			});    	    
		};
		/**
		* Method to fetch un-batched receipts
		*/
		this.getPendingReceipts = function(mode,isAgreement,productType,userID) {
			var url = {};
			if(mode === 'RPDC' || mode === 'PDD'){
				url = collectionServiceURL.batchingServices.GET_PENDINGACKNOWLEDGEMENTS;
				url.queryParams = {
						collectionAgentID : userID,
						view : 'getPendingReferences',
						product : productType,
						userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						source : 'pending',
						mode : mode,
						viewType : "lostTablet"
				};
			}
			else{
				url = collectionServiceURL.batchingServices.GET_RECEIPTDETAILS;
				url.queryParams = {
						collectionAgentID : userID,
						view : 'getPendingReferences',
						product : productType,
						userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						source : 'pending',
						mode : mode ,
						agreement : isAgreement,
						viewType : "lostTablet"
				};
			}
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data.data;    					
			}); 
		};
		
		this.getBatchedReceipts = function(mode,batchID,sortBy,sortVal,product) { 
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams = {
					userrole:($rootScope.identity.hierarchyName).toUpperCase(),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:mode,
					product:product
			};
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchID
			};
			if(sortBy && sortBy.length){
				collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams.sortBy = sortBy;
				collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams.asc = sortVal;
			}
			return restProxy.get(collectionServiceURL.batchingServices.GET_BATCHDETAILS).then(function(data){
				return data.data;    					
			});    	    	
		};
		
		this.getReceiptsToBeBatched = function(cfeId,product,isBatched){
			var url = {};
			if(isBatched){
				url = collectionServiceURL.batchingServices.GET_BATCHEDRECEIPTS;
				url.queryParams = {
						product : product,
						view:'lostTabletsHandsOff',
						userrole:($rootScope.identity.hierarchyName),
						userbranch:JSON.parse(getCookie('selectedBranch')).branchID
				};
			}
			else{
				url = collectionServiceURL.batchingServices.GET_RECEIPTSTOBEBATCHED;
				url.queryParams = {
						product : product,
						userrole : ($rootScope.identity.hierarchyName),
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						view:'lostTabletsBatching'
				};
			}
			if(cfeId){
				url.queryParams.collectionAgentID = cfeId;
			}
			return restProxy.get(url).then(function(data){
				return data.data;    					
			});    	
		};
	};
	batchingLostTablet.service('batchingLostTabletService',['$q','$rootScope','restProxy','authService',batchingLostTabletService]);
	return batchingLostTabletService;
});
