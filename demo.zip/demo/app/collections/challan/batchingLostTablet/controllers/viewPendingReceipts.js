/**
 * Represents batching pop up Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','batchingLostTablet','collectionConstants'],function(r,batchingLostTablet,collectionConstants){
	'use strict';
	/**
	* Batching Popup Controller function.
	* Dependency $scope,$modalInstance,data as parameters.
	*/
	var viewPendingReceipts = function($scope,$modalInstance,$rootScope,data,batchingLostTabletService){
		$scope.isAmt = $scope.isDate = true;
		$scope.disableSubmit = true;
		$scope.calculateTotal = function(){
			var data = _.where($scope.data,{selected:true});
			$scope.totalAmt = 0;
			_.each(data, function(item) {		
				$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
			});
		};
		$scope.selectAllCheckbox = function(check){
			_.each($scope.data,function(item){
				if(check){
					item.selected = true;
					$scope.disableSubmit = false;
				}else{
					item.selected = false;
					$scope.disableSubmit = true;
				}				
			});
			$scope.calculateTotal();
		};
		
		$scope.selectCheckbox = function(check){
			var data = _.where($scope.data,{selected:true});
			if(data.length > 0){
				$scope.disableSubmit = false;
			}else{
				$scope.disableSubmit = true;
			}
			if(data.length === $scope.data.length){
				$scope.selecteAll.all = true;				
			}else{
				$scope.selecteAll.all = false;				
			}
			$scope.calculateTotal();
		};
		var init = function(){
			$scope.data = data.data;
			$scope.batchId = data.batchId;
			$scope.selecteAll = {all : false};
			$scope.productType = data.productType;
			$scope.noRecords = (!$scope.data||!$scope.data.length)?true:false;
			$scope.mode = data.mode;
			$scope.totalAmt = 0;			
			$scope.source = data.source;
			$scope.collectionAgentID = data.collectionAgentID;
			$scope.receiptMode = false;		
			_.each($scope.data, function(item) {
				//$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
				if(item.pddAcknowledgementType && !isNaN(parseInt(item.pddAcknowledgementType))){
					var pddObj = _.findWhere(collectionConstants.REPAY_MODES,{documentID:parseInt(item.pddAcknowledgementType)});
					var pddType = pddObj.id == 'RC' ? pddObj.id : pddObj.id.toLowerCase();
					item.pddImage = {
							imageRef : item[pddType+'Detail'] ? item[pddType+'Detail'].imageRef : {}
					};
				}
			});			
			if($scope.mode === "PDD" || $scope.mode === "RPDC"){
				$scope.selectAllCheckbox(true);
			}
			$scope.selectCheckbox();
		};
		init();
		/**
		Method to close the pop up window
		*/		
		$scope.close = function(data){
			$modalInstance.close(data);
		};
		$scope.dismiss = function(){
			$modalInstance.dismiss();
		};
		/**
		Method to sort content by Date/Amount/Mode
		*/
		$scope.sortHandler = function(sortBy,sortVal){
			if(!$scope.batchId){
				return;
			}
			batchingLostTabletService.getBatchedReceipts($scope.mode,$scope.batchId,sortBy,sortVal,$scope.productType).then(function(data){
				if(data && data.length){
					$scope.data = data;
					$scope.noRecords = false;
					$scope.totalAmt = 0;
					_.each($scope.data, function(item) {
						$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
					});
				}
				else{
					$scope.data = [];
					$scope.noRecords = true;					
				}
			});
		};
		
		$scope.batchReceipts = function()
		{	
			var selectedDate = _.where($scope.data, {selected:true});
			var receiptNo = _.pluck(selectedDate, 'receiptNo');
			var pddAcknowledgementNo = _.pluck(selectedDate, 'pddAcknowledgementNo');
			var selectedreceipts = 	typeof receiptNo[0] === "undefined" ? pddAcknowledgementNo : receiptNo;		
			batchingLostTabletService.batchAll($scope.collectionAgentID,$scope.productType,'',selectedreceipts).then(function(data){
				if(data && data.length){
					$scope.close(data);											
				}
				else{
					$scope.dismiss();
				}
			});            		 
		};

	};
	batchingLostTablet.controller('viewPendingReceipts',['$scope','$modalInstance','$rootScope','data','batchingLostTabletService',viewPendingReceipts]);
	return viewPendingReceipts;
});