/**
 * Represents batching lost tablet Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','batchingLostTablet','collectionConstants'],function(require,batchingLostTablet,collectionConstants){
	'use strict';
	/**
	* Batching Lost Tablet Controller function.
	* Dependency $scope,$modal,$rootScope,dialogService,authService,batchingLostTabletService. 
	*/
	var batchingLostTabletController = function($scope,$modal,$rootScope,dialogService,batchingLostTabletService){
		var cfeId = '';
		var init = function(){
			$scope.noRecords = false;
			$scope.checkAll = false;
			$scope.productTypes = $rootScope.identity.productDetails;
			$scope.productType = $rootScope.productType;
			$scope.enableBatch = false;
			$scope.isCFE = false;
		}; 
		init();
		
		$scope.tabChangeHandler = function(tab){
			init();
			$scope.isBatched = tab.title==='Batched'?true:false;
		};
		/**
		Method to batch all the cfe generated receipts
		*/
		$scope.batchAll = function(){
			var noOfReceipts = 0;
			var totAmount = 0;
			var batchObj = {
					batchIDs:[]
				};
			cfeId = $scope.cfeId?$scope.cfeId:'';
			if($scope.isBatched){
				cfeId = cfeId?cfeId:$rootScope.identity.userID;
				var handsoffArr = [];
				_.each($scope.batchInfo,function(item){
					if(item.selected){
						batchObj.batchIDs.push(item.batchID);
						handsoffArr.push(item);
						noOfReceipts += item.referenceNo.length;
						totAmount += item.batchAmount && item.mode !== 'CANCELLED' ? item.batchAmount : 0;
					}
				});
			}
			else{
				if(!cfeId){
					_.each($scope.batchInfo,function(item){
						if(item.selected && item.collectionAgentID){
							cfeId = item.collectionAgentID;
							return;
						}
					});
				}
				batchObj = '';
			}			
			batchingLostTabletService.batchAll(cfeId,$scope.productType,batchObj).then(function(data){
				if(data && data.length){
					if($scope.isBatched){
						dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING,collectionConstants.POPUP_HEADER.MESSAGE_STRING,batchObj.batchIDs.length+' batch(es) with '+noOfReceipts+' receipt(s) for an amount of Rs.'+totAmount+' are handed over successfully').result.then(function(){},function(){
							$modal.open({
				                templateUrl: 'app/collections/challan/batchingLostTablet/partials/printBatches.html',
				                controller: ['$scope','$modalInstance','data',function($scope,$modalInstance,data){
			                    	$scope.batches = data.batches;	                   	
			                    	$scope.close = function(){	  
				            			$modalInstance.close();
				            		};
			                    }],
				                backdrop : 'static' ,
				                size : 'lg',
								resolve: {
				                    data: function() {
				                        return {
				                        	batches : handsoffArr
				                        };
				                    }
				                }
				            }).result.then(function(){
				            	if($scope.cfeId){
				            		$scope.getReceiptsToBeBatched($scope.cfeId);
				            	}
								else{
									$scope.getReceiptsToBeBatched('all');
								}
				            });							
						});
						
					}
					else{
						$scope.batchDetails = data;
						_.each($scope.batchInfo,function(item){
							if(!$scope.cfeId&&item.collectionAgentID!==cfeId){
								return;
							}
							var batchObj = {};
							var searchParams = {
								mode:item.modeOfPayment,
								product:item.productType
							};
							if(item.modeOfPayment !== 'RPDC' && item.modeOfPayment !== 'PDD'){
								searchParams.hasAgreementReceipts = item.isAgreementReceipt;
							}
							batchObj = _.findWhere($scope.batchDetails,searchParams);
							if(batchObj && batchObj.batchID){
								item.batchID = batchObj.batchID;
							}
						});     
						$scope.enableBatch = false;
					}
				}
			});            		 
		};
		/**
		Method to select/deselect all the rows of the batch table
		*/
		$scope.selectAll = function(event){
			$scope.enableBatch = event.target.checked;
			_.each($scope.batchInfo,function(item){
				item.selected = event.target.checked;
			});
		};
		/**
		Method to select/deselect all the receipts of the chosen CFE
		*/
		$scope.checkAllCFEs = function(cfeObj){
			if($scope.isBatched){
				$scope.enableBatch = false;
				$scope.checkAll = false;
				//cfeObj.selected = !cfeObj.selected;
				_.each($scope.batchInfo,function(item){
					if(item.selected){
						$scope.enableBatch = true;
					}
				});
				return;
			}
			$scope.enableBatch = cfeObj.selected;
			_.each($scope.batchInfo,function(item){
				if(item.collectionAgentID===cfeObj.collectionAgentID&&!item.batchID){
					item.selected = cfeObj.selected;
				}
				else{
					item.selected = false;
				}
			});
		};
		/**
		Method to fetch all the un-batched receipts of CFE
		*/
		$scope.getReceiptsToBeBatched = function(cfeId){
			if(!cfeId||!$scope.productType){
				return;
			}
			if(cfeId==='all'){
				$scope.cfeId = '';
				$scope.enableBatch = false;
				$scope.isCFE = false;
			}
			else{
				$scope.enableBatch = !$scope.isBatched;
				$scope.cfeId = cfeId;
				$scope.isCFE = true;
			}
			batchingLostTabletService.getReceiptsToBeBatched($scope.cfeId,$scope.productType,$scope.isBatched).then(function(data){
				if(data&&data.length){
					$scope.batchInfo = data; 
					$scope.totalAmount = 0;
					$scope.noRecords = false;
					_.each($scope.batchInfo,function(item){
						if($scope.isBatched){
							$scope.totalAmount += item.batchAmount && item.mode !== "CANCELLED" ? item.batchAmount:0;
							item.isAgreement = item.hasAgreementReceipts?'Agreement':'Non-Agreement';
						}
						else{
							$scope.totalAmount += item.amountPaid?item.amountPaid:0;
							item.isAgreement = item.isAgreementReceipt?'Agreement':'Non-Agreement';
						}
						if(item.pddAcknowledgementType||item.mode==='PDD'||item.mode==='RPDC')
						{
							item.modeOfPayment = item.mode?item.mode:isNaN(parseInt(item.pddAcknowledgementType))?'RPDC':'PDD';
							item.isAgreement = '-';
							//item.amountPaid = item._id.pddAcknowledgementType!=='RPDC'?'-':item.chequeValue;
							//item.batchAmount = '-';
						}
					});
				}
				else
				{
					$scope.batchInfo = {};
					$scope.noRecords = true;
				}
				$scope.checkAll = false;
			});   
		};
		/**
		Method to view the receipt details of the selected batch
		*/
		$scope.viewTellerReceipt = function(mode,batchID,productType){
			batchingLostTabletService.getBatchedReceipts(mode,batchID,'receiptDateTime',true,productType).then(function(data){
				$modal.open({
					templateUrl : 'app/collections/challan/batchingLostTablet/partials/viewBatchDetails.html',
					controller : 'popupController',        				 	
					size : 'lg',
					backdrop : 'static',
					resolve : {
					data : function(){
						return {
							data : data,
							batchId : batchID,
							productType : productType,
							mode : mode
							};
						}
					}
				});						
			});
		};
		/**
		Method to sort batches based on Amount
		*/
		$scope.sortHandler = function(fieldStr){
			var modelName = '';
			modelName = fieldStr==='product'?'isAmt':'isInst';
			$scope[modelName] = $scope[modelName]?false:true;
		};

		$scope.batchingTabs = [
			{title:'To be batched',template:'app/collections/challan/batchingLostTablet/partials/batchingPartial.html',active:true,isSelected:true},
			{title:'Batched',template:'app/collections/challan/batchingLostTablet/partials/batchingPartial.html',active:false,isSelected:false}                
		];
		
		$scope.viewAllReceipt = function(batch){
			var mode, productType;
			var isAgreement = (batch.isAgreement === 'Agreement');
			if($scope.isBatched){
				mode = batch.mode;
				productType = batch.product;
			}
			else{
				mode = batch.modeOfPayment;
				productType = batch.productType;
			}
			batchingLostTabletService.getPendingReceipts(mode,isAgreement,productType,batch.cfeDetails.cfeId).then(function(data){
				$modal.open({
					templateUrl:'app/collections/challan/batching/partials/viewBatchDetails.html',
					controller:'viewPendingReceipts',        				 	
					size:'lg',
					backdrop:'static',
					resolve:{
						data:function() {
							return {
								data:data,
								productType:productType,
								mode:mode,
								source:batch.receiptSource,
								collectionAgentID : batch.collectionAgentID
							};
						}
					}
				}).result.then(function(data){
					dialogService.showAlert('Alert', 'Success', 'Batch ('+data[0].batchID+') has been generated successfully.').result.then(
							function(){},function(){								
								$scope.getReceiptsToBeBatched('all');														
							}
					);		
				},function(data){				
				});

			});
		};
	};
	batchingLostTablet.controller('batchingLostTabletController',['$scope','$modal','$rootScope','dialogService','batchingLostTabletService',batchingLostTabletController]);
	return batchingLostTabletController;
});