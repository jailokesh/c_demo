/**
 * Represents batching lost tablet pop up Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','batchingLostTablet','collectionConstants'], function(r,batchingLostTablet,collectionConstants){
	'use strict';
	/**
	* Batching Lost Tablet Popup Controller function.
	* Dependency $scope,$modalInstance,data. 
	*/
	var popupController = function($scope,$modalInstance,data){	
		$scope.isAmt = $scope.isDate = true;
		var init = function(){
			$scope.data = data.data;
			$scope.batchId = data.batchId;
			$scope.noRecords = (!$scope.data||!$scope.data.length)?true:false;
			$scope.productType = data.productType;
			$scope.mode = data.mode;
			$scope.totalAmt = 0;
			_.each($scope.data,function(item){
				$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
				if(item.pddAcknowledgementType && !isNaN(parseInt(item.pddAcknowledgementType))){
					var pddObj = _.findWhere(collectionConstants.REPAY_MODES,{documentID:parseInt(item.pddAcknowledgementType)});
					var pddType = pddObj.id == 'RC' ? pddObj.id : pddObj.id.toLowerCase();
					item.pddImage = {
							imageRef : item[pddType+'Detail'] ? item[pddType+'Detail'].imageRef : {}
					};
				}
			});
		};
		init();
		/**
		Method to close the pop up window
		*/
		$scope.close = function(){
			$modalInstance.dismiss();
		};
		/**
		Method to sort content by Date/Amount/Mode
		*/
		$scope.sortHandler = function(fieldStr){
			var model = '';
			if(fieldStr==='instDate'){
				model = 'isDate';
			}
			else if(fieldStr==='amount'){
				model = 'isAmt';
			}
			else if(fieldStr==='mode'){
				model = 'isMode';
			}
			$scope[model]=$scope[model]?false:true;
		};
	};
	batchingLostTablet.controller('popupController',['$scope','$modalInstance','data',popupController]);
	return popupController;
});