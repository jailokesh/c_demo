define(['require','collectionsApp'],function(require,collectionsApp){
	'use strict';
	/**
	* Contains the batching lost tablet module's routing information.
	* Create and return the batching lost tablet module.
	*/
	var baseViewUrl = 'app/collections/challan/batchingLostTablet/';
	var app = angular.module('batchingLostTablet',['ui.router','collections']);

	var batchingLostTablet = {
		name : 'collections.batchingLostTablet',
		url : '/batchingLostTablet',
		views: {
			'mainContent' : {
				templateUrl : baseViewUrl+'batchingLostTablet.html',
				controller : 'batchingLostTabletController'
			}
		},
		data : {'headerText':'Batching - Lost Tablets',
				'stateActivity' : ['COL_LOST_TABLET_BATCHING']
			}
	};
	/**
	* Contains the batching lost tablet module's configuration details.
	*/
	var batchingLostTabletConfiguration = function($stateProvider){
		$stateProvider.state(batchingLostTablet);
	};

	app.config(['$stateProvider','$urlRouterProvider',batchingLostTabletConfiguration]);
	return app;
});
