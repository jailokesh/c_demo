define([],function(){
	'use strict';
	require.config({
		paths : {
			'collectionsApp':'app/collections/collections',
			'batchingLostTablet' : 'app/collections/challan/batchingLostTablet/batchingLostTablet',
			'batchingLostTabletService' : 'app/collections/challan/batchingLostTablet/services/batchingLostTabletService',
			'batchingLostTabletController' : 'app/collections/challan/batchingLostTablet/controllers/batchingLostTabletController',
			'lostTabletPopupController' : 'app/collections/challan/batchingLostTablet/controllers/lostTabletPopupController',
			'viewPendingReceipts' : 'app/collections/challan/batchingLostTablet/controllers/viewPendingReceipts'
		},
		shim : {
			'batchingLostTablet' : ['angular','angular-ui-router'],
			'batchingLostTabletController' : ['batchingLostTablet','batchingLostTabletService'],
			'lostTabletPopupController' : ['batchingLostTabletService'],
			'viewPendingReceipts' : ['batchingLostTabletService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['batchingLostTabletController','lostTabletPopupController','viewPendingReceipts'],callback);
			});
		});
	};
});