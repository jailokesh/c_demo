/**
* Represents the Challan Queue Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challanQueue','constants','DatePickerConfig','collectionConstants','utility'],function(r,challanQueue,constants,DatePickerConfig,collectionConstants,utility){
	'use strict';	
	/**
	* Controller function for Challan Queue Module.
	* Dependency injection $scope,$rootScope,challanQueueService,lazyModuleLoader as parameters.
	*/
	var challanQueueController = function($scope, $rootScope, challanQueueService,lazyModuleLoader,dialogService,$modal){
	
		var today = new Date();
		today.setHours(0,0,0,0);
		$scope.fromDate = $scope.toDate = today;
		$scope.totalRecord = 0;
		$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE+5;
		$scope.maxSize = constants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
		$scope.offset = $scope.sNo = 1;
		$scope.offsetlast = 10;
		$scope.allChallans = '';
		var reqObj = {};
		$scope.data = {};
		var filterOptions = collectionConstants.CHALLAN_FILTERS;
		var isAll = true;
		/**
		Method called to display contents of next page
		*/
		$scope.paginationHandler = function(pageNum){
			$scope.currentPage = pageNum;
			$scope.offset = pageNum;
			$scope.offsetlast = (($scope.offset * 10) > $scope.totalRecord) ? $scope.totalRecord : $scope.offset * 10;
			$scope.sNo = ((($scope.currentPage-1)*$scope.maxRecordPerPage)+1);
			if(reqObj.searchBy === 'filter'){
				$scope.getAllChallans(reqObj.searchBy,reqObj.filterBy);
			}
			else{
				$scope.getAllChallans('date');
			}
		};
		$scope.challanDate = new DatePickerConfig({
			value : '',
			readonly : true,
			maxDate : new Date()
		});
		/**
		Method to fetch all challans of the selected date range
		*/
		$scope.getAllChallans = function(searchBy,searchVal){
			if(!searchBy){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ENTER_SEARCY_BY);
				return;
			}
			reqObj = {};
			if(searchBy === 'date'){
				$scope.searchVal = '';
				filterOptions = collectionConstants.CHALLAN_FILTERS;
				isAll = true;
				if(!$scope.challanDate.dateValue){
					dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_CHALLAN_DATE);
					return;
				}
				searchVal = utility.formDateString(new Date($scope.challanDate.dateValue),true);
			}
			else if(searchBy == 'filter'){
				$scope.challanDate.value = $scope.challanDate.dateValue = $scope.searchVal = '';
				reqObj.searchBy = 'filter';
				reqObj.filterBy = searchVal !== 'all'?searchVal:'';
			}
			else{
				$scope.challanDate.value = $scope.challanDate.dateValue = '';
				filterOptions = collectionConstants.CHALLAN_FILTERS;
				isAll = true;
				if(!$scope.searchVal){
					dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.VALID_SEARCH);
					return;
				}
				$scope.offset = $scope.currentPage = $scope.sNo = 1;
			}
			reqObj.offset = $scope.offset;
			reqObj.searchVal = searchVal;
			challanQueueService.getAllChallans(searchBy,reqObj).then(function(response){
				if(!response.data||!response.data.length){
					$scope.allChallans = [];
					$scope.noChallans = true;
					$scope.totalRecord = 0;
				}
				else{
					$scope.allChallans = response.data;
					$scope.noChallans = false;
					$scope.totalRecord = response.meta?response.meta.totalRecords:0;
				}
			});
		};

		$scope.getAllChallans('filter','all');
		$scope.navigateChallan = function(challan){
			var challanId = challan.challanNo;
			//var challanId = challan.physicalChallanNo?challan.physicalChallanNo:challan.challanNo;
			if(challan.physicalChallanNo){
				lazyModuleLoader.loadState('collections.imageUpload',{challanId:challanId});
			}
			else{
				lazyModuleLoader.loadState('collections.challanGeneration',{challanId:challanId});
			}
		};
		$scope.getBatchDetails = function(item,batchID){			
			var selRowValue = item;
			challanQueueService.viewSelTellerChallan(batchID,selRowValue.mode,selRowValue.productGroup).then(function(response){
				$scope.data[batchID] = true;
				var viewList = response; 
				$modal.open({
					templateUrl: 'app/collections/challan/challaning/partials/viewChallaning.html',
					controller: ['$scope','$modalInstance','lazyModuleLoader','data',function($scope,$modalInstance,lazyModuleLoader,data){
						$scope.viewChallanModel = data.viewData;
						$scope.noRecords = $scope.viewChallanModel&&$scope.viewChallanModel.length?false:true;
						$scope.viewSelData = data.selectedValue;
						$scope.viewSelData.batchID = data.batchID;
						/**
						* Method to close the modal pop up
						*/
						$scope.close = function() {
							$modalInstance.dismiss();
						};
						
						$scope.modifyReceipts = function(item){
							lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:item.receiptNo,type:'offline'});
						};
	                }],
					size: 'lg',
					backdrop: 'static',
					windowClass: 'modal-custom',
					resolve: {
						data: function(){
							return {
								viewData: viewList,
								selectedValue: selRowValue,
								batchID : batchID
							};
						}
					}
				});
			});
		};
		$scope.filterPopup = {
				onOpen : function(contentData) {
					contentData.options = angular.copy(filterOptions);
					contentData.isAll = isAll;
				},
				isAllSelected : function(options) {
					_.each(options, function(item) {
						item.selected = $scope.filterPopup.isAll;
					});
				},
				filterQueue : function(options) {
					var searchBy = 'filter', searchValue = '';
					if($scope.filterPopup.isAll){
						searchValue = 'all';
					}
					else{
						for (var i = 0; i < options.length; i++) {
							if (options[i].selected) {
								if(searchValue){
									searchValue = 'all';
									break;
								}
								searchValue = options[i].value;
							}
						}
					}
					if (searchBy&&!searchValue) {
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_OPTION);
						return;
					}
					$scope.offset = 1;
					$scope.offset  = $scope.currentPage = $scope.sNo = 1;
					$scope.getAllChallans(searchBy,searchValue);
					filterOptions = angular.copy(options);
					isAll = $scope.filterPopup.isAll;
					if (typeof $scope.filterPopup.close === 'function'){
						$scope.filterPopup.close();
					}
				},
				resetAndClose : function() {
					$scope.filterPopup.close();
				}
			};
	};
	challanQueue.controller('challanQueueController',['$scope','$rootScope','challanQueueService','lazyModuleLoader','dialogService','$modal',challanQueueController]);
	return challanQueueController;
});
