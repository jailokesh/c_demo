/**
* Represents a Challan Queue Service.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challanQueue','collectionServiceURLs'],function(require,challanQueue,collectionServiceURLs){
	'use strict';
	/**
	* Represents a Challan Queue Service.
	* Challan Queue Service function
	* Dependency injection $q,restProxy,authService as a parameters.
	*/
	var challanQueueService = function($q,restProxy,authService,$rootScope){
		var loggedUserDetails;
		loggedUserDetails = $rootScope.identity;

		this.getAllChallans = function(searchBy,reqObj){
			var url = collectionServiceURLs.challanServices.GET_ALLCHALLANS;
			var queryParams = {};
			if(searchBy === 'Physical Challan No.'){
				queryParams = {
						view : 'getTellerChallans',
						searchBy : 'physicalChallanNo',
						searchValue : reqObj.searchVal
					};  
			}
			else if(searchBy === 'date'){
				queryParams = {
					fromDate : reqObj.searchVal,
					toDate : reqObj.searchVal,
					limit : 10,
					offset : reqObj.offset,
					view : 'getTellerChallans'
				};
			}
			else if(searchBy === 'Challan No.'){
				queryParams = {
					view : 'getTellerChallans',
					searchBy : 'challanNo',
					searchValue : reqObj.searchVal
				}; 
			}
			else if(searchBy === 'filter'){
				queryParams = {
					view : 'getTellerChallans',
					limit : 10,
					offset : reqObj.offset
				}; 
				if(reqObj.filterBy){
					queryParams.filter = reqObj.filterBy;
				}
			}
			queryParams.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			queryParams.userrole = loggedUserDetails.hierarchyName;
			url.queryParams = queryParams;
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				_.each(data.data,function(challan){
					var isNoMemoInitiated = _.findIndex(challan.workflow,{workStatus:'INITIATED',requestType:'NOMEMOUPLOAD'});
					if(isNoMemoInitiated >-1){
						var isNoMemoApproved = _.findIndex(challan.workflow,{workStatus:'APPROVED',requestType:'NOMEMOUPLOAD'});
						if(isNoMemoApproved === -1){
							challan.isPendingApproval = true;
						}
					}
				});
				return data;
			});	
		};
		
		/** Returns view teller challan on select of payment */
		this.viewSelTellerChallan = function(batchId,mode,product){
			collectionServiceURLs.batchingServices.GET_BATCHDETAILS.queryParams = {
					userrole:($rootScope.identity.hierarchyName),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:mode,
					product:product
			};
			collectionServiceURLs.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchId
			};
			return restProxy.get(collectionServiceURLs.batchingServices.GET_BATCHDETAILS).then(function(data){
				return data.data;    					
			});  	
		};
	};
	challanQueue.service('challanQueueService',['$q','restProxy','authService','$rootScope',challanQueueService]);
	return challanQueueService;
});