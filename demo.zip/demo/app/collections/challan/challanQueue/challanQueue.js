define(['require','collectionsApp'],function(require,collectionsApp){
	'use strict';
	var baseViewUrl = 'app/collections/challan/challanQueue/';
	/**
	* Contains the challan queue routing information.
	* Create and return the challan queue module.
	*/	
	var challanQueue = {
		name: 'collections.challanQueue',
		url: '/challanQueue',
		views: {
			'mainContent': {
				templateUrl: baseViewUrl + 'challanQueue.html',
				controller: 'challanQueueController'
			}
		},
		data: {'headerText':'Challan Queue',
			   'stateActivity' : ['COL_VIEW_CHALLAN_DETAILS']
		}
	};
	/**
	* Contains the challan queue configuration details.
	*/
	var challanQueueConfiguration = function($stateProvider,$urlRouterProvider){
		$stateProvider.state(challanQueue);
	};

	return angular.module('challanQueue',['ui.router','collections']).config(['$stateProvider','$urlRouterProvider', challanQueueConfiguration]);
});
