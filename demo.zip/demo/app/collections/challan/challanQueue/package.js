define([], function() {
'use strict';
   require.config({
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'challanQueue': 'app/collections/challan/challanQueue/challanQueue',
          'challanQueueService': 'app/collections/challan/challanQueue/services/challanQueueService',
          'challanQueueController': 'app/collections/challan/challanQueue/controllers/challanQueueController'
      },
      shim: {
    	  'challanQueue': ['angular', 'angular-ui-router'],
    	  'challanQueueService' : ['challanQueue'],
      	  'challanQueueController': ['challanQueueService']
      }
   });
   return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs(['challanQueueController'], callback);
			});
		});
	};
});