/**
* Represents an Image Upload Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challanSearch','constants','utility','collectionConstants'],function(r,challanSearch,constants,utility,collectionConstants){
	'use strict';
	/**
	* Dependency injection $scope,$modalInstance,challanSearchService,$modal as parameters.
	*/
	var challanSearchController = function($scope,$globalScope,$stateParams,$modal,authService,challanSearchService,masterService,messageBus,lazyModuleLoader,dialogService){
		$scope.data = {
			search : {}
		};
		var cleardate = function(){
			$scope.data.challanData = [];
			$scope.data.noRecords = $scope.data.enableSearch = false;
		};
		$scope.getChallanInfo = function(searchObj){
			var _len = _.without(_.values(searchObj), "").length;
			if(_len){
				if(searchObj.agreementNo && _len === 1){
					dialogService.showAlert(collectionConstants.ALERT,collectionConstants.ALERT,"Refine your search by giving other fields with agreement number.");
					cleardate();
					return;
				}else if(searchObj.txnId && (searchObj.physicalChallanNo || searchObj.challanNo || searchObj.batchID)){
					dialogService.showAlert(collectionConstants.ALERT,collectionConstants.ALERT,"Please enter a valid search combination!");
					cleardate();
					return;
				}
				challanSearchService.getChallanInfo(searchObj).then(function(response){
					$scope.data.challanData = response;
					$scope.data.batches = {};
					$scope.data.noRecords = (!response || !response.length);
					$scope.data.enableSearch = true;
					$scope.data.isReceiptSearch = (((searchObj.receiptNo || searchObj.txnId) && _len === 1)||(searchObj.receiptNo && searchObj.txnId && _len === 2)) ? true : false;
					$scope.data.hideChallanDetails = ((searchObj.txnId && _len === 1) || (searchObj.receiptNo && searchObj.txnId && _len === 2)) ? true : false;
					if($scope.data.challanData[0] && searchObj.receiptNo && _len === 1){
						$scope.data.hideChallanDetails = ($scope.data.challanData[0].receiptDetails && ($scope.data.challanData[0].receiptDetails.modeOfPayment === 'POS' || $scope.data.challanData[0].receiptDetails.modeOfPayment === 'RTGS' || $scope.data.challanData[0].receiptDetails.modeOfPayment === 'ONLINE_PAYMENT'));
					}
					if($scope.data.challanData[0] && $scope.data.challanData[0].receiptDetails && ($scope.data.challanData[0].receiptDetails.modeOfPayment === 'POS' || $scope.data.challanData[0].receiptDetails.modeOfPayment === 'RTGS')){
						var _lastIndex = _.findLastIndex($scope.data.challanData[0].receiptDetails.workflow,{requestType : $scope.data.challanData[0].receiptDetails.modeOfPayment});
						if(_lastIndex > -1){
							var _workFlow = $scope.data.challanData[0].receiptDetails.workflow[_lastIndex];
							$scope.data.challanData[0].receiptDetails.workStatus = (_workFlow.workStatus === 'RECOMMENDED' || _workFlow.workStatus ===  'INITIATED') ? 'PENDING' : _workFlow.workStatus;
						}
					}
				});
			}else{
				cleardate();
			}			
		};
		
		$scope.getBatchDetails = function(item,batchID){
			$scope.data.batches[batchID] = true;
			challanSearchService.viewSelTellerChallan(batchID,item);
		};
		
		$scope.capitalizeHandler = function(val,source){
			$scope.data.search[source] = val.toUpperCase();
		};
		
		$scope.showBalanceAllocation = function(_receiptDetails){
			var _agrNos = _receiptDetails.agreementNos;
			var _charges = angular.copy(_receiptDetails.chargeDetails);
			var _balTable = [],isIMD,_total;
			if(!_agrNos[0] || _receiptDetails.receiptType === 'IMD'){
				isIMD = true;
				_total = challanSearchService.calculateTotal(_charges);
				_charges.push({chargeType : 'Total', amount : _total});
				_balTable.push({agrNo : _receiptDetails.applicationNos[0], charges : _charges});
			}else{
				if(_receiptDetails.receiptType === 'TA'){
					var _principal = _.findWhere(_charges,{chargeID: collectionConstants.CHARGE_IDS.AMT_FINANCED});
					var _interest = _.findWhere(_charges,{chargeID: collectionConstants.CHARGE_IDS.INTEREST_COMPONENT});
					if(_principal){
						_principal.chargeType = 'Principal outstanding';
					}
					if(_interest){
						_interest.chargeType = 'Interest';
					}
				}
				_.each(_agrNos,function(_agrNo){
					var agrCharges = _.where(_charges, {referenceNo : _agrNo});
					_total = challanSearchService.calculateTotal(agrCharges);
					agrCharges.push({chargeType : 'Total', amount : _total});
					_balTable.push({agrNo : _agrNo, charges : agrCharges});
				});
			}
			var obj = {
            	showBalanceAllocation : true,
            	balanceTable : _balTable,
            	isIMD : isIMD
            };
			challanSearchService.openModal('app/collections/eReceipt/receipting/partials/popup/waiverDetails.html',obj);
		};
		
		$scope.showAgreements = function(_agreements,_type){
			var obj = {
				agreements : _agreements,
				type : _type
			};
			challanSearchService.openModal('app/collections/challan/challanSearch/partial/agreementList.html',obj);
		};
	};
	challanSearch.controller('challanSearchController',['$scope','$globalScope','$stateParams','$modal','authService','challanSearchService','masterService','messageBus','lazyModuleLoader','dialogService', challanSearchController]);
	return challanSearchController;
});