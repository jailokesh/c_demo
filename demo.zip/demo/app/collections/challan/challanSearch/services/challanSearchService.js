/**
* Represents Image Upload Service.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challanSearch','collectionServiceURLs'],function(require,challanSearch,collectionServiceURLs){
	'use strict';
	/**
	* Represents a image Upload Service.
	* Image Upload Service function
	* Dependency injection $q,restProxy,authService as parameters.
	*/
	var challanSearchService = function($q,restProxy,$rootScope,$modal){
		
		/**
		* Method to retrieve the challan details of the given challan id
		*/		
		this.getChallanInfo = function(searchObj){
			collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.queryParams = {
					userrole:($rootScope.identity.hierarchyName).toUpperCase(),					
					view : 'CHALLAN_SEARCH'									
			};
			_.extend(collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.queryParams,searchObj);			
			collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.urlParams = {};
			return restProxy.get(collectionServiceURLs.challanServices.GET_PENDINGCHALLANS).then(function(data){
				return data.data;
			});	
		};		
		
		this.viewSelTellerChallan = function(batchID,_details){
			collectionServiceURLs.batchingServices.GET_BATCHDETAILS.queryParams = {
					userrole:($rootScope.identity.hierarchyName),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:_details.mode,
					product:_details.productGroup
			};
			collectionServiceURLs.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchID
			};
			return restProxy.get(collectionServiceURLs.batchingServices.GET_BATCHDETAILS).then(function(data){
				$modal.open({
					templateUrl: 'app/collections/challan/challaning/partials/viewChallaning.html',
					controller: ['$scope','$modalInstance','lazyModuleLoader','data',function($scope,$modalInstance,lazyModuleLoader,data){
						$scope.viewChallanModel = data.viewData;
						$scope.noRecords = $scope.viewChallanModel&&$scope.viewChallanModel.length?false:true;
						$scope.viewSelData = data.selectedValue;
						$scope.viewSelData.batchID = data.batchID;
						/**
						* Method to close the modal pop up
						*/
						$scope.close = function() {
							$modalInstance.dismiss();
						};
						
						$scope.modifyReceipts = function(item){
							lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:item.receiptNo,type:'offline'});
						};
	                }],
					size: 'lg',
					backdrop: 'static',
					windowClass: 'modal-custom',
					resolve: {
						data: function(){
							return {
								viewData: data.data,
								selectedValue: _details,
								batchID : batchID
							};
						}
					}
				});  					
			});  	
		};
		
		this.calculateTotal = function(_agrCharges){
			var _total = _.reduce(_agrCharges, function(memo, item) {
				return memo + item.amount;
			}, 0);
			
			return _total;
		};
		
		this.openModal = function(_url, _modalData){
			var paramObj = {
				templateUrl: _url,
				controller: ['$scope', '$modalInstance', '$modal', 'data', function($scope, $modalInstance, $modal, data){
					$scope.data = data;
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				}],
				size : 'sm',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return  _modalData;
	                }
				}	
			};
			$modal.open(paramObj);
		};
		
	};
	challanSearch.service('challanSearchService',['$q','restProxy','$rootScope','$modal',challanSearchService]);
	return challanSearchService;
});