define(['require','collectionsApp'],function(require,collectionsApp){
	'use strict';
	/**
	* Contains the image upload routing information.
	* Create and return the image upload module.
	*/
	var baseViewUrl = 'app/collections/challan/challanSearch/';
	var app = angular.module('challanSearch',['ui.router','collections']);

	var challanSearch = {
		name : 'collections.challanSearch',
		url : '/challanSearch',
		views : {
			'mainContent': {
				templateUrl: baseViewUrl + 'challanSearch.html',
				controller: 'challanSearchController'
			}
		},
		data : {'headerText':'Challan / Receipt Search',				
				'stateActivity' : ['COL_CHALLAN_SEARCH']
			}
	};
	/**
	* Contains the challan search configuration details.
	*/
	var challanSearchConfiguration = function($stateProvider, $urlRouterProvider){
		$stateProvider.state(challanSearch);
	};
	app.config(['$stateProvider','$urlRouterProvider',challanSearchConfiguration]);
	return app;
});
