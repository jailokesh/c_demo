define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'challanSearch': 'app/collections/challan/challanSearch/challanSearch',
			'challanSearchService': 'app/collections/challan/challanSearch/services/challanSearchService',
			'challanSearchController': 'app/collections/challan/challanSearch/controllers/challanSearchController'
		},
		shim: {
			'challanSearch': ['angular', 'angular-ui-router'],
			'challanSearchController': ['challanSearchService'],			
			'handsOffService' : ['challanSearch']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['challanSearchController'],callback);
			});
		});
	};
});