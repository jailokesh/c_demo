define(['require','collectionsApp','challanGenerationResolver'],function(require,collectionsApp,challanGenerationResolver){
	'use strict';
	/**
	* Contains the challan generation routing information.
	* Create and return the challan generation module.
	*/
	var baseViewUrl = 'app/collections/challan/challanGeneration/';
	var challanGeneration = {
		name: 'collections.challanGeneration',
		url: '/imageUpload/:challanId',
		views: {
			'mainContent': {
				templateUrl: baseViewUrl + 'challanGeneration.html',
				controller: 'challanGenerationController',
				resolve: challanGenerationResolver
			}	
		},
		data: {'headerText':'Challan Image Upload',
				'backState':'collections.challanQueue',
			   'stateActivity' : ['COL_TELLER_CHALLANING']
		}	
	};
	/**
	* Contains the challan generation configuration details.
	*/
	var challanGenerationConfiguration = function($stateProvider,$urlRouterProvider){
		$stateProvider.state(challanGeneration);
	};

	return angular.module('challanGeneration',['ui.router','collections']).config(['$stateProvider','$urlRouterProvider', challanGenerationConfiguration]);
});
