define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'challanGeneration': 'app/collections/challan/challanGeneration/challanGeneration',
			'challanGenerationService': 'app/collections/challan/challanGeneration/services/challanGenerationService',
			'challanGenerationController': 'app/collections/challan/challanGeneration/controllers/challanGenerationController',
			'insDefectPopUpController': 'app/collections/challan/challanGeneration/controllers/insDefectPopUpController',
			'challanGenerationResolver': 'app/collections/challan/challanGeneration/resolvers/challanGenerationResolver',
			'delayNotificationController' :'app/collections/challan/challanGeneration/controllers/delayNotificationController'
		},
		shim: {
			'challanGeneration': ['angular', 'angular-ui-router','challanGenerationResolver'],
			'challanGenerationService': ['challanGeneration'],
			'challanGenerationController': ['challanGenerationService'],
			'insDefectPopUpController':  ['challanGenerationService'],
			'delayNotificationController':['challanGenerationService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['challanGenerationController','insDefectPopUpController','delayNotificationController'],callback);
			});
		});
	};
});