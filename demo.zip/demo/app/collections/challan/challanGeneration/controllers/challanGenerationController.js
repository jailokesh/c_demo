/**
* Represents a challan generation Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','challanGeneration','constants','utility','DatePickerConfig','collectionConstants'],function(r,challanGeneration,constants,utility,DatePickerConfig,collectionConstants){
	'use strict';
	/**
	* Challan Generation Controller function.
	* getChallanInfo is method in challan generation resolver to get the batches to be challaned before the page load.
	* Dependency $scope,$modal,$rootScope,getTellerBatchInfo,authService,batchingService. 
	*/
	var challanGenerationController = function($scope,$stateParams,$rootScope,$globalScope,$modal,getChallanInfo,challanGenerationService,lazyModuleLoader,masterService,messageBus,dialogService){
		var MAX_IMAGE_SIZE = 3;
		$scope.total = '';
		$scope.challanId = $stateParams.challanId;
		var totalReceiptAmt;
		$scope.categoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Challan'});
		//var loggedUserDetails = authService.loggedUserDetails;
		/**
		Method to get challan details for the given challan Id
		*/
		$scope.bankName = {};
		$scope.challanData = {};
		var fetchChallanDetails = function(){
			if(!$scope.challanData){
				$scope.noRecords = true;
				return;
			}
			else{
				$scope.noRecords = false;
			}
			$scope.challanData.physicalChallanedDate = new Date();
			if($scope.challanData.mode!=='CASH'){
				$scope.total = $scope.challanData.receiptAmount;
			}
			if(!$scope.bankNames){
				var source,bankID,mode;
				if($scope.challanData.mode === "DD"){
					mode = "DRAFT";
				}
				else if($scope.challanData.mode === "CHEQUE-NON-MICR"){
					mode = "CHEQUE";
				}	
				else{
					mode = $scope.challanData.mode;
				}	
				if($scope.challanData.productGroup === 'DEALER'){
					source = 'DealerBank';
				}
				else{
					source = '';
					bankID = _.findWhere($rootScope.identity.selectedBranch.bankDetails, {paymentMode: mode, leapFunction: $scope.challanData.productGroup+"-COLLECTIONS"});
					bankID = (bankID && bankID.dealingBankIDs) ? bankID.dealingBankIDs : '';
				}
				if(bankID || source){
					masterService.getBankName(bankID,mode==='CASH'?'C':'B',source).then(function(data){
						$scope.bankNames = data;
					});
				}				
			}
			totalReceiptAmt = angular.copy($scope.challanData.receiptAmount);
		};
		$scope.bankName.bank = '';
		if(getChallanInfo && getChallanInfo.length){
			$scope.challanData = getChallanInfo[0];
			fetchChallanDetails();
		}
		/**
		Method to fetch the challan details for the given challan id
		*/
		$scope.getChallanInfo = function(challanId){
			if(!challanId){
				return;
			}
			challanGenerationService.getChallanInfo(challanId).then(function(response){
				$scope.challanData = response[0]?response[0]:'';
				fetchChallanDetails();    			 
			});
		};
		/** Date picker value set up */ 
		$scope.physicalChallanDate = new DatePickerConfig({    		 	
			value:new Date(),
			maxDate:new Date(),
			onchange:function(val){
				$scope.challanData.physicalChallanedDate = val;					
			},
			readonly: true,
			maxErrorMsg : "Physical Challan Date cannot be greater than current date"
		});		
		$scope.cashDenominations = {
			twoThousands : '',
			thousands:'',
			fiveHundreds:'',
			twoHundreds:'',
			hundreds:'',
			fiftys:'',
			twenties:'',
			tens:'',
			fives:'',
			twos:'',
			ones:''
		};
		$scope.calculateCash = {
			twoThousands : '',
			thousands:'',
			fiveHundreds:'',
			twoHundreds:'',
			hundreds:'',
			fiftys:'',
			twenties:'',
			tens:'',
			fives:'',
			twos:'',
			ones:'',
			coins:''
		};
		/** Calculations for cash denominations for mode ='CASH' */
		$scope.calculateCollectedCashAmount = function(){
			$scope.calculateCash.twoThousands =  parseInt($scope.cashDenominations.twoThousands * 2000);
			$scope.calculateCash.thousands =  parseInt($scope.cashDenominations.thousands * 1000);
			$scope.calculateCash.fiveHundreds =  parseInt($scope.cashDenominations.fiveHundreds * 500);
			$scope.calculateCash.twoHundreds =  parseInt($scope.cashDenominations.twoHundreds * 200);
			$scope.calculateCash.hundreds =  parseInt($scope.cashDenominations.hundreds * 100);
			$scope.calculateCash.fiftys =  parseInt($scope.cashDenominations.fiftys * 50);
			$scope.calculateCash.twenties =  parseInt($scope.cashDenominations.twenties * 20);
			$scope.calculateCash.tens =  parseInt($scope.cashDenominations.tens * 10);
			$scope.calculateCash.fives =  parseInt($scope.cashDenominations.fives * 5);
			$scope.calculateCash.twos =  parseInt($scope.cashDenominations.twos * 2);
			$scope.calculateCash.ones =  parseInt($scope.cashDenominations.ones * 1);
			$scope.total =  parseInt($scope.calculateCash.twoThousands+$scope.calculateCash.thousands+$scope.calculateCash.fiveHundreds+$scope.calculateCash.twoHundreds+
			$scope.calculateCash.hundreds+$scope.calculateCash.fiftys+$scope.calculateCash.twenties+
			$scope.calculateCash.tens+$scope.calculateCash.fives+
			$scope.calculateCash.twos+$scope.calculateCash.ones+
			parseInt($scope.calculateCash.coins*1));
		};
		
		messageBus.onMsg('INSTRUMENTS',function(event,data){						
			$scope.challanData.fakeAmount = data.fakeAmount;
			$scope.challanData.fakeNoteRemarks = data.fakeNoteRemarks;
			$scope.challanData.memoPathRef = data.memoPathRef;
			for(var temp in $scope.calculateCash){
				$scope.calculateCash[temp] = $scope.calculateCollectedCashAmount[temp] = $scope.cashDenominations[temp] = '';
			}
			$scope.challanData.receiptAmount = parseInt(totalReceiptAmt) - parseInt($scope.challanData.fakeAmount);
			if($scope.challanData.mode === 'CASH') {
				$scope.total = '';
			}
			else {
				$scope.total = angular.copy($scope.challanData.receiptAmount);
			}
		},$scope);
		
		/** Method to POST challan details  */
		$scope.checkDelayNotification = function(){
			var imageLength = [];			
			_.each($scope.challanData.challanImageRef.imagePathReferences,function(item){
				if(!item.isDelete){
					imageLength.push(item);
				}
			});
			if(!imageLength.length){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.UPLOAD_CHALLAN_IMG);
				return;
			}else if(imageLength.length > MAX_IMAGE_SIZE){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,"Cannot upload more than "+MAX_IMAGE_SIZE+" challan images");
				return;
			}		
			challanGenerationService.getDelayNoticationDetails($scope.challanData).then(function(response){
				if (response && response.status === 'failed'){
					if(response.message.errors[0].errorCode === 'DCR-1009'){
						dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
							challanGenerationService.deleteCashReceipt($scope.challanData.productGroup).then(function(response){
								if(response){
									dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
										$scope.submitChallan();
									});
								}
							});
						}, function() {});						
					}
					else if(response.message.errors[0].errorCode === 'DCR-1010'){
						dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
							lazyModuleLoader.loadState('collections.dailyCashReport');					
						}, function() {});
					}else if(response.message.errors[0].errorCode === 'DCR-1013'){
						dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
					}else{
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,response.message.errors[0].message).result.then(function() {}, function() {});
					}
				}
				else if(response && response.data && response.data.length>0){				
					notifyDelay(response.data);
				}else{
					$scope.submitChallan();
				}
			});
		};
		var notifyDelay = function(delayedReceipts){			
			$modal.open({
				templateUrl: 'app/collections/challan/challaning/partials/delayNotificationPopup.html',
				controller: 'delayNotificationController',
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {
					data: function(){
						return {
							delayedReceipts: delayedReceipts
						};
					}
				}
				}).result.then(function () {}, function (value) {
					if(value && value!="escape key press"){
						dialogService.showAlert(collectionConstants.REPO_MSG.SUCCESS, collectionConstants.REPO_MSG.SUCCESS, "Reason and Remarks successfully updated").result.then(function () {}, function () {
							$scope.submitChallan();
						});
					}																					
				});	
		};
		$scope.submitChallan = function(){
			if(!$scope.challanData.physicalChallanedDate){
				return;
			}
			var obj = {};
			obj.physicalChallanNo = $scope.challanData.physicalChallanNo;
			obj.physicalChallanedDate =  new Date($scope.challanData.physicalChallanedDate);
			obj.challanedAmount = $scope.total;
			obj.bankID =  $scope.bankName.bank.bankID;		
			if($scope.challanData.mode==='CASH'){
				obj.cashDenominations = [
             	{'noOfNotes':2000,'denomination':$scope.cashDenominations.twoThousands ? parseInt($scope.cashDenominations.twoThousands) : 0},
             	{'noOfNotes':1000,'denomination':$scope.cashDenominations.thousands ? parseInt($scope.cashDenominations.thousands) : 0},
				{'noOfNotes':500,'denomination':$scope.cashDenominations.fiveHundreds? parseInt($scope.cashDenominations.fiveHundreds) : 0},
				{'noOfNotes':200,'denomination':$scope.cashDenominations.twoHundreds? parseInt($scope.cashDenominations.twoHundreds) : 0},
				{'noOfNotes':100,'denomination':$scope.cashDenominations.hundreds ? parseInt($scope.cashDenominations.hundreds) : 0},
				{'noOfNotes':50,'denomination':$scope.cashDenominations.fiftys ? parseInt($scope.cashDenominations.fiftys) : 0},
				{'noOfNotes':20,'denomination':$scope.cashDenominations.twenties ? parseInt($scope.cashDenominations.twenties) : 0},
				{'noOfNotes':10,'denomination':$scope.cashDenominations.tens ? parseInt($scope.cashDenominations.tens) : 0},
				{'noOfNotes':5,'denomination':$scope.cashDenominations.fives ? parseInt($scope.cashDenominations.fives) : 0},
				{'noOfNotes':2,'denomination':$scope.cashDenominations.twos ? parseInt($scope.cashDenominations.twos) : 0},
				{'noOfNotes':1,'denomination':$scope.cashDenominations.ones ? parseInt($scope.cashDenominations.ones) : 0},
				{'noOfNotes':0,'noOfCoins':$scope.calculateCash.coins ? parseInt($scope.calculateCash.coins) : 0}];
			}
			
			obj.challanImageRef = $scope.challanData.challanImageRef;
			if($scope.challanData.memoPathRef && $scope.challanData.memoPathRef.imagePathReferences){
				obj.memoPathRef = $scope.challanData.memoPathRef;
			}			
			obj.fakeAmount = $scope.challanData.fakeAmount ? parseInt($scope.challanData.fakeAmount) : 0;
			obj.fakeNoteRemarks =  $scope.challanData.fakeNoteRemarks ? $scope.challanData.fakeNoteRemarks : '';
			obj.majorVersion = $scope.challanData.majorVersion ;
			obj.minorVersion = $scope.challanData.minorVersion;
			challanGenerationService.submitChallan(obj,$scope.challanData.challanNo).then(function(response){
				if (response && response.status === 'failed'){
					if(response.message.errors[0].errorCode === 'DCR-1009'){
						dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
							challanGenerationService.deleteCashReceipt($scope.challanData.productGroup).then(function(response){
								if(response){
									dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
										$scope.submitChallan();
									});
								}
							});
						}, function() {});						
					}
					else if(response.message.errors[0].errorCode === 'DCR-1010'){
						dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
							lazyModuleLoader.loadState('collections.dailyCashReport');					
						}, function() {});
					}else if(response.message.errors[0].errorCode === 'DCR-1013'){
						dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
					}else{
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,response.message.errors[0].message).result.then(function() {}, function() {});
					}
				}else if(response && Object.keys(response).length){
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,constants.PROMPT.IMAGE_UPLOAD_ALERT).result.then(function(){},function(){
						lazyModuleLoader.loadState('collections.challanQueue');
					});
				}
			});
		};
		/** action on click of 'add instrument defect' button
		* opens the pop up  */ 
		$scope.addInsDefPopUp = function(){
			//dialogService.showAlert(constants.ERROR_HEADER.warning,constants.ERROR_HEADER.warning,"This feature is temporarly not available.");
			//return;
			$scope.challanData.totalReceiptAmount = totalReceiptAmt;
			$modal.open({
				templateUrl: 'app/collections/challan/challanGeneration/partials/instrumentDefects.html',
				controller: 'insDefectPopUpController',
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				 resolve: {
                     data: function() {
                         return {
                        	 popUpData : $scope.challanData
                         };
                     }
                 }
			});
		};
	};
	challanGeneration.controller('challanGenerationController',['$scope','$stateParams','$rootScope','$globalScope','$modal','getChallanInfo','challanGenerationService','lazyModuleLoader','masterService','messageBus','dialogService',challanGenerationController]);
	return challanGenerationController;
});