define(['require','challanGeneration','collectionConstants'],function(r,challanGeneration,collectionConstants){
	'use strict';
	var insDefectPopUpController = function($scope,$globalScope,$modalInstance,data,messageBus,dialogService){		
		$scope.categoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Fake note memo'});
		$scope.close = function() {
			dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function(){
				$modalInstance.dismiss();
			},function(){});
        };        
        $scope.instrument = angular.copy(data.popUpData);    
        
        $scope.setImageCount = function(){
    		var imageobj = [];
    		if($scope.instrument.memoPathRef && $scope.instrument.memoPathRef.imagePathReferences){
    			_.each($scope.instrument.memoPathRef.imagePathReferences,function(item){
    				if(!item.isDelete){
    					imageobj.push(item);
    				}
    			});
    		}
    		$scope.instrument.isUploadImg = imageobj.length > 4 ? true : false;
    	};
        
        $scope.saveInstrument = function(){
        	var fakeNoteAmt = parseInt($scope.instrument.fakeAmount);
        	var msg;
        	if(!fakeNoteAmt){
        		msg = $scope.instrument.mode === 'CASH' ? collectionConstants.ERROR_MSG.ENTER_FAKENOTE_AMT : collectionConstants.ERROR_MSG.ENTER_DAMAGEDINST_AMT;
        		dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,msg);
				return;
        	}
        	if(fakeNoteAmt > parseInt($scope.instrument.totalReceiptAmount)){
        		msg = $scope.instrument.mode === 'CASH' ? collectionConstants.ERROR_MSG.INVALID_FAKENOTE_AMT : collectionConstants.ERROR_MSG.INVALID_DAMAGEDINST_AMT;
        		dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,msg);
				return;
        	}
        	//dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.POPUP_HEADER.CONFIRM_STRING,'Are you sure you want to save the details?').result.then(function(){
    		var instrumentDetails = {};		
    		instrumentDetails.fakeAmount = $scope.instrument.fakeAmount;
    		instrumentDetails.fakeNoteRemarks = $scope.instrument.fakeNoteRemarks;
    		instrumentDetails.memoPathRef = $scope.instrument.memoPathRef;
    		messageBus.emitMsg("INSTRUMENTS",instrumentDetails);
    		$modalInstance.close();	
			//},function(){});
    	};
        
	};
	
	
	
	challanGeneration.controller('insDefectPopUpController',['$scope','$globalScope','$modalInstance','data','messageBus','dialogService',insDefectPopUpController]);
	return insDefectPopUpController;
});
	
