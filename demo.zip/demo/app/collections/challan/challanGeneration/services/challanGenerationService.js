/**
 * Represents a challanGeneration Service.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','challanGeneration','collectionServiceURLs'], function(require,challanGeneration, collectionServiceURLs) {
'use strict';

/**
 * Represents a challanGeneration Service.
 * challanGeneration Service function
 * Dependency injection $q,restAngularProxy,restProxy as a parameter.
 */

var challanGenerationService = function($q,restProxy,$rootScope,environmentConfig){
	/** searches challan info on typing the challan number
	 * returns challan details */
	
	this.getChallanInfo = function(challanId){
		collectionServiceURLs.challanServices.SEARCH_CHALLAN.queryParams = {
				userrole:($rootScope.identity.hierarchyName).toUpperCase(),
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID				
		};
		collectionServiceURLs.challanServices.SEARCH_CHALLAN.urlParams = {
				challanNo:challanId
		};
		return restProxy.get(collectionServiceURLs.challanServices.SEARCH_CHALLAN).then(function(data){ 
			return data.data;
		});	
	};
	
	/** submit challan */
	this.submitChallan = function(obj,challanId){		
		collectionServiceURLs.challanServices.SUBMIT_CHALLAN.queryParams = {
				userrole:($rootScope.identity.hierarchyName).toUpperCase(),
				userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
				view:"submitChallan"				
		};
		if(environmentConfig.isDCR){
			collectionServiceURLs.challanServices.SUBMIT_CHALLAN.queryParams.dcr = true;
		}
		collectionServiceURLs.challanServices.SUBMIT_CHALLAN.urlParams = {
				challanNo:challanId
		};
		collectionServiceURLs.challanServices.SUBMIT_CHALLAN.notify = false;
		obj.challanedAmount = obj.challanedAmount ? obj.challanedAmount : 0;
		return restProxy.save('PUT',collectionServiceURLs.challanServices.SUBMIT_CHALLAN,obj).then(function(data){
			if(data.status === 'failed'){
				return data;
			} else{
				return data.data;
			}
		});	
	};
	
	this.deleteCashReceipt = function(productType){
		var queryParams = {
			'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
			'product' : productType
		};
		collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
		return restProxy.save('DELETE',collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
			return response.data;
		});	
	};
	
	this.getDelayNoticationDetails = function(challanData){
		collectionServiceURLs.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS.queryParams = {
			'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
			'productType':challanData.productGroup,
			'view':"BROWSERRECEIPTSCHECK"
		};
		collectionServiceURLs.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS.notify = false;
		return restProxy.save('POST',collectionServiceURLs.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS,{"batchIds":challanData.batchIDs}).then(function(data){
			return data;
		});
	};

	this.updateDelayNotification = function(receiptArray){
		collectionServiceURLs.challanServices.POST_DELAY_REASON.queryParams={
			'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
			'view':"POSTRECEIPTSREASON"
		};
		return restProxy.save('POST',collectionServiceURLs.challanServices.POST_DELAY_REASON,receiptArray).then(function(data){
			return data.data;
		});
	};
};

challanGeneration.service('challanGenerationService',['$q','restProxy','$rootScope','environmentConfig',challanGenerationService]);
return challanGenerationService;
});