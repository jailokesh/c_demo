define([],function(){
	'use strict';
	/**
	* Represents Challan Generation Resolver.
	* Dependency injection challanGenerationService,$rootScope as parameters.
	* Returns the Challan details.
	*/
    return {
        getChallanInfo: ['challanGenerationService','$stateParams',
            function(challanGenerationService,$stateParams){
        		if(!$stateParams.challanId){
        			return [];
        		}
        		return challanGenerationService.getChallanInfo($stateParams.challanId).then(function(data){
                	return data;
                });
            }
        ]
    };
});