/**
 * Represents batching Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','batching','collectionConstants'], function(require,batching,collectionConstants) {
	'use strict';
	/**
	* Batching Controller function.
	* getTellerBatchInfo is method in a batching resolver to get the teller batches info before the page load.
	* Dependency $scope,$modal,$rootScope,getTellerBatchInfo,authService,batchingService. 
	*/
	var batchingController = function($scope,$modal,$rootScope,getTellerBatchInfo,batchingService,appFactory,dialogService) {
		$scope.productTypes = angular.copy($rootScope.identity.productDetails);
		$scope.productType = $rootScope.productType;
		if(appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.TA_RECEIPT))
			$scope.productTypes.push({value:"DEALER"});
		$scope.batchingTellerModel = getTellerBatchInfo;
		$scope.isAmt = $scope.isInst = false;
		$scope.amountSort = false;
		$scope.activity = {};
		
		$scope.disableSubmit = true;		
		if($rootScope.identity.standByTeller){
			$scope.activity.standByTellerID = "";
			$scope.activity.standByTeller = $rootScope.identity.standByTeller.status;
			$scope.activity.userTypes = ($rootScope.identity.standByTeller.tellerID) ? [{ text: $rootScope.identity.standByTeller.tellerID + "-TELLER", value: $rootScope.identity.standByTeller.tellerID }] :  [{ text: $rootScope.identity.standByTeller.standByTellerID + "-STANDBYTELLER", value: $rootScope.identity.standByTeller.standByTellerID }];
		}
		var init = function(){
			$scope.activity.approve  = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.BATCHING.GENERATE_BATCHES);
			
			if(!$scope.batchingTellerModel||!$scope.batchingTellerModel.length){
				//$scope.disableSubmit = true;
				$scope.noRecords = true;
			} 
			else
			{ 	
				$scope.totalAmount = 0;
				$scope.noRecords = false;
				_.each($scope.batchingTellerModel,function(item){
					item.isAgreement = item.isAgreementReceipt?'Agreement':'Non-Agreement';					
					if(item.amountPaid){
						$scope.totalAmount += item.amountPaid;
					}
					if(item.pddAcknowledgementType)
					{
						item.modeOfPayment = item.pddAcknowledgementType && item.pddAcknowledgementType.toUpperCase() === 'DOCUMENT' ? 'PDD' :'RPDC';
						item.isAgreement = '-';
						item.amountPaid = '';
					}
				});
				//$scope.disableSubmit = false;
			}
		};
		init();
		/**
		Method to batch all the teller generated receipts
		*/
		$scope.batchAll = function()
		{
			batchingService.batchAll($scope.productType).then(function(data){
				if(data && data.length){
					$scope.batchDetails = data;
					_.each($scope.batchingTellerModel,function(item){
						var batchObj = {},searchParams;
						searchParams = {
							mode:item.modeOfPayment,
							receiptSource : item.receiptSource
						};
						if(item.ITZBatchID){
							searchParams.ITZBatchID = item.ITZBatchID;
						}
						if(!item.ITZBatchID && item.modeOfPayment !== 'RPDC' && item.modeOfPayment !== 'PDD'){
							searchParams.hasAgreementReceipts = item.isAgreementReceipt;
						}
						batchObj = _.findWhere($scope.batchDetails,searchParams);
						if(batchObj && batchObj.batchID){ 
							item.batchID = batchObj.batchID;
						}
					});
					$scope.disableSubmit = true;
				}
			});            		 
		};
		/**
		Method to fetch all un-batched receipts based on product
		*/
		$scope.filterByProduct = function(product, user){
			if(!product){
				product = $scope.productType;
			}

			if(product !== 'DEALER'){
				$rootScope.productType = product;
			}
			batchingService.getTellerBatchList(product,$scope.amountSort,user).then(function(data){
				$scope.batchingTellerModel = data;
				init();
			});
		};
		
		var showReceipts = function(batchItem,data){
			$modal.open({
				templateUrl:'app/collections/challan/batching/partials/viewBatchDetails.html',
				controller:'batchReceiptPopupController',        				 	
				size:'lg',
				backdrop:'static',
				resolve:{
					data:function() {
						return {
							data:data,
							productType:$scope.productType,
							batchItem: batchItem
							//mode:batchItem.modeOfPayment,
							//source:batchItem.receiptSource
						};
					}
				}
			}).result.then(function(data){
				dialogService.showAlert('Alert', 'Success', 'Batch ('+ data[0].batchID +') has been generated successfully.').result.then(
						function(){},function(){
							$scope.filterByProduct($scope.productType, $scope.activity.standByTellerID);
						}
				);		
			},function(data){				
			});
		};
		/**
		Method to view receipt details of the generated batch IDs
		*/
		$scope.viewTellerReceipt = function(mode,batchID,productType){
			batchingService.getBatchedReceipts(mode,batchID,'receiptDateTime',true,productType).then(function(data){
				$modal.open({
					templateUrl:'app/collections/challan/batching/partials/viewBatchDetails.html',
					controller:'batchReceiptPopupController',        				 	
					size:'lg',
					backdrop:'static',
					resolve:{
						data:function() {
							return {
								data:data,
								batchId:batchID,
								productType:productType,
								mode:mode
							};
						}
					}
				});
			});
		};
		
		$scope.viewAllReceipt = function(batchItem){
			batchItem.standByTellerID = $scope.activity.standByTellerID;
			if(!batchItem.receipts){
				batchingService.getPendingReceipts(batchItem, $scope.activity.standByTellerID).then(function(data){
					batchItem.receipts = data;
					showReceipts(batchItem,data);
				});
			}else{
				showReceipts(batchItem,batchItem.receipts);
			}
		};
		
		/**
		Method to sort the un-batched receipts based on Product/Amount
		*/
		
		$scope.sortHandler = function(fieldStr) {
			var modelName = '';
			modelName = fieldStr==='product'?'isAmt':'isInst';
			$scope[modelName] = $scope[modelName]?false:true;
		};
	};
	batching.controller('batchingController',['$scope','$modal','$rootScope','getTellerBatchInfo','batchingService','appFactory','dialogService',batchingController]);
	return batchingController;
});