/**
 * Represents batching pop up Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','batching','collectionConstants'],function(r,batching,collectionConstants){
	'use strict';
	/**
	* Batching Popup Controller function.
	* Dependency $scope,$modalInstance,data as parameters.
	*/
	var batchReceiptPopupController = function($scope,dialogService,$modalInstance,data,batchingService,$modal,lazyModuleLoader){
		$scope.isAmt = $scope.isDate = true;
		$scope.disableSubmit = true;
		$scope.calculateTotal = function(){
			var data = _.where($scope.data,{selected:true});
			$scope.totalAmt = 0;
			_.each(data, function(item) {		
				$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
			});
		};
		$scope.selectAllCheckbox = function(check){
			_.each($scope.data,function(item){
				if(check){
					item.selected = true;
					$scope.disableSubmit = false;
				}else{
					item.selected = false;
					$scope.disableSubmit = true;
				}				
			});
			$scope.calculateTotal();
		};
		
		$scope.selectCheckbox = function(check){
			var data = _.where($scope.data,{selected:true});
			if(data.length > 0){
				$scope.disableSubmit = false;
			}else{
				$scope.disableSubmit = true;
			}
			if(data.length === $scope.data.length){
				$scope.selecteAll.all = true;				
			}else{
				$scope.selecteAll.all = false;				
			}
			$scope.calculateTotal();
		};
		var init = function(){
			$scope.data = data.data;
			$scope.batchId = data.batchId;
			$scope.selecteAll = {all : false};
			$scope.productType = data.productType;
			$scope.noRecords = (!$scope.data||!$scope.data.length)?true:false;
			$scope.mode = data.batchItem.modeOfPayment;
			$scope.totalAmt = 0;
			$scope.source = data.batchItem.receiptSource;
			$scope.receiptMode = false;	

			_.each($scope.data, function(item) {				
				//$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
				if(item.pddAcknowledgementType && !isNaN(parseInt(item.pddAcknowledgementType))){
					var pddObj = _.findWhere(collectionConstants.REPAY_MODES,{documentID:parseInt(item.pddAcknowledgementType)});
					var pddType = pddObj.id == 'RC' ? pddObj.id : pddObj.id.toLowerCase();
					item.pddImage = {
							imageRef : item[pddType+'Detail'] ? item[pddType+'Detail'].imageRef : {}
					};
				}
				if(item.lastWorkflow){
					item.isMRRejected = (item.lastWorkflow.requestType === "RECEIPTMODIFICATION" && item.lastWorkflow.workStatus === 'REJECTED');
					item.approvalStatus = item.lastWorkflow.requestType === "RECEIPTMODIFICATION" ? item.lastWorkflow.workStatus === 'INITIATED' ? "PENDING FOR APPROVAL" : item.lastWorkflow.workStatus : null;
				}
			});
			if(data.source && (data.source.toUpperCase() === "KIOSK" || data.source.toUpperCase() === "ITZCASH")){
				$scope.receiptMode = true;
				$scope.selectAllCheckbox(true);
			}
			if($scope.mode === "PDD" || $scope.mode === "RPDC"){
				$scope.selectAllCheckbox(true);
			}
			$scope.selectCheckbox();
		};
		init();
		/**
		Method to close the pop up window
		*/
		$scope.close = function(data){
			$modalInstance.close(data);
		};
		$scope.dismiss = function(){
			$modalInstance.dismiss();
		};
		/**
		Method to sort content by Date/Amount/Mode
		*/
		$scope.sortHandler = function(sortBy,sortVal){
			if(!$scope.batchId){
				return;
			}
			batchingService.getBatchedReceipts($scope.mode,$scope.batchId,sortBy,sortVal,$scope.productType).then(function(data){
				if(data && data.length){
					$scope.data = data;
					$scope.noRecords = false;
					$scope.totalAmt = 0;
					_.each($scope.data, function(item) {
						$scope.totalAmt += item.amountPaid?item.amountPaid:item.rpdcCollected[0]?item.rpdcCollected[0].chequeValue:0;
					});
				}
				else{
					$scope.data = [];
					$scope.noRecords = true;					
				}
			});
		};			
		var batchSelectedReceipts = function(_receipts){
			var receiptNo = _.pluck(_receipts, 'receiptNo');
			var pddAcknowledgementNo = _.pluck(_receipts, 'pddAcknowledgementNo');
			var selectedreceipts = 	typeof receiptNo[0] === "undefined" ? pddAcknowledgementNo : receiptNo;
			batchingService.batchAll($scope.productType,selectedreceipts,data.batchItem).then(function(data){
				if (data && data.status === 'failed'){
					if(data.message.errors[0].errorCode === 'DCR-1009'){
						dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
							batchingService.deleteCashReceipt($scope.productType).then(function(response){
								if(response){
									dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
										$scope.batchReceipts();
									});
								}
							});
						}, function() {});						
					}
					else if(data.message.errors[0].errorCode === 'DCR-1010'){
						dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
							lazyModuleLoader.loadState('collections.dailyCashReport');					
						}, function() {});
					}else if(data.message.errors[0].errorCode === 'DCR-1013'){
						dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
					}else{
						var edsmessages = [], a;
						for (a = data.message.errors.length - 1; a >= 0; a--) {
							edsmessages.push(data.message.errors[a].message);
							if (data.message.errors[a].data && data.message.errors[a].data.value) {
								edsmessages = _.union(edsmessages,data.message.errors[a].data.value);
							}
						}
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE, edsmessages.join('<br/>'), true).result.then(function() {
						}, function() {
						});
					}
				}else if(data && data.length){
					$scope.close(data);											
				}
				else{
					$scope.dismiss();
				}
			}); 
		};
		
		var rejectedReceipts = [];
		$scope.batchReceipts = function(){
			var selectedReceipts = _.where($scope.data, {selected:true}),showNotification;
			_.each(selectedReceipts,function(receipt){
				if(receipt.isMRRejected){
					if(rejectedReceipts.indexOf(receipt.receiptNo) === -1){
						showNotification = true;
						rejectedReceipts.push(receipt.receiptNo);
					}else if(!showNotification){
						showNotification = false;
					}
				}
			});
			
			if(showNotification){
				dialogService.showAlert("Warning","Warning","Manual Receipt No(s) ("+rejectedReceipts.toString()+") modification approval has been rejected").result.then(
					function(){},function(){
						_.each(rejectedReceipts,function(receipt){
							_.findWhere($scope.data, {receiptNo:receipt}).selected = false;
						});
					}
				);
				return;
			}else if(showNotification === false){ // strictly need to check false condition
				return $modal.open({
					templateUrl:'app/collections/challan/batching/partials/confirmBatch.html',
					size:'md',
					backdrop:'static',
					controller : ['$scope','$modalInstance','data',function($scope,$modalInstance,data){
						$scope.receipts = data;
						$scope.ok = function() {
	                        $modalInstance.close(true);
	                    };
	                    $scope.close = function() {
	                        $modalInstance.dismiss();
	                    };
					}],
					resolve : {
						data : function(){
							return rejectedReceipts;
						}
					}
				}).result.then(function(){
					batchSelectedReceipts(selectedReceipts);
				},function(){
					lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo : rejectedReceipts[0], type : 'cancel'});
				});
			}else{
				batchSelectedReceipts(selectedReceipts);
			}  		 
		};
		
	};
	batching.controller('batchReceiptPopupController',['$scope','dialogService','$modalInstance','data','batchingService','$modal','lazyModuleLoader',batchReceiptPopupController]);
	return batchReceiptPopupController;
});