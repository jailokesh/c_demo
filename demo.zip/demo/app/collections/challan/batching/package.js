define([],function(){
	'use strict';
	require.config({
		paths : {
			'collectionsApp':'app/collections/collections',
			'batching' : 'app/collections/challan/batching/batching',
			'batchingService' : 'app/collections/challan/batching/services/batchingService',
			'batchingController' : 'app/collections/challan/batching/controllers/batchingController',
			'batchingResolver' : 'app/collections/challan/batching/resolvers/batchingResolver',
			'batchReceiptPopupController' : 'app/collections/challan/batching/controllers/batchReceiptPopupController'
		},
		shim : {
			'batching' : ['angular','angular-ui-router','batchingResolver'],
			'batchingController' : ['batching','batchingService'],
			'batchReceiptPopupController' : ['batchingService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['batchingController','batchReceiptPopupController'],callback);
			});
		});
	};
});