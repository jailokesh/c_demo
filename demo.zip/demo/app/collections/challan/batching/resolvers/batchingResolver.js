define([],function(){
	'use strict';
	/**
	* Represents Batching Resolver.
	* Dependency injection batchingService,$rootScope as parameters.
	* Returns the un-batched response data.
	*/
    return {
        getTellerBatchInfo:['batchingService','$rootScope',
            function(batchingService,$rootScope){
				return batchingService.getTellerBatchList($rootScope.productType,false).then(function(data){
                	return data;
                });
            }
        ]
    };
});