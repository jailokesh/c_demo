/**
 * Represents Batching Service.
 * Dependency injection $q,restProxy,authService as parameters.
 */
define(['require','batching','collectionServiceURLs'],function(require,batching,collectionServiceURL){
	'use strict';
	var batchingService = function($q,$rootScope,restProxy,environmentConfig){ 
		/**
		* Method to retrieve the un-batched receipts
		*/
		this.getTellerBatchList = function(product,amountFlag, user) {
			//initService();
			collectionServiceURL.batchingServices.GET_RECEIPTSTOBEBATCHED.queryParams = {
					view : 'toBeBatched',
					product : product,
					collectionAgentID : user || $rootScope.identity.userID,
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					sortBy : 'amountPaid',
					asc : amountFlag,
					source : 'browser'
			};
			return restProxy.get(collectionServiceURL.batchingServices.GET_RECEIPTSTOBEBATCHED).then(function(data){
				var responseArr = [],obj;
				_.each(data.data,function(value){
						//receiptSource:value.receiptSource,
					obj = value.ITZBatchID ? undefined : _.findWhere(responseArr,{modeOfPayment:value.modeOfPayment,isAgreementReceipt:value.isAgreementReceipt,itzCashBatch : false});
					if(!obj){
						value.itzCashBatch = value.ITZBatchID ? true : false;
						value.products = [value.productType];
						responseArr.push(value);
					}else{
						obj.amountPaid += value.amountPaid;
						obj.count += value.count;
						if(obj.products.indexOf(value.productType) == -1){
							obj.products.push(value.productType);
						}
					}
				});
				return responseArr;
			});    	    	
		};
		/**
		* Method to batch all receipts
		*/
		this.batchAll = function(product,selectedreceipts,batchItem){
			var reqObj = {
					collectionAgentID : batchItem.standByTellerID || $rootScope.identity.userID,
					product : product,
					receiptNos : selectedreceipts
			};
			collectionServiceURL.batchingServices.BATCHALL_RECEIPTS.queryParams = {
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					userrole : $rootScope.identity.hierarchyName,
					source : 'browser',					
					viewType : batchItem.source === 'KIOSK' ? batchItem.source : ''
			};
			if(environmentConfig.isDCR){
				collectionServiceURL.batchingServices.BATCHALL_RECEIPTS.queryParams.dcr = true;
			}
			collectionServiceURL.batchingServices.BATCHALL_RECEIPTS.notify = false;
			return restProxy.save('POST',collectionServiceURL.batchingServices.BATCHALL_RECEIPTS,reqObj).then(function(data){
				if(data.status === 'failed'){
					return data;
				} else{
					return data.data;
				} 					
			});    	    
		};
		
		this.deleteCashReceipt = function(productType){
			var queryParams = {
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};
			
			collectionServiceURL.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
			return restProxy.save('DELETE',collectionServiceURL.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
				return response.data;
			});	
		};
		
		/**
		* Method to fetch batched receipts list
		*/
		this.getBatchedReceipts = function(mode,batchID,sortBy,sortVal,product) { 
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams = {
					userrole:($rootScope.identity.hierarchyName).toUpperCase(),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:mode,
					product:product
			};
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchID
			};
			if(sortBy && sortBy.length){
				collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams.sortBy = sortBy;
				collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams.asc = sortVal;
			}
			return restProxy.get(collectionServiceURL.batchingServices.GET_BATCHDETAILS).then(function(data){
				return data.data;    					
			});    	    	
		};			
		
		this.getPendingReceipts = function(batchObj, user) {
			var url = {};
			if(batchObj.modeOfPayment === 'RPDC' || batchObj.modeOfPayment === 'PDD'){
				url = collectionServiceURL.batchingServices.GET_PENDINGACKNOWLEDGEMENTS;
				url.queryParams = {
						collectionAgentID : $rootScope.identity.userID,
						view : 'getPendingReferences',
						product : batchObj.productType,
						userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						source : 'pending',
						mode : batchObj.modeOfPayment,
						viewType : 'browser'
				};
			}
			else{
				url = collectionServiceURL.batchingServices.GET_RECEIPTDETAILS;
				url.queryParams = {
						collectionAgentID : user || $rootScope.identity.userID,
						view : 'getPendingReferences',
						product : batchObj.productType === 'PL' ? 'VF' : batchObj.productType,
						userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
						userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
						source : 'pending',
						mode : batchObj.modeOfPayment ,
						agreement : batchObj.isAgreementReceipt,
						viewType : (batchObj.receiptSource === 'BROWSER' || batchObj.receiptSource === 'BROWSER_MANUAL') ? 'browser' : batchObj.receiptSource,
						itzBatchID : batchObj.ITZBatchID ? batchObj.ITZBatchID : ''
				};
			}
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data.data;    					
			}); 
		};
		

	};
	batching.service('batchingService',['$q','$rootScope','restProxy','environmentConfig',batchingService]);
	return batchingService;
});
