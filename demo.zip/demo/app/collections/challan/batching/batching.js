define(['require','collectionsApp','batchingResolver'],function(require,collectionsApp,batchingResolver){
   'use strict';
	/**
	* Contains the batching routing information.
	* Create and return the batching module.
	*/	
	var baseViewUrl = 'app/collections/challan/batching/'; 
	var app = angular.module('batching',['ui.router','collections']);
   
	var batching = {
		name : 'collections.batching',
		url : '/batching',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'batching.html',
				controller : 'batchingController',
				resolve : batchingResolver
			}
		},
		data : {'headerText':'Batching',
			'stateActivity' : ['COL_TELLER_BATCHING']
		}
	};
	/**
	* Contains the batching configuration details.
	*/
	var batchingConfiguration = function($stateProvider,$urlRouterProvider){
		$stateProvider.state(batching);
	};
   
	app.config(['$stateProvider', '$urlRouterProvider', batchingConfiguration]);
	return app;
});
