/**
 * Represents Handsoff Service.
 * Dependency injection $q,restProxy,authService as parameters.
 */
define(['require','handsOff','utility','collectionServiceURLs','collectionConstants'],function(require,handsOff,utility,collectionsServiceURL,collectionConstants){
	'use strict';
	var handsOffService = function($q,restProxy,$rootScope,$globalScope,environmentConfig,dialogService,lazyModuleLoader){
		var url = '';
		var thisObj = this;
		var loggedUserDetails;
		this.bankNames = [];

		var initService = function(){
			loggedUserDetails = $rootScope.identity;
		};
		initService();
		/**
		* Method to fetch bank names
		
		this.getPdcBanks = function(){
			initService();
			return restProxy.get(collectionsServiceURL.masterServices.GET_PDCBANK).then(function(data){ 
				return data.data;
			});	
		};*/
		/**
		* Method to fetch all pending/batched receipts
		*/
		var pageDetails;
		this.setPageDetails = function(value){
			pageDetails = value;
		};
		this.getPageDetails = function(){
			return pageDetails;
		};
		this.getPendingReceipts = function(cfeId,from,to){
			url = collectionsServiceURL.batchingServices.GET_ALLRECEIPTS;
			url.queryParams = {
					product : $rootScope.productType
				};
			url.queryParams.fromDate = $globalScope.isClickedViaMenu ? utility.formDateString(from,true) : '';
			url.queryParams.toDate = $globalScope.isClickedViaMenu ? utility.formDateString(to,true) :'';
			if(cfeId!=='all'){
				url.queryParams.collectionAgentID = cfeId;
			}
			url.queryParams.userrole = $globalScope.isClickedViaMenu ? $rootScope.identity.hierarchyName : 'CFE';
			url.queryParams.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			url.queryParams.view = $globalScope.isClickedViaMenu ? 'getPendingReceipts' : 'getPendingReceiptsForCFE';
			url.queryParams.source = $globalScope.isClickedViaMenu ? '' : 'dashboard';
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				var referenceArr = [];
				var response = [];
				var referenceStr = cfeId==='all'?'collectionAgentID':'receiptDateTime';
				_.each(data.data,function(item){
					if(referenceStr==='receiptDateTime'){
						/*var dateObj = new Date(item[referenceStr]);
						var date = dateObj.getDate();
						var month = dateObj.getMonth()+1;
						item[referenceStr] = (date<10?'0'+date:date)+'/'+(month<10?'0'+month:month)+'/'+dateObj.getFullYear();*/
						item[referenceStr] = (item.dayOfMonth<10?'0'+item.dayOfMonth:item.dayOfMonth)+'-'+
											 (item.month<10?'0'+item.month:item.month)+'-'+
											 item.year;
					}
					if(referenceArr.indexOf(item[referenceStr]) === -1){
						referenceArr.push(item[referenceStr]);
					}
				});	
				_.each(referenceArr,function(value){
					var receiptDetails = _.filter(data.data,function(receipt)
					{ 
						return receipt[referenceStr] === value;
					});
					var cfeName = '';
					var cfeID = '';
					var batchedReceipts = 0;
					var toBeBatched = 0;
					var totalAmount = 0;
					var cashObj = {totalNo:0,totalAmt:0};
					var othersObj = {totalNo:0,totalAmt:0};
					_.each(receiptDetails,function(detail){
						if(detail.status === 'BATCHED'){
							batchedReceipts += detail.count;
						}
						else{
							toBeBatched += detail.count;
						}
						if(detail.modeOfPayment === 'CASH')
						{
							cashObj.totalNo += detail.count;
							cashObj.totalAmt += detail.amountPaid;
						}
						else
						{
							othersObj.totalNo += detail.count;
							othersObj.totalAmt += detail.amountPaid;
						}
						totalAmount += detail.amountPaid;
						cfeID = detail.collectionAgentID;
						cfeName = detail.cfeDetails?detail.cfeDetails.cfeName:'';
					});
					response.push({cfeName:cfeName,cfeId:cfeID,id:value,batched:batchedReceipts,unbatched:toBeBatched,totalValue:totalAmount,cash:{totalNo:cashObj.totalNo,totalValue:cashObj.totalAmt},
					others:{totalNo:othersObj.totalNo,totalValue:othersObj.totalAmt},isOpen:true});
				});
				if(response.length){
					response[0].cfeDetails = data.data[0].cfeDetails;
				}
				data.data  = response;
				return data.data;
			});
		};
		/**
		* Method to fetch all pending acknowledgements
		*/
		this.getAcknowledgementDetails = function(cfeId,from,to,productType,source){
			if(cfeId==='all')
			{
				url = collectionsServiceURL.batchingServices.GET_ALLACKNOWLEDGEMENTS;
				url.queryParams = {
						fromDate : from,
						toDate : to,
						product : productType,
						view : 'getPendingAcknowledgements'
					};
			}
			else
			{
				url = collectionsServiceURL.batchingServices.GET_PENDINGACKNOWLEDGEMENTS;
				url.queryParams = {
						collectionAgentID : cfeId,
						stDate : from,
						endDate : to,
						product : productType,
						view : 'getPendingReferences',
						source : source
					};
			}
			url.queryParams.userrole = $rootScope.identity.hierarchyName;
			url.queryParams.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				var referenceArr = [];
				var response = [];
				if(cfeId!=='all'){
					_.each(data.data,function(item){
						if(isNaN(parseInt(item.pddAcknowledgementType))){
							return;
						}
						var pddObj = _.findWhere(collectionConstants.REPAY_MODES,{documentID:parseInt(item.pddAcknowledgementType)});
						item.pddType = pddObj.text;
						var pddType = pddObj.id == 'RC' ? pddObj.id : pddObj.id.toLowerCase();
						item.pddImage = {
							imageRef : item[pddType+'Detail'] ? item[pddType+'Detail'].imageRef : {}
						};
					});
					return data.data;
				}
				_.each(data.data,function(item){
					if(referenceArr.indexOf(item.collectionAgentID) === -1){
						referenceArr.push(item.collectionAgentID);
					}
				});	
				_.each(referenceArr,function(value){
					var ackDetails = _.filter(data.data,function(receipt)
					{ 
						return receipt.collectionAgentID === value;
					});
					var cfeName = '';
					var cfeID = '';
					var noOfAcks = 0;
					var pddAcks = 0;
					var rpdcAcks = 0;
					var toBeBatched = 0;
					var batched = 0;
					_.each(ackDetails,function(detail){
						if(detail.status === 'BATCHED'){
							batched += detail.count;
						}
						else{
							toBeBatched += detail.count;
						}
						if(isNaN(parseInt(detail.pddAcknowledgementType))){
							rpdcAcks += detail.count;
						}
						else{
							pddAcks += detail.count;
						}
						cfeName = detail.cfeDetails?detail.cfeDetails.cfeName:'';
						cfeID = detail.collectionAgentID;
					});
					noOfAcks = rpdcAcks+pddAcks;
					response.push({id:value,noOfAcks:noOfAcks,pddAcks:pddAcks,rpdcAcks:rpdcAcks,batched:batched,unbatched:toBeBatched,cfeName:cfeName,cfeId:cfeID});
				});
				if(response.length){
					response[0].cfeDetails = data.data[0].cfeDetails;
				}
				data.data  = response;
				return data.data;
			});
		};
		/**
		* Method to fetch all un-authorized challans
		*/
		this.getPendingChallans = function(cfeId,sortBy,sortFlag){
			var url=collectionsServiceURL.challanServices.GET_PENDINGCHALLANS;
			url.queryParams = {
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					userrole : $rootScope.identity.hierarchyName,
					view : 'getChallanToBeAuthorised',
					asc : sortFlag,
					sortBy : sortBy
			};
			if(cfeId!=='all'){
				url.queryParams.collectionAgentID = cfeId;
			}
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data.data;
			});
		};
		/**
		* Method to fetch all chola accounts
		*/
		this.getBankNames = function(){
			var url = collectionsServiceURL.masterServices.GET_CHOLABANKS;
			url.queryParams = {};
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data.data;
			});
		};
		/** 
		 * GET call - for hands off screen 'All' / 'cfe'
		 * Lists down the hands off batches
		 * author : Aishwerya , Dated: 19/3/2015
		*/
		this.searchHandler = function(value,productType){
			if(value !== 'All'){
				collectionsServiceURL.challanServices.HANDS_OFF_SEARCH.queryParams = {
						view:'getHandsOffBatches',
						userrole:loggedUserDetails.hierarchyName,
						userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
						collectionAgentID:value,
						product:productType
						};
			}else{
				collectionsServiceURL.challanServices.HANDS_OFF_SEARCH.queryParams = {
						view:'getHandsOffBatches',
						userrole:loggedUserDetails.hierarchyName,
						userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
						product:productType
				};
			}		
			collectionsServiceURL.challanServices.HANDS_OFF_SEARCH.urlParams = {};
			return restProxy.get(collectionsServiceURL.challanServices.HANDS_OFF_SEARCH).then(function(data){
				var responseObj = [];
				if(value === 'All'){
					var cfeArr = [];
					_.each(data.data,function(item){
						if(cfeArr.indexOf(item.collectionAgentID) === -1){
							cfeArr.push(item.collectionAgentID);
						}
					});
					_.each(cfeArr,function(value){
						var cfeDetails = _.where(data.data,{collectionAgentID:value});
						var cashTotal = 0;
						var chequeTotal = 0;
						var ddTotal = 0;
						var impsTotal = 0;
						var undepositedTotal = 0,cancelledTotal=0;
						_.each(cfeDetails,function(detail){
							if(!detail.batchAmount||detail.batchAmount===null){
								return;
							}
							if(detail.mode === 'CASH'){
								cashTotal += parseInt(detail.batchAmount);
							}
							else if(detail.mode === 'CHEQUE'){
								chequeTotal += parseInt(detail.batchAmount);
							}
							else if(detail.mode === 'DD'){
								ddTotal += parseInt(detail.batchAmount);
							}else if (detail.mode === 'CANCELLED') {
								cancelledTotal += parseInt(detail.batchAmount);
							} 
							else{
								impsTotal += parseInt(detail.batchAmount);
							}
						});
						undepositedTotal = cashTotal+chequeTotal+ddTotal+impsTotal; //+cancelledTotal
						responseObj.push({cfeID:value,cfeName:cfeDetails[0].cfeDetails?cfeDetails[0].cfeDetails.cfeName:'',cashValue:cashTotal,chequeValue:chequeTotal,cancelledValue : cancelledTotal,
						ddValue:ddTotal,impsValue:impsTotal,undepositedValue:undepositedTotal});
					});
					return responseObj;
				}
				return data.data;
			});
		};
		/** 
		 * GET call - for hands off screen 'cfe'
		 * Lists down the cfe data on expansion of the grid
		 * Input - Batch Id , Mode
		 * author : Aishwerya , Dated: 19/3/2015
		*/
		this.getBatchDetails = function(item){
			url = collectionsServiceURL.batchingServices.GET_BATCHDETAILS;
			url.queryParams = {
					userrole:loggedUserDetails.hierarchyName,
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:item.mode,
					product:item.product
					};
			url.urlParams = {
					batchID :item.batchID
			};
			return restProxy.get(url).then(function(data){
				return data.data;
			});
		};
		/**
		* Method to fetch branch names for the given bank ID
		
		this.getBranchNamesFromId = function(bBranchId){
			collectionsServiceURL.masterServices.GET_PDCBANKBRANCH.queryParams.bBranchID = bBranchId;
			return restProxy.get(collectionsServiceURL.masterServices.GET_PDCBANKBRANCH).then(function(data){
				return data.data;
			});
		};*/
		/**
		* Method to modify receipts
		*/
		this.updateReceipt = function(item){
			collectionsServiceURL.receiptingServices.MODIFY_RECEIPT.queryParams = {
					userrole:$rootScope.identity.hierarchyName,
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID
			};
			collectionsServiceURL.receiptingServices.MODIFY_RECEIPT.urlParams = {receiptNo:item.receiptNo};			
			var postObj = {instrumentType:item.instrumentDetail.instrumentType,
							bankBranchID:item.instrumentDetail.bankBranchID,
							instrumentDate:item.instrumentDetail.instrumentDate,
							instrumentNo:item.instrumentDetail.instrumentNo,
							bankID:item.instrumentDetail.bankID};
			return restProxy.save('PUT',collectionsServiceURL.receiptingServices.MODIFY_RECEIPT,postObj).then(function(data){
				return data.data;
			});
		};
		/**
		* Method to modify challans
		*/
		this.updateChallan = function(reqObj){
			collectionsServiceURL.challanServices.EDIT_CHALLAN.queryParams = {
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					view : 'editChallan'
			};
			collectionsServiceURL.challanServices.EDIT_CHALLAN.urlParams = {
					challanNo : reqObj.challanId	
			};
			return restProxy.save('PUT',collectionsServiceURL.challanServices.EDIT_CHALLAN,reqObj).then(function(data){
				return data.data;
			});
		};

		this.deleteCashReceipt = function(productType){
			var url = {
				EDS:environmentConfig.baseURL+"/dailyCashReporting",
				isEPS : false
			}
			var queryParams = {
				'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
				'product' : productType
			};			
			url.queryParams = queryParams;
			return restProxy.save('DELETE',url).then(function(response){ 
				return response.data;
			});	
		};
		var receiptingDetails = function(response,batchArray,productType){
			if(response.message.errors[0].errorCode === 'DCR-1009'){
				dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
					thisObj.deleteCashReceipt(productType).then(function(response){
						if(response){
							dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
								thisObj.approveBatches(batchArray,productType);
							});
						}
					});
				}, function() {});
			}else if(response.message.errors[0].errorCode === 'DCR-1010'){
				dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
					lazyModuleLoader.loadState('collections.dailyCashReport');					
				}, function() {});				
			}else if(response.message.errors[0].errorCode === 'DCR-1013'){
				dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
			}else{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,response.message.errors[0].message).result.then(function() {}, function() {});
			}
		};

		/** 
		 * PUT call - for hands off screen 'cfe'
		 * Approve batches
		 * Input - Array of Batch Id's
		 * author : Aishwerya , Dated: 19/3/2015 
		*/
		thisObj.approveBatches = function(batchArray,productType){
			collectionsServiceURL.challanServices.APPROVE_BATCHES.queryParams = {
					userrole:loggedUserDetails.hierarchyName,
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					view:'approveBatches'
			};
			if(environmentConfig.isDCR){
				collectionsServiceURL.challanServices.APPROVE_BATCHES.queryParams.dcr = true;
				collectionsServiceURL.challanServices.APPROVE_BATCHES.notify = false;
			}
			collectionsServiceURL.challanServices.APPROVE_BATCHES.urlParams = {};
			return restProxy.save('PUT',collectionsServiceURL.challanServices.APPROVE_BATCHES,{batchIDs:batchArray}).then(function(data){
				if(data.status === 'failed'){
					return data;
				} else{
					return data.data;
				}
			});
		};
		/**
		* Method to authorize challans
		*/
		this.authorizeChallans = function(challans){
			collectionsServiceURL.challanServices.AUTHORIZE_CHALLANS.queryParams = {
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					view : 'authoriseChallans'
			};
			collectionsServiceURL.challanServices.AUTHORIZE_CHALLANS.urlParams = {};
			return restProxy.save('PUT',collectionsServiceURL.challanServices.AUTHORIZE_CHALLANS,challans).then(function(response){
				return response.data;
			});
		};
		/**
		* Method to fetch the receipt details
		*/
		this.getReceiptDetails = function(date,cfeId,receiptType,productType,source)
		{
			collectionsServiceURL.batchingServices.GET_RECEIPTDETAILS.queryParams = {
					collectionAgentID : cfeId,
					view : 'getPendingReferences',
					stDate : date,
					endDate : date,
					product : productType,
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					source : source,
					isCancelled : (source && source.toUpperCase() === 'PENDING')
			};
			collectionsServiceURL.batchingServices.GET_RECEIPTDETAILS.urlParams = {};
			return restProxy.get(collectionsServiceURL.batchingServices.GET_RECEIPTDETAILS).then(function(data){
				return data.data;
			});
		};
		this.getDelayNoticationDetails = function(challanArray){
			collectionsServiceURL.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS.queryParams={
				'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
				'view':"BROWSERAUTHORIZATIONCHECK"
			};
			return restProxy.save('POST',collectionsServiceURL.challanServices.GET_DELAY_NOTIFICATION_RECEIPTS,{"challanNos":challanArray}).then(function(data){
				return data.data;
			});
		};
		this.updateDelayNotification = function(receiptArray){
			collectionsServiceURL.challanServices.POST_DELAY_REASON.queryParams={
				'userbranch':JSON.parse(getCookie('selectedBranch')).branchID,
				'view':"POSTRECEIPTSREASON"
			};
			return restProxy.save('POST',collectionsServiceURL.challanServices.POST_DELAY_REASON,receiptArray).then(function(data){
				return data.data;
			});
		};
	};
	handsOff.service('handsOffService',['$q','restProxy','$rootScope','$globalScope','environmentConfig','dialogService','lazyModuleLoader',handsOffService]);
	return handsOffService;
});
