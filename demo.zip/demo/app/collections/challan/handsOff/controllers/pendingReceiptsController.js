/**
 * Represents Pending Receipts Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'handsOff', 'constants', 'collectionConstants', 'utility' ], function(require, handsOff, constants, collectionConstantss, utility) {
	'use strict';
	/**
	 * Pending Receipts Controller function. Dependency
	 * $scope,$rootScope,$modal,handsOffService,dialogService.
	 */
	var pendingReceiptsController = function($scope, $rootScope, $modal, handsOffService, dialogService, $globalScope) {
		$scope.cfeDetails = {};
		$scope.dayObj = {};
		$scope.cfeId = '';
		$scope.isDayWise = false;
		$scope.noRecordFound = false;
		$scope.receiptType = 'receipt';
		var dateRange = {};
		var dayFlag = false;
		var init = function() {
			var today = new Date();
			var toDayStr = utility.formDateString(today, true);
			var yesterday = new Date(new Date().setDate(today.getDate() - 1));
			var yesterDayStr = utility.formDateString(yesterday, true);
			$scope.dateRange = $globalScope.isClickedViaMenu ? (toDayStr + ' - ' + toDayStr) : '';
			dateRange = {
				'today' : [ today, today ],
				'yesterday' : [ yesterday, yesterday ],
				'last7days' : [ new Date(new Date().setDate(today.getDate() - 6)), today ],
				'last30days' : [ new Date(new Date().setDate(today.getDate() - 29)), today ],
				'thisMonth' : [ new Date(new Date().setDate(1)), today ]
			};
			var days = [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ];
			$scope.dayObj[toDayStr] = 'Today';
			$scope.dayObj[yesterDayStr] = 'Yesterday';
			for (var i = 2; i < 7; i++) {
				var day = new Date(new Date().setDate(today.getDate() - i));
				var dayStr = utility.formDateString(day, true);
				$scope.dayObj[dayStr] = days[day.getDay()];
			}
			var pageDetails = handsOffService.getPageDetails();
			if (!$rootScope.isClickedViaMenu && $rootScope.filterValue != 'challanForAuth' && !pageDetails) {
				$rootScope.isClickedViaMenu = true;
				$scope.dateRange = '';
				$scope.receiptInfo = $scope.pendingReceipts;
				$scope.noRecordFound = $scope.receiptInfo.length ? false : true;
			}
		};
		init();
		/**
		 * Method to display receipts/acknowledgements for the selected date
		 * range
		 */
		$scope.datePopupContent = {
			onOpen : function(contentData) {
				contentData.currentDate = new Date();
				contentData.applyDateRange = function() {
					$scope.isDayWise = dayFlag;
					contentData.fromDate = contentData.fromDate ? contentData.fromDate : new Date();
					contentData.toDate = contentData.toDate ? contentData.toDate : new Date();
					var fromDate = utility.formDateString(contentData.fromDate, true);
					var toDate = utility.formDateString(contentData.toDate, true);
					$scope.dateRange = fromDate + ' - ' + toDate;
					$globalScope.isClickedViaMenu = true;
					contentData.close();
					$scope.getPendingList($scope.cfeId ? $scope.cfeId : 'all');
				};
				contentData.setDateRange = function(key) {
					if (key == 'today' || key == 'yesterday' || key == 'last7days')
						dayFlag = true;
					contentData.fromDate = dateRange[key][0];
					contentData.toDate = dateRange[key][1];
				};
				contentData.init = function() {
					dayFlag = false;
					if (!$scope.dateRange)
						return;
					var dateArr = $scope.dateRange.split(' - ');
					var fromDate = dateArr[0].split('-');
					var toDate = dateArr[1].split('-');
					contentData.fromDate = new Date(fromDate[2], parseInt(fromDate[1]) - 1, fromDate[0]);
					contentData.toDate = new Date(toDate[2], parseInt(toDate[1]) - 1, toDate[0]);
				};
				contentData.init();
			},
			close : function() {
				$scope.datePopupContent.close();
			}
		};
		/**
		 * Method to fetch pending receipts
		 */
		$scope.getPendingReceipts = function(cfeId) {
			var fromDate = '';
			var toDate = '';
			if ($rootScope.productType === 'VF' && $scope.dateRange) {
				var arr = $scope.dateRange.split(' - ');
				fromDate = arr[0].replace(/\//g, '-');
				toDate = arr[1].replace(/\//g, '-');
			}
			if (cfeId === 'all') {
				$scope.cfeId = '';
				$scope.isCFE = false;
				$scope.isDaywise = false;
			} else {
				$scope.cfeId = cfeId;
				$scope.isCFE = true;
			}
			$scope.receiptInfo = [];
			handsOffService.getPendingReceipts(cfeId, fromDate, toDate, $rootScope.productType).then(function(data) {
				if (!data || !data.length) {
					$scope.noRecordFound = true;
					$scope.cfeDetails = {};
				} else {
					$scope.noRecordFound = false;
					$scope.receiptInfo = data;
					$scope.cfeDetails = data[0].cfeDetails;
				}
			});
		};
		/**
		 * Method to show pending receipt details
		 */
		$scope.viewReceiptPopUp = function(date, source) {
			var receiptDate = date;
			date = date.replace(/\//g, '-');
			handsOffService.getReceiptDetails(date, $scope.cfeId, 'Receipt', $rootScope.productType, source).then(function(data) {
				$modal.open({
					templateUrl : 'app/collections/challan/handsOff/partials/receiptPopUp.html',
					controller : 'pendingReceiptsPopupController',
					size : 'lg',
					backdrop : 'static',
					resolve : {
						data : function() {
							return {
								popUpData : data,
								cfeDetails : $scope.cfeDetails,
								receiptDate : receiptDate,
								source : source
							};
						}
					}
				});
			});
		};
		/**
		 * Method to fetch pending acknowledgements
		 */
		var viewAckPopUp = function(data, cfeDetails, source) {
			$modal.open({
				templateUrl : 'app/collections/challan/handsOff/partials/ackPopUp.html',
				controller : 'pendingReceiptsPopupController',
				size : 'lg',
				backdrop : 'static',
				resolve : {
					data : function() {
						return {
							popUpData : data,
							cfeDetails : cfeDetails,
							source : source
						};
					}
				}
			});
		};

		$scope.getPendingAcknowledgements = function(cfeId, source) {
			var fromDate = '';
			var toDate = '';
			if ($rootScope.productType === 'VF') {
				var arr = $scope.dateRange.split(' - ');
				fromDate = arr[0].replace(/\//g, '-');
				toDate = arr[1].replace(/\//g, '-');
			}
			$scope.cfeId = '';
			$scope.isCFE = false;
			handsOffService.getAcknowledgementDetails(cfeId, fromDate, toDate, $rootScope.productType, source).then(function(data) {
				if (cfeId != 'all') {
					viewAckPopUp(data, data[0] ? data[0].cfeDetails : {}, source);
				} else {
					if (!data || !data.length) {
						$scope.noRecordFound = true;
						$scope.cfeDetails = {};
						$scope.ackInfo = [];
					} else {
						$scope.noRecordFound = false;
						$scope.ackInfo = data;
						$scope.cfeDetails = data[0].cfeDetails;
					}
				}
			});
		};
		/**
		 * Method to sort receipts by date
		 */
		$scope.sortByDate = function(receipt) {
			var date = receipt.id.split('/');
			if (date.length < 3)
				return;
			return new Date(date[1] + '/' + date[0] + '/' + date[2]);
		};
		/**
		 * Method to switch between receipts and acknowledgements
		 */
		$scope.getPendingList = function(empId, listType) {
			if (!empId && !listType)
				return;
			empId = empId ? empId : $scope.cfeId ? $scope.cfeId : 'all';
			$scope.receiptType = listType ? listType : $scope.receiptType;
			if ($scope.receiptType === 'receipt')
				$scope.getPendingReceipts(empId);
			else
				$scope.getPendingAcknowledgements('all');
		};
	};
	handsOff.controller('pendingReceiptsController', [ '$scope', '$rootScope', '$modal', 'handsOffService', 'dialogService', '$globalScope', pendingReceiptsController ]);
	return pendingReceiptsController;
});