/**
 * Represents Challan Authorization Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','handsOff','constants','collectionConstants'],function(require,handsOff,constants,collectionConstants){
	'use strict';
	/**
	* Challan Authorization Controller function.
	* Dependency $scope,$state,$timeout,$modal,$rootScope,handsOffService,dialogService. 
	*/
	var challanAuthController = function($scope,$rootScope,$state,$timeout,$modal,handsOffService,dialogService,masterService){
		var lastOpendItem = {};
		$scope.cfeId = '';
		$scope.checkAll = false;
		$scope.noRecordFound = false;
		$scope.sortObj = {
			isAmt : true,
			isBatchId : true
		};
		
		/**
		Method to get all unauthorized challans
		*/
		$scope.getPendingChallans = function(cfeId,sortBy,sortFlag){
			$scope.isCFE = cfeId==='all'?false:true;
			$scope.cfeId = cfeId==='all'?'':cfeId;
			handsOffService.getPendingChallans(cfeId,sortBy,sortFlag).then(function(data){
				$scope.checkAll = false;
				if(data && data.length)
				{
					$scope.noRecordFound = false;
					$scope.isNotSaved = false;
					$scope.isAuthorize = false;
					$scope.challanInfo = data;
					if(!$scope.bankNames||!$scope.bankNames.length)
						$scope.getBankNames();
				}
				else
				{
					$scope.noRecordFound = true;
					$scope.challanInfo = [];
				}
			});
		};

		/**
		Method to select all challans to authorize
		*/
		$scope.selectAll = function(event){
			$scope.isAuthorize = event.target.checked;
			_.each($scope.challanInfo, function(item){
				item.selected = event.target.checked;
			});
		};	
		/**
		Method to enable/disable Authorization
		*/
		$scope.setCheckboxState = function(item){
			$scope.checkAll = false;
			$scope.isAuthorize = false;
			_.each($scope.challanInfo, function(item) {
				if(item.selected)
				{
					$scope.isAuthorize = true;
					return;
				}
			});
		};
		/**
		Method to save the edited fields
		*/
		$scope.saveHandler = function(item){
			if(!(constants.REGULAR_EXPRESSION.alphaNumeric).test(item.physicalChallanNo))
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.INVALID_PHYSICAL_CHALLANNO);
				return;
			}
			if(!item.bankID)
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_BANK);
				return;
			}
			var reqObj = {};
			if(item.challanNo)
				reqObj.challanId = item.challanNo;
			if(item.physicalChallanNo)
				reqObj.physicalChallanNo = item.physicalChallanNo;
			if(item.bankID)
				reqObj.bankID = item.bankID;
			handsOffService.updateChallan(reqObj).then(function(data){		    			 
				item.edit = data.length?false:true;
				$scope.isNotSaved=false;
			});
		};
		/**
		Method to upload image files
		*/
		$scope.onFileSelect = function($files){
			var $file = $files[0];
			if($file.type.indexOf('image')>-1){
				$scope.dataUrls = [];
				if($file.type.indexOf('image')>-1){
					var fileReader = new FileReader();
					fileReader.readAsDataURL($files[0]);
					var loadFile = function(fileReader,index){
						fileReader.onload = function(e){
							$timeout(function(){
								$scope.dataUrls[index] = e.target.result;
							});
						};
					}(fileReader,0);
				}
			}
		};
		/**
		Method to modify branch name, Account name on bank change
		*/
		$scope.modifyBranch = function(challanDetail){
			var bank = _.findWhere($scope.bankNames,{bankID:challanDetail.bankID});
			challanDetail.bankdetails.bankBranch = bank.branchName;
			challanDetail.bankdetails.bankACNo = bank.bankACNo;
			challanDetail.bankdetails.bankName = bank.bankDesc;
		};
		/**
		Method to fetch chola bank masters
		*/
		$scope.getBankNames = function(){
			masterService.getBankName().then(function(data){
				$scope.bankNames = data ;
			});
		};
		
		/**
		Method to display the receipts of the selected batch
		*/
		$scope.getBatchDetails = function(item,index){
			handsOffService.getBatchDetails(item,index).then(function(data){
				data.receipts = data?data:{};
				$modal.open({
					templateUrl: 'app/collections/challan/handsOff/partials/batchDetailsPopup.html',
					controller: 'pendingReceiptsPopupController',
					size: 'lg',
					backdrop: 'static',
					resolve: {
						data: function(){
							return {
								popUpData: data,
								mode: item.mode
							};
						}
					}
				});
			});
		};
		/**
		Method to authorize the selected challans
		*/
		$scope.authorizeChallans = function(){
			var selectedChallan = _.pluck(_.where($scope.challanInfo,{selected:true}),'challanNo');
			handsOffService.getDelayNoticationDetails(selectedChallan).then(function(response){
				if(response.length>0){		
					notifyDelay(response);
				}else{
					proceedAuthorize();
				}
			});
		};
		var proceedAuthorize = function(){			
			var challanObj = {'challanNos':[]};
			_.each($scope.challanInfo,function(item){
				if(item.selected && item.challanNo)
					challanObj.challanNos.push(item.challanNo);
			});
			handsOffService.authorizeChallans(challanObj).then(function(data){
				if(data && data.length)
				{
					$scope.checkAll = false;
					$scope.getPendingChallans($scope.cfeId?$scope.cfeId:'all');
					$scope.isAuthorize = false;
				}	
			});
		};
		var notifyDelay = function(delayedchallans){		
			$modal.open({
				templateUrl: 'app/collections/challan/challaning/partials/delayNotificationPopup.html',
				controller: 'delayNotifyController',
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {
					data: function(){
						return {
							delayedchallans: delayedchallans
						};
					}
				}
			}).result.then(function () {}, function (value) {
				if(value && value!="escape key press"){
					dialogService.showAlert(collectionConstants.REPO_MSG.SUCCESS, collectionConstants.REPO_MSG.SUCCESS, "Reason and Remarks successfully updated").result.then(function () {}, function () {
					proceedAuthorize();
					});
				}																					
			});	
		};
		$scope.editHandler = function(item){
			masterService.getBankName('',item.mode==='CASH'?'C':'B','Bank').then(function(banks){
				item.edit=true;
				item.isNotSaved = false;
				$modal.open({
					templateUrl : 'app/collections/challan/handsOff/partials/challanDetailsPopup.html',
					controller : 'challanDetailsPopupController',
					size : 'lg',
					backdrop : 'static',
					windowClass : 'modal-custom',
					resolve : {
						data : function() {
							return {
								popUpData : item,
								bankList : banks
							};
						}
					}
				}).result.then(function(isSuccess){
					if(isSuccess){
						$scope.checkAll = false;
						$scope.getPendingChallans($scope.cfeId?$scope.cfeId:'all');
						$scope.isAuthorize = false;
					}
				});
			});
		};
		
		$scope.viewHandler = function(item){
			item.isNotSaved = true;
			item.edit=false;
			$modal.open({
				templateUrl : 'app/collections/challan/handsOff/partials/challanDetailsPopup.html',
				controller : 'challanDetailsPopupController',
				size : 'lg',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							popUpData : item							
						};
					}
				}
			}).result.then(function(isSuccess){
				if(isSuccess){
					$scope.checkAll = false;
					$scope.getPendingChallans($scope.cfeId?$scope.cfeId:'all');
					$scope.isAuthorize = false;
				}
			});				
			
			/*if($scope.isNotSaved)
				dialogService.showAlert('error','Warning!','Editing is in progress..Please save to proceed!');
			else{
				item.edit=true;
				$scope.isNotSaved = true;
			}			*/
		};
		var pageDetails = handsOffService.getPageDetails();
		if(!$rootScope.isClickedViaMenu&&$rootScope.filterValue=='challanForAuth' && !pageDetails){
			$scope.getPendingChallans('all');
			$rootScope.isClickedViaMenu = true;
		}
	};

	handsOff.controller('challanAuthController',['$scope','$rootScope','$state','$timeout','$modal','handsOffService','dialogService','masterService', challanAuthController]);
	return challanAuthController;
});