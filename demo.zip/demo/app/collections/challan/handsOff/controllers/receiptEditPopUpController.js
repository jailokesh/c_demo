/**
* Represents Pending Receipts Pop up Controller.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','handsOff','constants','DatePickerConfig','collectionConstants'],function(require,handsOff,constants,DatePickerConfig,collectionConstants){
	'use strict';	
	/**
	* Pop up controller function for Pending Receipts.
	* Dependency injection $scope,$modalInstance,data as parameters.
	*/
	var receiptEditPopUpController = function($scope,$modalInstance,data,dialogService,handsOffService,masterService){
		$scope.data = angular.copy(data.popUpData);
		$scope.bankList  = data.bankList;
		var minDate = new Date();
		minDate = new Date(minDate.setMonth(minDate.getMonth()-3));
		/*$scope.noRecords = false;
		$scope.data = [];
		$scope.mode = data.mode;
		$scope.receiptDate = data.receiptDate?data.receiptDate:'';
		if(!data.popUpData||!data.popUpData.length)
			$scope.noRecords = true;
		else
			$scope.data = data.popUpData;
		$scope.cfeDetails = data.cfeDetails?data.cfeDetails:{};*/
		/**
		* Method to close the modal pop up
		*/
		$scope.chequeDateConfig = new DatePickerConfig({
			//value: '',
			maxDate:new Date(),
			minDate:minDate
			//readonly: true
		});
		$scope.chequeDateConfig.setDateVal(new Date($scope.data.instrumentDetail.instrumentDate));
		//$scope.chequeDateConfig.minDate = new Date($scope.data.instrumentDetail.instrumentDate);
		//$scope.chequeDateConfig.setDateVal($scope.chequeDateConfig.minDate);
		//$scope.chequeDateConfig.value = (!$scope.chequeDateConfig.value) ? new Date() : $scope.chequeDateConfig.value;
		/**
		 * Method called when user saves the modified non-financial data of Cheque/DD Receipts
		*/
		
		$scope.saveHandler = function(item){
			if(!(constants.REGULAR_EXPRESSION.instrumentNo.test(item.instrumentDetail.instrumentNo)))
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ENTER_INSTRUMENT_NO);
				return;
			}
			if(!item.instrumentDetail.bankID||!item.instrumentDetail.bankBranchID)
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_BANKANDBRANCH);
				return;
			}
			
			item.instrumentDetail.instrumentDate = new Date($scope.chequeDateConfig.value);
			handsOffService.updateReceipt(item).then(function(data){
				if(data && data.length){
					item.bankDetail.bankName = _.findWhere($scope.bankList,{bankID:item.instrumentDetail.bankID}).name;
					item.bankDetail.branchName = _.findWhere($scope.branchList,{bBranchID:item.instrumentDetail.bankBranchID}).name;
					data.popUpData.instrumentDetail.instrumentNo = item.instrumentDetail.instrumentNo;
					item.edit = false;
					$scope.isDisabled = false;
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.SUCCESS_MSG.DETAILS_SUBMIT_SUCCESS);
					$modalInstance.dismiss();
				}
			});
			
		};
		/**
		 * 
		Method to fetch branch masters for the selected bank 
		*/
		$scope.getBranchFromBankID = function(chequeObj){
			if(!chequeObj.instrumentDetail.bankID){
				return;
			}
			chequeObj.bankDetail.micrCode = chequeObj.bankDetail.ifsCode = '';
			masterService.getBankBranches(chequeObj.instrumentDetail.bankID).then(function(data){
				$scope.branchList =  data;
			});
		};
		
		$scope.getBranchFromBankID($scope.data);
		/**
		 Method to get the IFSC Code of the selected branch
		*/
		
		
		$scope.populateMICR = function(bBranchId){
			if(!bBranchId){
				return;
			}
			$scope.data.bankDetail.micrCode = _.findWhere($scope.branchList,{bBranchID:$scope.data.instrumentDetail.bankBranchID}).micrCode; 
		};
		
		$scope.setBankDetails = function(){
			if($scope.branchList.length && $scope.branchList[0].micrCode===$scope.data.bankDetail.micrCode){
				return;
			}
			$scope.data.bankDetail.ifsCode = $scope.data.instrumentDetail.bankID = $scope.data.instrumentDetail.bankBranchID = '';
			$scope.branchList = [];
			if(!$scope.data.bankDetail.micrCode){
				return;
			}
			masterService.getBankIdFromMICR($scope.data.bankDetail.micrCode).then(function(data){
				$scope.branchList = data;
				if(!$scope.branchList.length){
					return;
				}
				$scope.data.bankDetail.ifsCode = $scope.branchList[0].ifsCode;
				$scope.data.instrumentDetail.bankID = $scope.branchList[0].bankID;
				$scope.data.bankDetail.bankName = _.findWhere($scope.bankList,{bankID:$scope.branchList[0].bankID}).name;
				$scope.data.bankDetail.branchName = $scope.branchList[0].name;
				$scope.data.instrumentDetail.bankBranchID = $scope.branchList[0].bBranchID;
			});
		};
		
		$scope.close = function(){
			$modalInstance.dismiss();
		};
	};
	handsOff.controller('receiptEditPopUpController',['$scope','$modalInstance','data','dialogService','handsOffService','masterService',receiptEditPopUpController]);
	return receiptEditPopUpController;
});