define(['require', 'handsOff', 'constants', 'utility'], function(r, handsOff, constants, utility) {
    'use strict';

    var delayNotifyController = function($scope, $state,handsOffService, messageBus, dialogService, $modal, $modalInstance,data,$rootScope) {
      
        $scope.notification = {reason:'',remarks:''};
        // var vdoData = data.vdoData;        
        $scope.remarksConstants = constants.DELAY_NOTIFICATION_REMARKS;
        var delayReceipts = data.delayedchallans;
        $scope.notificationData = _.uniq(_.flatten(_.pluck(delayReceipts,'receiptNos')));       
        $scope.close = function(val) {
            $modalInstance.dismiss(val);
        };
        $scope.handleRequest = function(notification){
            var reqObj={};
            if ($scope.notification.remarks && $scope.notification.reason) {                                
                var postReqObj=[];                
                _.each(data.delayedchallans,function(item){                                    
                    _.each(item.receiptNos, function(subitem){                                            
                        postReqObj.push({
                            "pendingWith": $rootScope.identity.userID,
                            "remarksData": [{
                                "remarks": $scope.notification.remarks,
                                "reason": $scope.notification.reason,
                                "approvalType": "TELLER_AUTHORIZATION",                        
                                "checkDate": new Date().toISOString(),
                                "numberOfDays" : item.numberOfDays
                            }],
                            "branchID": JSON.parse(getCookie('selectedBranch')).branchID,
                            "pendingReceiptAmount" : item.amountPaid,
                            "receiptNo" : subitem
                        });
                    });                    
                });     
                handsOffService.updateDelayNotification(postReqObj).then(function(data){
                    if(data){
                        $scope.close(data);
                    }
                });
            } else {
                dialogService.showAlert('Error', "Error", "Enter Reason/Remarks for Dealy");
                return;
            }
        };       
    };

    handsOff.controller('delayNotifyController', ['$scope', '$state', 'handsOffService', 'messageBus', 'dialogService','$modal', '$modalInstance','data','$rootScope', delayNotifyController]);
    return delayNotifyController;
});
