/**
 * Represents Handsoff Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','handsOff', 'constants','DatePickerConfig','collectionConstants', 'utility'], function(require,handsOff,constants,DatePickerConfig,collectionConstants,utility){
	'use strict';
	/**
	* Handsoff Controller function.
	* Dependency $scope,$state,$timeout,$modal,$rootScope,handsOffService,dialogService. 
	*/
	var handsOffController = function($scope,$state,$rootScope,$modal,handsOffService,masterService,dialogService,getPendingReceipts,appFactory,lazyModuleLoader,$globalScope){
		$scope.cfeId = '';
		$scope.handsOffs = [];
		$scope.receiptTypes = constants.RECEIPTTYPES;
		$scope.noRecordsFound = false;
		var minDate = new Date();
		minDate = new Date(minDate.setMonth(minDate.getMonth()-3));
		$scope.cfeDetails = {};
		$scope.searchSuccess = false;	
		$scope.isShowAll = false;
		var lastOpendItem = {};
		$scope.productTypes = $rootScope.identity.productDetails;
		
		$scope.activity = {};
		var initController = function(){
			$scope.activity.approve  = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CHALLANING.HANDS_OFF);
			$scope.activity.pendingReceipts  = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CHALLANING.PENDING_RECEIPT);
			$scope.activity.authorize  = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CHALLANING.CHALLAN_AUTH);
			var pageDetails = handsOffService.getPageDetails();
			if(!$globalScope.isClickedViaMenu){
				if(pageDetails){
					$scope.searchSuccess = true;
					$scope.cfeId = pageDetails.searchName;
					if(pageDetails.parentRow.mode === 'RPDC' && pageDetails.parentRow.details.length === 1){
						$scope.searchHandler($scope.cfeId);
					}else{
						$scope.handsOffs = pageDetails.data;
						$scope.cfeDetails = pageDetails.cfeDetails;
						pageDetails.parentRow.isClickedBefore = false;
						$scope.getBatchDetails(pageDetails.parentRow);
					}
				}else{
					if($rootScope.filterValue !== 'challanForAuth'){
						$scope.showPendingReceipts = true;
						$scope.pendingReceipts = getPendingReceipts;
					}
					else{
						$scope.showChallanAuth = true;
					}
				}
			}else{
				handsOffService.setPageDetails(null);
			}
		};
		
		$scope.chequeDateConfig = new DatePickerConfig({
			value: '',
			maxDate:new Date(),
			minDate:minDate,
			readonly: true
		});
		/** 
 		 * GET call - for hands off screen 'All' / 'cfe'
 		 * Lists down the hands off batches
 		 * author : Aishwerya , Dated: 19/3/2015
 		*/
		$scope.searchHandler = function(value,form){
			if(!value||!$rootScope.productType){
				return;
			}
			$scope.handsOffs = [];
			if(value === 'All'){
				$scope.searchSuccess = true;
				form.resetSubmited();
				$scope.isShowAll = true;
				handsOffService.searchHandler(value,$rootScope.productType).then(function(data){
					if(data){
						$scope.noRecordsFound = !(data.length);
						$scope.handsOffs = data;
						$scope.cfeDetails = {};
						$scope.isDisabled = false;
					}else{
						$scope.noRecordsFound = true;
					}
				});
			}else{
				$scope.searchSuccess = true;
				$scope.isShowAll = false;
				handsOffService.searchHandler(value,$rootScope.productType).then(function(data){
					if(data && data.length){
						if(!data[0].cfeDetails){
							$scope.cfeDetails = {};
							$scope.cfeDetails.cfeId = value;
							$scope.cfeDetails.cfeName = '';
						}else{
							$scope.cfeDetails = data[0].cfeDetails;
						}
						$scope.noRecordsFound = !(data.length);
						$scope.handsOffs = data;
						_.each($scope.handsOffs,function(item){
							item.isChecked = true; 
						});
						$scope.isDisabled = false;
					}else{
						$scope.noRecordsFound = true;
					}
				});
			}
		};
		/**
		Method to get bank/branch details for the given MICR Code
		*/
/**
		Method to fetch branch masters for the selected bank 
		*/
		$scope.getBranchFromBankID = function(chequeObj){
			if(!chequeObj.instrumentDetail.bankID){
				return;
			}
			chequeObj.bankDetail.micrCode = chequeObj.bankDetail.ifsCode = '';
			masterService.getBankBranches(chequeObj.instrumentDetail.bankID).then(function(data){
				$scope.branchList =  data;
			});
		};
		/**
		Method to get the IFSC Code of the selected branch
		*/
		$scope.getIFSCFromBranch = function(chequeObj){
			if(!chequeObj.instrumentDetail.bankBranchID){
				return;
			}
			chequeObj.bankDetail.ifsCode = _.findWhere($scope.branchList,{bBranchID:chequeObj.instrumentDetail.bankBranchID}).ifsCode; 
		};
		/** 
 		 * GET call - for hands off screen 'cfe'
 		 * Lists down the cfe data on expansion of the grid 
 		 * Input - Batch Id , Mode 
 		 * author : Aishwerya , Dated: 19/3/2015
 		*/
		$scope.getBatchDetails = function(item){
			lastOpendItem.isOpen = false;
			item.isOpen = true;
			lastOpendItem = item;
			if(item.isClickedBefore){
				return;
			}
			handsOffService.getBatchDetails(item).then(function(data){
				_.each(data.result,function(item){
					item.isSelected=false;
				});
				item.details = (!data) ? [] : data;
				item.validationError = false;
				_.each(item.details,function(value){
					if(value.validationMessage){
						value.validationMessage = !collectionConstants.ERROR_MSG[value.validationMessage] ? value.validationMessage : collectionConstants.ERROR_MSG[value.validationMessage];
						item.validationError = !value.isCancelled;
					}
					if(item.mode === 'PDD'){
						var pddObj = _.findWhere(collectionConstants.REPAY_MODES,{documentID:parseInt(value.pddAcknowledgementType)});
						value.pddType = pddObj.text;
						var pddType = pddObj.id == 'RC' ? pddObj.id : pddObj.id.toLowerCase();
						value.pddImage = {
								imageRef : value[pddType+'Detail'] ? value[pddType+'Detail'].imageRef : {}
						};
					}
				});
				
				item.isClickedBefore = true;
			});
		};
		/**
		Method to edit non-financial data of Cheque/DD Receipts
		*/
		var openEditPopup = function(item){
			$modal.open({
				templateUrl : 'app/collections/challan/handsOff/partials/receiptEditPopUp.html',
				controller : 'receiptEditPopUpController',
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							popUpData : item,
							bankList : $scope.bankList
						};
					}
				}
			});
		};
		var savePageData = function(item,cfeId,parentItem){
			var values = {
				data : $scope.handsOffs,
				searchName : cfeId,
				cfeDetails : $scope.cfeDetails,
				parentRow : parentItem
			};
			handsOffService.setPageDetails(values);
		};
		
		$scope.editHandler = function(item,cfeId,parentItem){
			savePageData(item,cfeId,parentItem);
			lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:item.receiptNo,type:'offline'});
		};
		
		initController();
		/**
		Method called when user saves the modified non-financial data of Cheque/DD Receipts
		*/
		$scope.saveHandler = function(item){
			if(!(constants.REGULAR_EXPRESSION.instrumentNo.test(item.instrumentDetail.instrumentNo)))
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ENTER_INSTRUMENT_NO);
				return;
			}
			if(!item.instrumentDetail.bankID||!item.instrumentDetail.bankBranchID)
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_BANKANDBRANCH);
				return;
			}	 
			item.instrumentDetail.instrumentDate = $scope.chequeDateConfig.value;
			handsOffService.updateReceipt(item).then(function(data){
				if(data && data.length){
					item.bankDetail.bankName = _.findWhere($scope.bankList,{bankID:item.instrumentDetail.bankID}).name;
					item.bankDetail.branchName = _.findWhere($scope.branchList,{bBranchID:item.instrumentDetail.bankBranchID}).name;
				}
				item.edit = false;
				$scope.isDisabled = false;
			});
		};
		/**
		Method to approve the batches of the selected CFE
		*/
		var proceed = function(){
			var challanArray = [];
			var noOfReceipts = 0;
			var totAmount = 0;
			_.each($scope.handsOffs,function(item){
				if(item.isChecked){
					noOfReceipts += item.referenceNo.length;
					totAmount += item.mode === 'CANCELLED' ? 0 : item.batchAmount;
					challanArray.push(item.batchID);
				}
			});
			if(!challanArray.length)
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_BATCH);
				return;
			}
			handsOffService.approveBatches(challanArray,$scope.productType).then(function(data){
				if (data && data.status === 'failed'){
					if(data.message.errors[0].errorCode === 'DCR-1009'){
						dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,collectionConstants.DAILY_CASH_REPORT.DELETE_DCR_MSG,true,true).result.then(function() {
							handsOffService.deleteCashReceipt($scope.productType).then(function(response){
								if(response){
									dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
										proceed();
									});
								}
							});
						}, function() {});						
					}
					else if(data.message.errors[0].errorCode === 'DCR-1010'){
						dialogService.confirm(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_MSG,false,true).result.then(function() {
							lazyModuleLoader.loadState('collections.dailyCashReport');					
						}, function() {});
					}else if(data.message.errors[0].errorCode === 'DCR-1013'){
						dialogService.showAlert(collectionConstants.ALERT, collectionConstants.ALERT,collectionConstants.DAILY_CASH_REPORT.DCR_APPROVAL_MSG).result.then(function() {}, function() {});					
					}else{
						dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,data.message.errors[0].message).result.then(function() {}, function() {});
					}
				}else if(data && data.length){
					totAmount = utility.currencyFormatter(totAmount);
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,challanArray.length+' batch(es) with '+noOfReceipts+' receipt(s) for an amount of Rs.'+totAmount+' are handed over successfully by '+$scope.cfeDetails.cfeId+'/'+$scope.cfeDetails.cfeName).result.then(function(){},function(){
						$state.current.forceReload = true;
						$state.transitionTo($state.current,{},{
							reload: true
						});
					});					
				}
			});
		};
		
		$scope.approveBatches = function(){
			var flag = false,hasError = _.findWhere($scope.handsOffs,{validationError:true, isChecked:true});
			var alertstring = '';
			if(hasError){
				dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error,collectionConstants.ERROR_MSG.HAS_ERROR_HANDSOFF);
				return;
			}
			if($rootScope.productType !== 'VF'){
				for(var len=0;len<$scope.handsOffs.length;len++){
					if($scope.handsOffs[len].partPaymentReceiptCount>0){
						if(!$scope.handsOffs[len].details){
							alertstring += $scope.handsOffs[len].batchID+',';
							flag = true;
							break;
						}
						for(var detaillen=0;detaillen<$scope.handsOffs[len].details.length;detaillen++){
							if($scope.handsOffs[len].details[detaillen].receiptType === 'PART PAYMENT' && !$scope.handsOffs[len].details[detaillen].isSelected){
								alertstring += $scope.handsOffs[len].batchID+',';
								flag = true;
								break;
							}
						}
					}
				}
			}
			if(!flag){
				proceed();			
			}
			else{
				dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING,collectionConstants.POPUP_HEADER.MESSAGE_STRING,collectionConstants.ERROR_MSG.PAYMENTLETTER_STATUS+alertstring.substring(0,alertstring.length-1)).result.then(function(){},function(){proceed();});
			}
		};
		
		$scope.cancelRPDC = function(item,cfeId,parentItem){
			savePageData(item,cfeId,parentItem);
			lazyModuleLoader.loadState('collections.cancelAck', {
				ackNo : item.pddAcknowledgementNo,
				type : 'RPDC-OFFLINE'
			});
		};
	};

	handsOff.controller('handsOffController',['$scope','$state','$rootScope','$modal','handsOffService','masterService','dialogService','getPendingReceipts','appFactory','lazyModuleLoader','$globalScope',handsOffController]);
	return handsOffController;
});
