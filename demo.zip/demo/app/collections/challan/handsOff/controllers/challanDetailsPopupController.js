define(['require','handsOff','constants','collectionConstants','DatePickerConfig'],function(require,handsOff,constants,collectionConstants,DatePickerConfig){
	'use strict';	
	/**
	* Pop up controller function for Pending Receipts.
	* Dependency injection $scope,$modalInstance,data as parameters.
	*/
	var challanDetailsPopupController = function($scope,$globalScope,$modalInstance,data,dialogService,handsOffService,masterService,$rootScope){
		$scope.challanCategoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Challan'});
		$scope.memoCategoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Fake note memo'});
		$scope.data = angular.copy(data.popUpData);		
		$scope.data.fakeAmount = $scope.data.fakeAmount ? parseInt($scope.data.fakeAmount) : '';
		var challanAmt = parseInt($scope.data.challanedAmount) + $scope.data.fakeAmount;
		var isSuccess;
		$scope.bankNames = '';//data.bankList;
		$scope.isEdited = true;		
		$scope.isNotSaved = $scope.data.isNotSaved;
		$scope.chequeDateConfig = new DatePickerConfig({
			maxDate:new Date()
		});
		$scope.chequeDateConfig.setDateVal(new Date($scope.data.physicalChallanedDate));
		var source,bankID,mode;
		if($scope.data.mode === "DD"){
			mode = "DRAFT";
		}
		else if($scope.data.mode === "CHEQUE-NON-MICR"){
			mode = "CHEQUE";
		}	
		else{
			mode = $scope.data.mode;
		}				
		if($scope.data.productGroup === 'DEALER'){
			source = 'DealerBank';
		}
		else{
			source = '';
			bankID = _.findWhere($rootScope.identity.selectedBranch.bankDetails, {paymentMode: mode, leapFunction: $scope.data.productGroup+"-COLLECTIONS"});
			bankID = (bankID && bankID.dealingBankIDs) ? bankID.dealingBankIDs : '';
		}	
		if(bankID || source){
			masterService.getBankName(bankID,mode==='CASH'?'C':'B',source).then(function(data){
				$scope.bankNames = data;
			});
		}
		else{
			$scope.bankNames = '';
		}		
		/**
		Method to authorize the selected challans
		*/
		$scope.authorizeChallans = function(item){
			var challanObj = {'challanNos':[item.challanNo]};
			isSuccess = false;
			handsOffService.authorizeChallans(challanObj).then(function(data){
				if(data && data.length)
				{
					isSuccess = true;
					$scope.$parent.checkAll = false;
					$scope.$parent.isAuthorize = false;
				}	
				$modalInstance.close(isSuccess);
			});
			
		};
		
		/**
		Method to save the edited fields
		*/
		$scope.saveHandler = function(item){
			var fakeAmt = parseInt(item.fakeAmount);
			if(fakeAmt === 0){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,"Fake note amount cant be zero");
				return;
			}
			if(!(constants.REGULAR_EXPRESSION.alphaNumeric).test(item.physicalChallanNo))
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.INVALID_PHYSICAL_CHALLANNO);
				return;
			}
			if(!item.bankID)
			{
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.SELECT_BANK);
				return;
			}
			if(fakeAmt && fakeAmt > challanAmt){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.INVALID_FAKENOTE_AMT);
				return;
			}
			if(!$scope.data.challanImageRef.imagePathReferences.length){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.UPLOAD_CHALLAN_IMG);
				return;
			}
			if(fakeAmt && !$scope.data.memoPathRef.imagePathReferences.length){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.UPLOAD_FAKENOTE_IMG);
				return;
			}
			var reqObj = {};
			if(item.challanNo){
				reqObj.challanId = item.challanNo;
			}
			if(item.physicalChallanNo && data.popUpData.physicalChallanNo !== item.physicalChallanNo ){
				reqObj.physicalChallanNo = item.physicalChallanNo;
			}
			if(item.bankID){
				reqObj.bankID = item.bankID;
			}
			reqObj.challanedAmount = item.challanedAmount;
			reqObj.fakeAmount = item.fakeAmount?parseInt(item.fakeAmount):0;
			reqObj.challanImageRef = $scope.data.challanImageRef;
			reqObj.memoPathRef = $scope.data.memoPathRef.imagePathReferences ? $scope.data.memoPathRef : '';
			reqObj.majorVersion = $scope.data.majorVersion ;
			reqObj.minorVersion = $scope.data.minorVersion;
			reqObj.physicalChallanedDate = new Date($scope.data.physicalChallanedDate).toISOString();
			isSuccess = false;
			handsOffService.updateChallan(reqObj).then(function(response){		    			 
				if(response && response.length){
					item.edit = true;
					$scope.isNotSaved=true;
					isSuccess = true;
					data.popUpData = angular.copy($scope.data);
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.SUCCESS_MSG.DETAILS_SUBMIT_SUCCESS).result.then(function(){},function(){
						//$modalInstance.close(isSuccess);
					});
				}
			});
			item.physicalChallanedDate = new Date($scope.chequeDateConfig.value);
		};
		
		/**
		Method to modify branch name, Account name on bank change
		*/
		$scope.modifyBranch = function(challanDetail){
			var bank = _.findWhere($scope.bankNames,{bankID:challanDetail.bankID});
			challanDetail.bankdetails = challanDetail.bankdetails || {};						
			challanDetail.bankdetails.bankBranch = bank.branchName;
			challanDetail.bankdetails.bankACNo = bank.bankACNo;
			challanDetail.bankdetails.bankName = bank.bankDesc;			
		};
		
		/**
		Method to fetch chola bank masters
		*/
		$scope.getBankNames = function(){
			masterService.getBankName().then(function(data){
				$scope.bankNames = data ;
			});
		};
		
		$scope.computeActual = function(){
			if(!$scope.data.fakeAmount){
				$scope.data.challanedAmount = challanAmt-0;
				return;
			}
			var fakeAmount = parseInt($scope.data.fakeAmount);
			if(fakeAmount>challanAmt ){
				return;
			}
			$scope.data.challanedAmount = challanAmt-fakeAmount;
			$scope.isEdited = false;
		};
		
		$scope.close = function(){
			if($scope.challan_auth_popup.$dirty){
				dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function(){
					$modalInstance.close(true);
				},function(){});
			}
			else{
				$modalInstance.dismiss();
			}
		};
	};
	handsOff.controller('challanDetailsPopupController',['$scope','$globalScope','$modalInstance','data','dialogService','handsOffService','masterService','$rootScope',challanDetailsPopupController]);
	return challanDetailsPopupController;
});