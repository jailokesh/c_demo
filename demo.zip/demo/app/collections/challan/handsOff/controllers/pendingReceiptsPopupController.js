/**
* Represents Pending Receipts Pop up Controller.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','handsOff'],function(require,handsOff){
	'use strict';	
	/**
	* Pop up controller function for Pending Receipts.
	* Dependency injection $scope,$modalInstance,data as parameters.
	*/
	var pendingReceiptsPopupController = function($scope,$modalInstance,data){
		$scope.noRecords = false;
		$scope.data = [];
		$scope.mode = data.mode;
		$scope.receiptDate = data.receiptDate?data.receiptDate:'';
		$scope.isBatched = data.source==='batched'?true:false;
		if(!data.popUpData||!data.popUpData.length){
			$scope.noRecords = true;
		}
		else{
			$scope.data = data.popUpData;
		}
		$scope.cfeDetails = data.cfeDetails?data.cfeDetails:{};
		/**
		* Method to close the modal pop up
		*/
		$scope.close = function(){
			$modalInstance.dismiss();
		};
	};
	handsOff.controller('pendingReceiptsPopupController',['$scope','$modalInstance','data',pendingReceiptsPopupController]);
	return pendingReceiptsPopupController;
});