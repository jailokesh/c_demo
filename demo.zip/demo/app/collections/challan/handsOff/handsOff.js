define(['require','collectionsApp','handsOffResolver'],function(require,collectionsApp,handsOffResolver){
	'use strict';
	/**
	* Contains the handsoff routing information.
	* Create and return the handsoff module.
	*/
	var baseViewUrl = 'app/collections/challan/handsOff/'; 
	var app = angular.module('handsOff',['common','ui.router','collections','angularFileUpload']);
	
	var handsOff = {
		name : 'collections.handsOff',
		url : '/handsOff',
		views : {
			'mainContent': {
				templateUrl: baseViewUrl + 'handsOff.html',
				controller: 'handsOffController',
				resolve: handsOffResolver
			}
		},
		data : {'headerText':'CFE - HandsOff',
				'stateActivity' : ['COL_APPROVE_HANDSOFF','COL_VIEW_PENDING_RECEIPTS','COL_CFE_CHALLAN_AUTHORIZATION']
			}
	};
	/**
	* Contains the handsoff configuration details.
	*/
	var handsOffsConfiguration = function($stateProvider, $urlRouterProvider){
		$stateProvider.state(handsOff);
	};
	
	app.config(['$stateProvider','$urlRouterProvider',handsOffsConfiguration]);
	return app;
});

