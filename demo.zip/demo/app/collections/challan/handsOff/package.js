define([],function(){
	'use strict';
	require.config({
		paths: {
			'handsOff': 'app/collections/challan/handsOff/handsOff',
			'handsOffController': 'app/collections/challan/handsOff/controllers/handsOffController',
			'pendingReceiptsController': 'app/collections/challan/handsOff/controllers/pendingReceiptsController',
			'challanAuthController': 'app/collections/challan/handsOff/controllers/challanAuthController',
			'handsOffResolver': 'app/collections/challan/handsOff/resolvers/handsOffResolver',
			'handsOffService': 'app/collections/challan/handsOff/services/handsOffService',
			'sharedPackage' : 'app/common/shared/package',
			'pendingReceiptsPopupController' : 'app/collections/challan/handsOff/controllers/pendingReceiptsPopupController',
			'receiptEditPopUpController' : 'app/collections/challan/handsOff/controllers/receiptEditPopUpController',
			'challanDetailsPopupController' : 'app/collections/challan/handsOff/controllers/challanDetailsPopupController',
			'delayNotifyController':'app/collections/challan/handsOff/controllers/delayNotifyController'
		},
		shim: {
			'handsOff': ['angular','angular-ui-router','handsOffResolver'],
			'handsOffService': ['handsOff'],
			'popUpController': ['handsOffService'],
			'handsOffController': ['handsOffService'],
			'pendingReceiptsController': ['handsOffService'],
			'challanAuthController': ['handsOffService'],
			'delayNotifyController':['handsOffService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['handsOffController','pendingReceiptsController','challanAuthController','pendingReceiptsPopupController','receiptEditPopUpController','challanDetailsPopupController','delayNotifyController'],callback);
			});
		});
	};
});