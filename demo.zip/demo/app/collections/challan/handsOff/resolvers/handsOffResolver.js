define([],function(){
	'use strict';
	/**
	 * Represents a HandsOff Resolver. 
	 * Dependency injection handsOffService as parameter.
	 */
	return {
		
		getPendingReceipts:['handsOffService','$rootScope',function(handsOffService,$rootScope){
			var pageDetails = handsOffService.getPageDetails();
			if($rootScope.isClickedViaMenu || pageDetails){
				return;
			}
			return handsOffService.getPendingReceipts('all',new Date(),new Date()).then(function(data){
				return data;
			});
		}]
	};
});