define(['require','collectionsApp','imageUploadResolver'],function(require,collectionsApp,imageUploadResolver){
	'use strict';
	/**
	* Contains the image upload routing information.
	* Create and return the image upload module.
	*/
	var baseViewUrl = 'app/collections/challan/imageUpload/';
	var app = angular.module('imageUpload',['ui.router','collections']);

	var imageUpload = {
		name : 'collections.imageUpload',
		url : '/imageReUpload/:challanId',
		views : {
			'mainContent': {
				templateUrl: baseViewUrl + 'imageUpload.html',
				controller: 'imageUploadController',
				resolve: imageUploadResolver
			}
		},
		data : {'headerText':'Challan Image Re-Upload',
				'backState':'collections.challanQueue',
				'stateActivity' : ['COL_CHALLAN_IMAGE_RE_UPLOAD']
			}
	};
	/**
	* Contains the image upload configuration details.
	*/
	var imageUploadConfiguration = function($stateProvider, $urlRouterProvider){
		$stateProvider.state(imageUpload);
	};
	app.config(['$stateProvider','$urlRouterProvider',imageUploadConfiguration]);
	return app;
});
