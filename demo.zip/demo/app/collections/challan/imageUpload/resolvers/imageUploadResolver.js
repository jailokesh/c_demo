define([],function(){
	'use strict';
	/**
	* Represents Image Upload Resolver.
	* Dependency injection imageUploadService,$rootScope as parameters.
	* Returns the challan details of the given challan Id.
	*/
    return {
        getChallanInfo: ['imageUploadService','$stateParams',function(imageUploadService,$stateParams){
			if(!$stateParams.challanId){
				return [];
			}
			return imageUploadService.getChallanInfo($stateParams.challanId).then(function(data){
				return data;
			});
        }]
    };
});