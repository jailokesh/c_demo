define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'imageUpload': 'app/collections/challan/imageUpload/imageUpload',
			'imageUploadService': 'app/collections/challan/imageUpload/services/imageUploadService',
			'imageUploadController': 'app/collections/challan/imageUpload/controllers/imageUploadController',
			'imageInsDefectPopUpController': 'app/collections/challan/imageUpload/controllers/imageInsDefectPopUpController',
			'imageUploadResolver': 'app/collections/challan/imageUpload/resolvers/imageUploadResolver'
		},
		shim: {
			'imageUpload': ['angular', 'angular-ui-router','imageUploadResolver'],
			'imageUploadController': ['imageUploadService'],
			'imageInsDefectPopUpController' : ['imageUploadService'],
			'handsOffService' : ['imageUpload']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['imageUploadController','imageInsDefectPopUpController'],callback);
			});
		});
	};
});