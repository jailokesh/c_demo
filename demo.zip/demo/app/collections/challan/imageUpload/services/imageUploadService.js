/**
* Represents Image Upload Service.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','imageUpload','collectionServiceURLs'],function(require,imageUpload,collectionServiceURLs){
	'use strict';
	/**
	* Represents a image Upload Service.
	* Image Upload Service function
	* Dependency injection $q,restProxy,authService as parameters.
	*/
	var imageUploadService = function($q,restProxy,$rootScope){
		
		/**
		* Method to retrieve the challan details of the given challan id
		*/
		this.getChallanInfo = function(challanId,isSearch){
			collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.queryParams = {
					userrole:($rootScope.identity.hierarchyName).toUpperCase(),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					view : 'getTellerChallans',
					searchBy : !isSearch ? 'challanNo' : 'physicalChallanNo',
					searchValue : challanId
			};
			collectionServiceURLs.challanServices.GET_PENDINGCHALLANS.urlParams = {};
			return restProxy.get(collectionServiceURLs.challanServices.GET_PENDINGCHALLANS).then(function(data){ 
				return data.data;
			});	
		};
		/**
		* Method to fetch the chola bank names
		*/
		/*this.getBankInfo = function(){
			return restProxy.get(collectionServiceURLs.masterServices.GET_CHOLABANKS).then(function(data){ 
				return data.data;
			});	
		};*/
		/**
		* Method to re-upload challan image
		*/
		this.submitChallan = function(obj,isPendingMemo){
			collectionServiceURLs.challanServices.EDIT_CHALLAN.queryParams = {
					userrole:($rootScope.identity.hierarchyName).toUpperCase(),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					view:"editChallan"
			};
			if(isPendingMemo){
				collectionServiceURLs.challanServices.EDIT_CHALLAN.queryParams.source = 'memoUpload';
				delete obj.challanImageRef;
			}
			collectionServiceURLs.challanServices.EDIT_CHALLAN.urlParams = {
					challanNo:obj.challanId
			};
			return restProxy.save('PUT',collectionServiceURLs.challanServices.EDIT_CHALLAN,obj).then(function(data){
				return data.data;
			});	
		};
	};
	imageUpload.service('imageUploadService',['$q','restProxy','$rootScope',imageUploadService]);
	return imageUploadService;
});