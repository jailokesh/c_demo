/**
* Represents an Image Upload Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','imageUpload','constants','utility','collectionConstants'],function(r,imageUpload,constants,utility,collectionConstants){
	'use strict';
	/**
	* Controller function for Image Upload module.
	* Dependency injection $scope,$modalInstance,imageUploadService,$modal as parameters.
	*/
	var imageUploadController = function($scope,$globalScope,$stateParams,$modal,getChallanInfo,authService,imageUploadService,masterService,messageBus,lazyModuleLoader,dialogService){
		var MAX_IMAGE_SIZE = 3;
		//$scope.challanId = $stateParams.challanId;
		$scope.data = {
			categoryDetails : _.findWhere($globalScope.imageCategories,{subCategory:'Challan'}),
			enableSearch : false,
			noRecords : false
		};
		/**
		Method to fetch the details of the given challan id
		*/
		var fetchChallanDetails = function(){
			if(Object.keys($scope.challanData).length){
				var initindex,rejectindex;
				$scope.data.enableSearch = true;
				$scope.data.noRecords = false;
				if((initindex = _.findLastIndex($scope.challanData.workflow,{workStatus:'INITIATED',requestType:'NOMEMOUPLOAD'})) > -1){
					if((rejectindex = _.findLastIndex($scope.challanData.workflow,{workStatus:'REJECTED',requestType:'NOMEMOUPLOAD'})) > -1 && rejectindex > initindex){
						$scope.imageDisable = false;
					}
					else if(_.findLastIndex($scope.challanData.workflow,{workStatus:'APPROVED',requestType:'NOMEMOUPLOAD'}) === -1){
						$scope.imageDisable = true;
					}
		        }				
		        if($scope.imageDisable){
		        	dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,"Approval is pending for memo upload request. Hence image upload is restricted.");
		        }
			}
			else{
				$scope.data.enableSearch = false;
				$scope.data.noRecords = true;
			}
			
		};

		if(getChallanInfo && getChallanInfo.length){
			$scope.challanData = getChallanInfo[0];
			$scope.data.challanId = $scope.challanData.physicalChallanNo; 
			$scope.data.enableSearch = true;
			$scope.data.noRecords = false;
			//fetchChallanDetails();
		}else{
			$scope.data.enableSearch = false;
			$scope.data.noRecords = true;
		}
		/*$scope.isPendingMemo = $globalScope.isPendingMemo||$scope.challanData.noMemoUpload;
		$globalScope.isPendingMemo = false;
		if((_.findLastIndex($scope.challanData.workflow,{workStatus:'REJECTED',requestType:'NOMEMOUPLOAD'}) > -1) && (_.findLastIndex($scope.challanData.workflow,{workStatus:'APPROVED',requestType:'NOMEMOUPLOAD'}) === -1)){        	
        	$scope.isPendingMemo = true;
        }
		if($scope.isPendingMemo){
			$scope.challanData.memoPathRef = {};
		}*/
		$scope.getChallanInfo = function(challanId){
			if(!challanId||!constants.REGULAR_EXPRESSION.alphaNumeric.test(challanId)){
				return; 
			}
			imageUploadService.getChallanInfo(challanId,true).then(function(response){
				$scope.challanData = response[0]?response[0]: [];
				$scope.data.enableSearch = $scope.challanData ? true : false; 
				$scope.data.noRecords = ($scope.challanData.length === 0);
				//fetchChallanDetails();
			});
		};		
		/*messageBus.onMsg('INSTRUMENTS',function(event,data){
			$scope.challanData.memoPathRef = data.memoPathRef;
			$scope.challanData.fakeNoteRemarks = data.fakeNoteRemarks;
			$scope.challanData.fakeNoteReason = data.fakeNoteReason;
		},$scope);*/
		
		/**
		Method to re-upload the challan image
		*/
		$scope.submitChallan = function(){
			var obj = {};			
			var imageLength = [];			
			_.each($scope.challanData.challanImageRef.imagePathReferences,function(item){
				if(!item.isDelete){
					imageLength.push(item);
				}
			});
			if(!imageLength.length){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.UPLOAD_CHALLAN_IMG);
				return;
			}else if(imageLength.length > MAX_IMAGE_SIZE){
				dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,"Cannot upload more than "+MAX_IMAGE_SIZE+" challan images");
				return;
			}
			if($scope.isPendingMemo){
				if((!$scope.challanData.memoPathRef||!$scope.challanData.memoPathRef.imagePathReferences)){
					dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,'Please upload fake note/memo image');
					return;
				}
				obj.branchID = $scope.challanData.branchID;
			}
			obj.challanId = $scope.challanData.challanNo;
			//obj.physicalChallanNo = $scope.challanData.physicalChallanNo;
			obj.physicalChallanedDate =  $scope.challanData.physicalChallanedDate;
			obj.challanedAmount = $scope.challanData.challanedAmount;
			obj.bankID =  $scope.challanData.bankID ;
			obj.challanImageRef = $scope.challanData.challanImageRef;	
			obj.memoPathRef = $scope.challanData.memoPathRef;
			obj.fakeAmount = $scope.challanData.fakeAmount;
			obj.fakeNoteRemarks =  $scope.challanData.fakeNoteRemarks;
			obj.majorVersion = $scope.challanData.majorVersion ;
			obj.minorVersion = $scope.challanData.minorVersion;
			if($scope.challanData.fakeNoteReason){
				obj.remarks = $scope.challanData.fakeNoteReason;
			}
			imageUploadService.submitChallan(obj,$scope.isPendingMemo).then(function(response){
				if(response && Object.keys(response).length){
					var alertString = "Details modified successfully";
					if($scope.isPendingMemo){
						alertString = 'Request is initiated for the uploaded fake note/memo image';
					}
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,alertString).result.then(function(){},function(){
						if($scope.isPendingMemo){
							lazyModuleLoader.loadState('collections.challaning');
						}
						else{
							lazyModuleLoader.loadState('collections.challanQueue');
						}
					});
				}
			});			
		};
		/**
		Method to show the instrument details pop up
		*/
		$scope.addInsDefPopUp = function(){
			//dialogService.showAlert(constants.ERROR_HEADER.warning,constants.ERROR_HEADER.warning,"This feature is temporarly not available.");
			//return;
			
			$modal.open({
			templateUrl: 'app/collections/challan/challanGeneration/partials/instrumentDefects.html',
			controller: 'imageInsDefectPopUpController',
			size: 'md',
			backdrop: 'static',
			windowClass: 'modal-custom',
			 resolve: {
                 data: function() {
                     return {
                    	 popUpData : $scope.challanData,
                    	 isImageReupload : true,
                    	 isPendingMemo : $scope.isPendingMemo,
                    	 imageDisable : $scope.imageDisable
                     };
                 }
             }
			});
		};	
	};
	imageUpload.controller('imageUploadController',['$scope','$globalScope','$stateParams','$modal','getChallanInfo','authService','imageUploadService','masterService','messageBus','lazyModuleLoader','dialogService', imageUploadController]);
	return imageUploadController;
});