/**
 * Represents image upload pop up Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','imageUpload','collectionConstants'],function(r,imageUpload,collectionConstants){
	'use strict';
	/**
	* Image upload popup Controller function.
	* Dependency $scope,$modalInstance as parameters
	*/
	var imageInsDefectPopUpController = function($scope,$globalScope,$modalInstance,data,messageBus,dialogService){
		$scope.close = function() {
			dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function(){
				$modalInstance.dismiss();
			},function(){});
        };  
        $scope.categoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Fake note memo'});
        var memoDeleteImages = [],intrumentObj = angular.copy(data.popUpData);
        if(intrumentObj.memoPathRef && intrumentObj.memoPathRef.imagePathReferences){
        	for(var i= intrumentObj.memoPathRef.imagePathReferences.length -1; i>=0; i--){
        		var obj = intrumentObj.memoPathRef.imagePathReferences[i];
        		if(obj.isDelete){
        			memoDeleteImages.push(obj);
        			intrumentObj.memoPathRef.imagePathReferences.splice(i,1);
        		}
        	}
        }
        $scope.instrument =  intrumentObj;
        $scope.instrument.isUploadImg = ($scope.instrument.memoPathRef && $scope.instrument.memoPathRef.imagePathReferences && $scope.instrument.memoPathRef.imagePathReferences.length > 4 && $scope.instrument.memoPathRef.imagePathReferences[4].imageRefID) ? true : false;
        $scope.instrument.isOnlyImage = data.isImageReupload;
        $scope.instrument.isPendingMemo = data.isPendingMemo;
        $scope.instrument.remarks = data.popUpData.fakeNoteRemarks;
        $scope.imageDisable = data.imageDisable;
        
       
        $scope.saveInstrument = function(){   
        	var msg = $scope.instrument.mode === 'CASH' ? collectionConstants.ERROR_MSG.UPLOAD_FAKENOTE_IMG : collectionConstants.ERROR_MSG.UPLOAD_DAMAGEDINST_IMG;
        	if(!$scope.instrument.memoPathRef || !$scope.instrument.memoPathRef.imagePathReferences || !$scope.instrument.memoPathRef.imagePathReferences.length){
    			dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE,collectionConstants.ERROR_MSG.ERROR_MESSAGE,msg);
				return;
    		}  
        	dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.POPUP_HEADER.CONFIRM_STRING,'Are you sure you want to save the details?').result.then(function(){
        		var instrumentDetails = {};		
        		instrumentDetails.fakeAmount = $scope.instrument.fakeAmount;
        		instrumentDetails.fakeNoteReason = $scope.instrument.fakeNoteReason;
        		instrumentDetails.fakeNoteRemarks = $scope.instrument.fakeNoteRemarks;
        		$scope.instrument.memoPathRef.imagePathReferences = _.union($scope.instrument.memoPathRef.imagePathReferences,memoDeleteImages);
        		instrumentDetails.memoPathRef = $scope.instrument.memoPathRef;
        		messageBus.emitMsg("INSTRUMENTS",instrumentDetails);
        		$modalInstance.close();	
			},function(){});
    	};
    	
    	$scope.setImageCount = function(){
    		var imageobj = [];
    		if($scope.instrument.memoPathRef && $scope.instrument.memoPathRef.imagePathReferences){
    			_.each($scope.instrument.memoPathRef.imagePathReferences,function(item){
    				if(!item.isDelete){
    					imageobj.push(item);
    				}
    			});
    		}
    		$scope.instrument.isUploadImg = (imageobj.length > 4);
    	};
	};
	imageUpload.controller('imageInsDefectPopUpController',['$scope','$globalScope','$modalInstance','data','messageBus','dialogService',imageInsDefectPopUpController]);
	return imageInsDefectPopUpController;
});

