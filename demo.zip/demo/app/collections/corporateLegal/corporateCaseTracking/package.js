/** Story Id : Corporate case tracking 
 * Created By - OFS
 * Represents a Package file for Corporate case tracking .
 * @version v1.0 Date: 22-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the Corporate case tracking  module file names with their paths.
     * Contains the Corporate case tracking  required dependency configuration.
     */
    require.config({
        paths: {
            'corpCaseTracking': 'app/collections/corporateLegal/corporateCaseTracking/corpCaseTrackingQueue',
            'corpCaseTrackingController': 'app/collections/corporateLegal/corporateCaseTracking/controllers/corpCaseTrackingController',
            'caseTrackBulkUpdationController': 'app/collections/corporateLegal/corporateCaseTracking/controllers/caseTrackBulkUpdationController',
            'corporateQueController' : 'app/collections/corporateLegal/corporateCaseTracking/controllers/corporateQueController',
            'versionCorporateHistoryController' : 'app/collections/corporateLegal/corporateCaseTracking/controllers/versionCorporateHistoryController',
            'corporateLegalStagesController' : 'app/collections/corporateLegal/corporateCaseTracking/controllers/corporateLegalStagesController',
            'corpExpenseDetailsController' : 'app/collections/corporateLegal/corporateCaseTracking/controllers/corpExpenseDetailsController',
            'corporateCaseService' : 'app/collections/corporateLegal/corporateCaseTracking/services/corporateCaseService',
            'corpCTBulkUpdationService' : 'app/collections/corporateLegal/corporateCaseTracking/services/corpCTBulkUpdationService',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
            'corporateCaseResolver': 'app/collections/corporateLegal/corporateCaseTracking/resolvers/corporateCaseResolver',
            'childCaseLegalStageController' : 'app/collections/corporateLegal/corporateCaseTracking/controllers/childCaseLegalStageController'
            
        },
        shim: {
            'corpCaseTracking': ['angular', 'angular-ui-router', 'corporateCaseResolver'],
            'corpCaseTrackingController':['corpCaseTracking', 'corporateCaseService'],
            'caseTrackBulkUpdationController':['corpCaseTracking', 'corpCTBulkUpdationService'],
            'corporateQueController' :  ['corpCaseTracking'],
            'corporateLegalStagesController' : ['corpCaseTracking'],
            'versionCorporateHistoryController' : ['corpCaseTracking'],
            'corpExpenseDetailsController' : ['corpCaseTracking'],
            'childCaseLegalStageController'  : ['corpCaseTracking']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the Corporate case tracking module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpCaseTrackingController', 'caseTrackBulkUpdationController', 'workplanController','corporateQueController','corporateLegalStagesController','versionCorporateHistoryController','corpExpenseDetailsController','childCaseLegalStageController'], callback);
            });
        });
    };
});