/** Story Id : Corporate case tracking 
 * Created By - OFS
 * Represents a resolver for corporate case tracking.
 * @version v1.0 Date:  05-04-2018
 */
define([], function() {
'use strict';

	/**
	 * Returns the corporate case information
	 */
	var corporateCaseDetailsResolver = {
		getCorporateCases : [ 'corporateCaseService', '$stateParams', function(corporateCaseService, $stateParams) {
			if ($stateParams.caseID) {
				return corporateCaseService.getCholaCaseDetails($stateParams.caseID).then(function(data) {
					return data;
				});
			} else {
				return;
			}
		} ]
	};
	/**
	 * Returns the Agreement based info
	 */
	var agreementResolver = {
		getCorporateAgreementCases : [ 'corporateCaseService', '$stateParams', function(corporateCaseService, $stateParams) {
			return corporateCaseService.getAgreementCases($stateParams.agreementNo).then(function(data) {
				return data;
			});
		} ]
	};
	/**
	 * Returns the Agreement based info
	 */
	var corporateQResolver = {
		getCorporateQueue : [ 'corporateCaseService','$globalScope','$q', function(corporateCaseService,$globalScope,$q) {
			if(!$globalScope.isClickedViaMenu){
				var details = corporateCaseService.getPageDetails();
				return $q.when(details);
			}
			return corporateCaseService.getCorporateQueue({}).then(function(data) {
				return data;
			});
		} ]
	};
	/**
	 * Returns the Agreement based info getCorporateLegalStages
	 */
	var getCorporateLegalStagesResolver = {
		getCorporateLegalStages : [ 'corporateCaseService', '$stateParams', function(corporateCaseService, $stateParams) {
			return corporateCaseService.getCorporateLegalStages($stateParams.caseID).then(function(data) {
				return data;
			});
		} ]
	};
	/**
	 * get expense types
	 */
	var getExpenseTypesResolver = {
		getExpenseList : [ 'masterService', function(masterService) {
			return masterService.getExpenseList().then(function(data) {
				return data;
			});
		}]
	};
	/**
	 * get common header info
	 */
	var getHeaderInfoResolver = {
		getHeaderInfo : [ 'corporateCaseService','$stateParams', function(corporateCaseService, $stateParams) {
			return corporateCaseService.getHeaderInfo($stateParams.agreementNo).then(function(data) {
				return data;
			});
		}]
	};
	/**
	 * get Right pane details
	 */
	var getCorpCaseRightPaneInfoResolver = {
	 	getCorpCaseAsideInfo : ['corporateCaseService','$stateParams',
 	    function(corporateCaseService,$stateParams) {
 		    return corporateCaseService.getRightPaneDetails($stateParams.agreementNo).then(function(data){
 			    return data;
 		    });
 	   }]
	 };
    /**
	 * get zone details
	 */
	var getZoneDetailsResolver = {
	 	getZones : [ 'corporateCaseService', function(corporateCaseService) {
	 		return corporateCaseService.getUserDataMapping();
	 	} ]
	};
    /**
	 * get 'assigned to' details
	 */
	var getAssignedToDetailsResolver = {
	 	getManagerInfo: ['corporateCaseService',function(corporateCaseService,$stateParams) {
	 		return corporateCaseService.getManagerList().then(function(data){
	 			return data;
	 		});
	 	}]
	 };
    /**
	 * get advocate details
	 */
	var getAdocateDetailsResolver = {
		getAdvocateInfo: ['corporateCaseService',function(corporateCaseService,$stateParams) {
            return corporateCaseService.getAdvocateList(true).then(function(data){
            	return data;
            });
        }]
    };
    /**
	 * get advocate details
	 */
	var getBUAdocateDetailsResolver = {
		getBUAdvocateInfo: ['corpCTBulkUpdationService',function(corpCTBulkUpdationService,$stateParams) {
            return corpCTBulkUpdationService.getAdvocateList(true).then(function(data){
            	return data;
            });
        }]
    };
	return {
		getCorporateAgreementCases : agreementResolver,
		getCorporateCases : corporateCaseDetailsResolver,
		getCorporateQueue : corporateQResolver,
		getCorporateLegalStages : getCorporateLegalStagesResolver,
		getExpenseList:getExpenseTypesResolver,
		getHeaderInfo : getHeaderInfoResolver,
		getCorpCaseAsideInfo : getCorpCaseRightPaneInfoResolver,
		getZones : getZoneDetailsResolver,
		getManagerInfo : getAssignedToDetailsResolver,
        getAdvocateInfo : getAdocateDetailsResolver,
        getBUAdvocateInfo: getBUAdocateDetailsResolver
	};
});