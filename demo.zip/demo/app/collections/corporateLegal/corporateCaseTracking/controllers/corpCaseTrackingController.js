 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  05-04-2018
 */
define(['require','collectionConstants','corpCaseTracking','utility','constants','legalConstants','corpLegalConstants' ], function(r,collectionConstants,corpCaseTracking,utility,constants,legalConstants,corpLegalConstants) {
'use strict';
	/** Legal case Controller function.| Dependency injection | $scope,corporateCaseService as parameters. */
	var corpCaseTrackingController = function($scope, $state, $stateParams, corporateCaseService, dialogService, lazyModuleLoader, getCorporateQueue, $rootScope,collectionFactory,$globalScope,$modal, getAdvocateInfo) {
		$scope.productTypes = angular.copy($rootScope.identity.productDetails);
		$scope.productTypes.push({value: "Others", id: $scope.productTypes.length});
		$scope.productType = $rootScope.productTypes;
		$scope.data = {};
		var dateRange = {}, params = {},dateObj;
		$scope.searchType = angular.copy(legalConstants.LEGAL_VALUES.LEGAL_Q_SEARCH);
		$scope.advocateList = getAdvocateInfo.advocates;
		
		$scope.filterPopup = {
			onOpen : function(contentData) {
				contentData.options = angular.copy($scope.data.mainMenu);
				contentData.isAll = $scope.data.isAll;
			},
			isAllSelected : function(options) {
				collectionFactory.isAllSelected(options, $scope.filterPopup.isAll);
			},
			checkAll : function(options) {
				$scope.filterPopup.isAll = collectionFactory.filterCheckAll(options);
			},
			filterQueue : function(options, isDone) {
				$scope.filterPopup.reqObj = {};
				$scope.data.isAll = $scope.filterPopup.isAll;
				$scope.data.mainMenu = angular.copy(options);
				if (typeof $scope.filterPopup.close === 'function') {
					$scope.filterPopup.close();
				}
				if (isDone) {
					$scope.filterPopup.reqObj = collectionFactory.filterQueue(options, $scope.filterPopup.reqObj, $scope.filterPopup.isAll, !isDone);
					if (!$scope.filterPopup.reqObj) {
						return;
					}
				}
				$scope.filterPopup.reqObj.filterSec = $scope.filterPopup.reqObj.legalSections ? $scope.filterPopup.reqObj.legalSections.join() : '';
				$scope.filterPopup.reqObj.filterStatus = $scope.filterPopup.reqObj.workStatus ? $scope.filterPopup.reqObj.workStatus.join() : '';
				$scope.searchBy(1);
			},
			resetAndClose : function() {
				$scope.filterPopup.close();
			}
		};
		$scope.filterPopup.reqObj = {
			legalSections : '',
			workStatus : ''
		};
		var dateFormat = function(date,hour,minutes,seconds) {
			var formateDate = date.match(/(\d{2})-(\d{2})-(\d{4})/);
			var newFormateDate = formateDate[2]+"-"+formateDate[1]+"-"+formateDate[3];
			newFormateDate = new Date(newFormateDate);
			return newFormateDate.setHours(hour,minutes,seconds);
		}
		$scope.searchBy = function(currentPage) {
			params = {};
			$scope.data.pageNo = currentPage ? currentPage : 1;
			params.offset = currentPage ? currentPage : 1;
			params.productGroup = $rootScope.productTypes;
			if ($scope.data.dateRange) {
				params.stDate = dateFormat($scope.data.dateRange.split(" / ")[0],0,0,0);
				params.endDate = dateFormat($scope.data.dateRange.split(" / ")[1],23,59,59);
				params.isCount = true;
			}
			if ($scope.data.currentSearch.value) {
				params[$scope.data.currentSearch.value] = $scope.data.searchParams;
			}
			if ($scope.filterPopup.reqObj) {
				params.workStatus = $scope.filterPopup.reqObj.filterStatus;
				params.legalSections = $scope.filterPopup.reqObj.filterSec;
				params.isCount = true;
			}
			corporateCaseService.getCorporateQueue(params).then(function(response) {
				$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
				if (response.data) {
					$scope.data.corporateCase = response.data.length ? response.data : [];
					$scope.data.offset = (currentPage - 1) * $scope.data.limit;
					$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
				} else {
					$scope.data.legalCases = [];
				}
			});
		};
		var uniqueFilterOptions = function(c){
			var uniqueValues =_.uniq(_.pluck(c.reverse(),'value'));
			uniqueValues.reverse();
			var uniqueObjects = _.filter(c,function(item){
				if(uniqueValues.indexOf(item.value)>-1){
			uniqueValues.splice(uniqueValues.indexOf(item.value),1);
			return true;
			}return false;}) ;
			$scope.legalSections = uniqueObjects.reverse();
		};
		var init = function() {
			var today = new Date();
			var yesterday = new Date(new Date().setDate(today.getDate() - 1));
			$scope.data.limit = 5;
			if (!$globalScope.isClickedViaMenu) {
				$scope.data = getCorporateQueue.data;
				$scope.filterPopup.reqObj = {};
				$scope.filterPopup.reqObj.filterStatus = _.pluck(_.where($scope.data.mainMenu[1].subMenu,{selected : true}),'value');
				$scope.filterPopup.reqObj.filterSec = _.pluck(_.where($scope.data.mainMenu[0].subMenu,{selected : true}),'value');
				$scope.searchBy($scope.data.pageNo);
			} else {
				$scope.data.offset = 0;
				$scope.legalSections = corpLegalConstants.LEGAL_VALUES.SECTIONS;
				uniqueFilterOptions($scope.legalSections);
				$scope.data.currentSearch = angular.copy(legalConstants.LEGAL_VALUES.LEGAL_STOCK_CURRENT_SEARCH);
				$scope.flagStatus = legalConstants.CASE_STATUS_DOCSQ;
				$scope.data.mainMenu = [ {
					label : "Legal Sections",
					value : "legalSections",
					selected : false,
					subMenu : $scope.legalSections
				}, {
					label : "Status",
					value : "workStatus",
					selected : false,
					subMenu : $scope.flagStatus
				}];
				$scope.data.corporateCase = getCorporateQueue.data || [];
				$scope.data.totalRecord = (getCorporateQueue.meta && getCorporateQueue.meta.count) ? parseInt(getCorporateQueue.meta.count) : 0;
				$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
			}

			dateRange = {
				'today' : [ today, today ],
				'yesterday' : [ yesterday, yesterday ],
				'last7days' : [ new Date(new Date().setDate(today.getDate() - 6)), today ],
				'last30days' : [ new Date(new Date().setDate(today.getDate() - 29)), today ],
				'thisMonth' : [ new Date(new Date().setDate(1)), today ]
			};
			$scope.data.workStatus = legalConstants.LEGAL_WORK_STATUS;
		};
		init();
		
		/**
		 * Method to display Legal cases for the selected date range
		 */
		$scope.datePopupContent = {
			onOpen : function(contentData) {
				contentData.applyDateRange = function() {
					dateObj = collectionFactory.applyDateRange(contentData);
					$scope.data.dateRange = dateObj.fromDate + ' / ' + dateObj.toDate;
					$scope.searchBy(1);
				};
				contentData.setDateRange = function(key) {
					contentData.fromDate = dateRange[key][0];
					contentData.toDate = dateRange[key][1];
				};
				contentData.init = function() {
					if ($scope.data.dateRange) {
						dateObj = collectionFactory.initDate($scope.data.dateRange);
						contentData.fromDate = dateObj.fromDate;
						contentData.toDate = dateObj.toDate;
					}
				};
				contentData.clear = function(){
					$scope.data.dateRange = '';
					$scope.searchBy(1);
				};
				contentData.init();
			},
			close : function() {
				$scope.datePopupContent.close();
			}
		};
		/**
		 * Method is to get Advocate List with AdvocateName and AdvocateID
		 */
		$scope.onAdvocateChange = function(item) {
			var advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}) ? _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName : '-';
			return advocateName;
		}
		/** Method for Pagination */
		$scope.paginationHandler = function(currentPage) {
			$scope.searchBy(currentPage);
		};
		var documentsReceivedCheck = function(legalData) {
			var pageObj = {
				data : $scope.data,
			};
			corporateCaseService.setPageDetails(pageObj);
			corporateCaseService.setLegalDetails(legalData);
			$stateParams.agreementNo = legalData.agreementNo;
			
			if (!legalData.childCase && legalData.workStatus =='CORPORATECASEFILED' && legalData.corporateStageLength==0) { //getCorporateCases.parentCaseID
				lazyModuleLoader.loadState("collections.corpCaseTracking.childCase", {caseID : legalData.caseID});

			}else{
				lazyModuleLoader.loadState('collections.corpCaseTracking.stages',{agreementNo : legalData.agreementNo,caseID : legalData.caseID});
			}
		};
		$scope.moreHandler = function(legalData) {
			$globalScope.isClickedViaMenu = true;
			documentsReceivedCheck(legalData);
		};
		$scope.legalSearch = function(value) {
			$scope.data.searchParams = '';
			$scope.data.placeholder = value ? _.findWhere($scope.searchType, {value : value}).type : '';
		};
		/** Method to Search Legal cases by Agreement No & Case ID */
		$scope.searchByAgreement = function(type, val) {
			if (val === '') {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (val.length < legalConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + legalConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
			$scope.searchBy(1);
		};

		/** CIF Id click navigates to Case details summary */
		$scope.navigateToCaseDetails = function(data) {
			var agreementNumber = data.agreementNo;
			$rootScope.agreementList = data.workflow[0].agreementNos;
			var pageObj = {
					data : $scope.data,
			};
			corporateCaseService.setPageDetails(pageObj);
			lazyModuleLoader.loadState('collections.caseDetail', {
				agreementNo : agreementNumber
			});
		};
		/** Change product type */
		$scope.setProductType = function() {
			$scope.searchBy(1);
		};
		/** BULKUPDATION **/
		$scope.showBulkUpdationList = function() {
			var pageObj = {
				data : $scope.data,
			};
			corporateCaseService.setPageDetails(pageObj);
			lazyModuleLoader.loadState('collections.caseTrackBulkUpload',{serviceProvider:'CORPORATECASESTAGETRACKING'});			
		};
	};
	corpCaseTracking.controller('corpCaseTrackingController', [ '$scope', '$state', '$stateParams', 'corporateCaseService', 'dialogService', 'lazyModuleLoader', 'getCorporateQueue', '$rootScope','collectionFactory','$globalScope','$modal','getAdvocateInfo', corpCaseTrackingController]);
	return corpCaseTrackingController;
});