 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  05-04-2018
 */
define([ 'require', 'corpCaseTracking', 'collectionConstants','legalConstants','corpLegalConstants' ], function(r, corpCaseTracking, collectionConstants,legalConstants, corpLegalConstants) {
'use strict';
	/**Legal case Controller function. Dependency injection | $scope,stageQueueService as parameters.*/
	var corporateLegalStagesController = function($scope, $state, $stateParams, $modal, corporateCaseService, lazyModuleLoader, dialogService,  $rootScope,getCorporateLegalStages, getCorporateCases, getZones, getManagerInfo ,getAdvocateInfo ) { 
		$scope.legalDetails = corporateCaseService.getLegalDetails();
		if ($scope.legalDetails.childCase) {
			dialogService.showAlert('Alert', 'Warning', collectionConstants.SUCCESS_MSG.IS_CHILD).result.then(function() {
			}, function() {});
		}
		if (!$scope.legalDetails.childCase && $scope.legalDetails.workStatus =='CORPORATECASECLOSED') {
			dialogService.showAlert('Alert', 'Warning', $scope.legalDetails.caseID+collectionConstants.SUCCESS_MSG.CASE_CLOSED_REOPEN_IT).result.then(function() {
			}, function() {});
		}
		$scope.data = {};
		$scope.data.isAppeal = getCorporateCases ? getCorporateCases.isAppeal : false;
		$scope.data.isComplaince = getCorporateCases ? getCorporateCases.isComplaince : false;
		$scope.stages = {};
		$scope.stages.parentStage = getCorporateLegalStages[0].stageNames;
		$scope.selectedStage =$scope.stages.parentStage && $scope.stages.parentStage.length ? $scope.stages.parentStage[$scope.stages.parentStage.length-1]:''; //$scope.stages.parentStage[0];
		$scope.stages.stageVersions = getCorporateLegalStages[0].corporateCaseStage[$scope.selectedStage];
		var caseObject = {};
		caseObject.majorVersion = $scope.legalDetails.majorVersion;
		caseObject.minorVersion = $scope.legalDetails.minorVersion;
		$scope.advocateObj = "";
		$scope.getAdvName = function(item){
			$scope.advocateObj = _.findWhere(getAdvocateInfo.advocates, {AdvocateID : item.advocateID});
		}

		/** selected stage populates its respective versions */
		$scope.setStageValues = function(currentObj) {
			$scope.selectedStage = currentObj;
			$scope.stages.stageVersions = getCorporateLegalStages[0].corporateCaseStage[$scope.selectedStage];
		};
		/** selected version stage populates its history */
		$scope.showVersionStage = function(stageID) {
			var loginHierarchyID = $rootScope.identity.primaryHierarchyID;
			var stageVersions = angular.copy($scope.stages.stageVersions);
			var selectedIndex = _.findIndex(stageVersions, {caseStageID : stageID});
			var selectedVersionStage = stageVersions[selectedIndex];
			var params = {
				'createdBy': getCorporateCases.createdBy
	    	};
	    	corporateCaseService.getVersionUserEdit(params).then(function(response) {
	    		$scope.createdByHerID = response.data;
	    		$scope.isEditHierarchyID = false;
            	if(corpLegalConstants.HIERARCHYSTAGE[$scope.createdByHerID[0].primaryHierarchyID] >= corpLegalConstants.HIERARCHYSTAGE[loginHierarchyID]){
            		$scope.isEditHierarchyID = true;
            	}
            	else{
            		$scope.isEditHierarchyID = false;
            	}
				$modal.open({
					templateUrl : 'app/collections/corporateLegal/corporateCaseTracking/partials/versionHistoryPopup.html',
					controller : 'versionCorporateHistoryController',
					size : 'lg',
					backdrop : 'static',
					windowClass : 'modal-custom',
					resolve : {
						data : function() {
							return {
								version : selectedVersionStage,
								legal : $scope.legalDetails,
								parentCaseID : getCorporateCases.parentCaseID,
								isLastElem : ((selectedIndex === $scope.stages.stageVersions.length - 1) && ($scope.stages.parentStage.length - 1 === $scope.stages.parentStage.indexOf($scope.selectedStage)) && $scope.isEditHierarchyID),
								zoneDetails : getZones,
	                            managerDetails : getManagerInfo
							};
						}
					}
				});
			});
		};
		/** Navigate to Expense Details Page */
		$scope.navigateToExpense = function() {
			lazyModuleLoader.loadState("collections.corpCaseTracking.expenses", {caseID : $scope.legalDetails.caseID});
		};
		var submitCaseDetails = function(caseObject,caseStageID, actionCode) {
			corporateCaseService.closeCase($stateParams.caseID, caseStageID, caseObject, actionCode).then(function(response) {
				if (response) {
					dialogService.showAlert('Alert', 'Success', collectionConstants.SUCCESS_MSG.CLOSE_CASE).result.then(function() {
					}, function() {
						$state.go('collections.corporateCaseTracking');
					});
				}
			});
		};
		
		/** submit the case details for that caseID */
		$scope.submitCase = function(type) {
			var caseStageID = $scope.stages.stageVersions[$scope.stages.stageVersions.length-1].caseStageID;
			if (type === 'CLOSECASE') {
				dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.PROCEED).result.then(function() {
					caseObject.legalSections = $scope.legalDetails.workflow[0].legalSections;
					caseObject.agreementNos = [ $stateParams.agreementNo ];
					submitCaseDetails(caseObject, caseStageID, type);
				}, function() {
					return;
				});
			} else if (type === 'REOPENCASE') {
				if ($scope.legalDetails.childCase) {
					dialogService.showAlert('Alert', 'Warning', collectionConstants.SUCCESS_MSG.EXIST_REOPEN).result.then(function() {
					}, function() {
					});
				} else {
					$modal.open({
						templateUrl : 'app/collections/corporateLegal/corporateCaseTracking/partials/reopenCorporateCase.html',
						controller : [ '$scope', '$modalInstance', 'data', '$stateParams', function($scope, $modalInstance, data, $stateParams) {
							$scope.sections = corpLegalConstants.LEGAL_CASE_MAPPING;
							$scope.close = function() {
								$modalInstance.close();
							};
							$scope.reopenCase = function(childSection, childRemarks) {
								caseObject.parentCaseID = $stateParams.caseID;
								caseObject.legalSections = [];
								caseObject.legalSections.push($scope.sectionFiled);
								caseObject.agreementNos = [];
								caseObject.agreementNos = data.agreementNos;
								caseObject.productGroup = data.productGroup;
								caseObject.remarks = childRemarks;
								corporateCaseService.reopenCase($stateParams.caseID, caseStageID, caseObject, type).then(function(response) {
									$modalInstance.close();
									if (response) {
										dialogService.showAlert('Alert', 'Success', collectionConstants.SUCCESS_MSG.REOPEN +" "+ collectionConstants.SUCCESS_MSG.CORP_REOPEN_CASE + $stateParams.caseID).result.then(function() {
										}, function() {
											$state.go('collections.corporateCaseTracking');
										});
									}
								});
							};
						} ],
						size : 'md',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return {
									agreementNos : $scope.legalDetails.workflow[0].agreementNos,
									productGroup : getCorporateLegalStages ? getCorporateLegalStages[0].productGroup : ''
                                };
							}
						}
					});
				}
			}
		};
		/** Create child case for the agreement created */
		$scope.createChildCasePop = function() {
			$modal.open({
				templateUrl : 'app/collections/corporateLegal/corporateCaseTracking/partials/corporateChildCase.html',
				controller : [ '$scope', '$modalInstance', 'data', '$stateParams', function($scope, $modalInstance, data, $stateParams) {
					$scope.childCaseSections = corpLegalConstants.LEGAL_VALUES.CHILD_CASE_NATURE;
					$scope.sections = corpLegalConstants.LEGAL_CASE_MAPPING;
					$scope.close = function() {
						$modalInstance.close();
					};
					$scope.createChildCase = function(childSection, childRemarks) {
						if ((!data.isAppeal && !data.isComplaince)) {
							if (true) {};
							dialogService.showAlert('Alert', 'Warning!', childSection+" case is yet to get approval to create child case!").result.then(function() {
							}, function() {
								$modalInstance.close();
								return;
							});
						} else {
							var childCaseBody = {};
							childCaseBody.parentCaseID = $stateParams.caseID;
							childCaseBody.natureOfCase = childSection;
							childCaseBody.legalSections = [];
							childCaseBody.legalSections.push($scope.sectionFiled);
							childCaseBody.agreementNos = [];
							childCaseBody.agreementNos.push($stateParams.agreementNo);
							childCaseBody.remarks = childRemarks;
							childCaseBody.majorVersion = data.legalData.majorVersion;
							childCaseBody.minorVersion = data.legalData.minorVersion;
							childCaseBody.branchID = data.legalData.branchID;
							childCaseBody.productGroup = $rootScope.productTypes;
							childCaseBody.isCaseAgainstChola = "true";
							corporateCaseService.createChildCase(childCaseBody).then(function(data) {
								$modalInstance.close();
								if (data.status === 'success') {
									dialogService.showAlert('Alert', 'Success!', collectionConstants.SUCCESS_MSG.CORP_CHILD_CASE + " - "+ data.data).result.then(function() {
									}, function() {
										$state.go('collections.corporateCaseTracking');
									});
								}
							});
						}
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							isAppeal : $scope.data.isAppeal,
							isComplaince: $scope.data.isComplaince,
							legalData : $scope.legalDetails
						};
					}
				}
			});
		};
		
	};
	corpCaseTracking.controller('corporateLegalStagesController', [ '$scope', '$state', '$stateParams', '$modal', 'corporateCaseService', 'lazyModuleLoader', 'dialogService', '$rootScope', 'getCorporateLegalStages', 'getCorporateCases','getZones', 'getManagerInfo', 'getAdvocateInfo',corporateLegalStagesController ]);
	return corporateLegalStagesController;
});