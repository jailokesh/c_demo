 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  05-04-2018
 */
define(['require','corpCaseTracking','constants','collectionConstants','utility','DatePickerConfig','legalConstants'],
	function(r, corpCaseTracking, constants, collectionConstants, utility, DatePickerConfig,legalConstants) {
		'use strict';
		var corpExpenseDetailsController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,getExpenseList, getCorporateCases,corporateCaseService, $globalScope,lazyModuleLoader) {
        $scope.legalDetails = corporateCaseService.getLegalDetails();
		$scope.trackingInfo = {};
		$scope.enableInvoice = false;
		$scope.isallData = false;
		$scope.trackingInfo.caseID = $scope.legalDetails.caseID;
		$scope.tabSet = {expDetails : true,expHistory : false};
		$scope.legalExpenseTypes = (!getExpenseList) ? {} : angular.copy(_.pluck(getExpenseList,'expenseDescription'));
		removeDuplicates = function() {
				var testArr = _.pluck(angular.copy($scope.trackingInfo.expenseInfo.expenseDetails),'expenseID');
				var returnArr = _.filter(angular.copy($scope.legalExpenseTypes),function(val) {
					return testArr.indexOf(val) === -1;
				});
				return returnArr;
			};
		var expenseDetails = {expenseID : '',amountPaid : '',paidTo : $scope.legalDetails.advocateName,remarks : '',date : new Date(),
			dateConfig : new DatePickerConfig({maxDate : new Date(),value : new Date()})
		};
		var lastOpendItem = {}, postExpenseCase = {};
		var removeDuplicates;
		var categoryList = _.findWhere($globalScope.imageCategories, {subCategory : "document images"});
		$scope.categoryDetails = categoryList ? categoryList : {};
		$scope.invoiceDateConfig = new DatePickerConfig({
			value : new Date(),
			readonly : true,
			maxDate : new Date(),
			minDate : $scope.legalDetails.filingDate ? new Date($scope.legalDetails.filingDate) : new Date()
		});
		$scope.chequeDateConfig = new DatePickerConfig({
			value : new Date(),
			readonly : true,
			maxDate : new Date(),
			minDate : $scope.legalDetails.filingDate ? new Date($scope.legalDetails.filingDate) : new Date()
		});
		/** Navigate to Expense Details Page */
		$scope.navigateToCase = function() {
			if ($scope.legalDetails.corporateStageLength) {
				lazyModuleLoader.loadState("collections.corpCaseTracking.stages", {caseID : $scope.legalDetails.caseID});
			} else {
				//lazyModuleLoader.loadState(legalConstants.LOAD_LEGAL_CREATE_CORPORATE_CASE, {caseID : $scope.legalDetails.caseID});
			}
		};
		
		/**  Load stages for its respection Section filed | Allow only available | stages | Slice the past stages from the list  */
		$scope.getAdvocates = function() {
			$scope.isallData = true;
			corporateCaseService.advocateList($scope.isallData).then(function(response) {
				$scope.advocatesList = response ? _.pluck(response,'vendorName') : [];
				$scope.trackingInfo.expenseInfo = {expenseDetails : [ expenseDetails ]};
				$scope.trackingInfo.expenseInfo.expenseDetails[0].legalExpenseTypes = removeDuplicates();
				$scope.trackingInfo.expenseInfo.expenseDetails[0].isAdd = ($scope.trackingInfo.expenseInfo.expenseDetails[0].legalExpenseTypes.length > 1)?true:false;
			});
		};
		$scope.getAdvocates();
		/** set tab expense details submit navigates to history */
		$scope.getTab = function(type) {
			if (type === 'HISTORY') {
				$scope.tabSet.expHistory = true;
				$scope.tabSet.expDetails = false;
			} else {
				$scope.tabSet.expHistory = false;
				$scope.tabSet.expDetails = true;
			}
		};
		/** add / remove rows of expense type */
		$scope.modifyRows = function(pos, count) {
			if (!count) {
			var obj = angular.copy(expenseDetails);
				obj.legalExpenseTypes = removeDuplicates();
				obj.isAdd = (obj.legalExpenseTypes.length > 1) ?true:false;
				$scope.trackingInfo.expenseInfo.expenseDetails.push(obj);
			} else {
				$scope.trackingInfo.expenseInfo.expenseDetails.splice(pos, count);
			}
		};
		/** Navigate to Expense Details Page */
		$scope.fetchExpense = function() {
			corporateCaseService.getExpenseDetails($scope.trackingInfo.caseID).then(function(response) {
				$scope.trackingInfo.expenseData = response ? response : [];
			});
		};
		/** Navigate to Expense Details Page */
		$scope.openInvoice = function(item) {
			lastOpendItem.isOpen = false;
			item.isOpen = true;
			lastOpendItem = item;
			corporateCaseService.getInvoiceDetails(item).then(function(response) {
				$scope.trackingInfo.invoiceResponse = response && response.invoiceDetail ? response.invoiceDetail[0] : [];
				$scope.trackingInfo.invoiceData = $scope.trackingInfo.invoiceResponse.expenseDetails;
			});
		};
		/** submit the expense details */
		$scope.submitExpense = function() {
			postExpenseCase.caseID = $scope.trackingInfo.caseID;
			postExpenseCase.caseStageID = $scope.trackingInfo.expenseInfo.caseStageID;
			postExpenseCase.feesAgreed = $scope.trackingInfo.expenseInfo.feesAgreed;
			postExpenseCase.invoiceNo = $scope.trackingInfo.expenseInfo.invoiceNo;
			postExpenseCase.invoiceDate = $scope.trackingInfo.expenseInfo.invoiceDate?$scope.trackingInfo.expenseInfo.invoiceDate:new Date();
			postExpenseCase.invoiceAmount = $scope.trackingInfo.expenseInfo.invoiceAmount;
			postExpenseCase.chequeDate = $scope.trackingInfo.expenseInfo.chequeDate ? $scope.trackingInfo.expenseInfo.chequeDate : new Date();
			postExpenseCase.chequeNo = $scope.trackingInfo.expenseInfo.chequeNo;
			postExpenseCase.expenseDetails = [];
			var expAmount = 0;
			var expenseDetails = [];
			if ($scope.trackingInfo.expenseInfo && $scope.trackingInfo.expenseInfo.expenseDetails) {
				_.each($scope.trackingInfo.expenseInfo.expenseDetails, function(item) {
					var obj = {};
					obj.expenseID = item.expenseID;
					obj.amountPaid = item.amountPaid;
					obj.date = item.date ? item.date : new Date();
					obj.paidTo = item.paidTo;
					obj.remarks = item.remarks;
					obj.documentImageRef = [item.documentImageRef];
					expAmount = parseInt(expAmount) + parseInt(item.amountPaid);
					expenseDetails.push(obj);
					
				});
			}
			postExpenseCase.remarks = $scope.trackingInfo.expenseInfo.remarks;
			if(!$scope.trackingInfo.expenseInfo.chequeNo || ($scope.trackingInfo.expenseInfo.chequeNo && $scope.trackingInfo.expenseInfo.chequeNo.length >= 6 && $scope.trackingInfo.expenseInfo.chequeNo.length <= 9)){
				if((parseInt($scope.trackingInfo.expenseInfo.invoiceAmount) !== expAmount)){
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.EXP_AMT_EXD).result.then(function() {}, function() {
						return;
					});
				}else if(parseInt( $scope.trackingInfo.expenseInfo.invoiceAmount) > parseInt($scope.trackingInfo.expenseInfo.feesAgreed)){
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning,collectionConstants.ERROR_MSG.INV_AMT_EXCD).result.then(function() {}, function() {
						return;
					});
				}else{	
				dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.PROCEED).result.then(function() {
					postExpenseCase.expenseDetails = expenseDetails;
					corporateCaseService.createExpenseDetails(postExpenseCase).then(function(data) {
						if (data.status) {
							dialogService.showAlert(collectionConstants.ALERT, collectionConstants.SUCCESS, collectionConstants.SUCCESS_MSG.EXPENSE).result.then(function() {
							}, function() {
								$scope.tabSet.expHistory = true;
								$scope.tabSet.expDetails = false;
								$scope.fetchExpense();
							});
						}
					});
				}, function() {
					return;
				});
			  }
			} /*else {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, constants.ERROR_MSG.invalidChequeNo);
			}*/
			
		};
		/** cancel the case */
		$scope.cancelCase = function() {
			dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.CANCEL).result.then(function() {
			
			}, function() {
				lazyModuleLoader.loadState(legalConstants.LOAD_CORPQ);
			});
		};
		$scope.enterExpense = function(expenseID,index) {
			$scope.enableInvoice = expenseID ? expenseID : false;
			var newExpense = _.where($scope.trackingInfo.expenseInfo.expenseDetails, {expenseID: expenseID});
			if(newExpense.length > 1 ){
				dialogService.showAlert('Alert', "Alert", "Expense type already selected. Kindly do any modification to the existing expense.").result.then(function() {
				}, function() {
					$scope.trackingInfo.expenseInfo.expenseDetails[index].expenseID = "";
				});
			}
		};
    };
	corpCaseTracking.controller('corpExpenseDetailsController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','getExpenseList', 'getCorporateCases', 'corporateCaseService' , '$globalScope', 'lazyModuleLoader',corpExpenseDetailsController]);
	return corpExpenseDetailsController;
});
