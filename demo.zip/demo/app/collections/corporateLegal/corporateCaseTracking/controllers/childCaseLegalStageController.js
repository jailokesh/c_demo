/** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  23-04-2018
 */
define(['require','corpCaseTracking','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],function(r, corpCaseTracking, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants) {
	'use strict';
	var childCaseLegalStageController = function($scope,$stateParams,$state,messageBus,dialogService,$rootScope,masterService,corporateCaseService, $filter,$globalScope, lazyModuleLoader,appFactory,getAdvocateInfo,getManagerInfo,getZones,getCorporateCases){
    $scope.parentInfo = {};
		$scope.parentInfo.caseID = getCorporateCases.caseID;
		$scope.parentInfo.section = getCorporateCases.workflow[0].legalSections;
		$scope.parentInfo.parentCaseID = getCorporateCases.parentCaseID;
	  $scope.isHOUser = ($rootScope.identity.primaryHierarchyID=="HO_CORP_LEGAL")?true : false;
    $scope.filedBy = corpLegalConstants.caseFiledByArray;      
    $scope.businessTypeArray = corpLegalConstants.businessTypeArray;
    $scope.natureArray= corpLegalConstants.disputeNatureArray;
    $scope.generalTypeArray= corpLegalConstants.caseTypeGeneralArray;
    $scope.servedOnArray= corpLegalConstants.noticeServedOnArray;
    $scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
    $scope.statusArray= corpLegalConstants.statusOfCaseArray;
    $scope.stageArray= corpLegalConstants.stageOfCaseArray;
    $scope.injunctionArray= corpLegalConstants.injunctionTypeArray;
    $scope.courtOrderArray= corpLegalConstants.courtOrderArray;
    $scope.riskAssessmentArray= corpLegalConstants.riskAssessmentArray;
    $scope.cauAppealArray = corpLegalConstants.cauAppealArray;
    $scope.favourCustArray = corpLegalConstants.orderFavourCustomerArray;
    $scope.courtName = corpLegalConstants.courtName;
    $scope.advocateList = getAdvocateInfo.advocates;
    $scope.managerArray = getManagerInfo;
    $scope.paymentArray = corpLegalConstants.PAYMENT_MODE;
    $scope.bankArray = corpLegalConstants.BANK_TYPE;

    $scope.isCaseClose = false;
    $scope.corpCaseData = {};
    $scope.isDateOfEntry = true;
    $scope.isCustomer = false;
    $scope.locationData = {};
    $scope.dropDownValues = getZones.locations;
    $scope.dataType = {
      isType : false,
      isDate : false,
      isDcr:false,
      isZoneUser:false,
      isRegUser:false,
      isAreaUser:false,
      isBranchUser:false
    };
    $scope.isRiskDisable = false;
    var postCorporateCase = {};
    var date = new Date();
     $scope.firstHearingDateConfig = new DatePickerConfig({
      dateValue : new Date(),
      readonly : true
    });
    $scope.lastHearingDateConfig = new DatePickerConfig({
      dateValue : new Date(),
      readonly : true
    });
    $scope.nextHearingDateConfig = new DatePickerConfig({
      value :  new Date(),
      readonly : true
    });
    $scope.dateOfEntryConfig = new DatePickerConfig({
      value :  new Date(),
      readonly : true
    });
    var caseFilingYear = new Date($scope.corpCaseData.caseFilingYear, 0, 1);
    $scope.caseFilingYearDateConfig = new DatePickerConfig({
      readonly : true,
      dateOptions : {'datepickerMode' : "'year'",'minMode' : "year"},
      value : $scope.corpCaseData.caseFilingYear ? caseFilingYear : new Date(),
      onchange : function(value) {
        $scope.corpCaseData.caseFilingYear = value;
      }
    });
    
    $scope.changeHandler = function(type, ID, value) {
      var branchArr, areaArr, regionArr;
      if (type === 'Zone') {
        $scope.dropDownValues.branchDetails.regionID = "";
        if($scope.dataType.isHoUser){
          if(ID){
            $scope.userSelection({ZoneID : ID}, 'Region','filteredRegions');
          }
          $scope.dropDownValues.branchDetails.areaID = "";
          $scope.dropDownValues.branchDetails.branchID = "";
          $scope.dropDownValues.branchDetails.filteredRegions = [];
          $scope.dropDownValues.branchDetails.filterdAreas = [];
          $scope.dropDownValues.branchDetails.filterdBranch = [];
          $scope.dropDownValues.branchDetails.disableRegion = true ;
          $scope.dropDownValues.branchDetails.disableArea = true ;
          $scope.dropDownValues.branchDetails.disableBranch = true;
        }else{
          regionArr = ($scope.dropDownValues.branchDetails.zoneID) ? _.where($scope.dropDownValues.branchDetails.regions, {
            ZoneID : $scope.dropDownValues.branchDetails.zoneID
          }) : '';
          if (regionArr.length > 1 && $scope.dropDownValues.branchDetails.zoneID) {
            $scope.dropDownValues.branchDetails.disableRegion = false;
          } else {
            $scope.dropDownValues.branchDetails.regionID = regionArr[0] ? regionArr[0].regionID : "";
            $scope.dropDownValues.branchDetails.disableRegion = (!$scope.dropDownValues.branchDetails.regionID);
          }
          $scope.dropDownValues.branchDetails.filteredRegions = regionArr;
          type = 'Region';
        }
        
      }

      if (type === 'Region') {
        $scope.dropDownValues.branchDetails.areaID = "";
        if($scope.dataType.isHoUser){
          if(ID){
            $scope.userSelection({regionID:ID}, 'Area','filterdAreas');
          }
          $scope.dropDownValues.branchDetails.branchID = "";
          $scope.dropDownValues.branchDetails.filterdAreas = [];
          $scope.dropDownValues.branchDetails.filterdBranch = [];
          $scope.dropDownValues.branchDetails.disableArea = true ;
          $scope.dropDownValues.branchDetails.disableBranch = true;
        }else{
          areaArr = ($scope.dropDownValues.branchDetails.regionID) ? _.where($scope.dropDownValues.branchDetails.areas, {
            regionID : $scope.dropDownValues.branchDetails.regionID
          }) : '';
          if (areaArr.length > 1 && $scope.dropDownValues.branchDetails.regionID) {
            $scope.dropDownValues.branchDetails.disableArea = false;
          } else {
            $scope.dropDownValues.branchDetails.areaID = areaArr[0] ? areaArr[0].areaID : "";
            $scope.dropDownValues.branchDetails.disableArea = (!$scope.dropDownValues.branchDetails.areaID);
          }
          $scope.dropDownValues.branchDetails.filterdAreas = areaArr;
          type = 'Area';
        }
      }

      if (type === 'Area') {
        $scope.dropDownValues.branchDetails.branchID = "";
        if($scope.dataType.isHoUser){
          if(ID){
            $scope.userSelection({areaID:ID}, 'Branch','filterdBranch');
          }
          $scope.dropDownValues.branchDetails.filterdBranch = [];
          $scope.dropDownValues.branchDetails.disableBranch = true;
        }else{
          branchArr = ($scope.dropDownValues.branchDetails.areaID) ? _.where($scope.dropDownValues.branchDetails.branches, {
            areaID : $scope.dropDownValues.branchDetails.areaID
          }) :'';
          if (branchArr.length > 1 && $scope.dropDownValues.branchDetails.areaID) {
            $scope.dropDownValues.branchDetails.disableBranch = false;
          } else {
            $scope.dropDownValues.branchDetails.branchID = branchArr[0] ? branchArr[0].branchID : "";
            $scope.dropDownValues.branchDetails.disableBranch = (!$scope.dropDownValues.branchDetails.branchID);
          }
          $scope.dropDownValues.branchDetails.filterdBranch = branchArr;
        }
      }
      if(type === 'Branch' && !ID){
        $scope.dropDownValues.branchDetails.branchID = "";
      }
    };
    $scope.userSelection = function(reqObj,type,selection){
			corporateCaseService.getUserSelection(reqObj,type).then(function(data){		
				$scope.dropDownValues.branchDetails[selection] = data;
			});
		};
    $scope.onStatusChange = function(status) {
      $scope.stageArray = corpLegalConstants.stageOfCaseArray;
      $scope.corpCaseData.caseStage = "Select";
      if(status == 'Live') {
        $scope.stageArray = _.without($scope.stageArray,'Ordered')
        $scope.corpCaseData.caseStage = "Select";
      } else if(status == 'Closed') {
        $scope.stageArray = ["Ordered"];
        $scope.corpCaseData.caseStage = "Ordered";
      }
    };
    $scope.onChangeOfStage = function(item){  
    	$scope.corpCaseData.stageID = corpLegalConstants.stageOfCaseArray.indexOf(item) +1;
    	if(item == "Ordered"){
    		$scope.corpCaseData.caseStatus = "Closed"
    	}
    };
    $scope.onAmountChange = function(){
      if($scope.corpCaseData.claimAmount >=1000000 || $scope.corpCaseData.approvedFee >=1000000){
        $scope.corpCaseData.riskAssessment = "High";
      }else{
        $scope.corpCaseData.riskAssessment = "";
      }
      $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
    };
    $scope.onGeneralCaseChange = function(value){
      $scope.corpCaseData.generalType = value;
      $scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
      $scope.corpCaseData.specificType = "Select";      
      if(value == "Consumer"){
        $scope.corpCaseData.riskAssessment = "Medium";
        $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
      }else if(value == "Civil"){
        $scope.corpCaseData.riskAssessment = "Medium";
        $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
      }else if(value == "Criminal"){
        $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition","complaint"]);
      }else if(value == "WRIT"){
        $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
        $scope.corpCaseData.specificType = "Petition";
      }else if(value == "MACT"){
        $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
        $scope.corpCaseData.specificType = "Petition";
      }else{
        $scope.corpCaseData.riskAssessment = "";
      }
      $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
    };
    $scope.onSpecificCaseChange = function(value){
      $scope.corpCaseData.specificType = value;
      if(value == "Execution"){
        $scope.corpCaseData.riskAssessment ="High"; 
      }else{
        $scope.corpCaseData.riskAssessment ="";
      }
      $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
    };
    $scope.getReleifSoughtVal = function(val){
      $scope.corpCaseData.reliefSought = val ;
      $scope.setRiskAssessment("");
    };
    $scope.setRiskAssessment = function(val){
      if($scope.corpCaseData.specificType == "Execution" || ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000 )){
        $scope.corpCaseData.riskAssessment = "High";
      }else if($scope.corpCaseData.generalType == "Consumer" && $scope.corpCaseData.specificType == "Execution"){
        $scope.corpCaseData.riskAssessment = "High";
      }else if($scope.corpCaseData.generalType == "Consumer" && ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000)){
        $scope.corpCaseData.riskAssessment = "High";
      }else if($scope.corpCaseData.generalType == "Consumer" && (($scope.corpCaseData.claimAmount<1000000|| $scope.corpCaseData.claimAmount==undefined) || ($scope.corpCaseData.approvedFee<1000000|| $scope.corpCaseData.approvedFee==undefined))){
        $scope.corpCaseData.riskAssessment ="Medium";
      }else if($scope.corpCaseData.generalType == "Civil" && $scope.corpCaseData.specificType == "Execution"){
        $scope.corpCaseData.riskAssessment = "High";
      }else if($scope.corpCaseData.generalType == "Civil" && ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000)){
        $scope.corpCaseData.riskAssessment = "High";
      }else if($scope.corpCaseData.generalType == "Civil" && $scope.corpCaseData.reliefSought){
        $scope.corpCaseData.riskAssessment ="Medium";
      }else if($scope.corpCaseData.generalType == "Civil" && !$scope.corpCaseData.reliefSought){
        $scope.corpCaseData.riskAssessment ="Low";
      }else{
        $scope.corpCaseData.riskAssessment = val;
      } 
      if($scope.corpCaseData.riskAssessment != undefined && $scope.corpCaseData.riskAssessment!=""){
        $scope.isRiskDisable = true;
      }else{
        $scope.isRiskDisable = false;
      }
    }
    $scope.onAdvocateChange= function(item){
      $scope.corpCaseData.advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName;
    }
    $scope.downloadAllotmentLetter = function(){
  	  var reqObj = {
        "advocate" : $scope.corpCaseData.advocateName,
        "area" : $scope.dropDownValues.branchDetails.areaID,
        "branch" : $scope.dropDownValues.branchDetails.branchID,
        "caseNo": $scope.corpCaseData.courtCaseNo,
        "caseFilingYear" : $scope.corpCaseData.caseFilingYear.getFullYear(),
        "courtName" :$scope.corpCaseData.courtName,
        "agreementNo" : $scope.corpCaseData.agreementNo,
        "customerName" : $scope.corpCaseData.customerName,
        "stageOfCase" : $scope.corpCaseData.caseStage,
        "subStageOfCase" : $scope.corpCaseData.subStageOfCase ,
        "nextHearingDate" : $filter(collectionConstants.DATE)($scope.corpCaseData.nextHearingDate, collectionConstants.DATE_FILTER_STANDARD),
        "year" : $scope.corpCaseData.nextHearingDate.getFullYear(),
        "approvedFee" : $scope.corpCaseData.approvalFee,
        "contactNo" : $scope.corpCaseData.contactNo
      }
      corporateCaseService.getAllotmentLetter(reqObj);
    }
    var date = new Date();
    $scope.dateConfig = new DatePickerConfig({
    	dateValue : new Date(),
    	readonly : true
    });
    $scope.SentToBranchDateConfig = new DatePickerConfig({
    	dateValue : new Date(),
    	readonly : true
    });

    /** Navigate to Expense Details Page */
    $scope.navigateToExpense = function() {
      lazyModuleLoader.loadState("collections.corpCaseTracking.expenses", {caseID : $scope.legalDetails.caseID});
    };
    var getFormDetails = function(){
      var caseYear = $filter(collectionConstants.DATE)($scope.corpCaseData.caseFilingYear, collectionConstants.DATE_YEAR_FILTER);
      $scope.corpCaseData.caseFilingYear = parseInt(caseYear);
      $scope.queryObj = {
        "majorVersion" : getCorporateCases.majorVersion,
	      "minorVersion" : getCorporateCases.minorVersion,
        "casefiledBy":$scope.corpCaseData.caseFiledBy,
        "caseFiledByName" : $scope.corpCaseData.name,
        "customerName": $scope.corpCaseData.custName,
        "courtCaseNo" : $scope.corpCaseData.caseNo,
        "businessType" : $scope.corpCaseData.businessType,
        "agreementNos" : $scope.corpCaseData.agreementNo,
        "disputeNature" : $scope.corpCaseData.disputeNature,
        "caseFilingYear" : $scope.corpCaseData.caseFilingYear,
        "caseType" : $scope.corpCaseData.generalType,
        "noticeServedOn" : $scope.corpCaseData.noticeServedOn ,
        "casefiledAgainst" : $scope.corpCaseData.caseFileAgainst ,
        "caseSpecificCategory" : $scope.corpCaseData.specificType ,
        "caseNoTypeIndicator" : $scope.corpCaseData.caseNoTypeIndicator ,
        "caseStatus" : $scope.corpCaseData.caseStatus ,
        "caseStage" : $scope.corpCaseData.caseStage ,
        "caseStageID" : $scope.corpCaseData.stageID+".1",
        "subStageOfCase" : $scope.corpCaseData.subStageCase ,
        "injunctionType" : $scope.corpCaseData.injunctionType ,
        "interimReliefSought" : $scope.corpCaseData.reliefSought ,
        "interimOrderPassed" : $scope.corpCaseData.interimOrderPassed ,
        "courtOrder" : $scope.corpCaseData.courtOrder ,
        "orderFavourToCustomer" : $scope.corpCaseData.favCustomer,
        "courtRemarks" : $scope.corpCaseData.courtRemarks,
        "claimAmount" : $scope.corpCaseData.claimAmount ,  
        "approvalFee" : $scope.corpCaseData.approvalFee ,
        "nextHearingDate" : $scope.corpCaseData.nextHearingDate ,
        "firstHearingDate" : $scope.corpCaseData.firstHearingDate ,
        "lastHearingDate" : $scope.corpCaseData.lastHearingDate ,
        "entryDate" : $scope.corpCaseData.dateOfEntry ,
        "zoneID": $scope.dropDownValues.branchDetails.zoneID,
        "regionID": $scope.dropDownValues.branchDetails.regionID, 
        "areaID" : $scope.dropDownValues.branchDetails.areaID ,
        "branchID" : $scope.dropDownValues.branchDetails.branchID,
        "advocateID" : $scope.corpCaseData.advocate ,
        "courtName" : $scope.corpCaseData.courtName ,
        "riskAssesement" : $scope.corpCaseData.riskAssessment , 
        "remarks" : $scope.corpCaseData.remarks ,
        "reliefText" : $scope.corpCaseData.reliefText ,
        "assignedTo" : $scope.corpCaseData.assignedTo ,
        "appealOrCAU" : $scope.corpCaseData.cauOrAppeal ,
        "replyFiledStatus": $scope.corpCaseData.replyFiledStatus , 
        "isPaperAvailable" : $scope.corpCaseData.isPaperAvailable ,
        "allotmentFiledStatus" : $scope.corpCaseData.allotmentFileStatus,
        "documentImageRef" :  $scope.corpCaseData.docUpload,
        "contactNumber" : $scope.corpCaseData.contactNo,
        "orderBrief" : $scope.corpCaseData.orderBrief,
        "workDoneBy" : $rootScope.identity.userID,
        "securityAmount" : $scope.bankDetails.amount ,
        "pmtModeRequirement": $scope.bankDetails.paymentMode,
        "bankType": $scope.bankDetails.bankType,
        "pmtModeNumber": $scope.bankDetails.number,
        "date": $scope.bankDetails.date,
        "bankName" :$scope.bankDetails.bankName,
        "inFavourOf": $scope.bankDetails.inFavourOf,
        "sentToBranchDate": $scope.bankDetails.sentDate,
        "recipientName": $scope.bankDetails.recipientName
      };
    }
    $scope.createCorporateCase = function(){
    	getFormDetails();
      corporateCaseService.isFirstChild = true;
    	corporateCaseService.updateCustomerCase($scope.parentInfo.caseID,$scope.queryObj).then(function(response) {
    		if (response.status === collectionConstants.SUCCESS) {
    			dialogService.showAlert(collectionConstants.ALERT, collectionConstants.SUCCESS, collectionConstants.SUCCESS_MSG.CASE_TRACK_UPDATE).result.then(function() {
      			}, function() {
    				$state.current.forceReload = true;
    				$state.transitionTo($state.current,{ caseID : $scope.parentInfo.caseID, agreementNo : $stateParams.agreementNo },{
    					reload: true
    				});
  					lazyModuleLoader.loadState("collections.corporateCaseTracking", {caseID : $stateParams.caseID,agreementNo : $stateParams.agreementNo});
				  });
    		}
    	});
    };

  };
	corpCaseTracking.controller('childCaseLegalStageController', ['$scope','$stateParams', '$state', 'messageBus','dialogService','$rootScope','masterService','corporateCaseService', '$filter','$globalScope', 'lazyModuleLoader','appFactory','getAdvocateInfo', 'getManagerInfo','getZones','getCorporateCases', childCaseLegalStageController]);
	return childCaseLegalStageController;
});