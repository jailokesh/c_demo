 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  05-04-2018
 */
define(['require','corpCaseTracking','constants','collectionConstants','utility','DatePickerConfig'],
	function(r, corpCaseTracking, constants, collectionConstants, utility, DatePickerConfig ) {
	'use strict';
	var corporateQueController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,getHeaderInfo,getCorpCaseAsideInfo) {
		$scope.headerInfo = getHeaderInfo.data;
		$scope.propertyData = $scope.headerInfo.caseDetailInfo.propertyDetails;
		$scope.userData = {};
		$scope.groupAgreementList = $scope.headerInfo.caseDetailInfo.agreementNos;
		$scope.shortFallinformation = $scope.headerInfo.caseDetailInfo.shortfallDetails;
		$scope.agreementInfo = getCorpCaseAsideInfo;

        if(getCorpCaseAsideInfo.AsOn !="No Record")
        $scope.agreementInfo.address =  getCorpCaseAsideInfo.AsOn? getCorpCaseAsideInfo.AsOn.address[0] : "";
        
        $scope.availability = getCorpCaseAsideInfo.availablityDetails;
        $scope.cauInfo = [];
        $scope.cfuInfo = [];
        $scope.noticeInfo = [];

		var getUserData = function(){
			if($scope.headerInfo.caseDetailInfo != "No Record"){
				if($scope.headerInfo.caseDetailInfo.partyDetails.length>0){
					for(var i=0;i<$scope.headerInfo.caseDetailInfo.partyDetails.length;i++){
						if($scope.headerInfo.caseDetailInfo.partyDetails[i].partyType == "A"){
							$scope.userData = $scope.headerInfo.caseDetailInfo.partyDetails[i];
						}
					}
				}
			}
		};
		var getCaseDetails = function(){
			for(var i=0;i<getCorpCaseAsideInfo.caseDetails.length;i++){
				if(getCorpCaseAsideInfo.caseDetails[i].isCaseAgainstChola){
					$scope.cauInfo.push(getCorpCaseAsideInfo.caseDetails[i]);
				}else{
					$scope.cfuInfo.push(getCorpCaseAsideInfo.caseDetails[i]);
				}
			}
			for (var i = 0; i < $scope.agreementInfo.noticeDetails.length; i++) {
	        	$scope.noticeInfo.push($scope.agreementInfo.noticeDetails[i]);
	        };
		};
		/** Bucket trend button click pops up delinquency string */
		$scope.bucketPopup = function() {
			$modal.open({
				templateUrl : 'app/collections/corporateLegal/corporateCaseInitiation/partials/bucketTrendPopup.html',
				controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
					if(data.bucketTrends) 
						$scope.agreementBuckets = data.bucketTrends;
					$scope.getMonthInWord = function(date) {
						var objDate = new Date(date), locale = "en-us";
						return objDate.toLocaleString(locale,{month: "short"});
					};
					$scope.close = function() {
						$modalInstance.close();
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							bucketTrends : getCorpCaseAsideInfo.bucketTrendDetails?getCorpCaseAsideInfo.bucketTrendDetails:getCorpCaseAsideInfo.data.bucketTrendDetails
						};
					}
				}
			});
		};
		
		var init = function () {
			getUserData();
			getCaseDetails();
		}
        init();
    };

	corpCaseTracking.controller('corporateQueController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','getHeaderInfo','getCorpCaseAsideInfo',corporateQueController]);
	return corporateQueController;
});