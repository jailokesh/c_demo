 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a controller file.
 * @version v1.0 Date:  05-04-2018
 */
define(['require','corpCaseTracking','constants','collectionConstants','utility','DatePickerConfig','legalConstants', 'corpLegalConstants'],function(r, corpCaseTracking, constants, collectionConstants, utility, DatePickerConfig, legalConstants, corpLegalConstants) {
	'use strict';
	var versionCorporateHistoryController = function($scope,$stateParams,$state, $modalInstance, data, messageBus,dialogService,$rootScope,masterService,corporateCaseService, $filter,$globalScope, lazyModuleLoader,appFactory){
		$scope.versionHistory = {};
		$scope.versionHistory.stages = data.version;
		$scope.versionHistory.stages.letterType = false;
		$scope.isallData = false;
		$scope.versionHistory.legalDetails = data.legal;
		$scope.parentCaseId = data.parentCaseID;
		$scope.isLastElem = data.isLastElem;
		$scope.corporateCombo = {};
		var postCorporateCase = {};
		var postSubStageVersion,tempVersion, prevTempVersion,stageStatusChange = {};
		$scope.courtOrders = legalConstants.LEGAL_VALUES.COURT_ORDER;
		/** get Advocates list from Vendor management service */
		$scope.getAdvocates = function() {
			$scope.isallData = true;
			corporateCaseService.advocateList($scope.isallData).then(function(response) {
				$scope.advocatesList = response ? response : [];
				$scope.versionHistory.stages.advocateName = _.findWhere($scope.advocatesList, {vendorID : $scope.versionHistory.stages.advocateID});
			});
		};
		$scope.getAdvocates();
		/** close the stages window */
		$scope.close = function() {
			$scope.versionHistory.stages.isEdit = false;
			$modalInstance.dismiss();
		};
		var init = function() {
			$scope.isCaseNo = true;
			$rootScope.transitionBackstate='';
		    $scope.versionHistory.stages.isEdit = false;
			$scope.isALM = ($rootScope.identity.hierarchyName === 'ALM');
			$scope.versionHistory.stages.agreementNo = $scope.versionHistory.legalDetails.workflow[0].agreementNos[0];
			var noticeStagesArr = $scope.versionHistory.stages.documentImageRef[0];
			if (noticeStagesArr) {
				$scope.versionHistory.stages.docUpload = noticeStagesArr;		
			}

			if($scope.versionHistory.stages.entryDate != undefined && $scope.versionHistory.stages.entryDate!=""){
	            $scope.isDateOfEntryDisable = true;
	        }else {
	            $scope.isDateOfEntryDisable = false;
		    }
			tempVersion = angular.copy($scope.versionHistory.stages.caseStageID);
			prevTempVersion = tempVersion;
			var stageIndex = _.findLastIndex(corpLegalConstants.STAGES, {
				caseStageID : parseInt($scope.versionHistory.stages.caseStageID).toString()
			});
			$scope.corporateCombo.stages = corpLegalConstants.STAGES.slice(stageIndex);
			if (stageIndex > -1) {
				$scope.corporateCombo.stages = corpLegalConstants.STAGES.slice(stageIndex);
			}
			$scope.versionHistory.stages.versionID = angular.copy($scope.versionHistory.stages.caseStageID);
			$scope.versionHistory.stages.caseStageID = $scope.corporateCombo.stages[0].caseStageID;
			stageStatusChange.caseStatusID = angular.copy($scope.versionHistory.stages.caseStageID);

			var categoryList = _.findWhere($globalScope.imageCategories, {subCategory : "document images"});
			$scope.categoryDetails = categoryList ? categoryList : {};
		
			$scope.isHOUser = ($rootScope.identity.primaryHierarchyID=="HO_CORP_LEGAL")?true : false;
			$scope.filedBy = corpLegalConstants.caseFiledByArray;      
			$scope.businessTypeArray = corpLegalConstants.businessTypeArray;
			$scope.natureArray= corpLegalConstants.disputeNatureArray;
			$scope.generalTypeArray= corpLegalConstants.caseTypeGeneralArray;
			$scope.servedOnArray= corpLegalConstants.noticeServedOnArray;
			$scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
			$scope.statusArray= corpLegalConstants.statusOfCaseArray;
			$scope.stageArray= corpLegalConstants.stageOfCaseArray;
			$scope.injunctionArray= corpLegalConstants.injunctionTypeArray;
			$scope.courtOrderArray= corpLegalConstants.courtOrderArray;
			$scope.riskAssessmentArray= corpLegalConstants.riskAssessmentArray;
			$scope.cauAppealArray = corpLegalConstants.cauAppealArray;
			$scope.favourCustArray = corpLegalConstants.orderFavourCustomerArray;
			$scope.courtNameArray = corpLegalConstants.courtName;
			$scope.managerArray = data.managerDetails;

			$scope.paymentArray = corpLegalConstants.PAYMENT_MODE;
			$scope.bankArray = corpLegalConstants.BANK_TYPE;

			$scope.dropDownValues = data.zoneDetails.locations;
			$scope.dataType = {
				isType : false,
				isDate : false,
				isDcr:false,
				isZoneUser:false,
				isRegUser:false,
				isAreaUser:false,
				isBranchUser:false
			};
			$scope.dropDownValues.branchDetails.zoneID = $scope.versionHistory.stages.zoneID;
		    $scope.dropDownValues.branchDetails.regionID = $scope.versionHistory.stages.regionID;
		    $scope.dropDownValues.branchDetails.areaID = $scope.versionHistory.stages.areaID;
		    $scope.dropDownValues.branchDetails.branchID = $scope.versionHistory.stages.branchID;
			if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.ZONE_REPORT)){
				$scope.dataType.isZoneUser = true;
			}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.REGION_REPORT)){
				$scope.dataType.isRegUser = true;
			}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.AREA_REPORT)){
				$scope.dataType.isAreaUser = true;
			}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.BRANCH_REPORT)){
				$scope.dataType.isBranchUser = true;
			}
			if($scope.versionHistory.stages.caseStatus == 'Live') {
				$scope.corporateCombo.stages = _.without($scope.corporateCombo.stages,$scope.corporateCombo.stages[4]);
			}
		}
		init();
		$scope.changeHandler = function(type, ID, value) {
			var branchArr, areaArr, regionArr;
			if (type === 'Zone') {
				$scope.dropDownValues.branchDetails.regionID = "";
				if($scope.dataType.isHoUser){
					if(ID){
						$scope.userSelection({ZoneID : ID}, 'Region','filteredRegions');
					}
					$scope.dropDownValues.branchDetails.areaID = "";
					$scope.dropDownValues.branchDetails.branchID = "";
					$scope.dropDownValues.branchDetails.filteredRegions = [];
					$scope.dropDownValues.branchDetails.filterdAreas = [];
					$scope.dropDownValues.branchDetails.filterdBranch = [];
					$scope.dropDownValues.branchDetails.disableRegion = true ;
					$scope.dropDownValues.branchDetails.disableArea = true ;
					$scope.dropDownValues.branchDetails.disableBranch = true;
				}else{
					regionArr = ($scope.dropDownValues.branchDetails.zoneID) ? _.where($scope.dropDownValues.branchDetails.regions, {
						ZoneID : $scope.dropDownValues.branchDetails.zoneID
					}) : '';
					if (regionArr.length > 1 && $scope.dropDownValues.branchDetails.zoneID) {
						$scope.dropDownValues.branchDetails.disableRegion = false;
					} else {
						$scope.dropDownValues.branchDetails.regionID = regionArr[0] ? regionArr[0].regionID : "";
						$scope.dropDownValues.branchDetails.disableRegion = (!$scope.dropDownValues.branchDetails.regionID);
					}
					$scope.dropDownValues.branchDetails.filteredRegions = regionArr;
					type = 'Region';
				}
			}

			if (type === 'Region') {
				$scope.dropDownValues.branchDetails.areaID = "";
				if($scope.dataType.isHoUser){
					if(ID){
						$scope.userSelection({regionID:ID}, 'Area','filterdAreas');
					}
					$scope.dropDownValues.branchDetails.branchID = "";
					$scope.dropDownValues.branchDetails.filterdAreas = [];
					$scope.dropDownValues.branchDetails.filterdBranch = [];
					$scope.dropDownValues.branchDetails.disableArea = true ;
					$scope.dropDownValues.branchDetails.disableBranch = true;
				}else {
					areaArr = ($scope.dropDownValues.branchDetails.regionID) ? _.where($scope.dropDownValues.branchDetails.areas, {
						regionID : $scope.dropDownValues.branchDetails.regionID
					}) : '';
					if (areaArr.length > 1 && $scope.dropDownValues.branchDetails.regionID) {
						$scope.dropDownValues.branchDetails.disableArea = false;
					}else {
						$scope.dropDownValues.branchDetails.areaID = areaArr[0] ? areaArr[0].areaID : "";
						$scope.dropDownValues.branchDetails.disableArea = (!$scope.dropDownValues.branchDetails.areaID);
					}
					$scope.dropDownValues.branchDetails.filterdAreas = areaArr;
					type = 'Area';
				}

			}

			if (type === 'Area') {
				$scope.dropDownValues.branchDetails.branchID = "";
				if($scope.dataType.isHoUser){
					if(ID){
						$scope.userSelection({areaID:ID}, 'Branch','filterdBranch');
					}
					$scope.dropDownValues.branchDetails.filterdBranch = [];
					$scope.dropDownValues.branchDetails.disableBranch = true;
				}else {
					branchArr = ($scope.dropDownValues.branchDetails.areaID) ? _.where($scope.dropDownValues.branchDetails.branches, {
						areaID : $scope.dropDownValues.branchDetails.areaID
					}) :'';
					if(branchArr.length > 1 && $scope.dropDownValues.branchDetails.areaID) {
						$scope.dropDownValues.branchDetails.disableBranch = false;
					}else {
						$scope.dropDownValues.branchDetails.branchID = branchArr[0] ? branchArr[0].branchID : "";
						$scope.dropDownValues.branchDetails.disableBranch = (!$scope.dropDownValues.branchDetails.branchID);
					}
					$scope.dropDownValues.branchDetails.filterdBranch = branchArr;
				}

			}
			if(type === 'Branch' && !ID){
				$scope.dropDownValues.branchDetails.branchID = "";
			}
		};
		$scope.userSelection = function(reqObj,type,selection){
			corporateCaseService.getUserSelection(reqObj,type).then(function(data){		
				$scope.dropDownValues.branchDetails[selection] = data;
			});
		};
		$scope.firstHearingDateConfig = new DatePickerConfig({
			readonly : true,
			value : $scope.versionHistory.stages.firstHearingDate ? new Date($scope.versionHistory.stages.firstHearingDate) : new Date(),
			onchange : function(value) {
				$scope.versionHistory.stages.firstHearingDate = value;
			}
		});
		$scope.lastHearingDateConfig = new DatePickerConfig({
			readonly : true,
			value : $scope.versionHistory.stages.lastHearingDate ? new Date($scope.versionHistory.stages.lastHearingDate) : new Date(),
			onchange : function(value) {
				$scope.versionHistory.stages.lastHearingDate = value;
			}
		});
		$scope.nextHearingDateConfig = new DatePickerConfig({
			value : $scope.versionHistory.stages.nextHearingDate ? new Date($scope.versionHistory.stages.nextHearingDate) : new Date(),
			readonly : true,
			onchange : function(value) {
				$scope.versionHistory.stages.nextHearingDate = value;
			}
		});
		$scope.entryDateConfig = new DatePickerConfig({
			readonly : true,
			maxDate : new Date(),
			value : $scope.versionHistory.stages.entryDate ? new Date($scope.versionHistory.stages.entryDate) : new Date(),
			onchange : function(value) {
				$scope.versionHistory.stages.entryDate = value;
			}
		});
		$scope.invoiceDateConfig = new DatePickerConfig({
			readonly : true,
			maxDate : new Date(),
			value : $scope.versionHistory.stages.invoiceDate ? new Date($scope.versionHistory.stages.invoiceDate) : new Date(),
			onchange : function(value) {
				$scope.versionHistory.stages.invoiceDate = value;
			}
		});
		$scope.caseFilingYearDateConfig = new DatePickerConfig({
			readonly : true,
			maxDate : new Date(),
			value : $scope.versionHistory.stages.caseFilingYear ? new Date($scope.versionHistory.stages.caseFilingYear) : new Date(),
			onchange : function(value) {
				$scope.versionHistory.stages.caseFilingYear = value;
			}
		});
		stageStatusChange.prevSplicedStartIndex = 0;
		$scope.onStatusChange = function(status) {
			var verStages = angular.copy(legalConstants.LEGAL_VALUES.STAGES);
			var spliceIndex = 0;
			if (stageStatusChange.prevSplicedStartIndex !== 0) {
				spliceIndex = stageStatusChange.prevSplicedStartIndex;
				stageStatusChange.prevSplicedStartIndex = 0;
			} else {
				spliceIndex = _.findIndex(verStages, {caseStageID: stageStatusChange.caseStatusID});	
			}
			verStages.splice(0, spliceIndex);
			if (status === 'Closed') {
				stageStatusChange.prevSplicedStartIndex = spliceIndex;
				$scope.corporateCombo.stages = [{caseStage: "Ordered", caseStageID: "5"}];
			} else if (status === 'Live') {
				var spliceInital = _.findIndex(verStages, {caseStageID: "5"});
				verStages.splice(spliceInital,1);
				$scope.corporateCombo.stages = verStages;
			} else {
				$scope.corporateCombo.stages = verStages;
			}
			$scope.versionHistory.stages.caseStageID = $scope.corporateCombo.stages[0].caseStageID;
			$scope.versionHistory.stages.caseStage = $scope.corporateCombo.stages[0].caseStage;
			$scope.changeStage($scope.versionHistory.stages.caseStageID);
		};
	    $scope.onAmountChange = function(){
	      if($scope.versionHistory.stages.claimAmount >=1000000 || $scope.versionHistory.stages.approvalFee >=1000000){
	          $scope.versionHistory.stages.riskAssesement = "High";
	      }else{
	          $scope.versionHistory.stages.riskAssesement = "";
	      }
	      $scope.setRiskAssessment($scope.versionHistory.stages.riskAssesement);
	    };
	    $scope.onGeneralCaseChange = function(value){
	      $scope.versionHistory.stages.caseType = value;
	      $scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
	      $scope.versionHistory.stages.caseSpecificCategory = "Select";      
	      if(value == "Consumer"){
	          $scope.versionHistory.stages.riskAssesement = "Medium";
	          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
	      }else if(value == "Civil"){
	          $scope.versionHistory.stages.riskAssesement = "Medium";
	          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
	      }else if(value == "Criminal"){
	          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition","Complaint"]);
	      }else if(value == "WRIT"){
	          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
	          $scope.versionHistory.stages.caseSpecificCategory = "Petition";
	      }else if(value == "MACT"){
	          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
	          $scope.versionHistory.stages.caseSpecificCategory = "Petition";
	      }else{
	          $scope.versionHistory.stages.riskAssesement = "";
	      }
	      $scope.setRiskAssessment($scope.versionHistory.stages.riskAssesement);
	    };
	    $scope.onSpecificCaseChange = function(value){
	      $scope.versionHistory.stages.caseSpecificCategory = value;
	      if(value == "Execution"){
	          $scope.versionHistory.stages.riskAssesement ="High"; 
	      }else{
	          $scope.versionHistory.stages.riskAssesement ="";
	      }
	      $scope.setRiskAssessment($scope.versionHistory.stages.riskAssesement);
	    };
	    $scope.getReleifSoughtVal = function(val){
	       $scope.versionHistory.stages.reliefSought = val ;
	       $scope.setRiskAssessment("");
	    };
	    $scope.setRiskAssessment = function(val){
	      if($scope.versionHistory.stages.caseSpecificCategory == "Execution" || ($scope.versionHistory.stages.claimAmount>1000000 || $scope.versionHistory.stages.approvalFee>1000000 )){
	         $scope.versionHistory.stages.riskAssesement = "High";
	      }else if($scope.versionHistory.stages.caseType == "Consumer" && $scope.versionHistory.stages.caseSpecificCategory == "Execution"){
	         $scope.versionHistory.stages.riskAssesement = "High";
	      }else if($scope.versionHistory.stages.caseType == "Consumer" && ($scope.versionHistory.stages.claimAmount>1000000 || $scope.versionHistory.stages.approvalFee>1000000)){
	         $scope.versionHistory.stages.riskAssesement = "High";
	      }else if($scope.versionHistory.stages.caseType == "Consumer" && (($scope.versionHistory.stages.claimAmount<1000000|| $scope.versionHistory.stages.claimAmount==undefined) || ($scope.versionHistory.stages.approvalFee<1000000|| $scope.versionHistory.stages.approvalFee==undefined))){
	         $scope.versionHistory.stages.riskAssesement ="Medium";
	      }else if($scope.versionHistory.stages.caseType == "Civil" && $scope.versionHistory.stages.caseSpecificCategory == "Execution"){
	         $scope.versionHistory.stages.riskAssesement = "High";
	      }else if($scope.versionHistory.stages.caseType == "Civil" && ($scope.versionHistory.stages.claimAmount>1000000 || $scope.versionHistory.stages.approvalFee>1000000)){
	         $scope.versionHistory.stages.riskAssesement = "High";
	      }else if($scope.versionHistory.stages.caseType == "Civil" && $scope.versionHistory.stages.reliefSought){
	         $scope.versionHistory.stages.riskAssesement ="Medium";
	      }else if($scope.versionHistory.stages.caseType == "Civil" && !$scope.versionHistory.stages.reliefSought){
	         $scope.versionHistory.stages.riskAssesement ="Low";
	      }else{
	         $scope.versionHistory.stages.riskAssesement = val;
	      } 
	      if($scope.versionHistory.stages.riskAssesement != undefined && $scope.versionHistory.stages.riskAssesement!=""){
	            $scope.isRiskDisable = true;
	      }else{
	            $scope.isRiskDisable = false;
	      }
	    };
	    $scope.downloadAllotmentLetter = function(){
	      	var reqObj = {
	          "advocate" : _.findWhere($scope.advocatesList, {vendorID : $scope.versionHistory.stages.advocateID}) ? _.findWhere($scope.advocatesList, {vendorID : $scope.versionHistory.stages.advocateID}).vendorName : '',
	          "area" : $scope.dropDownValues.branchDetails.areaID,
	          "branch" : $scope.dropDownValues.branchDetails.branchID,
	          "caseNo": $scope.versionHistory.stages.courtCaseNo,
	          "caseFilingYear" : $filter(collectionConstants.DATE)(new Date($scope.versionHistory.stages.caseFilingYear), collectionConstants.DATE_YEAR_FILTER),
	          "courtName" :$scope.versionHistory.stages.courtName,
	          "agreementNo" : $scope.versionHistory.stages.agreementNo,
	          "customerName" : $scope.versionHistory.stages.customerName,
	          "stageOfCase" : (_.findWhere($scope.corporateCombo.stages, {caseStageID : (parseInt(tempVersion).toString())})).caseStage,
	          "subStageOfCase" : $scope.versionHistory.stages.subStageOfCase ,
	          "nextHearingDate" : $filter(collectionConstants.DATE)($scope.versionHistory.stages.nextHearingDate, collectionConstants.DATE_FILTER_STANDARD),
	          "year" : $scope.versionHistory.stages.nextHearingDate.getFullYear(),
	          "approvedFee" : $scope.versionHistory.stages.approvalFee,
	          "contactNo" : $scope.versionHistory.stages.contactNumber
	        }
	        if($scope.versionHistory.stages.letterType == true){
	          corporateCaseService.getAllotmentLetter(reqObj,'word');
	        }else{
	           corporateCaseService.getAllotmentLetter(reqObj,'pdf');
	        }
	    };
	    var date = new Date();
	    $scope.dateConfig = new DatePickerConfig({
	      	dateValue : new Date(),
	      	readonly : true
	    });
	    $scope.SentToBranchDateConfig = new DatePickerConfig({
	      	dateValue : new Date(),
	      	readonly : true
	    });

		/**Allow editing of the case details only for the last version of the last stage*/
		$scope.enableEdit = function(e) {
			$scope.versionHistory.stages.isEdit = true;
			e.preventDefault();
			e.stopPropagation();
		};
		/** Change Stages */
		$scope.changeStage = function(currentStage) {
			if (!currentStage){
				$scope.versionHistory.stages.caseStageID = stageStatusChange.caseStatusID;
			} else if(currentStage == parseInt(prevTempVersion)) {
				tempVersion = prevTempVersion;
			} else {
				tempVersion = currentStage;
			}
            if(currentStage == 5){
            	$scope.versionHistory.stages.caseStatus = "Closed"
		    }
		};
		/** Submit/Post legal case details for corporate case in the stage case tracking for the first time */
		$scope.createCorporateCase = function() {
			postCorporateCase.majorVersion = $scope.versionHistory.legalDetails.majorVersion;
			postCorporateCase.minorVersion = $scope.versionHistory.legalDetails.minorVersion;
			postSubStageVersion = tempVersion.split('.');
			postSubStageVersion = postSubStageVersion[0] + '.' + (postSubStageVersion[1] ? parseInt(postSubStageVersion[1]) + 1 : '1');
			postCorporateCase.parentCaseID = $scope.versionHistory.stages.parentCaseID;
			postCorporateCase.casefiledBy = $scope.versionHistory.stages.casefiledBy ; //
			postCorporateCase.caseFiledByName = $scope.versionHistory.stages.caseFiledByName; //
			postCorporateCase.customerName = $scope.versionHistory.stages.customerName; //
			postCorporateCase.zoneID = $scope.dropDownValues.branchDetails.zoneID; //
			postCorporateCase.regionID = $scope.dropDownValues.branchDetails.regionID; //
			postCorporateCase.areaID = $scope.dropDownValues.branchDetails.areaID;  //
			postCorporateCase.branchID = $scope.dropDownValues.branchDetails.branchID;
			postCorporateCase.noticeServedOn = $scope.versionHistory.stages.noticeServedOn;
			postCorporateCase.businessType = $scope.versionHistory.stages.businessType;
			postCorporateCase.agreementNos = $scope.versionHistory.stages.agreementNo;
			postCorporateCase.casefiledAgainst = $scope.versionHistory.stages.casefiledAgainst;
			postCorporateCase.caseType = $scope.versionHistory.stages.caseType;
			postCorporateCase.caseSpecificCategory = $scope.versionHistory.stages.caseSpecificCategory;
			postCorporateCase.caseNoTypeIndicator = $scope.versionHistory.stages.caseNoTypeIndicator;
			postCorporateCase.courtCaseNo = $scope.versionHistory.stages.courtCaseNo;
            postCorporateCase.courtName = $scope.versionHistory.stages.courtName;
            postCorporateCase.claimAmount = $scope.versionHistory.stages.claimAmount;     
            postCorporateCase.reliefText = $scope.versionHistory.stages.reliefText;
            postCorporateCase.interimReliefSought = $scope.versionHistory.stages.interimReliefSought;  //
            postCorporateCase.interimOrderPassed = $scope.versionHistory.stages.interimOrderPassed;
			postCorporateCase.injunctionType = $scope.versionHistory.stages.injunctionType;
			postCorporateCase.riskAssesement = $scope.versionHistory.stages.riskAssesement;
			// var caseYear = $filter(collectionConstants.DATE)($scope.versionHistory.stages.caseFilingYear, collectionConstants.DATE_YEAR_FILTER);
			postCorporateCase.caseFilingYear = $scope.versionHistory.stages.caseFilingYear;
			postCorporateCase.nextHearingDate = $scope.versionHistory.stages.nextHearingDate;
			postCorporateCase.firstHearingDate = $scope.versionHistory.stages.firstHearingDate;
			postCorporateCase.lastHearingDate = $scope.versionHistory.stages.lastHearingDate;
			postCorporateCase.caseStatus = $scope.versionHistory.stages.caseStatus;
			postCorporateCase.caseStageID = postSubStageVersion;
			postCorporateCase.caseStage = (_.findWhere($scope.corporateCombo.stages, {caseStageID : (parseInt(tempVersion).toString())})).caseStage;
            postCorporateCase.subStageOfCase = $scope.versionHistory.stages.subStageOfCase;  //
            postCorporateCase.disputeNature = $scope.versionHistory.stages.disputeNature;
            postCorporateCase.appealOrCAU = $scope.versionHistory.stages.appealOrCAU; //
            postCorporateCase.remarks = $scope.versionHistory.stages.remarks;
            postCorporateCase.advocateID = $scope.versionHistory.stages.advocateID;
            postCorporateCase.contactNumber = $scope.versionHistory.stages.contactNumber; //
            postCorporateCase.orderBrief = $scope.versionHistory.stages.orderBrief; //
            postCorporateCase.courtOrder = $scope.versionHistory.stages.courtOrder;
			postCorporateCase.orderFavourToCustomer = $scope.versionHistory.stages.orderFavourToCustomer; //
			postCorporateCase.courtRemarks = $scope.versionHistory.stages.courtRemarks;  //
			postCorporateCase.approvalFee = $scope.versionHistory.stages.approvalFee;
			postCorporateCase.assignedTo = $scope.versionHistory.stages.assignedTo;
			postCorporateCase.entryDate = $scope.versionHistory.stages.entryDate;
			postCorporateCase.replyFiledStatus = $scope.versionHistory.stages.replyFiledStatus;  //
            postCorporateCase.allotmentFiledStatus = $scope.versionHistory.stages.allotmentFiledStatus; //
            postCorporateCase.isPaperAvailable = $scope.versionHistory.stages.isPaperAvailable; 
			// postCorporateCase.documentImageRef = $scope.versionHistory.stages.documentImageRef;
			postCorporateCase.documentImageRef = $scope.versionHistory.stages.docUpload;
			if($scope.parentCaseId){
			    postCorporateCase.securityAmount = $scope.versionHistory.stages.bankDetails.securityAmount ;
			    postCorporateCase.pmtModeRequirement = $scope.versionHistory.stages.bankDetails.pmtModeRequirement;
			    postCorporateCase.bankType = $scope.versionHistory.stages.bankDetails.bankType;
			    postCorporateCase.pmtModeNumber = $scope.versionHistory.stages.bankDetails.pmtModeNumber;
			    postCorporateCase.date = $scope.versionHistory.stages.bankDetails.date;
			    postCorporateCase.bankName = $scope.versionHistory.stages.bankDetails.bankName;
			    postCorporateCase.inFavourOf = $scope.versionHistory.stages.bankDetails.inFavourOf;
			    postCorporateCase.sentToBranchDate = $scope.versionHistory.stages.bankDetails.sentDate;
			    postCorporateCase.recipientName = $scope.versionHistory.stages.bankDetails.recipientName;
			}
			corporateCaseService.updateCustomerCase($scope.versionHistory.legalDetails.caseID, postCorporateCase, postSubStageVersion).then(function(response) {
				if (response.status === collectionConstants.SUCCESS) {
					$modalInstance.dismiss();
					dialogService.showAlert(collectionConstants.ALERT, collectionConstants.SUCCESS, collectionConstants.SUCCESS_MSG.CASE_TRACK_UPDATE).result.then(function() {
					}, function() {
						$rootScope.transitionBackstate=true;
						$state.current.forceReload = true;
						$state.transitionTo($state.current,{ caseID : $scope.versionHistory.legalDetails.caseID, agreementNo : $scope.versionHistory.legalDetails.agreementNo },{
							reload: true
						});
					});
				}
			});
		};
	};
	corpCaseTracking.controller('versionCorporateHistoryController', ['$scope','$stateParams', '$state', '$modalInstance', 'data','messageBus','dialogService','$rootScope','masterService','corporateCaseService', '$filter','$globalScope', 'lazyModuleLoader','appFactory', versionCorporateHistoryController]);
	return versionCorporateHistoryController;
});