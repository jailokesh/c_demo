 /** Story : case tracking queue for Corporate Legal user.
 * Created By - OFS
 * Represents a Bulk updation controller file.
 * @version v1.0 Date:  11-04-2018
 */
define([ 'require', 'corpCaseTracking', 'utility', 'collectionConstants', 'constants' ,'DatePickerConfig','corpLegalConstants'], function(r, corpCaseTracking, utility, collectionConstants, constants,DatePickerConfig,corpLegalConstants) {
	'use strict';
	
	var caseTrackBulkUpdationController = function($scope, $stateParams,$state, corpCTBulkUpdationService, dialogService,$rootScope,$modal,$upload,environmentConfig,getBUAdvocateInfo) {				
		var view,product,stages,caseTypeGeneral,mainMenu,updatedMenu;		
		function init(){
			view = $stateParams.serviceProvider;
			if($stateParams.serviceProvider === "CORPORATECASESTAGETRACKING"){
				$scope.excelUpload = true;
			}else{
				$scope.excelUpload = false;
			}
			$scope.bulkBtn = true;
			product = $rootScope.productTypes;			
			stages = corpLegalConstants.LEGAL_VALUES;
			$scope.excelTypes = corpLegalConstants.BULK_EXCEL_TYPE;
			$scope.excelType = $scope.excelTypes[0].value;
			$scope.advocatesList = [];
			$scope.courtNames = [];
			$scope.noticeStages = corpLegalConstants.STAGES;
			$scope.isallData = false;
			caseTypeGeneral = angular.copy(corpLegalConstants.LEGAL_VALUES.CASE_TYPE_GENERAL);
			//getBulkList(view);
			getAdvocates();
			$scope.advocateList = getBUAdvocateInfo.advocates;
		}		
		init();	
		$scope.initialize = function(){
			$scope.showSummaryPage = false;
			$scope.showUploadPage = true;
			$scope.uploadShow = false;
			$scope.uploadedFileName = '';
			document.getElementById('userUpload').value = '';
		};
		function getAdvocates(){
			$scope.isallData = true;
			corpCTBulkUpdationService.advocateList($scope.isallData).then(function(response) {
				var advocates = response ? response : [];				
				_.each(advocates,function(item){
					var list = {};
					list.label = item.vendorName;
					list.value = item.vendorID;					
					list.selected = false;
					$scope.advocatesList.push(list);
				});
				getCourtName(view);
			});
		}
		function getBulkList(view){
			corpCTBulkUpdationService.getCaseType(view).then(function(response){				
				_.each(response,function(item,index){					
					item.selected = false;					
				});
				$scope.caseType = response || [];				
			});
		}
		function getCourtName(view){
			corpCTBulkUpdationService.courtName(view).then(function(response) {
				var courtList = response ? response : [];				
				_.each(courtList,function(item){
					var list = {};
					list.label = item.branch;
					list.value = item.branchID;		
					list.selected = false;
					$scope.courtNames.push(list);
				});		
				mainMenu = [ {
					label : "Case Type General",
					value : "caseType",			
					subMenu : caseTypeGeneral
				}, {
					label : "Court Name",
					value : "courtName",			
					subMenu : $scope.courtNames
				}, {
					label : "Advocates",
					value : "advocateID",			
					subMenu : $scope.advocatesList
				},{
					label : "Stages",
					value : "caseStage",			
					subMenu : $scope.noticeStages
				} ];
				updatedMenu = angular.copy(mainMenu);					
			});
		}
		$scope.selectAllCheckbox = function(check){
			_.each($scope.caseType,function(item){
				if(check){
					item.selected = true;
				}else{
					item.selected = false;
				}				
			});
			btnDisabled();
		};
		$scope.selectCheckbox = function(check){
			var data = _.where($scope.caseType,{selected:true});
			if(data.length === $scope.caseType.length){
				$scope.selecteAll = true;
			}else{
				$scope.selecteAll = false;
			}
			btnDisabled();
		};
		function btnDisabled(){
			var data = _.where($scope.caseType,{selected:true});
			if(data.length === 0){
				$scope.bulkBtn = true;
			}else{
				$scope.bulkBtn = false;
			}
		}	
		var HearingDateConfig = new DatePickerConfig({						
			readonly : true,
			value : ''
		});
		/**
		 * Method to convert date to YYYY-MM-DD format
		 */
		var dateFormater = function(dateVal) {
			if (!dateVal) {
				return '';
			}
			if (typeof dateVal === 'string') {
				var dateArr = dateVal.split('-');
				dateVal = dateArr[2] + '-' + dateArr[1] + '-' + dateArr[0];
			}
			var date = new Date(dateVal);
			var yyyy = date.getFullYear().toString();
			var mm = (date.getMonth() + 1).toString();
			var dd = date.getDate().toString();
			
			return yyyy + '-' + (mm[1] ? mm : "0" + mm[0]) + '-' + (dd[1] ? dd : "0" + dd[0]);
		};
		$scope.filterPopup = {
				date : HearingDateConfig,
				onOpen : function(contentData) {					
					contentData.options = angular.copy(updatedMenu);
					contentData.isPopoutOpen = true;
					/*contentData.date.value="";
					contentData.date.dateVal = new Date();
					contentData.date.initDate = new Date();*/
				},				
				checkAll : function(options) {
					var selectedMenu = _.where(options, {
						selected : true
					});					
				},
				checkCaseTypeGeneral : function(options,item){
					var caseTypeGeneral = _.findWhere(options, {
						label : 'Case Type General'
					});
					_.each(caseTypeGeneral.subMenu,function(data){
						if(data.key === item.key){
							data.selected = true;
						}else{
							data.selected = false;
						}															
					});	
				},
				checkStages : function(options,item){							
					var stages = _.findWhere(options, {
						label : 'Stages'
					});							
					_.each(stages.subMenu,function(data){
						if(data.caseStageID === item.caseStageID){
							data.selected = true;
						}else{
							data.selected = false;
						}															
					});									
				},
				filterQueue : function(contentData,flag) {

					if(!flag)
					{
						$scope.isFiltered = false;
						$scope.selecteAll = false;
						$scope.caseType = [];
						updatedMenu = angular.copy(mainMenu);
						contentData.date.value = '';
						$scope.filterPopup.close();
						return;
					}
					$scope.filterPopup.reqObj = {};
					var options = contentData;
					for (var i = 0; i < contentData.length; i++) {						
						$scope.filterPopup.reqObj[options[i].value] = [];
						for (var j = 0; j < options[i].subMenu.length; j++) {
							if (options[i].subMenu[j].selected) {
								$scope.filterPopup.reqObj[options[i].value].push(options[i].subMenu[j].value);
							}
						}
						$scope.filterPopup.reqObj[options[i].value] = $scope.filterPopup.reqObj[options[i].value].toString();																
					}
					$scope.filterPopup.reqObj.productGroup = $rootScope.productTypes;
					$scope.filterPopup.reqObj.type = 'BULKUPDATE';
					if($scope.filterPopup.date.value){
						var hearingDate = $scope.filterPopup.date.value.split('/');
						var nextDate = new Date(dateFormater(utility.formDateString(new Date(hearingDate[2]+'/'+hearingDate[1]+'/'+hearingDate[0]),true)));
						$scope.filterPopup.reqObj.nextHearingDate = nextDate.setHours(0,0,0);
					}
					$scope.filterPopup.reqObj.view = view;					
					if (!$scope.filterPopup.reqObj.advocateID && !$scope.filterPopup.reqObj.courtName && !$scope.filterPopup.reqObj.caseStage && !$scope.filterPopup.reqObj.caseType && !$scope.filterPopup.date.value) {
						dialogService.showAlert(collectionConstants.REPO_MSG.ERROR, collectionConstants.REPO_MSG.ERROR, collectionConstants.REPO_MSG.SELECT);
						return;
					}
					corpCTBulkUpdationService.getCaseTypeFliter($scope.filterPopup.reqObj).then(function(response){										
						$scope.selecteAll = false;
						$scope.isFiltered = true;
						$scope.caseType = response || [];				
					});
					updatedMenu = angular.copy(options);
					if (typeof $scope.filterPopup.close === 'function') {
						contentData.isPopoutOpen = false;
						$scope.filterPopup.close();
					}
				},
				resetAndClose : function(contentData) {
					updatedMenu = angular.copy(mainMenu);	
					contentData.isPopoutOpen = false;
					$scope.filterPopup.close();					
				}
		};

		$scope.cancelAll = function() {
			dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.CANCEL).result.then(function() {
		       $state.go("collections.corporateCaseTracking");
		    }, function() {});
		};
		/**
		 * Method is to get Advocate List with AdvocateName and AdvocateID
		 */
		$scope.onAdvocateChange = function(item) {
			var advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}) ? _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName : '-';
			return advocateName;
		}
		$scope.corpBulkUpdation = function(){
			$modal.open({
				templateUrl : 'app/collections/corporateLegal/corporateCaseTracking/partials/corpInitiateUpdation.html',
				controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {		
					$scope.stages = data.stages;
					$scope.nextHearingDateConfig = new DatePickerConfig({						
						readonly : true,
						value : '',
						minDate : new Date()
					});
					$scope.close = function(data) {
						if (data) {
							$modalInstance.close(data);
						} else {
							$modalInstance.dismiss();
						}
					};
					$scope.initiateUpdation = function() {
						if(!$scope.stage && !$scope.subStageOfCase && !$scope.nextHearingDate){
							dialogService.showAlert('Error', "Error", "Please enter values to update!");
							return;
						}
						var selectedAdvocates = _.where(updatedMenu[2].subMenu,{selected:true});
						var selectedCases = _.where(updatedMenu[0].subMenu,{selected:true});
						var selectedCourts = _.where(updatedMenu[1].subMenu,{selected:true});
						var selectedStages = _.where(updatedMenu[3].subMenu,{selected:true});
						var caseids = [];
						_.each(data.caseType,function(item){
							if(item.selected){
								caseids.push(item.caseID);
							}
						});
						var reqObj = {
						    filters: {
						        advocateID: selectedAdvocates ? _.pluck(selectedAdvocates,'value').toString() : '',
						        caseType: selectedCases ?_.pluck(selectedCases,'value').toString() : '',
						        courtName: selectedCourts ?_.pluck(selectedCourts,'value').toString() : '',
						        nextHearingDate: data.nextHearingDate ? data.nextHearingDate : '',
						        //stageID: selectedStages ?_.pluck(selectedStages,'value').toString() : '',
						        caseStage: selectedStages ?_.pluck(selectedStages,'value').toString() : ''
						    },
						    caseIDs: caseids,

						    updateAll: data.selectAll
						};
						if($scope.stage){
							
							reqObj.stageID = $scope.stage.caseStageID;
							reqObj.caseStage = $scope.stage.caseStage;
						}
						if($scope.subStageOfCase){
							reqObj.subStageOfCase = $scope.subStageOfCase;
						}
						if($scope.nextHearingDate){
							reqObj.nextHearingDate = new Date($scope.nextHearingDate).toISOString();
						}
						$scope.$parent.reqObj = reqObj;
						$modalInstance.close();
					};
				} ],
				backdrop : 'static',
				size : 'md',
				resolve : {
					data : function() {
						return {
							stages : updatedMenu[3].subMenu,
							nextHearingDate : $scope.filterPopup.reqObj.nextHearingDate,
							caseType : $scope.caseType,
							selectAll : $scope.selecteAll
						};
					}
				},
				windowClass : 'modal-custom'
			}).result.then(function(response) {
				corpCTBulkUpdationService.updateCases($scope.reqObj,view).then(function(response){
					if(response.status == 'success'){
						dialogService.showAlert('Success', "Success", "Case(s) updated successfully").result.then(function(){},function(){
							corpCTBulkUpdationService.getCaseTypeFliter($scope.filterPopup.reqObj).then(function(response){	
								$scope.selecteAll = false;
								$scope.isFiltered = true;
								$scope.caseType = response || [];

							});
						});
					}
				});
			});
		};

	/*..................................Excel Upload functionality starts here...............................*/
		 /*Method to check the uploaded file type*/
	 	var file;
        $scope.onFileSelect = function($files) {
            //$files: an array of files selected, each file has name, size, and type.
            if ($files && $files.length > 0) { //todo:Check file extension here
                var extTemp = $files[0].name.split('.');
                var ext = extTemp[extTemp.length - 1];
                if (ext.indexOf('cs') === 0) {
                    file = $files[0];
                    $scope.uploadedFileName = file.name;
                    $scope.formNotValid = false;
                    $scope.uploadShow = true;
                } else {
                	dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.UPLOAD_CSV_CHECK);
                    $scope.uploadedFileName = '';
                    $scope.uploadShow = false;
                }
            }
        };
        /* Method to upload file */
        $scope.upload = function(excelType) {
        	if (file === undefined) {
        		$scope.formNotValid = true;
        	} else {
        		corpCTBulkUpdationService.excelUpload(file).then(function(data){
        			if(!data.data.error) {
        				$scope.uploadStatus = data.data;
        				$scope.uploadStatus.uploadStatus = "Uploaded Successfully"
        				$scope.showSummaryPage =true;
        				$scope.uploadShow = false;
        				$scope.showUploadPage = false;
        				document.getElementById('userUpload').value = '';
        			} else {
        				dialogService.showAlert("Error", constants.ERROR_HEADER.error, data.data.error);
        			}
        		});  
            }
        };
		
        $scope.errorDownload = function() {
        	/*if($scope.uploadStatus.summaryID){
        		corpCTBulkUpdationService.downloadFile($scope.uploadStatus.summaryID,$scope.uploadStatus.fileName);
        	}*/
        	utility.downloadJSONToCSV($scope.uploadStatus.errorReport, "CorporateLegal-BulkUpdationErrorReport");
        };
        $scope.showUpload = function() {
  			$scope.uploadedFileName = '';
			$scope.initialize();
  		};
  		//method to download sample template for data updation
		$scope.downloadTemplate = function() {
			corpCTBulkUpdationService.downloadJSONToCSV(corpLegalConstants.DATA_UPDATION_CASES, "SampleDataTemplate");
		};
        /*..................................Excel Upload functionality ends here...............................*/
	};
	corpCaseTracking.controller('caseTrackBulkUpdationController', [ '$scope', '$stateParams','$state','corpCTBulkUpdationService', 'dialogService', '$rootScope','$modal','$upload','environmentConfig','getBUAdvocateInfo', caseTrackBulkUpdationController ]);
	return caseTrackBulkUpdationController;
});