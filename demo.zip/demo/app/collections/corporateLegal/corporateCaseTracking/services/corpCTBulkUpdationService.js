/** Story Id : Corporate case tracking 
 * Created By - OFS
 * Represents corporate case tracking.
 * @version v1.0 Date:  04-04-2018
 */
define(['require','corpCaseTracking','collectionServiceURLs','constants','collectionConstants'],function(require,corpCaseTracking,collectionServiceURLs,constants,collectionConstants){
	var corpCTBulkUpdationService = function($q,restProxy,$rootScope,$http,$upload) {	
		/**
	   	 * Method to get Legal Cases list for the specific BRM/ARM
	   	 */
		this.getCaseType = function(view){
			var param = {
				productGroup : $rootScope.productTypes					
			};
			param.view = view;
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.queryParams = param;
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.urlParams = {};
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE).then(function(data){ 
				if (data.status === constants.SUCCESS_MSG) {
					return data.data;
				} else {
					return $q.reject(data);
				}
			});	
		};

		this.getCaseTypeFliter = function(reqObj){
			var param = {
				productGroup : $rootScope.productTypes					
			};
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE_BULKUPLOAD.queryParams = param;
	        var bodyParams = {
	            'caseStage': reqObj.caseStage,
	            'caseType': reqObj.caseType,
	            'nextHearingDate':reqObj.nextHearingDate
	        }
	        if(reqObj.advocateID.length > 0 && reqObj.advocateID != ""){
	        	bodyParams.advocateID = reqObj.advocateID.split(",");
	        }
	        if(reqObj.courtName.length > 0 && reqObj.courtName !=""){
	        	bodyParams.courtName = reqObj.courtName.split(",");
	        }
            return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE_BULKUPLOAD,bodyParams).then(function(data){ 
	            if(data.message && data.message.errors && data.message.errors.length){
		            if(data.message.errors[0].errorCode === 'COM-EXE-2002'){
			            dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, data.errors[0].message);
		            }
		        }
	            return data.data;
	        });
        }

		this.advocateList = function(isallData) {
			var reqObj = {};
			if (isallData) {
				reqObj.allData = isallData;
			};
			reqObj.currentStatus = collectionConstants.APPLICATION_STATUS.STATUS9 + ',' + collectionConstants.APPLICATION_STATUS.STATUS8 + ',' + collectionConstants.APPLICATION_STATUS.STATUS7 + ',' + collectionConstants.APPLICATION_STATUS.STATUS12;
			reqObj.vendorType = "ADVOCATES";
			reqObj.productGroup = $rootScope.productTypes;
			collectionServiceURLs.corpLegalServices.GET_ADVOCATE_LIST.queryParams = reqObj;
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_LIST).then(function(data) {
				if (data.status === constants.SUCCESS_MSG) {
					var vendorList = data.data;
					return vendorList;
				}else {
					return $q.reject(data);
				}
			});
		};
		
		this.courtName = function(view) {			
			var param = {
				view : view,
				type : 'COURTNAME',
				productGroup : $rootScope.productTypes
			};			
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.queryParams = param;
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.urlParams = {};			
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE).then(function(data) {
				if (data.status === constants.SUCCESS_MSG) {
					var courtNameList = data.data;
					return courtNameList;
				}else {
					return $q.reject(data);
				}
			});
		};
		
		this.updateCases = function(reqObj,type) {
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.queryParams = {
				view : 'BULKUPDATE',
				type : type,
				productGroup : $rootScope.productTypes
			};
			return restProxy.save('PUT',collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST,reqObj).then(function(data) {
				if (data.status === constants.SUCCESS_MSG) {
					return data;
				}else {
					return $q.reject(data);
				}
			});
		};
		
		//to get the advocate list
        this.getAdvocateList = function(){
	        return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_DETAILS).then(function(data) {
	            var advocateList = data.data;
	            return advocateList;
	        });
        };
        
		this.excelUpload = function(file){
		    return $upload.upload({
                url: '/collectionsapi/corpLegalCaseMigration',
                method: 'POST',
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization':getCookie('token')
                },
                //withCredentials: true,
                data: {
                 collectionType : {
                  type : 'LegalCase'
                 },
                 updateType : 'UPDATE_STAGE'
                },
                file: file,
                fileFormDataName: 'CorpCaseMigrationData'
            }).progress(function() {

            }).success(function(data, status, headers, config) {
              
                if (status === 200) {   
                           return data;
                } else {
                    console.log("error")
                }
            });  
		}
		this.downloadJSONToCSV = function(JSONData,ReportTitle) {

			var arrData = (typeof(JSONData) != 'object') ? JSON.parse(JSONData) : JSONData;
			var csv = '';
			var row = '';
			for ( var index in arrData[0]) {
			  row += index + ',';
			} 
			row = row.slice(0,-1);
			csv += row + '\r\n';
	  
			for (var i = 0; i<arrData.length; i++) {
			  row = '';
			  for( var index in arrData[i]) {
				row += '"'+ arrData[i][index] + '",';
			  }
			  row.slice(0, row.length -1);
			  csv += row + '\r\n';
			} 
			if(csv == '') {
			  //console.log("Invalid Data");
			  return;
			} else {
			  var fileName = "CFE_ID Report";
			  fileName += ReportTitle.replace(/ /g,"_");  
			  var uri = 'data:text/csv;charset=utf-8,' + escape(csv);
			  var link = document.createElement("a");
			  link.href = uri;
			  link.style = "visibility:hidden";
			  link.download = fileName + ".csv";
			  document.body.appendChild(link);
			  link.click();
			  document.body.removeChild(link);
			}        
		  }
    };
	corpCaseTracking.service('corpCTBulkUpdationService',['$q','restProxy','$rootScope','$http','$upload',corpCTBulkUpdationService]);
	return corpCTBulkUpdationService;
});