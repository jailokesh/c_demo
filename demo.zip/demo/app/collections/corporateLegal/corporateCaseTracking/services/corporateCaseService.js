/** Story Id : Corporate case tracking 
 * Created By - OFS
 * Represents a service for corporate case tracking.
 * @version v1.0 Date:  04-04-2018
 */
define([ 'require', 'corpCaseTracking', 'collectionServiceURLs', 'constants', 'collectionConstants','utility' ], function(require, corpCaseTracking, collectionServiceURLs, constants, collectionConstants,utility) {
'use strict';
	var corporateCaseService = function($q, restProxy, dialogService, $stateParams, $rootScope, $http, masterService ) {
		var limit = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		var legalData, initiationData, productGroup;
		var header = {
           'Content-Type' : 'application/json',
           'Authorization':getCookie('token'),
           'userID' : $rootScope.identity.userName
        };
        var serviceObj = this;
        this.locations = { 
            branchDetails : {}
        };
        this.isFirstChild = false;
		/**
		 * Model set for get and post of CASE DETAILS - LEGAL - STAGE TRACKING
		 */
		this.returnCorporateCaseDetails = function() {
			return new CorporateCaseDetails(); 
		};
		this.setLegalDetails = function(legalInfo) {
			legalData = legalInfo;
		};
		this.getLegalDetails = function() {
			return legalData;
		};
		this.setInitiationFlag = function(initiationFlag) {
			initiationData = initiationFlag;
		};
		this.getInitiationFlag = function() {
			return initiationData;
		};
		var pageDetails;
		this.setPageDetails = function(value){
			pageDetails = value;
		};
		this.getPageDetails = function(){
			return pageDetails;
		};

		this.getProductGroup = function(){
			return productGroup?productGroup:$rootScope.productTypes;
		};
		
		var CorporateCaseDetails;
		this.setCCPageDetails = function(value){
			CorporateCaseDetails = value;
		};
		this.getCCPageDetails = function(){
			return CorporateCaseDetails;
		};
		var _agreementNo;
		this.setInitiatedAgreement = function(value){
			_agreementNo = value;
		};
		this.getInitiatedAgreement = function(){
			return _agreementNo;
		};
		/**
		 * Method to get corporate Cases list for the specific agreement number
		 * |search by agreement Number
		 */
		this.getCorporateCases = function(params) {
			params.offset = params.offset ? ((params.offset - 1) * limit) : 0;
			params.limit = limit;
			collectionServiceURLs.legalServices.CORPORATE_CASE.queryParams = params;
			collectionServiceURLs.legalServices.CORPORATE_CASE.urlParams = {};
			return restProxy.get(collectionServiceURLs.legalServices.CORPORATE_CASE).then(function(data) {
				data.offset = params.offset;
				return data;
			});
		};
		/**
		 * Method to get corporate Cases - details list against CASEID | caseID -
		 * input
		 */
		this.getCholaCaseDetails = function(caseID) {
			collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS.urlParams = {
				caseID : caseID
			};
			collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS.queryParams = {};
			return restProxy.get(collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS).then(function(data) {
				return data.data[0];
			});
		};
		/** Method to get agreement information based on agreementNo */
		this.getAgreementCases = function(agreementNo, caseID) {
			collectionServiceURLs.legalServices.GET_AGREEMENT_CASE.urlParams = {
				agreementNo : agreementNo
			};
			collectionServiceURLs.legalServices.GET_AGREEMENT_CASE.queryParams = {
				caseID : caseID
			};
			return restProxy.get(collectionServiceURLs.legalServices.GET_AGREEMENT_CASE).then(function(data) {
				if(data.data && data.data[0]){
					if(data.data[0].bucketTrend && data.data[0].bucketTrend.length > 0){
						data.data[0].bucketTrend = utility.handleDelequency(true,data.data[0].bucketTrend,collectionConstants.NON_DELEQUENCY_DATA);
					}else{
						data.data[0].bucketTrend = utility.handleDelequency(false,[],collectionConstants.NON_DELEQUENCY_DATA);
					}
				}
				productGroup = data && data.data && data.data[0] ? data.data[0].productGroup:'';
				return data.data[0];
			});
		};
		/**
		 * Method to get corporate Cases - expense details list against CASEID |
		 * caseID - input
		 */
		this.getCorporateAgreementDetails = function(agrNo) {
			collectionServiceURLs.legalServices.CORPORATE_AGREEMENT_DETAILS.urlParams = {
				agreementNo : agrNo
			};
			collectionServiceURLs.legalServices.CORPORATE_AGREEMENT_DETAILS.queryParams = {
				'view' : 'CHOALFIELDCASE'
			};
			return restProxy.get(collectionServiceURLs.legalServices.CORPORATE_AGREEMENT_DETAILS).then(function(data) {
				if (data.length) {
					dialogService.showAlert('Alert', 'Success', $stateParams.caseID + " has cases filed against chola ").result.then(function() {
					}, function() {
					});
				}
				return data;
			});
		};
		/**
		 * Method to get corporate queue list for the specific agreement number |
		 * search by agreement Number
		 */
		this.getCorporateQueue = function(params) {
			params.offset = params.offset ? ((params.offset - 1) * limit): 0;
			params.limit = limit;
			params.productGroup = $rootScope.productTypes ? $rootScope.productTypes : 'VF';
			params.isCount = true;
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.queryParams = params;
			collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.urlParams = {};
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE).then(function(data) {
				if(data.data){
					_.each(data.data, function(corporateCase) {
						var workflow = corporateCase.workflow.length ? corporateCase.workflow[0] : {};
						if (workflow.agreementNos && workflow.agreementNos.length) {
							corporateCase.agreementNo = workflow.agreementNos[0];
						} else {
							corporateCase.agreementNo = '';
						}
					});
					data.offset = params.offset;
				}
				return data;
			});
		};
		//GEt property details for HE
		this.getAssetDetails = function(agreementNo, productGroup) {
			collectionServiceURLs.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS.queryParams = {
				'product' : productGroup
			};
			collectionServiceURLs.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			var _clone = angular.copy(collectionServiceURLs.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS);
			_clone.notify = false;
			
			return restProxy.get(_clone, "assetdetails").then(function(data) {
				return data.data;
			});
		};
		/**
		 * Method to submit corporate- case and expense details for CASEID |
		 * caseID - input
		 */
		this.createCorporateCase = function(postCorporateCase) {
			collectionServiceURLs.legalServices.CORPORATE_FILE_CASE.urlParams = {};
			collectionServiceURLs.legalServices.CORPORATE_FILE_CASE.queryParams = {};
			return restProxy.save('POST', collectionServiceURLs.legalServices.CORPORATE_FILE_CASE, postCorporateCase).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to submit corporate- case and expense details for CASEID
		 * |caseID - input
		 */
		this.updateCustomerCase = function(caseID, postExpenseCase, stageID) {
			collectionServiceURLs.corpLegalServices.CORPORATE_FILE_CASE_UPDATE.urlParams = {
				caseID : caseID,
				stageID : stageID
			};
			collectionServiceURLs.corpLegalServices.CORPORATE_FILE_CASE_UPDATE.queryParams = {
				'action' : 'CUSTOMERFILEDCASE'
			};
			return restProxy.save('PUT', collectionServiceURLs.corpLegalServices.CORPORATE_FILE_CASE_UPDATE, postExpenseCase).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to submit corporate- case and expense details for CASEID |
		 * caseID - input
		 */
		this.createExpenseDetails = function(expenseDetails) {
			collectionServiceURLs.legalServices.POST_EXPENSE_DETAILS.urlParams = {};
			collectionServiceURLs.legalServices.POST_EXPENSE_DETAILS.queryParams = {};
			return restProxy.save('POST', collectionServiceURLs.legalServices.POST_EXPENSE_DETAILS, expenseDetails).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to submit corporate- case and expense details for CASEID |
		 * caseID - input
		 */
		this.createChildCase = function(childCase) {
			collectionServiceURLs.corpLegalServices.CORPORATE_CHILD_CASE.urlParams = {};
			collectionServiceURLs.corpLegalServices.CORPORATE_CHILD_CASE.queryParams = {};
			return restProxy.save('POST', collectionServiceURLs.corpLegalServices.CORPORATE_CHILD_CASE, childCase).then(function(data) {
				return data;
			});
		};
		/** Method to get records - historical stages captured for the caseID */
		this.getCorporateLegalStages = function(caseID) {
			collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS.queryParams = {};
			collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS.urlParams = {
				caseID : caseID
			};
			return restProxy.get(collectionServiceURLs.corpLegalServices.CORPORATE_CASE_DETAILS).then(function(data) {
				return data.data;
			});
		};

		/** close Corporate Case */
		this.closeCase = function(caseID, stageID, bodyParams, actionCode) {
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.queryParams = {
				action : actionCode
			};
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.urlParams = {
				caseID : caseID,
				stageID : stageID
			};
			return restProxy.save('PUT', collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST, bodyParams).then(function(data) {
				return data.data;
			});
		};
		/** Reopen Corporate Case */
		this.reopenCase = function(caseID, stageID, bodyParams, actionCode) {
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.queryParams = {
				action : actionCode
			};
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.urlParams = {
				caseID : caseID,
				stageID : stageID
			};
			return restProxy.save('PUT', collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST, bodyParams).then(function(data) {
				return data.data;
			});
		};
		/** get advocates list */
		this.advocateList = function(isallData) {
			var reqObj = {};
			if (isallData) {
				reqObj.allData = isallData;
			};
			reqObj.currentStatus = collectionConstants.APPLICATION_STATUS.STATUS9 + ',' + collectionConstants.APPLICATION_STATUS.STATUS8 + ',' + collectionConstants.APPLICATION_STATUS.STATUS7 + ',' + collectionConstants.APPLICATION_STATUS.STATUS12;
			reqObj.vendorType = "ADVOCATES";
			collectionServiceURLs.corpLegalServices.GET_ADVOCATE_LIST.queryParams = reqObj;
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_LIST).then(function(data) {
				var vendorList = data.data;
				return vendorList;
			});
		};
		/**
		 * Method to get expense details info for the specific case ID and
		 * agreement No.
		 */
		this.getExpenseDetails = function(caseID) {
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.urlParams = {
				caseID : caseID
			};
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.queryParams = {
				'view' : 'EXPENSE'
			};
			return restProxy.get(collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST).then(function(data) {
				return data.data;
			});
		};
		/**
		 * Method to get invoice details info for the specific case ID and
		 * agreement No.
		 */
		this.getInvoiceDetails = function(queryInput) {
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.urlParams = {
				caseID : queryInput.caseID
			};
			collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST.queryParams = {
				'view' : 'INVOICE',
				'invoiceID' : queryInput.invoiceID
			};
			return restProxy.get(collectionServiceURLs.corpLegalServices.SUBMIT_REQUEST).then(function(data) {
				return data.data[0];
			});
		};
        //to get header info
		this.getHeaderInfo = function(input){
	        var queryObj = {"agreementNo" : input};
            return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_HEADER_DETAILS, queryObj).then(function(response) {
	        if(response && response.data) {
	           return response;
	        } else {
		        return [];
	        }
	        });
        };

        /**
		 * Method to right pane details
	    */
        this.getRightPaneDetails = function(agreementNo){
	        var bodyParams = {
	            'agreementNo' : agreementNo
	        }
            return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS,bodyParams).then(function(data){ 
	            if(data.message && data.message.errors && data.message.errors.length){
		            if(data.message.errors[0].errorCode === 'COM-EXE-2002'){
			            dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, data.errors[0].message);
		            }
		        }
	            return data.data;
	        });
        }

	    /**
		 * Method to get drop down values for zone,region,area,branch
	    */
	    this.getUserDataMapping = function() {
	      if ($rootScope.identity.zoneIDs.length > 0) {
	        masterService.getAreas({
	          ZoneID : $rootScope.identity.zoneIDs.toString()
	        }, 'zone').then(function(userZones) {
	          $rootScope.identity.userZones = userZones;
	          serviceObj.locations.branchDetails.zones = userZones;
	          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
	        });
	      }
	      if ($rootScope.identity.regionIDs.length > 0) {
	        masterService.getAreas({
	          regionID : $rootScope.identity.regionIDs.toString()
	        }, 'region').then(function(userRegions) {
	          $rootScope.identity.userRegions = userRegions;
	          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
	          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
	        });
	      }
	      if ($rootScope.identity.areaIDs.length > 0) {
	        masterService.getAreas({
	          areaID : $rootScope.identity.areaIDs.toString()
	        }, 'area').then(function(userAreas) {
	          $rootScope.identity.userAreas = userAreas;
	          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
	          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
	        });
	      }
	      if ($rootScope.identity.branchIDs.length > 0) {
	        masterService.getBranches({
	          branchID : $rootScope.identity.branchIDs.toString()
	        }).then(function(userBranches) {
	          $rootScope.identity.userBranches = userBranches;
	          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
	        });
	      }
	      return serviceObj;
	    };

	    this.getUserSelection = function(reqObj,type) {
	     	var identity = $rootScope.identity;
	     	if (identity.zoneIDs.length > 0) {
	     		return masterService.getAreas(reqObj,type).then(function(userZones) {
	     			return userZones;
	     		});
	     	}
	    };

	    // to get the ALM / RLM / ZLM / ZRM list for case assigned to
        this.getManagerList = function(){ 
			var role = $rootScope.identity.roles[0].roleName;
			collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS.queryParams = {};
			collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS.queryParams.roleName = role;
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS).then(function(data) {
				var managerList = data.data;
				return managerList;
			});
        };
        //to get the advocate list
        this.getAdvocateList = function(){
	        return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_DETAILS).then(function(data) {
	            var advocateList = data.data;
	            return advocateList;
	        });
        };
        this.getAllotmentLetter = function(queryObj, docType){
        	var requestUrl;
        	if (docType == 'word') {
		        requestUrl = collectionServiceURLs.corpLegalServices.GET_ALLOTMENT_LETTER_WORD;
		    } else {
		        requestUrl = collectionServiceURLs.corpLegalServices.GET_ALLOTMENT_LETTER;
		    }
        	requestUrl.queryParams = {};
        	requestUrl.queryParams.advocateName = queryObj.advocate;
        	requestUrl.queryParams.area = queryObj.area;
        	requestUrl.queryParams.branch = queryObj.branch;
        	requestUrl.queryParams.caseNo = queryObj.caseNo;
        	requestUrl.queryParams.caseFilingYear = queryObj.caseFilingYear;
        	requestUrl.queryParams.courtName = queryObj.courtName;
        	requestUrl.queryParams.agreementNo = queryObj.agreementNo;
        	requestUrl.queryParams.customerName = queryObj.customerName;
        	requestUrl.queryParams.stageOfCase = queryObj.stageOfCase;
        	requestUrl.queryParams.subStageOfCase = queryObj.subStageOfCase;
        	requestUrl.queryParams.nextHearingDate = queryObj.nextHearingDate;
        	requestUrl.queryParams.year = queryObj.year;
        	requestUrl.queryParams.approvedFee = queryObj.approvedFee;
        	requestUrl.queryParams.contactNo = queryObj.contactNo;
        	requestUrl.queryParams.docType = docType;

        	if (docType == 'word') {
		        restProxy.get(requestUrl).then(function(result) {
		           if (result.status === "success") {
		                var blob = new Blob([ result.data ], {
				            type : "application/docx"
			            });
			            if (navigator.appVersion.toString().indexOf('.NET') > 0) {
				            window.navigator.msSaveOrOpenBlob(blob, 'Allotment letter.docx');
			            } else {
				            var url = URL.createObjectURL(blob);
				            var link = document.createElement("a");
				            if (link.download !== undefined) {
				                link.setAttribute("href", url);
				                link.setAttribute("download", 'Allotment letter.docx');
				                link.style.visibility = 'hidden';
				                link.click();
				                return result;
				            }
			            }
		            }
		        });
		    } else {
	            restProxy.getBlob(requestUrl, undefined, undefined, 'arraybuffer', 'application/pdf').then(function(result) {
		            if (result.status === "success") {
			            var blob = new Blob([ result.data ], {
			                type : "application/pdf"
			            });
			            if (navigator.appVersion.toString().indexOf('.NET') > 0) {
				            window.navigator.msSaveOrOpenBlob(blob, 'Allotment letter.pdf');
			            } else {
				            var url = URL.createObjectURL(blob);
			                var link = document.createElement("a");
			                if (link.download !== undefined) {
				                link.setAttribute("href", url);
				                link.setAttribute("download", 'Allotment letter.pdf');
				                link.style.visibility = 'hidden';
				                link.click();
				                return result;
			                }
			            }
			        }
		        });
			}
        };
        /**
	     * Method to returns the role based previlage to update records
		*/
		this.getVersionUserEdit = function(params) {
			collectionServiceURLs.corpLegalServices.GET_HIERARCHY_ID.queryParams = {
				"userId": params.createdBy
			};
			collectionServiceURLs.corpLegalServices.GET_HIERARCHY_ID.urlParams = {};
			return restProxy.get(collectionServiceURLs.corpLegalServices.GET_HIERARCHY_ID).then(function(data){
				if(data && data.data && data.data.length){
					return data;
				}else{
					return [];
				}
			});
		};
		
	};
	corpCaseTracking.service('corporateCaseService', [ '$q', 'restProxy', 'dialogService', '$stateParams', '$rootScope', '$http', 'masterService', corporateCaseService ]);
	return corporateCaseService;
});