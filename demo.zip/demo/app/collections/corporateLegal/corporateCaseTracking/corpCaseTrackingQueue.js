/** Story Id : Corporate case tracking 
 * Created By - OFS
 * Represents corporate case tracking.
 * @version v1.0 Date:  22-02-2018
 */
define(['require','corporateCaseResolver','collectionsApp'],
	function(require, corporateCaseResolver, collectionsApp) {
		'use strict';
		var baseViewUrl = 'app/collections/corporateLegal/corporateCaseTracking/'; 
		var app = angular.module('corpCaseTracking', [ 'common','ui.router', 'collections']);
		var cau =  function($stateProvider) {
			$stateProvider.state('collections.corporateCaseTracking', {
				name : 'collections.corporateCaseTracking',
				url : '/caseTracking',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'corpCaseTrackingQueue.html',
						controller : 'corpCaseTrackingController',
						resolve : angular.extend({}, corporateCaseResolver.getCorporateQueue, corporateCaseResolver.getAdvocateInfo)
					}
				},
				data:{
					'headerText':'Corporate Case Tracking Queue',
					'stateActivity' : [ 'COL_HO_CORP_LEGAL_CASE_TRACKING' ]
				}
			}).state('collections.corpCaseTracking',{
				name : 'collections.corpCaseTracking',
				url : '/corpQueueTracking/:agreementNo',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'partials/corporateQue.html',
						controller : 'corporateQueController',
						resolve : angular.extend({},  corporateCaseResolver.getHeaderInfo, corporateCaseResolver.getCorpCaseAsideInfo)
					}
				},
				data : {
					'headerText' : 'Corporate Case Tracking Queue',
					'backState' : 'collections.corporateCaseTracking'

				}
			}).state('collections.corpCaseTracking.stages',{
				name : 'collections.corpCaseTracking.stages',
				url : '/corpStages/caseID/:caseID',
                
				views : {
					'corporateView' : {
						templateUrl : baseViewUrl + 'partials/legalStages.html',
						controller : 'corporateLegalStagesController',
						resolve : angular.extend({}, corporateCaseResolver.getCorporateLegalStages, corporateCaseResolver.getCorporateCases, corporateCaseResolver.getZones,corporateCaseResolver.getManagerInfo ,corporateCaseResolver.getAdvocateInfo)						
					}
				},
				data : {
					'headerText' : 'Corporate Case Tracking Queue - Stages',
					'backState' : 'collections.corporateCaseTracking',
					'stateActivity' : ['COL_HO_CORP_LEGAL_CASE_TRACKING']

				}
			}).state('collections.corpCaseTracking.childCase',{
				name : 'collections.corpCaseTracking.childCase',
				url : '/corpChildStages/caseID/:caseID',
                
				views : {
					'corporateView' : {
						templateUrl : baseViewUrl + 'partials/childCaseLegalStage.html',
						controller : 'childCaseLegalStageController',
						resolve : angular.extend({}, corporateCaseResolver.getCorporateCases, corporateCaseResolver.getZones,corporateCaseResolver.getManagerInfo ,corporateCaseResolver.getAdvocateInfo)						
					}
				},
				data : {
					'headerText' : 'Corporate Case Tracking Queue - Child Case Stages',
					'backState' : 'collections.corporateCaseTracking',
					'stateActivity' : ['COL_HO_CORP_LEGAL_CASE_TRACKING']

				}
			}).state('collections.corpCaseTracking.expenses',{
				name : 'collections.corpCaseTracking.expenses',
				url : '/corpExpenses/:caseID',

				views : {
					'corporateView' : {
						templateUrl : baseViewUrl + 'partials/expenseDetails.html',
						controller : 'corpExpenseDetailsController',
						resolve : angular.extend({}, corporateCaseResolver.getExpenseList, corporateCaseResolver.getCorporateCases)
					}
				},
				data : {
					'headerText' : 'Corporate Case Tracking Queue - Expense Details',
					'backState' : 'collections.corporateCaseTracking'

				}
			}).state('collections.caseTrackBulkUpload',{
		        name : 'collections.caseTrackBulkUpload',
				url : '/corpBulkUpdation/:serviceProvider',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl+ 'partials/corporateBulkUpdation.html',
						controller : 'caseTrackBulkUpdationController',
						resolve : angular.extend({}, corporateCaseResolver.getBUAdvocateInfo)
					}
				},
				data:{
					'headerText': 'Corporate - Bulk Updation',
					'backState' : 'collections.corporateCaseTracking'
				}
            });
    };
	app.config([ '$stateProvider', cau ]);
	return app;
});