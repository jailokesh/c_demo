/** Story : Dashboard for HO Corporate Legal user.
 * Created By - OFS
 * Represents a Dashbaord file.
 * @version v1.0 Date:  21-02-2018
 */
define(['require','collectionsApp', 'corpLegalDashboardResolver'],
   function(require,collectionsApp,corpLegalDashboardResolver) {
   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpDashboard/'; 
       var cau = {
				name : 'collections.corpDashboard',
				url : '/corporateLegalDashboard',
				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'corpLegalDashboard.html',
						controller : 'corpLegalDashboardController',
						resolve : angular.extend({}, corpLegalDashboardResolver.getCorpDashboard,corpLegalDashboardResolver.getZones)
					}
				},data:{'headerText':'Corporate Legal HO Dashboard'}
			};
       
       var corpLegalConfiguration = function($stateProvider,$urlRouterProvider) {
			$stateProvider.state(cau);
       };
		
       return angular.module('corpLegalDashboard', [ 'ui.router','collections' ]).config([ '$stateProvider', '$urlRouterProvider',corpLegalConfiguration ]);
  });