define(['require','corpLegalDashboard','corpLegalConstants'], function(r,corpLegalDashboard,corpLegalConstants) {
	'use strict';
	var corpLegalDashboardController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,corpLegalDashboardService, getCorpDashboardDataOne, getCorpDashboardDataTwo, getCorpDashboardDataThree, getCorpDashboardDataFour,getZones) {
		var alignTable = function(data){		 	
			var tableData =  {
				"1" : {regionID : [], total : 0, zone : "South"},
				"2" : {regionID : [], total : 0, zone : "North"},
				"3" : {regionID : [], total : 0, zone : "West"},
				"4" : {regionID : [], total : 0, zone : "East"},
				"5" : {regionID : [], total : 0, zone : "HE_North"},
				"6" : {regionID : [], total : 0, zone : "HE_South"},
				"7" : {regionID : [], total : 0, zone : "HE_Head Office"},
				"8" : {regionID : [], total : 0, zone : "HE_East"},
				"9" : {regionID : [], total : 0, zone : "HE_West"},
				"10" : {regionID : [], total : 0, zone : "HL_South"},
				"11" : {regionID : [], total : 0, zone : "HL_Head Office"},
				"12" : {regionID : [], total : 0, zone : "HL_West"},
				"13" : {regionID : [], total : 0, zone : "HL_North"},
				"14" : {regionID : [], total : 0, zone : "HL_East"},
				"15" : {regionID : [], total : 0, zone : "VF_Head Office"}
			};
		    _.each(data, function(res){              
              tableData[res.zoneID].regionID.push({region : res.region, count: res.count });
              tableData[res.zoneID].total = tableData[res.zoneID].total+ res.count;
              tableData[res.zoneID].zone = res.zone;
		    });
		    return tableData;
		};
		$scope.formatedData = function(getTableData){
			var tableData = getTableData;
        	var finalData = [];
        	var largestLengthArea = Math.max(tableData[1].regionID.length, tableData[2].regionID.length, tableData[3].regionID.length,  tableData[4].regionID.length,  tableData[5].regionID.length,  tableData[6].regionID.length,  tableData[7].regionID.length,  tableData[8].regionID.length,  tableData[9].regionID.length,  tableData[10].regionID.length,  tableData[11].regionID.length,  tableData[12].regionID.length,  tableData[13].regionID.length,  tableData[14].regionID.length,  tableData[15].regionID.length);
        	for(var i=0; i<largestLengthArea; i++){
        		finalData[i] = {}
        		if(tableData[3] && tableData[3].regionID[i]){
                   finalData[i].WEST = tableData[3].regionID[i];
        		}
        		if(tableData[4] && tableData[4].regionID[i]){
                   finalData[i].EAST = tableData[4].regionID[i];
        		}
        		if(tableData[2] && tableData[2].regionID[i]){
                   finalData[i].NORTH = tableData[2].regionID[i];
        		}
        		if(tableData[1] && tableData[1].regionID[i]){
                   finalData[i].SOUTH = tableData[1].regionID[i];
        		}
        		if(tableData[9] && tableData[9].regionID[i]){
                   finalData[i].HE_WEST = tableData[9].regionID[i];
        		}
        		if(tableData[8] && tableData[8].regionID[i]){
                   finalData[i].HE_EAST = tableData[8].regionID[i];
        		}
        		if(tableData[5] && tableData[5].regionID[i]){
                   finalData[i].HE_NORTH = tableData[5].regionID[i];
        		}
        		if(tableData[6] && tableData[6].regionID[i]){
                   finalData[i].HE_SOUTH = tableData[6].regionID[i];
        		}
        		if(tableData[12] && tableData[12].regionID[i]){
                   finalData[i].HL_WEST = tableData[12].regionID[i];
        		}
        		if(tableData[14] && tableData[14].regionID[i]){
                   finalData[i].HL_EAST = tableData[14].regionID[i];
        		}
        		if(tableData[13] && tableData[13].regionID[i]){
                   finalData[i].HL_NORTH = tableData[13].regionID[i];
        		}
        		if(tableData[10] && tableData[10].regionID[i]){
                   finalData[i].HL_SOUTH = tableData[10].regionID[i];
        		}
        		if(tableData[7] && tableData[7].regionID[i]){
                   finalData[i].HE_HEAD_OFF = tableData[7].regionID[i];
        		}
        		if(tableData[11] && tableData[11].regionID[i]){
                   finalData[i].HL_HEAD_OFF = tableData[11].regionID[i];
        		}
        		if(tableData[15] && tableData[15].regionID[i]){
                   finalData[i].VF_HEAD_OFF = tableData[15].regionID[i];
        		}
        	}
        	return finalData;
        };
        $scope.getTotal = function(type, dataType, tableData) {
            if (tableData != 0) {
            	var data = tableData[dataType];
           }else {
            	var data = {};
            	data.regionID = [];
            	data.total = 0;
            }  
            return data.total;   	
        };
		var init = function() {
        	$scope.zone = {
        		SOUTH: false,
	        	HESOUTH: false,
	        	HLSOUTH: false,
	        	NORTH: false,
	        	HENORTH: false,
	        	HLNORTH: false,
	        	WEST: false,
	        	HEWEST: false,
	        	HLWEST: false,
	        	HEHEADOFF: false,
	        	HLHEADOFF: false,
	        	VFHEADOFF: false,
	        	EAST: false,
	        	HEEAST: false,
	        	HLEAST: false
	        };

        	$scope.formatedDataOne = $scope.formatedData(alignTable(getCorpDashboardDataOne));
        	$scope.formatedDataTwo = $scope.formatedData(alignTable(getCorpDashboardDataTwo));
        	$scope.formatedDataThree = $scope.formatedData(alignTable(getCorpDashboardDataThree));
        	$scope.formatedDataFour = $scope.formatedData(alignTable(getCorpDashboardDataFour));
			var zones = corpLegalConstants.dashboardZones;
			$scope.dataOneTotal = {};
        	if($scope.formatedDataOne.length > 0) {
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataOneTotal[i] = $scope.getTotal('Total',i,alignTable(getCorpDashboardDataOne));
        		}
        	}else {
        		$scope.dataOneTotal = {};
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataOneTotal[i] = $scope.getTotal('Total',i,0);
        		}
        	}
	        $scope.dataTwoTotal = {};  	
        	if($scope.formatedDataTwo.length > 0) {
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataTwoTotal[i] = $scope.getTotal('Total',i,alignTable(getCorpDashboardDataOne));
        		}
        	}else {
        		$scope.dataTwoTotal = {};
				for (var i = 1; i <= zones.length; i++) {
        			$scope.dataTwoTotal[i] = $scope.getTotal('Total',i,0);
        		}		        		
        	}
            $scope.dataThreeTotal = {};
        	if($scope.formatedDataThree.length > 0) {
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataThreeTotal[i] = $scope.getTotal('Total',i,alignTable(getCorpDashboardDataOne));
        		}
        	}else {
        		$scope.dataThreeTotal = {};
				for (var i = 1; i <= zones.length; i++) {
        			$scope.dataThreeTotal[i] = $scope.getTotal('Total',i,0);
        		}	 	        		
        	}
			$scope.dataFourTotal = {};
        	if($scope.formatedDataFour.length > 0) {
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataFourTotal[i] = $scope.getTotal('Total',i,alignTable(getCorpDashboardDataOne));
        		}
        	}else {
        		$scope.dataFourTotal = {};
        		for (var i = 1; i <= zones.length; i++) {
        			$scope.dataFourTotal[i] = $scope.getTotal('Total',i,0);
        		}
        	}

        	if($rootScope.identity.zoneIDs.length > 0) {
        		$rootScope.identity.zoneIDs.forEach(function(zone){
        			switch(zone){
        				case '1' : $scope.zone.SOUTH = true;
        				           break;
        				case '2' : $scope.zone.NORTH = true;
			        				break;
        				case '3' : $scope.zone.WEST = true; 
			        				 break;
        				case '4' : $scope.zone.EAST = true;
			        				break;
        				case '5' : $scope.zone.HENORTH = true;
			        				break;
        				case '6' : $scope.zone.HESOUTH = true;
			        				break;
        				case '7' : $scope.zone.HEHEADOFF = true;
			        				break;
        				case '8' : $scope.zone.HEEAST = true;
			        				break;
        				case '9' : $scope.zone.HEWEST = true;
			        				break;
        				case '10' : $scope.zone.HLSOUTH = true;
			        				break;
        				case '11' : $scope.zone.HLHEADOFF = true;
			        				break;
        				case '12' : $scope.zone.HLWEST = true;
			        				break;
        				case '13' : $scope.zone.HLNORTH = true;
			        				break;
        				case '14' : $scope.zone.HLEAST = true;
			        				break;
        				case '15' : $scope.zone.VFHEADOFF = true;
			        				break;
        			}
        		});
        	}
	        $scope.dashSelectData = corpLegalConstants.productTypeArray;
	        var splicedZone = angular.copy(getZones.locations.branchDetails.zones);
	        if(splicedZone.length > 1){
	        	splicedZone.splice(0,0,{ZoneID: "0", name: "ALL", description: "ALL"});
	        }
            $scope.dashSelectZone = splicedZone;
        	$scope.selectedProductGroup= 'ALL'
        	$scope.selectedZone = $scope.dashSelectZone[0].id;
        	$scope.changeDetails("ALL", 0);
		};
	    $scope.totalProductGroup=[];
	    $scope.changedValue=function(item){
	    	$scope.singleProductGroup = [item];
	    	if(item == "ALL") {
	    		$scope.singleProductGroup = corpLegalConstants.businessTypeArray;
	    	} else if(item == "OTHERS") {
	    		$scope.singleProductGroup = corpLegalConstants.productGroupOthers;
	    	}
	    	var zones = corpLegalConstants.dashboardZones;
			/*ALLOCTMANT LETTER PENDING LIST start*/
			
			var dashboardDataOne = function(){
				var obj = {
					"productGroup": $scope.singleProductGroup,
					"zoneID": $rootScope.identity.zoneIDs,
					"regionID": $rootScope.identity.regionIDs 
				}
				corpLegalDashboardService.getCorpDashboardOne(obj).then(function(data){
					
					if(data && !(data.hasOwnProperty("errors"))){
						if (data.length > 0) {
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataOneTotal[i] = $scope.getTotal('Total',i,alignTable(data));
			        		}
						    $scope.formatedDataOne = $scope.formatedData(alignTable(data));
						} 
						else{
							$scope.formatedDataOne = [];
							$scope.dataOneTotal = {};
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataOneTotal[i] = $scope.getTotal('Total',i,0);
			        		}
							$scope.hasRecords= false;
							$scope.errmsgShow = true;
						};
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
		    }
		    dashboardDataOne();
		    var dashboardDataTwo = function(){
				var obj = {
					"productGroup": $scope.singleProductGroup,
					"zoneID": $rootScope.identity.zoneIDs,
					"regionID": $rootScope.identity.regionIDs 
				}
				corpLegalDashboardService.getCorpDashboardTwo(obj).then(function(data){
					if(data && !(data.hasOwnProperty("errors"))){
						if (data.length > 0) {
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataTwoTotal[i] = $scope.getTotal('Total',i,alignTable(data));
			        		}
						    $scope.formatedDataTwo = $scope.formatedData(alignTable(data));
							$scope.errmsgShow = false;
						} 
						else{
							$scope.formatedDataTwo = [];
							$scope.dataTwoTotal = {};
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataTwoTotal[i] = $scope.getTotal('Total',i,0);
			        		}
							$scope.hasRecords= false;
							$scope.errmsgShow = true;
						};
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
		    }
		    dashboardDataTwo();
		    var dashboardDataThree = function(){
				var obj = {
					"productGroup": $scope.singleProductGroup,
					"zoneID": $rootScope.identity.zoneIDs,
					"regionID": $rootScope.identity.regionIDs 
				}

				corpLegalDashboardService.getCorpDashboardThree(obj).then(function(data){
					if(data && !(data.hasOwnProperty("errors"))){
						if (data.length > 0) {
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataThreeTotal[i] = $scope.getTotal('Total',i,alignTable(data));
			        		}
						    $scope.formatedDataThree = $scope.formatedData(alignTable(data));
							$scope.errmsgShow = false;
						} 
						else{
							$scope.formatedDataThree = [];
							$scope.dataThreeTotal = {};
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataThreeTotal[i] = $scope.getTotal('Total',i,0);
			        		}
							$scope.hasRecords= false;
							$scope.errmsgShow = true;
						};
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
		    }
		    dashboardDataThree();
		    var dashboardDataFour = function(){
				var obj = {
					"productGroup": $scope.singleProductGroup,
				    "zoneID": $rootScope.identity.zoneIDs,
					"regionID": $rootScope.identity.regionIDs 
				}
				corpLegalDashboardService.getCorpDashboardFour(obj).then(function(data){
					if(data && !(data.hasOwnProperty("errors"))){
						if (data.length > 0) {
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataFourTotal[i] = $scope.getTotal('Total',i,alignTable(data));
			        		}
					        $scope.formatedDataFour = $scope.formatedData(alignTable(data));
							$scope.errmsgShow = false;
						} else{
							$scope.formatedDataFour = [];
							$scope.dataFourTotal = {};
							for (var i = 1; i <= zones.length; i++) {
			        			$scope.dataFourTotal[i] = $scope.getTotal('Total',i,0);
			        		}
							$scope.hasRecords= false;
							$scope.errmsgShow = true;
						};
					} else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
		    }
		    dashboardDataFour();	
	    };  
		/*Dashboard1 data end*/

		/* Tab2 Chart data handling*/
        function createChartOption(chartKeyData,chartValueData,headTitle) {
        	if( chartKeyData&&chartValueData) {
        		var makeChart = {
           	        chart: { 
                        type: 'bar',
	    	            borderWidth: 1,
	    	            plotBorderWidth: 1,
	    	            spacingBottom: 0,
	    	            borderColor: '#C0C0C0',
	                },
		            credits: { enabled: false},
		            title: { text: headTitle },
		            xAxis: { 
			            categories:  chartKeyData,
		            },
        	        yAxis: { 
		             	min:0,
		    	        title: { 
		    		      text: 'Ranges',
		    		      align: 'middle'
	    		        },
	    		        reserveSapce: true,
	    		        labels: {
	    	    			overflow: 'justify'
            		    }
		            },
		            tooltip: {
		    	       useHTML: true,
     		    	   headerFormat: '<b>{point.key}</b><br/>'
	                },
		            series: [
			            { 
				      	    name: 'Total Count',
				      	    data: chartValueData 
			            }
		            ]
		        }
	            return makeChart;
        	}
        };
        function getRegionWiseChartData(Params){
            var customSortMonth = moment.months(); 
            corpLegalDashboardService.getCorpRegionWiseCaseChart(Params).then(function(response){
           	 	var makeData = [];
           	    var chartObj ={};
           	    if(response.data.length > 0) {
           	    	if(response.data !== undefined){
	       	 	       	response.data.forEach(function(data){
	                        var obj={}
	                        obj.Region = data.region;
	                        obj.Count = data.count;
	                        makeData.push(obj);
	                    });
	                    makeData.forEach(function(data){
	                        chartObj[data.Region] = data.Count;
	                    }); 
	                    var sumArr = Object.values(chartObj)
	                    $scope.totalRecordsCases = sumArr.reduce(function(acc, val) { return acc + val; });
	                    $scope.dashboardDetails = chartObj;
	       	 	    }
           	    } else {
           	    	$scope.totalRecordsCases = $scope.totalRecordsCases;
                    $scope.dashboardDetails = null;
           	    }
            });
       	    corpLegalDashboardService.getCorpNameWiseCaseChart(Params).then(function(response){
           	 	var makeNameWiseData =[];
             	var chartNameObj={}
                if(response.data !== undefined) {
                   	response.data.forEach(function(data){
                        var obj={}
                        obj.DisputeNature = data.disputeNature;
                        obj.Count = data.count;
                        makeNameWiseData.push(obj);
                    });
                    _.each(makeNameWiseData,function(data){
       	 	            if(chartNameObj[data.DisputeNature]) {
       	 	            	chartNameObj[data.DisputeNature] += data.Count;
       	 	            } else {
       	 	            	chartNameObj[data.DisputeNature] = data.Count;
       	 	            }
       	 	        });
                    var nameWiseChart = _.omit(chartNameObj,'null');
                    var  chartKeyData = [];
	                var chartValueData = [];
	                chartKeyData = _.keys(nameWiseChart);
	                chartValueData = _.values(nameWiseChart);
	                $scope.chartOptions1 = createChartOption(chartKeyData,chartValueData,'Name  wise Categorization');
                }
            });
            corpLegalDashboardService.getCorpValueWiseCaseChart(Params).then(function(response){
            	var makeData = [];
       	        var valueChartObj ={};
       	        var sortdata =[];
                var customSort = corpLegalConstants.valueWiseCategory;
       	 	    if(response.data !== undefined){
   	 	        	response.data.forEach(function(data){
                        var obj={}
                        obj.claimRange = data.claimRange;
                        obj.Count = data.count;
                        makeData.push(obj);	
                    });
       	 	        for(var i=0; i<customSort.length; i++){
       	 	            var count = 0;
       	 	            var obj={};
       	 	            makeData.forEach(function(data, index){
           	 	        	if(data.claimRange == customSort[i]){
           	 	        		obj.claimRange = data.claimRange;
           	 	        		count = count+data.Count;
                                obj.Count = count;
       	 	        	    }
           	 	        	if(index == makeData.length-1 && obj.claimRange)
                            sortdata.push(obj);
       	 	            });
       	 	        }
                    sortdata.forEach(function(data,index){                     
                        valueChartObj[data.claimRange] = data.Count;
                    }); 
                    var valueWiseData = valueChartObj;
                    var valueWiseKeydata =[];
                    var valueWiseValuedata=[];
                    valueWiseKeydata = _.keys(valueWiseData);
	                valueWiseValuedata = _.values(valueWiseData);		
                    $scope.chartOptions2 = createChartOption(valueWiseKeydata,valueWiseValuedata,'Value  wise Categorization')
       	 	    }
            });
            corpLegalDashboardService.getCorpNewCaseChart(Params).then(function(response){
            	if(response.data !== undefined){
            		var chartNewObj ={}
            		var getNewCaseChartData = response.data
                    var sortMonthWiseData =[]
                    customSortMonth.forEach(function(sortData,sortIndex){
                		var makeObj = {};
                    	getNewCaseChartData.forEach(function(data,index){
                    		if(data.monthRange==sortData){
                                makeObj.monthRange = data.monthRange
                                makeObj.count = data.count;
                    		}
                    		if(index == getNewCaseChartData.length-1 && makeObj.monthRange){
                    			sortMonthWiseData.push(makeObj)
                    		}
                    	})
                    })
            		sortMonthWiseData.forEach(function(data){
	                    chartNewObj[data.monthRange] = data.count;
                    }); 
                   var newCaseChart = chartNewObj
                   var  chartKeyData = [];
	               var chartValueData = [];
	               chartKeyData = _.keys(newCaseChart);
	               chartValueData = _.values(newCaseChart);
	               $scope.chartOptions3 = createChartOption(chartKeyData,chartValueData,'New Case For Last 3 Months');
        	    }
            });
            corpLegalDashboardService.getCorpOldCaseChart(Params).then(function(response){
                if(response.data !== undefined){
            		var chartOldObj ={}
            		var getOldCaseChartData = response.data
                    var sortMonthWiseData =[]
                    customSortMonth.forEach(function(sortData,sortIndex){
                		var makeObj = {};
                    	getOldCaseChartData.forEach(function(data,index){
                    		if(data.monthRange==sortData){
                                makeObj.monthRange = data.monthRange
                                makeObj.count = data.count;
                    		}
                    		if(index == getOldCaseChartData.length-1 && makeObj.monthRange){
                    			sortMonthWiseData.push(makeObj)
                    		}
                    	})
                    })
            		sortMonthWiseData.forEach(function(data){
	                    chartOldObj[data.monthRange] = data.count;
                    }); 
                   var oldCaseChart = chartOldObj;
                   var  chartKeyData = [];
	               var chartValueData = [];
	               chartKeyData = _.keys(oldCaseChart);
	               chartValueData = _.values(oldCaseChart);
	               $scope.chartOptions4 = createChartOption(chartKeyData,chartValueData,'Closed Case For Last 3 Months');
            	}	
            });
        };
		$scope.changeDetails = function (selectedProductGroup, selectedZoneId ) {
            var getAllProductGroup =[];
            if(selectedProductGroup === "ALL"){
               getAllProductGroup = corpLegalConstants.businessTypeArray;
            }else if(selectedProductGroup === "OTHERS"){
            	getAllProductGroup = corpLegalConstants.productGroupOthers;
            } else {
               getAllProductGroup.push(selectedProductGroup)
            }
            var getAllZoneId=[];
            if(selectedZoneId == 0) { 
            	getAllZoneId = _.pluck(getZones.locations.branchDetails.zones, 'ZoneID');
            } else {
                getAllZoneId.push(selectedZoneId);
            }
            var Params= {
            	"productGroup": getAllProductGroup,
            	"zoneID": getAllZoneId,
            	"regionID": $rootScope.identity.regionIDs
            }
        	getRegionWiseChartData(Params);
        };
	    init();
    };
	corpLegalDashboard.controller('corpLegalDashboardController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','corpLegalDashboardService','getCorpDashboardDataOne','getCorpDashboardDataTwo','getCorpDashboardDataThree','getCorpDashboardDataFour','getZones', corpLegalDashboardController ]);
	return corpLegalDashboardController;
});