/** Story : Dashboard for HO Corporate Legal user.
 * Created By - OFS
 * Represents package file for Corporate Legal Dashboard.
 * @version v1.0 Date:  21-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the HO Corporate Legal dashboard module file names with their paths.
     * Contains the HO Corporate Legal dashboard module required dependency configuration.
     */
    require.config({
        paths: {
            'corpLegalDashboard': 'app/collections/corporateLegal/corpDashboard/corpLegalDashboard',
            'corpLegalDashboardController': 'app/collections/corporateLegal/corpDashboard/controllers/corpLegalDashboardController',
            'corpLegalDashboardService': 'app/collections/corporateLegal/corpDashboard/services/corpLegalDashboardService',
            'corpLegalDashboardResolver': 'app/collections/corporateLegal/corpDashboard/resolvers/corpLegalDashboardResolver',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader'
        },
        shim: {
            'corpLegalDashboard': ['angular', 'angular-ui-router','highcharts','corpLegalDashboardResolver'],
            'workplanController': ['corpLegalDashboard'],
            'corpLegalDashboardController' : ['corpLegalDashboard','corpLegalDashboardService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the dashboard module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpLegalDashboardController','workplanController'], callback);
            });
        });
    };
});