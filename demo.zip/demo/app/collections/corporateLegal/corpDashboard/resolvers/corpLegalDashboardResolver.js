/** Story Id : Corporate Legal Dashboard
 * Created By - OFS
 * Represents a resolver for corporate legal dashboard.
 * @version v1.0 Date:  02-05-2018
 */
define(['require','corpLegalConstants'], function(require, corpLegalConstants) {
	'use strict';
	/**
	 * Returns the Dashboard based info
	 */
	var corpDashboardResolver = {
		getCorpDashboardDataOne : [ 'corpLegalDashboardService','$rootScope', function(corpLegalDashboardService, $rootScope) {
			return corpLegalDashboardService.getCorpDashboardOne({"productGroup": corpLegalConstants.businessTypeArray,"zoneID": $rootScope.identity.zoneIDs, "regionID": $rootScope.identity.regionIDs}).then(function(response) {
				return response;
			});
		} ],
		getCorpDashboardDataTwo : ['corpLegalDashboardService','$rootScope', function(corpLegalDashboardService, $rootScope) {
			return corpLegalDashboardService.getCorpDashboardTwo({"productGroup": corpLegalConstants.businessTypeArray,"zoneID": $rootScope.identity.zoneIDs, "regionID": $rootScope.identity.regionIDs}).then(function(response) {
				return response;
			});
		} ],
		getCorpDashboardDataThree : ['corpLegalDashboardService','$rootScope', function(corpLegalDashboardService, $rootScope) {
			return corpLegalDashboardService.getCorpDashboardThree({"productGroup": corpLegalConstants.businessTypeArray,"zoneID": $rootScope.identity.zoneIDs, "regionID": $rootScope.identity.regionIDs}).then(function(response) {
				return response;
			});
		}],
		getCorpDashboardDataFour : ['corpLegalDashboardService','$rootScope', function(corpLegalDashboardService, $rootScope) {
			return corpLegalDashboardService.getCorpDashboardFour({"productGroup": corpLegalConstants.businessTypeArray,"zoneID": $rootScope.identity.zoneIDs, "regionID": $rootScope.identity.regionIDs}).then(function(response) {
				return response;
			});
		}],
		getZones : ['corpLegalDashboardService', function(corpLegalDashboardService) {
			return corpLegalDashboardService.getUserDataMapping();
		}]
	};
	return {
		getCorpDashboard : corpDashboardResolver
	};
});