2/** Story Id : Corporate Legal Dashboard 
 * Created By - OFS
 * Represents a service for corporate legal dashboard.
 * @version v1.0 Date:  02-05-2018
 */
define([ 'require', 'corpLegalDashboard', 'collectionServiceURLs', 'constants', 'collectionConstants','utility' ], function(require, corpLegalDashboard, collectionServiceURLs, constants, collectionConstants,utility) {
'use strict';
  var corpLegalDashboardService = function($q, restProxy, dialogService, $stateParams, $rootScope, $http, masterService ) {
    var limit = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
    var legalData, initiationData, productGroup;
    var header = {
       'Content-Type' : 'application/json',
       'Authorization':getCookie('token'),
       'userID' : $rootScope.identity.userName
    };
    var serviceObj = this;
    this.locations = { 
        branchDetails : {}
    };
    this.getCorpRegionWiseCaseChart = function(params){
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_REGION_WISE_CASE_CHART,params)
    };
    /**
     * Method to get corporate legal dashboard data
     */
    this.getCorpDashboardOne = function(params) {
      collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_ONE.queryParams = params;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_ONE, params).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
      });
    };
    
    this.getCorpDashboardTwo = function(params) {
      collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_TWO.queryParams = params;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_TWO, params).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
        
      });
    };

    this.getCorpDashboardThree = function(params) {
      collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_THREE.queryParams = params;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_THREE, params).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
      });
    };

    this.getCorpDashboardFour = function(params) {
      collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_FOUR.queryParams = params;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_DASHBOARD_DETAILS_FOUR, params).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
      });
    };

    this.getCorpNameWiseCaseChart = function(params){
      var requestUrl = collectionServiceURLs.corpLegalServices.GET_LEGAL_NAME_WISE_CASE_CHART;
      return restProxy.save('POST',requestUrl, params);
    };
    this.getCorpValueWiseCaseChart = function(params){
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_VALUE_WISE_CASE_CHART,params);
    };

    this.getCorpNewCaseChart = function(params) {
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_NEW_CASE_CHART,params); 
    };

    this.getCorpOldCaseChart = function(params) {
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_LEGAL_OLD_CASE_CHART,params); 
    };

    /**
     * Method to generate the reports
     */
    this.getUserDataMapping = function() {
      if ($rootScope.identity.zoneIDs.length > 0) {
        masterService.getAreas({
          ZoneID : $rootScope.identity.zoneIDs.toString()
        }, 'zone').then(function(userZones) {
          $rootScope.identity.userZones = userZones;
          serviceObj.locations.branchDetails.zones = userZones;
          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
        });
      }
      if ($rootScope.identity.regionIDs.length > 0) {
        masterService.getAreas({
          regionID : $rootScope.identity.regionIDs.toString()
        }, 'region').then(function(userRegions) {
          $rootScope.identity.userRegions = userRegions;
          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
        });
      }
      if ($rootScope.identity.areaIDs.length > 0) {
        masterService.getAreas({
          areaID : $rootScope.identity.areaIDs.toString()
        }, 'area').then(function(userAreas) {
          $rootScope.identity.userAreas = userAreas;
          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
        });
      }
      if ($rootScope.identity.branchIDs.length > 0) {
        masterService.getBranches({
          branchID : $rootScope.identity.branchIDs.toString()
        }).then(function(userBranches) {
          $rootScope.identity.userBranches = userBranches;
          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
        });
      }
      return serviceObj;
    };
  };
  corpLegalDashboard.service('corpLegalDashboardService', [ '$q', 'restProxy', 'dialogService', '$stateParams', '$rootScope', '$http', 'masterService', corpLegalDashboardService ]);
  return corpLegalDashboardService;
});