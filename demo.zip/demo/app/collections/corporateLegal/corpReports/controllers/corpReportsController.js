define(['require','corpReports','constants','collectionConstants','utility','DatePickerConfig', 'corpLegalConstants'],
	function(r, corpReports, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants ) {
		'use strict';
		var corpReportsController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,corpReportService,getZones,appFactory) {
			console.log("Inside Reports controllers................")
			$scope.reportArray = corpLegalConstants.CORPORATE_REPORT_TYPES;
			$scope.dateRangeList =  corpLegalConstants.DATE_RANGE;
			$scope.zoneWiseList = corpLegalConstants.ZONE_WISE;
			$scope.dropDownValues = getZones.locations;
			$scope.dataType = {
				isType : false,
				isDate : false,
				isDcr:false,
				isZoneUser:false,
				isRegUser:false,
				isAreaUser:false,
				isBranchUser:false,
				reportProduct:""
			};
            $scope.fromDateValue = new Date();
            $scope.toDateValue = new Date();
			$scope.fromDateConfig = new DatePickerConfig({
				dateValue : new Date(),
				readonly : true,
				onchange : function(val) {
               	   $scope.fromDateValue = val;
               }
			});
			$scope.toDateConfig = new DatePickerConfig({
				dateValue : new Date(),
				readonly : true,
				onchange : function(val) {
               	   $scope.toDateValue = val;
               }
			});
			$scope.changeHandler = function(type, ID, value) {
				var branchArr, areaArr, regionArr;
				if (type === 'Zone') {
					$scope.dropDownValues.branchDetails.regionID = "";
					if($scope.dataType.isHoUser){
						if(ID){
							$scope.userSelection({ZoneID : ID}, 'Region','filteredRegions');
						}
						$scope.dropDownValues.branchDetails.areaID = "";
						$scope.dropDownValues.branchDetails.branchID = "";
						$scope.dropDownValues.branchDetails.filteredRegions = [];
						$scope.dropDownValues.branchDetails.filterdAreas = [];
						$scope.dropDownValues.branchDetails.filterdBranch = [];
						$scope.dropDownValues.branchDetails.disableRegion = true ;
						$scope.dropDownValues.branchDetails.disableArea = true ;
						$scope.dropDownValues.branchDetails.disableBranch = true;
					}else{
						regionArr = ($scope.dropDownValues.branchDetails.zoneID) ? _.where($scope.dropDownValues.branchDetails.regions, {
							ZoneID : $scope.dropDownValues.branchDetails.zoneID
						}) : '';
						if (regionArr.length > 1 && $scope.dropDownValues.branchDetails.zoneID) {
							$scope.dropDownValues.branchDetails.disableRegion = false;
						} else {
							$scope.dropDownValues.branchDetails.regionID = regionArr[0] ? regionArr[0].regionID : "";
							$scope.dropDownValues.branchDetails.disableRegion = (!$scope.dropDownValues.branchDetails.regionID);
						}
						$scope.dropDownValues.branchDetails.filteredRegions = regionArr;
						type = 'Region';
					}

				}

				if (type === 'Region') {
					$scope.dropDownValues.branchDetails.areaID = "";
					if($scope.dataType.isHoUser){
						if(ID){
							$scope.userSelection({regionID:ID}, 'Area','filterdAreas');
						}
						$scope.dropDownValues.branchDetails.branchID = "";
						$scope.dropDownValues.branchDetails.filterdAreas = [];
						$scope.dropDownValues.branchDetails.filterdBranch = [];
						$scope.dropDownValues.branchDetails.disableArea = true ;
						$scope.dropDownValues.branchDetails.disableBranch = true;

					}else{
						areaArr = ($scope.dropDownValues.branchDetails.regionID) ? _.where($scope.dropDownValues.branchDetails.areas, {
							regionID : $scope.dropDownValues.branchDetails.regionID
						}) : '';
						if (areaArr.length > 1 && $scope.dropDownValues.branchDetails.regionID) {
							$scope.dropDownValues.branchDetails.disableArea = false;
						} else {
							$scope.dropDownValues.branchDetails.areaID = areaArr[0] ? areaArr[0].areaID : "";
							$scope.dropDownValues.branchDetails.disableArea = (!$scope.dropDownValues.branchDetails.areaID);
						}
						$scope.dropDownValues.branchDetails.filterdAreas = areaArr;
						type = 'Area';
					}

				}

				if (type === 'Area') {
					$scope.dropDownValues.branchDetails.branchID = "";
					if($scope.dataType.isHoUser){
						if(ID){
							$scope.userSelection({areaID:ID}, 'Branch','filterdBranch');
						}
						$scope.dropDownValues.branchDetails.filterdBranch = [];
						$scope.dropDownValues.branchDetails.disableBranch = true;
					}else{
						branchArr = ($scope.dropDownValues.branchDetails.areaID) ? _.where($scope.dropDownValues.branchDetails.branches, {
							areaID : $scope.dropDownValues.branchDetails.areaID
						}) :'';
						if (branchArr.length > 1 && $scope.dropDownValues.branchDetails.areaID) {
							$scope.dropDownValues.branchDetails.disableBranch = false;
						} else {
							$scope.dropDownValues.branchDetails.branchID = branchArr[0] ? branchArr[0].branchID : "";
							$scope.dropDownValues.branchDetails.disableBranch = (!$scope.dropDownValues.branchDetails.branchID);
						}
						$scope.dropDownValues.branchDetails.filterdBranch = branchArr;
					}

				}
				if(type === 'Branch' && !ID){
					$scope.dropDownValues.branchDetails.branchID = "";
				}
			};
			$scope.userSelection = function(reqObj,type,selection){
				corpReportService.getUserSelection(reqObj,type).then(function(data){	
					$scope.dropDownValues.branchDetails[selection] = data;
					$scope.dropDownValues.branchDetails["disable"+type] = (data.length === 0) ? true :false ;
				});
			};
			var initDropdown = function(){
				$scope.dropDownValues.branchDetails.zoneID ='';
				$scope.dropDownValues.branchDetails.regionID ='';
				$scope.dropDownValues.branchDetails.areaID ='';
				$scope.dropDownValues.branchDetails.branchID ='';
				
				if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.ZONE_REPORT)){
					$scope.dataType.isZoneUser = true;
				}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.REGION_REPORT)){
					$scope.dataType.isRegUser = true;
				}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.AREA_REPORT)){
					$scope.dataType.isAreaUser = true;
				}else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.BRANCH_REPORT)){
					$scope.dataType.isBranchUser = true;
				}
			};
			$scope.generateReport = function(type){
				var queryObj = {};
				queryObj.reportType = type;
				var queData = _.findWhere($rootScope.identity.roles,{"roleID":$rootScope.identity.selectedRoleID})
				queryObj.hierarchyId = queData.hierarchyID;
				queryObj.leapFunction = queData.leapFunction;
				if ($scope.zoneRange == "Without Zone") {
					queryObj.regionID = $rootScope.identity.regionIDs.toString();
				};
				if($scope.dateRange == "With Date Range"){
					queryObj.fromDate = $scope.fromDateValue;
					queryObj.toDate = $scope.toDateValue;
				}
				if($scope.zoneRange == "With Zone"){
					queryObj.zoneID = $scope.dropDownValues.branchDetails.zoneID;
					queryObj.regionID = $scope.dropDownValues.branchDetails.regionID;
					queryObj.areaID = $scope.dropDownValues.branchDetails.areaID;
					queryObj.branchID = $scope.dropDownValues.branchDetails.branchID; 
				}
                corpReportService.getCorpReportDetails("/collectionsapi/getReports",queryObj);
			};
			initDropdown();
		};

		corpReports.controller('corpReportsController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','corpReportService','getZones','appFactory',corpReportsController]);
		return corpReportsController;
	});