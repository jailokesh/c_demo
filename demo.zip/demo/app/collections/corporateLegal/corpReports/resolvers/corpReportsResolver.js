/** Story: Corporate legal cases reports.
 * Modified By - OFS
 * Represents a corporate legal cases Reports Resolver.
 * @version v1.0 Date: 20-04-2018
 */
define([], function() {
	'use strict';
	return {
		getZones : [ 'corpReportService', function(corpReportService) {
			return corpReportService.getUserDataMapping();
		} ]
	};
});