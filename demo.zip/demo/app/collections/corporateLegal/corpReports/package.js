/** Story Id : HO Corporate legal Reports.
 * Modified By - OFS
 * Represents a Package file for HO Corporate Legal Reports.
 * @version v1.0 Date:  22-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the HO corporate Reports module file names with their paths.
     * Contains the HO Corporate Reports module required dependency configuration.
     */
    require.config({
        paths: {
            'corpReports': 'app/collections/corporateLegal/corpReports/reports',
            'corpReportsController': 'app/collections/corporateLegal/corpReports/controllers/corpReportsController',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
            'corpReportService' : 'app/collections/corporateLegal/corpReports/services/corpReportService',
            'corpReportsResolver' : 'app/collections/corporateLegal/corpReports/resolvers/corpReportsResolver'
        },
        shim: {
            'corpReports': ['angular', 'angular-ui-router'],
            'corpReportsController':['corpReports','corpReportService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the Reports module.
     *  @param {method} call back.
     */
    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpReportsController', 'workplanController'], callback);
            });
        });
    };
});