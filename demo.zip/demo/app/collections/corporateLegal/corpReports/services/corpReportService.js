/** Story Id : Corporate legal cases reports
 * Created By - OFS
 * Represents corporate reports
 * @version v1.0 Date:  15-05-2018
 */
define(['require','corpReports','collectionServiceURLs','constants','collectionConstants'],function(require,corpReports,collectionServiceURLs,constants,collectionConstants){
	var corpReportService = function($q,restProxy,$rootScope,$http,masterService,dialogService){
        var serviceObj = this;
		this.locations = {
			branchDetails : {}
		};
		/**
		 * Method to generate the reports
		 */
		this.getUserDataMapping = function() {
			if ($rootScope.identity.zoneIDs.length > 0) {
				masterService.getAreas({
					ZoneID : $rootScope.identity.zoneIDs.toString()
				}, 'zone').then(function(userZones) {
					$rootScope.identity.userZones = userZones;
					serviceObj.locations.branchDetails.zones = userZones;
					serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
				});
			}
			if ($rootScope.identity.regionIDs.length > 0) {
				masterService.getAreas({
					regionID : $rootScope.identity.regionIDs.toString()
				}, 'region').then(function(userRegions) {
					$rootScope.identity.userRegions = userRegions;
					serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
					serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
				});
			}
			if ($rootScope.identity.areaIDs.length > 0) {
				masterService.getAreas({
					areaID : $rootScope.identity.areaIDs.toString()
				}, 'area').then(function(userAreas) {
					$rootScope.identity.userAreas = userAreas;
					serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
					serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
				});
			}
			if ($rootScope.identity.branchIDs.length > 0) {
				masterService.getBranches({
					branchID : $rootScope.identity.branchIDs.toString()
				}).then(function(userBranches) {
					$rootScope.identity.userBranches = userBranches;
					serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
				});
			}
			return serviceObj;
		};

		this.getUserSelection = function(reqObj,type) {
			var identity = $rootScope.identity;
            if (identity.zoneIDs.length > 0) {
				return masterService.getAreas(reqObj,type).then(function(userZones) {
					return userZones;
				});
            }
        };
        this.getCorpReportDetails = function(urlString,queryObj){
		 	return $http({
		 		url: urlString,
		 		method: 'GET',
		 		headers: {
                    'Content-Type' : 'text/csv',
                    'Authorization':getCookie('token'),
                    'Content-Disposition': 'attachment'
               },
               responseType: 'arraybuffer',
               params: queryObj
            }).success(function (data, status, headers, config) {
	            if(data == "" || status != 200){
	              	dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, JSON.parse(headers('errorMessage')));
                } else if(data.hasOwnProperty("errors")) {	              	
	                if(data.errors[0].errorCode=="CORP_LEGAL_REPORT-1001"){
	                   dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error,data.errors[0].message);
	                }
	            }else {
	            	if(status == 200) {
		            	var blob = new Blob([data],{type:'application/vnd.ms-excel'});
		            	var objectUrl = URL.createObjectURL(blob);
		            	var link = document.createElement("a");
		                if (link.download !== undefined) { // feature detection
		                    // Browsers that support HTML5 download attribute
		                    link.setAttribute("href", objectUrl);
		                    link.setAttribute("download", queryObj.reportType+'Reports.xls');
		                    link.style.visibility = 'hidden';
		                    link.click();
		                }
		            }
	            }
            }).error(function (e) {
        	    console.log("got error while fetching in  service...." +  e);
            });
        };
	};

	corpReports.service('corpReportService',['$q','restProxy','$rootScope','$http','masterService','dialogService',corpReportService]);
	return corpReportService;
});