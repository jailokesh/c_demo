/** Story Id : HO Corporate Reports
 * Modified By - OFS
 * Represents HO Corporate Legal Reports.
 * @version v1.0 Date:  22-02-2018
 */
define(['require','collectionsApp', 'corpReportsResolver'],
   function(require,collectionsApp, corpReportsResolver) {
	   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpReports/'; 
       var cau = {
			name : 'collections.corpReports',
			url : '/CorporateReports',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'reports.html',
					controller : 'corpReportsController',
					resolve: corpReportsResolver
				}
			},data:{'headerText':'Corporate Report Cases'}
		};
       
       var reportConfig = function($stateProvider,$urlRouterProvider) {
			$stateProvider.state(cau);
       };
		
    return angular.module('corpReports', [ 'ui.router','collections' ]).config([ '$stateProvider', '$urlRouterProvider',reportConfig ]);
});