/** Story : Corporate Legal Address Query.
 * Created By - OFS
 * Represents a Package file for Corporate Legal Address Query Cases.
 * @version v1.0 Date:  21-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the Corporate Legal Address Query module file names with their paths.
     * Contains the Corporate Legal Address Query module required dependency configuration.
     */
    require.config({
        paths: {
            'addressQuery': 'app/collections/corporateLegal/corpLegalAddressQuery/corpAddressQuery',
            'corpAddressQueryController': 'app/collections/corporateLegal/corpLegalAddressQuery/controllers/corpAddressQueryController',
            'addressQueryService': 'app/collections/corporateLegal/corpLegalAddressQuery/services/addressQueryService',
            'addressQueryResolver': 'app/collections/corporateLegal/corpLegalAddressQuery/resolvers/addressQueryResolver',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'addressQuery': ['angular', 'angular-ui-router','ui.bootstrap'],
            'corpAddressQueryController':['addressQuery','addressQueryService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the Corporate Legal Address Query module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpAddressQueryController', 'workplanController'], callback);
            });
        });
    };
});