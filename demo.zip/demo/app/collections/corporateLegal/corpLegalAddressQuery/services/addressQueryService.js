define(['require','constants','addressQuery','collectionServiceURLs','utility'],function(require,constants,addressQuery,collectionServiceURLs,utility){
	var addressQueryService = function ($q,restProxy,$rootScope,environmentConfig,$http,dialogService,masterService,$upload) {	
    var limit = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		var header = {
      'Content-Type' : 'application/json',
      'Authorization':getCookie('token'),
      'userID' : $rootScope.identity.userName
    };
    var serviceObj = this;
    this.locations = { 
      branchDetails : {}
    };
    this.getSearchDetails = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_ADDRESS_QUERY_SEARCH.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_ADDRESS_QUERY_SEARCH, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.getQuerySearchData = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_ADDRESS_QUERY_DATA.queryParams = queryObj
      return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADDRESS_QUERY_DATA).then(function(data){
        if(data && data.data && data.data.length){
          return data;
        }else{
          return [];
        }
      });
    };
    this.updateAddressQueryCase = function(queryID,updateType,queryObj){
      collectionServiceURLs.corpLegalServices.GET_UPDATE_QUERY.EDS = environmentConfig.baseURL+'/updateQuery/'+queryID+"?type="+updateType;
      return restProxy.save('PUT',collectionServiceURLs.corpLegalServices.GET_UPDATE_QUERY, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.getUserDataMapping = function() {
      if ($rootScope.identity.zoneIDs.length > 0) {
        masterService.getAreas({
          ZoneID : $rootScope.identity.zoneIDs.toString()
          }, 'zone').then(function(userZones) {
          $rootScope.identity.userZones = userZones;
          serviceObj.locations.branchDetails.zones = userZones;
          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
        });
      }
      if ($rootScope.identity.regionIDs.length > 0) {
        masterService.getAreas({
          regionID : $rootScope.identity.regionIDs.toString()
          }, 'region').then(function(userRegions) {
          $rootScope.identity.userRegions = userRegions;
          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
        });
      }
      if ($rootScope.identity.areaIDs.length > 0) {
        masterService.getAreas({
          areaID : $rootScope.identity.areaIDs.toString()
          }, 'area').then(function(userAreas) {
          $rootScope.identity.userAreas = userAreas;
          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
        });
      }
      if ($rootScope.identity.branchIDs.length > 0) {
        masterService.getBranches({
          branchID : $rootScope.identity.branchIDs.toString()
          }).then(function(userBranches) {
          $rootScope.identity.userBranches = userBranches;
          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
        });
      }
      return serviceObj;
    };
    this.getUserSelection = function(reqObj,type) {
      var identity = $rootScope.identity;
      if (identity.zoneIDs.length > 0) {
        return masterService.getAreas(reqObj,type).then(function(userZones) {
          return userZones;
        });
      }
    };
  };
	addressQuery.service('addressQueryService',['$q','restProxy','$rootScope','environmentConfig','$http','dialogService','masterService','$upload', addressQueryService]);
	return addressQueryService;
});