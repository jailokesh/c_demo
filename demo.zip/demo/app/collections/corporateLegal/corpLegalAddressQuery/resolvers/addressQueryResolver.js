define([], function() {
'use strict';
	return {
		getZones : [ 'addressQueryService', function(addressQueryService) {
            return addressQueryService.getUserDataMapping();
        }]
    };
});