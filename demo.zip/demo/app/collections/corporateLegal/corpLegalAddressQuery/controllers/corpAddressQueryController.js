define(['require','addressQuery','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, addressQuery, constants,  collectionConstants, utility, DatePickerConfig, corpLegalConstants) {
		'use strict';
		var corpAddressQueryController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,addressQueryService,lazyModuleLoader) {
	        $scope.corpAddQueData = corpLegalConstants.ADDRESS_QUERY_RESPONSE_SEARCH;
	        $scope.addressQuery = {};
	        $scope.statusTypes = {};
	        $scope.currStatus = {};
	        $scope.loggedUser= $rootScope.identity.userID;

	        $scope.isTextareaDiasble = false;
	        $scope.isCloseDisable = false;
	        $scope.isReopenDisable = false;
	        $scope.isRespondDisable = false;
	        $scope.updateType = {};
	        $scope.queryId = {};
	        $scope.createdUser ="";
	        $scope.currentWorkStatus ="";
	        $scope.itemConversation  = {};

	        $scope.searchType = corpLegalConstants.CORP_LEGAL_ADDRESSQUERY_SEARCH_TYPE;
			$scope.placeHolder = $scope.searchType[0].placeHolder;
			$scope.roleAddressSearchType = corpLegalConstants.RAISEQUERY_ROLADDRES_SEARCH_TYPE;
			$scope.userType = corpLegalConstants.CORP_LEGAL_USER_TYPE;
			var obj = {};
			var resultObj = {};
			$scope.data = {};
			$scope.data.maxRecordPerPage = 10;
			$scope.data.maxSize = 10;
			$scope.data.currentPage = 1;
			$scope.data.offset = 0;
			$scope.argNo = "";
	        $scope.partyType = {};
	        $scope.partyType.isUser = false;
	        $scope.currentItem = ""; 

			function afterChanged() {
				$scope.currentSearch.value = $scope.searchType[0].value;
				$scope.placeHolder = $scope.searchType[0].placeHolder;
		    };
			$scope.searchDataInitiation = function(dataInitiation,currentPage){
				$scope.data.offset = (currentPage - 1) * $scope.data.maxRecordPerPage;
				var params = {
					queryType: dataInitiation,
					offset: $scope.data.offset,
					limitValue: $scope.data.maxRecordPerPage
				};
				$scope.searchResults = null;
				addressQueryService.getQuerySearchData(params).then(function(data){
					if(data.data && !(data.hasOwnProperty("errors"))){
						if (data.data.length > 0) {
							$scope.searchResults = data.data;
							$scope.hasRecords= true;
							$scope.errmsgShow = false;
							(function(){
								$scope.searchInput = null;
								afterChanged();
							})();
							var countParams = {
								queryType: dataInitiation,
								isCount: true
							}
							addressQueryService.getQuerySearchData(countParams).then(function(data){
								$scope.data.totalRecords = data.data[0].count ? data.data[0].count : 0;
								$scope.data.offsetLast = (($scope.data.offset + $scope.data.maxSize) > $scope.data.totalRecords) ? $scope.data.totalRecords : $scope.data.offset + ($scope.data.maxSize - 1);
							})
						} 
						else{
							$scope.searchResults = 'No record found';
							$scope.hasRecords= true;
							$scope.errmsgShow = true;
							(function(){
								$scope.searchInput = null;
								afterChanged();
							})();
						};
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
			}
			$scope.searchChangeHandler = function(value){
				$scope.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
				$scope.searchInput = '';
			};
			$scope.getDetails = function(value){
			    $scope.disableUserName = false;
			    $scope.data.offset = 0;
			    $scope.data.currentPage = 1;
			    if($scope.searchInput != '' && $scope.searchInput != null){
			       getSearchData($scope.data.currentPage);
			       $scope.data.totalRecords = 0;
                }else if($scope.searchInput == null){
                	$scope.searchDataInitiation($scope.search,$scope.data.currentPage);
                }
			    else{
			    	dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Please enter vaild input to search");
			    }
			};
		    var queryObj = function(key,value){
				switch(key){
					case "noticeID" : obj={"noticeID":value,"offSet":$scope.data.offset};
					break;
					case "agreementNo" : obj={"agreementNo":value,"offSet":$scope.data.offset};
					break;
					case "queryID" : obj={"queryID":value,"offSet":$scope.data.offset};
					break;					
					case "caseID" : obj={"caseID":value,"offSet":$scope.data.offset};
					break;
				}
		    };
		    var getSearchData = function(currentPage){
				$scope.data.offset = (currentPage - 1) * $scope.data.maxRecordPerPage;
				queryObj($scope.currentSearch.value, $scope.searchInput);
				addressQueryService.getSearchDetails(obj).then(function(data){
					if(data.data && !(data.hasOwnProperty("errors"))){
						if (data.data.length > 0) {
							$scope.searchResults = data.data;
							$scope.hasRecords= true;
							$scope.errmsgShow = false;
						} 
						else{
							$scope.searchResults = 'No record found';
							$scope.hasRecords= true;
							$scope.errmsgShow = true;
						};
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
		    };
			var getFormDetails = function(querySearchResults){
			    $scope.queryObj = {
			        "workDoneBy" : $rootScope.identity.userID, 
			        "hierarchyID": $rootScope.identity.primaryHierarchyID,
					"comments" : $scope.queryComments, 
					"workStatus" : $scope.currentWorkStatus, 
					"workDoneDate" : new Date().toGMTString(),
					"assignedTo": querySearchResults[0].workflow[0].assignedTo,
					"majorVersion" : querySearchResults[0].majorVersion, 
					"minorVersion" : querySearchResults[0].minorVersion
			    };
	        };
	        $scope.getWorkflowStatus = function(item){
	            $scope.queryId = item.queryID;
	            $scope.currItem = item;
	            $scope.createdUser = item.createdBy;
	            $scope.workDoneBy = item.workflow[0].workDoneBy;
	            $scope.currentWorkStatus =  item.workflow[0].workStatus;
	            $scope.assignedTo = item.workflow[0].assignedTo;
	            checkValidations();
	            $scope.itemConversation = item;
	            $scope.getReserve(item);
	        };
	        var checkValidations = function(){
	        	$scope.isCloseDisable = true;
                $scope.isReopenDisable = true;
	        	if($scope.currentWorkStatus == "assigned") {
	        		$scope.isTextareaDiasble = true;
	        		$scope.currItem.comments = $scope.currItem.workflow[0].comments;
	        		$scope.isRespondDisable = true;
	        		if(_.contains($scope.assignedTo,$rootScope.identity.userID)) {
		        		$scope.isTextareaDiasble = false;
		        		$scope.currItem.comments = '';
		        		$scope.isRespondDisable = false;
		        		$scope.isCloseDisable = true;
		        	}
		        }
		        if($scope.currentWorkStatus == "resolved") {
		        	if($rootScope.identity.userID == $scope.createdUser) {
		        		$scope.isTextareaDiasble = false;
		        		$scope.currItem.comments = '';
		        		$scope.isRespondDisable = false;
		        		$scope.isCloseDisable = false;
		        	}else if(_.contains($scope.assignedTo,$rootScope.identity.userID)) {
		        		$scope.isTextareaDiasble = true;
		        		$scope.currItem.comments = $scope.currItem.workflow[0].comments;
		        		$scope.isRespondDisable = true;
		        	}
		        }
		        if($scope.currentWorkStatus == "closed") {
		        	if($rootScope.identity.userID == $scope.createdUser) {
		        		$scope.isTextareaDiasble = true;
		        		$scope.currItem.comments = $scope.currItem.workflow[0].comments;
		        		$scope.isRespondDisable = true;
		        		$scope.isCloseDisable = true;
	                    $scope.isReopenDisable = false;
		        	}else{
		        		$scope.isTextareaDiasble = true;
		        		$scope.currItem.comments = $scope.currItem.workflow[0].comments;
		        		$scope.isRespondDisable = true;
		        		$scope.isCloseDisable = true;
	                    $scope.isReopenDisable = true;
		        	}
		        }
	        }
	        $scope.onCloseBtn = function(queryID){
	        	$scope.queryResponseData = _.where($scope.searchResults,{"queryID": queryID});
	            $scope.updateType = "close" ;
	            $scope.currentWorkStatus = "closed";
	            getFormDetails($scope.queryResponseData);
	            if(!$scope.queryObj.comments) {
	            	$scope.queryObj.comments = "Query Closed";
	            };
	            $scope.getRespondToQuery($scope.queryId, $scope.updateType);
	        };
	        $scope.onReopenBtn = function(){
	            $scope.isTextareaDiasble = false;
	            $scope.isCloseDisable = true;
	            $scope.isReopenDisable = true;
	            $scope.isRespondDisable = false;
	            $scope.addressQuery.reason = "";
	        };
	        $scope.onRespondToQueryBtn = function(queryID, comments, queryDetails){
	        	$scope.queryResponseData = _.where($scope.searchResults,{"queryID": queryID});
		    	queryDetails.workflow[0].comments = comments;
		    	$scope.queryComments = comments;

	        	if($rootScope.identity.userID != $scope.createdUser){
	               $scope.updateType = "resolve";
	               $scope.currentWorkStatus = "resolved";
	               getFormDetails($scope.queryResponseData);
	               $scope.getRespondToQuery($scope.queryId, $scope.updateType);
	        	}else if($rootScope.identity.userID == $scope.createdUser){
	        		if($scope.currentWorkStatus == "closed"){
	        	       $scope.updateType = "reopen";
	                   $scope.currentWorkStatus = "assigned";
	                   getFormDetails($scope.queryResponseData);
	                   $scope.getRespondToQuery($scope.queryId, $scope.updateType);
	        	    }else{
	                    $scope.updateType = "reply";
	                    $scope.currentWorkStatus = "assigned";
	                    getFormDetails($scope.queryResponseData);
	                    $scope.getRespondToQuery($scope.queryId, $scope.updateType);
	                }
	        	}
	        };
	        $scope.getRespondToQuery = function(queryID, updateType){
	        	addressQueryService.updateAddressQueryCase(queryID,updateType,$scope.queryObj).then(function(res){
	        		if(res.data != undefined){
	        			if(res.status=="success"){
	        				dialogService.showAlert('Message', "Message", "Raise Query Submitted successfully ").result.then(function(){},function() {
					    		$state.current.forceReload = true;
				    			$state.transitionTo($state.current,{ },{reload:true});
					    	});
	                        checkValidations();
	                        $scope.hasRecords= true;
		                }
		            } else if(res.message.hasOwnProperty("errors")) {
		            	if(res.message.errors[0].errorCode=="COM-EXE-2002"){_
		            		dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, res.message.errors[0].message);
		            	}
		            }
		        });
	        };
		    $scope.getReserve = function(item){
				/** Navigate to View Conversation Modal */
				$scope.navigateToViewConversation = function() {
					$modal.open({
						templateUrl : 'app/collections/corporateLegal/corpLegalAddressQuery/partials/viewConversation.html',
						controller : [ '$scope','data', '$modalInstance', function($scope, data, $modalInstance) {
							$scope.data = item;
							$scope.close = function() {
								$modalInstance.close();
							};
						}],
						size : 'md',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return {
									data : item.workflow,
								};
							}
						}
					});
				};
		    };
		    /** Method for Pagination */
			$scope.paginationHandler = function(currentPage) {
				$scope.searchDataInitiation($scope.search,currentPage);
			};
		    var init = function(){
				$scope.searchDataInitiation($scope.corpAddQueData[0],1);
		    }
		    init();
	 	}
	addressQuery.controller('corpAddressQueryController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','addressQueryService', 'lazyModuleLoader',corpAddressQueryController]);
	return corpAddressQueryController;
});