/** Story : Corporate Legal Address Query.
 * Modified By - OFS
 * Represents Address Query.
 * @version v1.0 Date:  21-02-2018
 */
define(['require','collectionsApp','addressQueryResolver'],
	function(require,collectionsApp, addressQueryResolver) {
	'use strict';
	var baseViewUrl = 'app/collections/corporateLegal/corpLegalAddressQuery/';
	var app = angular.module('addressQuery', [ 'common','ui.router', 'collections']);
	var addressConfig =  function($stateProvider,$urlRouterProvider) {
		$stateProvider.state('collections.corpLegalAddressQuery', {
			name : 'collections.corpLegalAddressQuery',
			url : '/corpAddressQuery',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'corpAddressQuery.html',
					controller : 'corpAddressQueryController',
					resolve : addressQueryResolver
				}
			},
			data:{
				'headerText':'Corporate Legal Address Query'
			}
		});
	};
	return app.config([ '$stateProvider', '$urlRouterProvider', addressConfig ]);
});