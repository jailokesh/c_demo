
define(['require','constants','corpLegalRaiseQuery','collectionServiceURLs','utility'],function(require,constants,corpLegalRaiseQuery,collectionServiceURLs,utility){
	var raiseQueryService = function ($q,restProxy,$rootScope,$http,dialogService,masterService,$upload) {	
    var limit = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		var header = {
      'Content-Type' : 'application/json',
      'Authorization':getCookie('token'),
      'userID' : $rootScope.identity.userName
    };
    var serviceObj = this;
    this.locations = { 
      branchDetails : {}
    };

    this.getSearchDetails = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_RAISE_QUERY_SEARCH.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RAISE_QUERY_SEARCH, queryObj).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
      });
    };
    this.getMailIdDetails = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_RAISE_QUERY_EMAIL_ID.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RAISE_QUERY_EMAIL_ID, queryObj).then(function(response) {
        if(response && response.data) {
          return response.data;
        } else {
          return [];
        }
      });
    };
    this.createEmailSOARaiseQuery = function(queryObj){
      collectionServiceURLs.corpLegalServices.CORPLEGAL_EMAIL_SOA_RAISE_QUERY.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.CORPLEGAL_EMAIL_SOA_RAISE_QUERY, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.createRaiseQueryCase = function(queryObj){
      collectionServiceURLs.corpLegalServices.CORPLEGAL_CREATE_RAISE_QUERY.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.CORPLEGAL_CREATE_RAISE_QUERY, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.getUserDataMapping = function() {
      if ($rootScope.identity.zoneIDs.length > 0) {
        masterService.getAreas({
          ZoneID : $rootScope.identity.zoneIDs.toString()
          }, 'zone').then(function(userZones) {
          $rootScope.identity.userZones = userZones;
          serviceObj.locations.branchDetails.zones = userZones;
          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
        });
      }
      if ($rootScope.identity.regionIDs.length > 0) {
        masterService.getAreas({
          regionID : $rootScope.identity.regionIDs.toString()
          }, 'region').then(function(userRegions) {
          $rootScope.identity.userRegions = userRegions;
          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
        });
      }
      if ($rootScope.identity.areaIDs.length > 0) {
        masterService.getAreas({
          areaID : $rootScope.identity.areaIDs.toString()
          }, 'area').then(function(userAreas) {
          $rootScope.identity.userAreas = userAreas;
          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
        });
      }
      if ($rootScope.identity.branchIDs.length > 0) {
        masterService.getBranches({
          branchID : $rootScope.identity.branchIDs.toString()
          }).then(function(userBranches) {
          $rootScope.identity.userBranches = userBranches;
          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
        });
      }
      return serviceObj;
    };
    this.getUserSelection = function(reqObj,type) {
      var identity = $rootScope.identity;
      if (identity.zoneIDs.length > 0) {
        return masterService.getAreas(reqObj,type).then(function(userZones) {
          return userZones;
        });
      }
    };
    /**
     * Method to get corporate queue list for the specific agreement number |
     * search by agreement Number
     */
    this.getCorporateQueue = function(params) {
      params.offset = params.offset ? (((params.offset - 1) * limit) + 1) : 1;
      params.limit = limit;
      collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.queryParams = params;
      collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE.urlParams = {};
      return restProxy.get(collectionServiceURLs.corpLegalServices.GET_LEGAL_QUEUE).then(function(data) {
        if(data.data){
          _.each(data.data, function(corporateCase) {
            var workflow = corporateCase.workflow.length ? corporateCase.workflow[0] : {};
            if (workflow.agreementNos && workflow.agreementNos.length) {
              corporateCase.agreementNo = workflow.agreementNos[0];
            } else {
              corporateCase.agreementNo = '';
            }
          });
          data.offset = params.offset;
        }
        return data;
      });
    };
  };
	corpLegalRaiseQuery.service('raiseQueryService',['$q','restProxy','$rootScope','$http','dialogService','masterService','$upload', raiseQueryService]);
	return raiseQueryService;
});
