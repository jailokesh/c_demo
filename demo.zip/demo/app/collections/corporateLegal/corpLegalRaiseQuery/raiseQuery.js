/** Story Id : HO Corporate Legal Raise Query.
 * Modified By - OFS
 * Represents Raise Query Screen.
 * @version v1.0 Date: 21-02-2018
 */
define(['require','collectionsApp','raiseQueryResolver'],
   function(require,collectionsApp, raiseQueryResolver) {
   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpLegalRaiseQuery/'; 
       var app = angular.module('corpLegalRaiseQuery', ['ui.router', 'collections']);

       var raiseQueryConfig = function($stateProvider, $urlRouterProvider) {
		    $stateProvider.state('collections.corpLegalRaiseQuery', {
				name : 'collections.corpLegalRaiseQuery',
				url : '/raiseQuery/:agreementNo/:noticeID/:isFromNotice/:isSoaMailNotify',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'raiseQuery.html',
						controller : 'raiseQueryController',
						resolve : raiseQueryResolver
					}
				},data:{'headerText':'Corporate Legal Raise Query'}
			});
		};

	app.config(['$stateProvider', '$urlRouterProvider', raiseQueryConfig]);
    return app;
});