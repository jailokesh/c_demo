define(['require','corpLegalRaiseQuery','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpLegalRaiseQuery, constants, collectionConstants, utility, DatePickerConfig,corpLegalConstants ) {
		'use strict';
		var raiseQueryController = function($scope,$stateParams,$state,$location,$modal, messageBus,dialogService,$rootScope,masterService,lazyModuleLoader,getZones,raiseQueryService, ) {
			$scope.isFromNotice = $stateParams.isFromNotice;
			$scope.isNotified = false;
			$scope.searchInput = $stateParams.agreementNo;
			$scope.searchType = corpLegalConstants.CORP_LEGAL_RAISEQUERY_SEARCH_TYPE;
			$scope.placeHolder = $scope.searchType[0].placeHolder;
			$scope.roleAddressSearchType = corpLegalConstants.RAISEQUERY_ROLADDRES_SEARCH_TYPE;
			$scope.userType = corpLegalConstants.CORP_LEGAL_USER_TYPE;
			var obj = {};
			var resultObj = {};
			$scope.data = {};
			$scope.data.maxRecordPerPage = collectionConstants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
			$scope.data.maxSize = collectionConstants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
			$scope.data.currentPage = 1;
			$scope.data.offset = 0;
			$scope.argNo = "";
            $scope.partyType = {};
            $scope.partyType.isUser = false;
            $scope.currentItem = ""; 
            $scope.raiseQuery = {};
            $scope.dropDownValues = getZones.locations;
            $scope.raiseQueryRole = corpLegalConstants.RAISE_QUERY_ROLES;
            $scope.isNotified = $stateParams.isFromNotice ? JSON.parse($stateParams.isFromNotice) : false;
			$scope.isSoaMailNotify = $stateParams.isSoaMailNotify ? JSON.parse($stateParams.isSoaMailNotify) : false;
             // Dropdown multiple
			$scope.roleAddress1data = [];
			$scope.roleAddress2data = [];
			$scope.roleAddress3data = [];
			$scope.roleAddress4data = [];
			$scope.roleAddress5data = [];
			$scope.roleAddress6data = [];
			$scope.roleAddress7data = [];

			$scope.roleAddress1model = [];
			$scope.roleAddress2model = [];
			$scope.roleAddress3model = [];
			$scope.roleAddress4model = [];
			$scope.roleAddress5model = [];
			$scope.roleAddress6model = [];
			$scope.roleAddress7model = [];
           
            var init = function(){
            	if($scope.isFromNotice){
                   obj = {"noticeID": $stateParams.noticeID };
                    raiseQueryService.getSearchDetails(obj).then(function(data){
			    	    if(data && data.length){
		    				$scope.searchResultsMain = data;
			    		}else {
			    			dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
			    		}
			       });
                }
			    if(angular.isDefined($scope.dropDownValues.branchDetails.regionsID)){
		            delete $scope.dropDownValues.branchDetails.regionsID;
		        }
            };
            init();
			$scope.searchChangeHandler = function(value){
				$scope.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
				$scope.searchInput = '';
			};
			$scope.getDetails = function(value){
				$scope.isFromNotice = false;
				$scope.disableUserName = false;
				$scope.raiseQuery.reason = '';
				$scope.dropDownValues.branchDetails.regionsID = '';
				$scope.roleAddress1data = [];
				$scope.roleAddress1model = [];
				$scope.roleAddress2data = [];
				$scope.roleAddress2model = [];
				$scope.roleAddress3data = [];
				$scope.roleAddress3model = [];
				$scope.roleAddress4data = [];
				$scope.roleAddress4model = [];
				$scope.roleAddress5data = [];
				$scope.roleAddress5model = [];
				$scope.roleAddress6data = [];
				$scope.roleAddress6model = [];
				$scope.roleAddress7data = [];
				$scope.roleAddress7model = [];
				$scope.roleAddressMainsettings = {};
				$scope.data.offset = 0;
				$scope.data.currentPage = 1;
				if($scope.searchInput != '')
				    getSearchData($scope.data.currentPage);
				else{
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Please enter vaild input to search");
				}
			};
			var queryObj = function(key,value){
				switch(key){
					case "noticeID" : obj={"noticeID":value,"offSet":$scope.data.offset};
					break;
					case "agreementNo" : obj={"agreementNo":value,"offSet":$scope.data.offset};
					break;
					case "queryID" : obj={"queryID":value,"offSet":$scope.data.offset};
					break;
					case "caseID" : obj={"caseID":value,"offSet":$scope.data.offset};
					break;
				}
			}
			var getSearchData = function(currentPage){
				$scope.data.offset = (currentPage - 1) * $scope.data.maxRecordPerPage;
				queryObj($scope.currentSearch.value, $scope.searchInput);
				raiseQueryService.getSearchDetails(obj).then(function(data){
					if(data){
						if (data.length > 0) {
							$scope.searchResults = data;
							$scope.hasRecords= true;
							$scope.errmsgShow = false;
						} 
						else{
							$scope.searchResults = 'No record found';
							$scope.hasRecords= false;
							$scope.errmsgShow = true;
						};
					}else {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
			}
            $scope.enableUserType = function(item) {
				$scope.currentItem = item;
				obj = {"noticeID": item.noticeID}
				$stateParams.noticeID = item.noticeID;
				raiseQueryService.getSearchDetails(obj).then(function(data){
					if(data){
						if(data.length > 0) {
							$scope.searchResultsMain = data;
                            $scope.hasRecords= false;
							$scope.errmsgShow = false;
						}else {
							$scope.searchResults = 'No record found';
							$scope.hasRecords= true;
							$scope.errmsgShow = true;
						};
					}else {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
				$scope.disableUserName = true;
				$scope.hasRecords = true;
				var elems = document.querySelector(".actives");
	            if( elems !== null) {
	                elems.classList.remove("actives");
	            }
	            $scope.toggle = false;
			}
			/** Pagination for search records */
			$scope.paginationHandler = function(currentPage) {
				getSearchData(currentPage);
			};
			var getFormDetails = function(){
				$scope.itemList = [];
				for(var i = 0; i < $scope.raiseQueryRole.length; i++){
					if($scope.raiseQueryRole[i].isSelected == true) {
						$scope.itemList.push($scope.searchResultsMain[0].productType + "_" + $scope.raiseQueryRole[i].name);
					}
				}
				$scope.assignedToArr = [];
				$scope.email = [];
				$scope.emailId = [];
				$scope.roleAddress1model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress1data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress2model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress2data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress3model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress3data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress4model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress4data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress5model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress5data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress6model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress6data,roleId.id);
					$scope.email.push(email);
				});
				$scope.roleAddress7model.forEach(function(roleId){
					$scope.assignedToArr.push(roleId.id);
					var email = _.findWhere($scope.roleAddress7data,roleId.id);
					$scope.email.push(email);
				});
				$scope.email.forEach(function(value) {
					$scope.emailId.push(value.emailId);
				});
		        $scope.queryObj = {
		          "agreementNo" : $scope.searchResultsMain[0].agreementNo,
		          "noticeID" : $scope.searchResultsMain[0].noticeID,
		          "caseID" : $scope.searchResultsMain[0].caseID,
		          "mailID" : $scope.emailId,
		          "notification" : $scope.isNotified,
		          "workflow":[{
			          "comments": $scope.raiseQuery.reason,
			          "workDoneBy": $rootScope.identity.userID,
			          "hierarchyID": $rootScope.identity.primaryHierarchyID,
			          "workStatus": 'assigned',
			          "workDoneDate": new Date(),
			          "assignedTo": $scope.assignedToArr			          
		          }]
		        };
            };

		    $scope.roleAddressMainsettings = {
		        scrollableHeight: '200px',
		        scrollable: true,
		        enableSearch: true
		    };

			// Dropdown multiple end
			$scope.onRegionChange = function(selectedItem){
			  	var obj1 = {
				    "primaryHierarchyID": "COMP_SEC",
				    "regionIDs": [selectedItem]
				}
				var obj2 = {
				    "primaryHierarchyID": "CORP_LEGAL_SR_MANAGER",
				    "$scope.roleAddress1data1regionIDs": [selectedItem]
				}
				var obj3 = {
				    "primaryHierarchyID": "HO_CORP_LEGAL_JR_MANAGER",
				    "regionIDs": [selectedItem]
				}
				var obj4 = {
				    "primaryHierarchyID": "HO_CORP_LEGAL_SUPPORT_EXECUTIVE",
				    "regionIDs": [selectedItem]
				}
				var obj5 = {
				    "primaryHierarchyID": "ZLM",
				    "regionIDs": [selectedItem]
				}
				var obj6 = {
				    "primaryHierarchyID": "RLM",
				    "regionIDs": [selectedItem]
				}
				var obj7 = {
				    "primaryHierarchyID": "ALM",
				    "regionIDs": [selectedItem]
				}
				if ($scope.roleAddress1model.length > 0) {
					$scope.roleAddress1model.length = 0;
				};
				if ($scope.roleAddress2model.length > 0) {
					$scope.roleAddress2model.length = 0;
				};
				if ($scope.roleAddress3model.length > 0) {
					$scope.roleAddress3model.length = 0;
				};
				if ($scope.roleAddress4model.length > 0) {
					$scope.roleAddress4model.length = 0;
				};
				if ($scope.roleAddress5model.length > 0) {
					$scope.roleAddress5model.length = 0;
				};
				if ($scope.roleAddress6model.length > 0) {
					$scope.roleAddress6model.length = 0;
				};
				if ($scope.roleAddress7model.length > 0) {
					$scope.roleAddress7model.length = 0;
				};
				var getMail = function(mailObj){
					var roleAddressData = [];
					raiseQueryService.getMailIdDetails(mailObj).then(function(data){					
						if(data){						
							if (data.length > 0) {					
								$scope.roleAddressModelMain = data;
						  		var rolefinalData = $scope.roleAddressModelMain.map(function (element) {
								   return {"label":element.userName + ' - ' + element.emailID,'id':element.userID,'emailId':element.emailID};
								});
								for(var i in rolefinalData ){
			                       roleAddressData[i] = rolefinalData[i];
								}
							} 
							else{							
								roleAddressData = [];
							}
						}else {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						}
					});
					return roleAddressData;
				}
				$scope.roleAddress1data = getMail(obj1);
				$scope.roleAddress2data = getMail(obj2);
				$scope.roleAddress3data = getMail(obj3);
				$scope.roleAddress4data = getMail(obj4);
				$scope.roleAddress5data = getMail(obj5);
				$scope.roleAddress6data = getMail(obj6);
				$scope.roleAddress7data = getMail(obj7);
			};

			$scope.createRaiseQuery = function(){
                getFormDetails();
		        if($scope.isSoaMailNotify) {
                	 raiseQueryService.createEmailSOARaiseQuery($scope.queryObj).then(function(res){
		                if(res != undefined){
			                if(res.status== "success"){
			                    dialogService.confirm('Confirm', "Confirm","Corporate Legal Notice created successfully.<br/>"+res.data.DataInserted[0].queryID, false, true).result.then(function() {
								        lazyModuleLoader.loadState('collections.corpLegalNoticeTrackingQueue');
									}, function() {
								});
			                }else if(res.status== "failure") {
				                if(res.message.hasOwnProperty("errors")){_
					                dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, res.message.error[0].message);
				                }
			                }
			            }
			        });
                }else {
                	raiseQueryService.createRaiseQueryCase($scope.queryObj).then(function(res){
		                if(res.data != undefined){
			                if(res.status== "success"){
			                    dialogService.confirm('Confirm', "Confirm","Corporate Legal Notice created successfully.<br/>"+res.data.DataInserted[0].queryID, false, true).result.then(function() {
								        lazyModuleLoader.loadState('collections.corpLegalNoticeTrackingQueue');
									}, function() {
								});
			                }else if(res.status== "failure") {
				                if(res.message.hasOwnProperty("errors")){_
					                dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, res.message.error[0].message);
				                }
			               }
			            }
			        });
                }
			};
	    };
		corpLegalRaiseQuery.controller('raiseQueryController', ['$scope','$stateParams', '$state','$location', '$modal', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader','getZones','raiseQueryService',raiseQueryController]);
		return raiseQueryController;
});