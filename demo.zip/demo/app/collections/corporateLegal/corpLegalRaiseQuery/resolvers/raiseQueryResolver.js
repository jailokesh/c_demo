define([], function() {
'use strict';

return {
	getZones : [ 'raiseQueryService', function(raiseQueryService) {
            return raiseQueryService.getUserDataMapping();
        }]
    };
});

