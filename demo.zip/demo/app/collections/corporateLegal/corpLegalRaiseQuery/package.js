/** Story Id : Corporate Legal Raise Query
 * Modified By - OFS
 * Represents a Package file for Raise Query.
 * @version v1.0 Date:  21-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the Raise Query module file names with their paths.
     * Contains the Raise Query module required dependency configuration.
     */
    require.config({
        paths: {

            'corpLegalRaiseQuery': 'app/collections/corporateLegal/corpLegalRaiseQuery/raiseQuery',
            'raiseQueryController': 'app/collections/corporateLegal/corpLegalRaiseQuery/controllers/raiseQueryController',
            'raiseQueryService' : 'app/collections/corporateLegal/corpLegalRaiseQuery/services/raiseQueryService',
            'raiseQueryResolver' : 'app/collections/corporateLegal/corpLegalRaiseQuery/resolvers/raiseQueryResolver',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'corpLegalRaiseQuery': ['angular', 'angular-ui-router'],
            'raiseQueryController':['corpLegalRaiseQuery', 'raiseQueryService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the Raise Query module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','raiseQueryController', 'workplanController'], callback);
            });
        });
    };
});