/** Story Id : Corporate Case Initiation for HO Corporate Legal User
 * Created By - OFS
 * Represents a Package file for Corporate Case initiation.
 * @version v1.0 Date:  22-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the corporate case initiation module file names with their paths.
     * Contains the corporate case initiation module required dependency configuration.
     */
    require.config({
        paths: {
            'caseInitiation': 'app/collections/corporateLegal/corporateCaseInitiation/corpInitiation',
            'caseInitiationController': 'app/collections/corporateLegal/corporateCaseInitiation/controllers/caseInitiationController',
            'caseInitiationService' : 'app/collections/corporateLegal/corporateCaseInitiation/services/caseInitiationService',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
            'userTypeSelectionController': 'app/collections/corporateLegal/corporateCaseInitiation/controllers/userTypeSelectionController',
            'customerSearchController' : 'app/collections/corporateLegal/corporateCaseInitiation/controllers/customerSearchController',
            'customerCaseController' : 'app/collections/corporateLegal/corporateCaseInitiation/controllers/customerCaseController',
            'nonCustomerCaseController' : 'app/collections/corporateLegal/corporateCaseInitiation/controllers/nonCustomerCaseController',
            'caseAgainstUsPopupController' : 'app/collections/corporateLegal/corporateCaseInitiation/controllers/caseAgainstUsPopupController',
            'caseInitiationResolver' : 'app/collections/corporateLegal/corporateCaseInitiation/resolvers/caseInitiationResolver'
       },
        shim: {
            'caseInitiation': ['angular', 'angular-ui-router'],
            'caseInitiationController':['caseInitiation','caseInitiationService'],
            'userTypeSelectionController' : ['caseInitiation'],
            'customerSearchController' : ['caseInitiation','caseInitiationService'],
            'customerCaseController' : ['caseInitiation','caseInitiationService'],
            'nonCustomerCaseController' : ['caseInitiation','caseInitiationService'],
            'caseAgainstUsPopupController' : ['caseInitiation']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the corporate case initiation module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','caseInitiationController', 'workplanController','userTypeSelectionController','customerSearchController',
                   'customerCaseController', 'nonCustomerCaseController','caseAgainstUsPopupController'], callback);
            });
        });
    };
});