/** Story Id : Corporate Case Initiation for HO Corporate Legal User.
 * Modified By - OFS
 * Represents Corporate Case Initiation.
 * @version v1.0 Date:  22-02-2018
 */
define(['require','collectionsApp','caseInitiationResolver'],function(require,collectionsApp,caseInitiationResolver) {
	'use strict';
	var baseViewUrl = 'app/collections/corporateLegal/corporateCaseInitiation/'; 
	var app = angular.module('caseInitiation', [ 'common','ui.router', 'collections']);
	var cau =  function($stateProvider) {
		$stateProvider.state('collections.corporateCaseInitiation', {
			name : 'collections.corporateCaseInitiation',
			url : '/caseInitiation',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'corpInitiation.html',
					controller : 'caseInitiationController',
				}
			},data:{'headerText':'Corporate Case Initiation'}
		}).state('collections.custSearch',{
			name : 'collections.custSearch',
			url : '/customerSearch',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'partials/customerCaseSearch.html',
					controller : 'customerSearchController',
					resolve : caseInitiationResolver
				}
			},data:{'headerText':'Corporate Case Initiation'}
		}).state('collections.customer',{
			name : 'collections.customer',
			url : '/customerCaseInitiation/:agreementNo/:ZoneID/:regionID/:areaID/:branchID',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'partials/customerCase.html',
					controller : 'customerCaseController',
					resolve :caseInitiationResolver
				}
			},data:{'headerText':'Customer - Corporate Case Initiation',
		        'backState': 'collections.custSearch'}
		}).state('collections.nonCustomer',{
			name : 'collections.nonCustomer',
			url : '/nonCustomerCaseInitiation',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'partials/nonCustomerCase.html',
					controller : 'nonCustomerCaseController',
					resolve : caseInitiationResolver
				}
			},data:{'headerText':'Non Customer - Corporate Case Initiation'}
		});
	};
	app.config([ '$stateProvider', cau ]);
	return app;
});