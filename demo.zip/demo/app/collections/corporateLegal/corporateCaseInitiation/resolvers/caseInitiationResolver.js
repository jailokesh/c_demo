define([], function() {
'use strict';

	return {
        getHeaderInfo: ['caseInitiationService','$stateParams',
            function(caseInitiationService,$stateParams) {
                return caseInitiationService.getHeaderInfo($stateParams.agreementNo).then(function(data){
                	return data;
                });
            }],
        getAdvocateInfo: ['caseInitiationService',function(caseInitiationService,$stateParams) {
                return caseInitiationService.getAdvocateList().then(function(data){
                	return data;
                });
            }],
         getManagerInfo: ['caseInitiationService',function(caseInitiationService,$stateParams) {
                return caseInitiationService.getManagerList().then(function(data){
                	return data;
                });
            }],
         getCorpCaseAsideInfo : ['caseInitiationService','$stateParams',
            function(caseInitiationService,$stateParams) {
                return caseInitiationService.getRightPaneDetails($stateParams.agreementNo).then(function(data){
                	return data;
                });
            }],
        getZones : [ 'caseInitiationService', function(caseInitiationService) {
            return caseInitiationService.getUserDataMapping();
        } ]
      
    };
});