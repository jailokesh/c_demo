/** Story Id : Corporate case Initiation  .
 * Modified By - OFS
 * Represents a corporate case initiation Service for HO Corporate Legal user.
 * @version v1.0 Date:  04-03-2018
 */
define(['require','constants','caseInitiation','collectionServiceURLs','utility'],function(require,constants,caseInitiation,collectionServiceURLs,utility){
	var caseInitiationService=function($q,restProxy,$rootScope,$http,dialogService,masterService,$upload){	
		var header = {
       'Content-Type' : 'application/json',
       'Authorization':getCookie('token'),
       'userID' : $rootScope.identity.userName
    };
    var serviceObj = this;
    this.locations = { 
      branchDetails : {}
    };

    this.getSearchDetails = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_CORPLEGAL_CUSTOMER_SEARCH.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_CORPLEGAL_CUSTOMER_SEARCH, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.getThirdPersonName = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_PARTY_TYPE_NAME.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_PARTY_TYPE_NAME, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
      
    this.getHeaderInfo = function(input){
      queryObj = {"agreementNo" : input};
      collectionServiceURLs.corpLegalServices.GET_HEADER_DETAILS.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_HEADER_DETAILS, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
        
    this.getCorpCaseAsideInfo = function(input){
      queryObj = {"agreementNo" : input};
      collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };

    this.createCorpLegalCase = function(queryObj){
      collectionServiceURLs.corpLegalServices.CREATE_CORPLEGAL_CASE.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.CREATE_CORPLEGAL_CASE, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    //to get the advocate list
    this.getAdvocateList = function(){
      return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_DETAILS).then(function(data) {
        var advocateList = data.data;
        return advocateList;
      });
    };
    // to get the ALM / RLM / ZLM / ZRM list for case assigned to
    this.getManagerList = function(){ 
      var role = $rootScope.identity.roles[0].roleName;
      collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS.queryParams = {};
      collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS.queryParams.roleName = role;
      return restProxy.get(collectionServiceURLs.corpLegalServices.GET_MANAGER_DETAILS).then(function(data) {
        var managerList = data.data;
        return managerList;
      });
    };
    //to get user location details
    this.getUserLocationDetails = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_CASE_LOCATION_INFO.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_CASE_LOCATION_INFO, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    //to get customer right side details
    this.getRightPaneDetails = function(agreementNo){
      var bodyParams = {
        'agreementNo' : agreementNo
      }
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS,bodyParams).then(function(data){ 
        if(data.message && data.message.errors && data.message.errors.length){
          if(data.message.errors[0].errorCode === 'COM-EXE-2002'){
            dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, data.errors[0].message);
          }
        }
        return data.data;
      });
    }

    /**
    * Method to get drop down values for zone,region,area,branch
    */
    this.getUserDataMapping = function() {
      if ($rootScope.identity.zoneIDs.length > 0) {
        masterService.getAreas({
          ZoneID : $rootScope.identity.zoneIDs.toString()
        }, 'zone').then(function(userZones) {
          $rootScope.identity.userZones = userZones;
          serviceObj.locations.branchDetails.zones = userZones;
          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
        });
      }
      if ($rootScope.identity.regionIDs.length > 0) {
        masterService.getAreas({
          regionID : $rootScope.identity.regionIDs.toString()
        }, 'region').then(function(userRegions) {
          $rootScope.identity.userRegions = userRegions;
          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
        });
      }
      if ($rootScope.identity.areaIDs.length > 0) {
        masterService.getAreas({
          areaID : $rootScope.identity.areaIDs.toString()
        }, 'area').then(function(userAreas) {
          $rootScope.identity.userAreas = userAreas;
          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
        });
      }
      if ($rootScope.identity.branchIDs.length > 0) {
        masterService.getBranches({
          branchID : $rootScope.identity.branchIDs.toString()
        }).then(function(userBranches) {
          $rootScope.identity.userBranches = userBranches;
          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
        });
      }
      return serviceObj;
    };

    this.getUserSelection = function(reqObj,type) {
      var identity = $rootScope.identity;
      if (identity.zoneIDs.length > 0) {
        return masterService.getAreas(reqObj,type).then(function(userZones) {
          return userZones;
        });
      }
    };
  
    this.getAllotmentLetter = function(queryObj, docType){
      var requestUrl;
      if (docType == 'word') {
        requestUrl = collectionServiceURLs.corpLegalServices.GET_ALLOTMENT_LETTER_WORD;
      } else {
        requestUrl = collectionServiceURLs.corpLegalServices.GET_ALLOTMENT_LETTER;
      }
      requestUrl.queryParams = {};
      requestUrl.queryParams.advocateName = queryObj.advocate;
      requestUrl.queryParams.area = queryObj.area;
      requestUrl.queryParams.branch = queryObj.branch;
      requestUrl.queryParams.caseNo = queryObj.caseNo;
      requestUrl.queryParams.caseFilingYear = queryObj.caseFilingYear;
      requestUrl.queryParams.courtName = queryObj.courtName;
      requestUrl.queryParams.agreementNo = queryObj.agreementNo;
      requestUrl.queryParams.customerName = queryObj.customerName;
      requestUrl.queryParams.stageOfCase = queryObj.stageOfCase;
      requestUrl.queryParams.subStageOfCase = queryObj.subStageOfCase;
      requestUrl.queryParams.nextHearingDate = queryObj.nextHearingDate;
      requestUrl.queryParams.year = queryObj.year;
      requestUrl.queryParams.approvedFee = queryObj.approvedFee;
      requestUrl.queryParams.contactNo = queryObj.contactNo;
      requestUrl.queryParams.docType = docType;

      if (docType == 'word') {
        restProxy.get(requestUrl).then(function(result) {
          if (result.status === "success") {
            var blob = new Blob([ result.data ], {
              type : "application/docx"
            });
            if (navigator.appVersion.toString().indexOf('.NET') > 0) {
              window.navigator.msSaveOrOpenBlob(blob, 'Allotment letter.docx');
            } else {
              var url = URL.createObjectURL(blob);
              var link = document.createElement("a");
              if (link.download !== undefined) {
                link.setAttribute("href", url);
                link.setAttribute("download", 'Allotment letter.docx');
                link.style.visibility = 'hidden';
                link.click();
                return result;
              }
            }
          }
        });
      } else {
          restProxy.getBlob(requestUrl, undefined, undefined, 'arraybuffer', 'application/pdf').then(function(result) {
          if (result.status === "success") {
            var blob = new Blob([ result.data ], {
              type : "application/pdf"
            });
            if (navigator.appVersion.toString().indexOf('.NET') > 0) {
              window.navigator.msSaveOrOpenBlob(blob, 'Allotment letter.pdf');
            } else {
              var url = URL.createObjectURL(blob);
              var link = document.createElement("a");
              if (link.download !== undefined) {
                link.setAttribute("href", url);
                link.setAttribute("download", 'Allotment letter.pdf');
                link.style.visibility = 'hidden';
                link.click();
                return result;
              }
            }
          }
        });
      }
    };
	};
	caseInitiation.service('caseInitiationService',['$q','restProxy','$rootScope','$http','dialogService','masterService','$upload', caseInitiationService]);
	return caseInitiationService;
});