define(['require','caseInitiation','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants','legalConstants'],
	function(r, caseInitiation, constants, collectionConstants,  utility, DatePickerConfig , corpLegalConstants,legalConstants) {
		'use strict';
		var customerSearchController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,lazyModuleLoader,caseInitiationService) {
			$scope.searchResults =[];
			$scope.hasRecords=false;
			$scope.disableUserName = false;
			$scope.searchType = corpLegalConstants.CORP_LEGAL_CUST_SEARCH_TYPE;
			$scope.placeHolder = "Enter Agreement Number";
			$scope.userType = corpLegalConstants.CORP_LEGAL_USER_TYPE;
			var obj = {};
			var resultObj = {};
			$scope.data = {};
			$scope.data.maxRecordPerPage = collectionConstants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
			$scope.data.maxSize = collectionConstants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
			$scope.data.currentPage = 1;
			$scope.data.offset = 0;
			$scope.argNo = "";
            $scope.partyType = {};
            $scope.partyType.isUser = false;
            $scope.currentItem = "";
			$scope.searchChangeHandler = function(value){
				$scope.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
				$scope.searchInput = '';
			};
			// $scope.getDetails = function(value){
			// 	$scope.disableUserName = false;
			// 	$scope.data.offset = 0;
			// 	$scope.data.currentPage = 1;
			// 	if($scope.searchInput != '')
			// 	   getSearchData($scope.data.currentPage);
			// 	else{
			// 		dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Please enter vaild input to search");
			// 	}
			// };
			$scope.getDetails = function(value){
				$scope.disableUserName = false;
				$scope.data.offset = 0;
				$scope.data.currentPage = 1;
				if(!value){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Please enter vaild input to search");
					return;
				}
				else if (value.length < legalConstants.SEARCH_LIMIT) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + legalConstants.SEARCH_LIMIT + " Characters to Search !");
					return;
				}
				getSearchData($scope.data.currentPage);
				 
			};
			var queryObj = function(key,value){
				switch(key){
					case "agreementNo" : obj={"agreementNo":value,"offSet":$scope.data.offset};
					break;
					case "vehicleNo" : obj={"vehicleNo":value,"offSet":$scope.data.offset};
					break;
					case "cifId" : obj={"cifId":value,"offSet":$scope.data.offset};
					break;
				}
			};
			var getSearchData = function(currentPage){
				$scope.data.offset = (currentPage - 1) * $scope.data.maxRecordPerPage;
				queryObj($scope.currentSearch.value,$scope.searchInput);
				
				caseInitiationService.getSearchDetails(obj).then(function(data){					
					$scope.data.totalRecords = data.data.count ? data.data.count : 0;				
					$scope.data.offsetLast = (($scope.data.offset + $scope.data.maxSize) > $scope.data.totalRecords) ? $scope.data.totalRecords : $scope.data.offset + ($scope.data.maxSize - 1);
					if(data.data && !(data.hasOwnProperty("errors"))){
						$scope.searchResults = data.data.res;
						$stateParams.ZoneID = $scope.searchResults.ZoneID;
						$stateParams.regionID = $scope.searchResults.regionID;
						$stateParams.areaID = $scope.searchResults.areaID;
						$stateParams.branchID = $scope.searchResults.lmsBranchID;
						$scope.hasRecords= true;
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}
				});
			};
			/** Pagination for search records */
			$scope.paginationHandler = function(currentPage) {
				getSearchData(currentPage);
			};
			$scope.typeChangeHandler = function (user){
				switch(user){
					case "customer" : if($scope.resultObj.customerName){
						        $scope.partyType.inputName = $scope.resultObj.customerName;
					        }else{
						        $scope.partyType.inputName = "";
					        }
					break;
					case "guarantor" : if($scope.resultObj.guarantier){
						        $scope.partyType.inputName = $scope.resultObj.guarantier;
					        }else{
						        $scope.partyType.inputName = "";
					        }
					break;
					case "coApplicant" : if($scope.resultObj.coApplicant){
						        $scope.partyType.inputName = $scope.resultObj.coApplicant;
					        }else{
						        $scope.partyType.inputName = "";
					        }
					break;
					default :
					        $scope.partyType.inputName = "";
					break;
				}
				if( $scope.partyType.inputName != "" ){
					$scope.partyType.isUser = true;
				}else{
					$scope.partyType.isUser = false;
				}
			};
			$scope.enableUserType = function(item,type){
				$scope.currentItem = item;
				if(type!=$scope.userType[0].value){
					$scope.partyType.user =   $scope.userType[0].value;
				}
				obj = {"agreementNo": item.agreementNo}
				$stateParams.agreementNo = item.agreementNo;
				caseInitiationService.getThirdPersonName(obj).then(function(res){
				if(res.data) {
					$scope.resultObj = res.data;
					$scope.partyType.inputName = res.data.customerName;
					$scope.partyType.isUser = true;
				   }
				});
				$scope.disableUserName = true;
				var elems = document.querySelector(".actives");
	            if( elems !== null) {
	                elems.classList.remove("actives");
	            }
	            $scope.toggle = false;
			};
			$scope.InitiateForm = function(){
				$rootScope.caseFileBy = $scope.partyType.user;
				$rootScope.inputData = $scope.partyType.inputName;
				lazyModuleLoader.loadState('collections.customer', {agreementNo :$stateParams.agreementNo, ZoneID: $stateParams.ZoneID, regionID: $stateParams.regionID,  areaID: $stateParams.areaID, branchID: $stateParams.branchID});
			};
	    };
	caseInitiation.controller('customerSearchController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader','caseInitiationService',customerSearchController]);
	return customerSearchController;
});