define(['require','caseInitiation','constants','collectionConstants','utility','DatePickerConfig'],
	function(r, caseInitiation, constants, collectionConstants, utility, DatePickerConfig ) {
		'use strict';
		var userTypeSelectionController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,lazyModuleLoader) {
      $scope.launchCaseInitiation = function (userType){
        if(userType == "Customer"){
              lazyModuleLoader.loadState('collections.custSearch');
        }else if(userType == "NonCustomer") {
              lazyModuleLoader.loadState('collections.nonCustomer');
        }
      };
      $scope.launchDashboard = function (){
        lazyModuleLoader.loadState('collections.corpDashboard');
      };
    };

  caseInitiation.controller('userTypeSelectionController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader',userTypeSelectionController]);
  return userTypeSelectionController;
});