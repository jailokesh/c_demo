define(['require','caseInitiation','constants','collectionConstants','utility','DatePickerConfig'],
	function(r, caseInitiation, constants, collectionConstants, utility,DatePickerConfig ) {
		'use strict';
		var caseInitiationController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,lazyModuleLoader) {
			
		dialogService.showCustomDialog('app/collections/corporateLegal/corporateCaseInitiation/partials/userSelection.html', 'userTypeSelectionController', {
			data: function() {
				return {
					/*insuranceDetail : msDetail,
					isMSFlag : true,
					assetDetail : $scope.selectedAgreement.assetDetail*/
				};
			}
		},function(result){
			if (result.status === "success") {
				/*$scope.value.cholaMSDetails = result.data;
				$scope.totalOD = $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = Math.round(result.data.totalPremium);
				$scope.receiptPostModel.Receipt.amountPaid = Math.round(result.data.totalPremium);
				$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = Math.round(result.data.totalPremium);
				balanceAutoAllocation($scope.receiptPostModel.Receipt.amountPaid);
				$scope.value.isMSFlag = result.data.isMSFlag;*/
			}else{
				/*$scope.receiptType = $scope.value.receiptType = 'OD';
				initController();*/
			}
		},'sm', 'modal-custom', true);
	};

	caseInitiation.controller('caseInitiationController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader' ,caseInitiationController]);
	return caseInitiationController;
});