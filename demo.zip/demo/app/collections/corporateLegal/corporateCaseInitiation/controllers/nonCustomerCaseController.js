define(['require','caseInitiation','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, caseInitiation, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants) {
		'use strict';
		var nonCustomerCaseController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,caseInitiationService,getAdvocateInfo,getManagerInfo,getZones,appFactory,$globalScope,$filter) {
      $scope.isHOUser = ($rootScope.identity.primaryHierarchyID=="HO_CORP_LEGAL")?true : false;
      $scope.filedBy = corpLegalConstants.caseFiledByArray;      
      $scope.businessTypeArray = corpLegalConstants.businessTypeArray;
      $scope.natureArray= corpLegalConstants.disputeNatureArray;
      $scope.generalTypeArray= corpLegalConstants.caseTypeGeneralArray;
      $scope.servedOnArray= corpLegalConstants.noticeServedOnArray;
      $scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
      $scope.statusArray= corpLegalConstants.statusOfCaseArray;
      $scope.stageArray= corpLegalConstants.stageOfCaseArray;
      $scope.injunctionArray= corpLegalConstants.injunctionTypeArray;
      $scope.courtOrderArray= corpLegalConstants.courtOrderArray;
      $scope.riskAssessmentArray= corpLegalConstants.riskAssessmentArray;
      $scope.cauAppealArray = corpLegalConstants.cauAppealArray;
      $scope.favourCustArray = corpLegalConstants.orderFavourCustomerArray;
      $scope.courtName = corpLegalConstants.courtName;
      $scope.advocateList = getAdvocateInfo.advocates;
      $scope.managerArray = getManagerInfo;
      $scope.isCaseClose = false;
      $scope.corpCaseData = {};
      $scope.isDateOfEntry = true;
      $scope.locationData = {};
      $scope.dropDownValues = getZones.locations;
      $scope.dataType = {
        isType : false,
        isDate : false,
        isDcr:false,
        isZoneUser:false,
        isRegUser:false,
        isAreaUser:false,
        isBranchUser:false
      };
      $scope.isRiskDisable = false;
      var date = new Date();
       $scope.firstHearingDateConfig = new DatePickerConfig({
        dateValue : new Date(),
        readonly : true
      });
      $scope.lastHearingDateConfig = new DatePickerConfig({
        dateValue : new Date(),
        readonly : true
      });
      $scope.nextHearingDateConfig = new DatePickerConfig({
        value :  new Date(),
        readonly : true
      });
      $scope.dateOfEntryConfig = new DatePickerConfig({
        value :  new Date(),
        readonly : true
      });
      $scope.caseFilingYearDateConfig = new DatePickerConfig({
        value :  new Date(),
        readonly : true
      });
      $scope.changeHandler = function(type, ID, value) {
        var branchArr, areaArr, regionArr;
        if (type === 'Zone') {
          $scope.dropDownValues.branchDetails.regionID = "";
          if($scope.dataType.isHoUser){
            if(ID){
              $scope.userSelection({ZoneID : ID}, 'Region','filteredRegions');
            }
            $scope.dropDownValues.branchDetails.areaID = "";
            $scope.dropDownValues.branchDetails.branchID = "";
            $scope.dropDownValues.branchDetails.filteredRegions = [];
            $scope.dropDownValues.branchDetails.filterdAreas = [];
            $scope.dropDownValues.branchDetails.filterdBranch = [];
            $scope.dropDownValues.branchDetails.disableRegion = true ;
            $scope.dropDownValues.branchDetails.disableArea = true ;
            $scope.dropDownValues.branchDetails.disableBranch = true;
          }else{
            regionArr = ($scope.dropDownValues.branchDetails.zoneID) ? _.where($scope.dropDownValues.branchDetails.regions, {
              ZoneID : $scope.dropDownValues.branchDetails.zoneID
            }) : '';
            if (regionArr.length > 1 && $scope.dropDownValues.branchDetails.zoneID) {
              $scope.dropDownValues.branchDetails.disableRegion = false;
            } else {
              $scope.dropDownValues.branchDetails.regionID = regionArr[0] ? regionArr[0].regionID : "";
              $scope.dropDownValues.branchDetails.disableRegion = (!$scope.dropDownValues.branchDetails.regionID);
            }
            $scope.dropDownValues.branchDetails.filteredRegions = regionArr;
            type = 'Region';
          }
          
        }

        if (type === 'Region') {
          $scope.dropDownValues.branchDetails.areaID = "";
          if($scope.dataType.isHoUser){
            if(ID){
              $scope.userSelection({regionID:ID}, 'Area','filterdAreas');
            }
            $scope.dropDownValues.branchDetails.branchID = "";
            $scope.dropDownValues.branchDetails.filterdAreas = [];
            $scope.dropDownValues.branchDetails.filterdBranch = [];
            $scope.dropDownValues.branchDetails.disableArea = true ;
            $scope.dropDownValues.branchDetails.disableBranch = true;
            
          }else{
            areaArr = ($scope.dropDownValues.branchDetails.regionID) ? _.where($scope.dropDownValues.branchDetails.areas, {
              regionID : $scope.dropDownValues.branchDetails.regionID
            }) : '';
            if (areaArr.length > 1 && $scope.dropDownValues.branchDetails.regionID) {
              $scope.dropDownValues.branchDetails.disableArea = false;
            } else {
              $scope.dropDownValues.branchDetails.areaID = areaArr[0] ? areaArr[0].areaID : "";
              $scope.dropDownValues.branchDetails.disableArea = (!$scope.dropDownValues.branchDetails.areaID);
            }
            $scope.dropDownValues.branchDetails.filterdAreas = areaArr;
            type = 'Area';
          }
          
        }

        if (type === 'Area') {
          $scope.dropDownValues.branchDetails.branchID = "";
          if($scope.dataType.isHoUser){
            if(ID){
              $scope.userSelection({areaID:ID}, 'Branch','filterdBranch');
            }
            $scope.dropDownValues.branchDetails.filterdBranch = [];
            $scope.dropDownValues.branchDetails.disableBranch = true;
          }else{
            branchArr = ($scope.dropDownValues.branchDetails.areaID) ? _.where($scope.dropDownValues.branchDetails.branches, {
              areaID : $scope.dropDownValues.branchDetails.areaID
            }) :'';
            if (branchArr.length > 1 && $scope.dropDownValues.branchDetails.areaID) {
              $scope.dropDownValues.branchDetails.disableBranch = false;
            } else {
              $scope.dropDownValues.branchDetails.branchID = branchArr[0] ? branchArr[0].branchID : "";
              $scope.dropDownValues.branchDetails.disableBranch = (!$scope.dropDownValues.branchDetails.branchID);
            }
            $scope.dropDownValues.branchDetails.filterdBranch = branchArr;
          }
        }
        if(type === 'Branch' && !ID){
          $scope.dropDownValues.branchDetails.branchID = "";
        }
      };

      $scope.init = function(){
        var categoryList = _.findWhere($globalScope.imageCategories, {subCategory : "document images"});
        $scope.categoryDetails = categoryList ? categoryList : {};
        $scope.dropDownValues.branchDetails.zoneID ='';
        $scope.dropDownValues.branchDetails.regionID ='';
        $scope.dropDownValues.branchDetails.areaID ='';
        $scope.dropDownValues.branchDetails.branchID ='';
        if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.ZONE_REPORT)){
          $scope.dataType.isZoneUser = true;
        }else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.REGION_REPORT)){
          $scope.dataType.isRegUser = true;
        }else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.AREA_REPORT)){
          $scope.dataType.isAreaUser = true;
        }else if(appFactory.getActivityAccess(corpLegalConstants.USER_BASED_REPORT.BRANCH_REPORT)){
          $scope.dataType.isBranchUser = true;
        }
      };

      $scope.init();
      $scope.onStatusChange = function(status) {
        $scope.stageArray = corpLegalConstants.stageOfCaseArray;
        if(status == 'Live') {
          $scope.stageArray = _.without($scope.stageArray,'Ordered')
          $scope.corpCaseData.caseStage = "";
        } else if(status == 'Closed') {
          $scope.stageArray = ["Ordered"];
          $scope.corpCaseData.caseStage = "Ordered";
          $scope.corpCaseData.stageID = 5;
        } else if(status == undefined) {
          $scope.corpCaseData.caseStage = "";
        }
      };
      $scope.onChangeOfStage = function(item){  
        $scope.corpCaseData.stageID = corpLegalConstants.stageOfCaseArray.indexOf(item) +1;
      };
      $scope.onCourtOrderChange = function(value){
        
      };
      $scope.getCauValue = function(val){
        
      };
      $scope.onAmountChange = function(){
        if($scope.corpCaseData.claimAmount >=1000000 || $scope.corpCaseData.approvedFee >=1000000){
          $scope.corpCaseData.riskAssessment = "High";
        }else{
          $scope.corpCaseData.riskAssessment = "";
        }
        $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
      };
      $scope.onGeneralCaseChange = function(value){
        $scope.corpCaseData.generalType = value;
        $scope.specificTypeArray= corpLegalConstants.caseTypeSpecificArray;
        $scope.corpCaseData.specificType = "";      
        if(value == "Consumer"){
          $scope.corpCaseData.riskAssessment = "Medium";
          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
        }else if(value == "Civil"){
          $scope.corpCaseData.riskAssessment = "Medium";
          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Compensation","Injunction","Execution","First Appeal"]);
        }else if(value == "Criminal"){
          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition","Complaint"]);
        }else if(value == "WRIT"){
          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
          $scope.corpCaseData.specificType = "Petition";
        }else if(value == "MACT"){
          $scope.specificTypeArray= _. intersection( $scope.specificTypeArray,["Petition"]);
          $scope.corpCaseData.specificType = "Petition";
        }else{
          $scope.corpCaseData.riskAssessment = "";
        }
        $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
      };
      $scope.onSpecificCaseChange = function(value){
        $scope.corpCaseData.specificType = value;
        if(value == "Execution"){
          $scope.corpCaseData.riskAssessment ="High"; 
        }else{
          $scope.corpCaseData.riskAssessment ="";
        }
        $scope.setRiskAssessment($scope.corpCaseData.riskAssessment);
      };
      $scope.getReleifSoughtVal = function(val){
        $scope.corpCaseData.reliefSought = val ;
        $scope.setRiskAssessment("");
      };
      $scope.setRiskAssessment = function(val){
        if($scope.corpCaseData.specificType == "Execution" || ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000 )){
          $scope.corpCaseData.riskAssessment = "High";
        }else if($scope.corpCaseData.generalType == "Consumer" && $scope.corpCaseData.specificType == "Execution"){
          $scope.corpCaseData.riskAssessment = "High";
        }else if($scope.corpCaseData.generalType == "Consumer" && ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000)){
          $scope.corpCaseData.riskAssessment = "High";
        }else if($scope.corpCaseData.generalType == "Consumer" && (($scope.corpCaseData.claimAmount<1000000|| $scope.corpCaseData.claimAmount==undefined) || ($scope.corpCaseData.approvedFee<1000000|| $scope.corpCaseData.approvedFee==undefined))){
          $scope.corpCaseData.riskAssessment ="Medium";
        }else if($scope.corpCaseData.generalType == "Civil" && $scope.corpCaseData.specificType == "Execution"){
          $scope.corpCaseData.riskAssessment = "High";
        }else if($scope.corpCaseData.generalType == "Civil" && ($scope.corpCaseData.claimAmount>1000000 || $scope.corpCaseData.approvedFee>1000000)){
          $scope.corpCaseData.riskAssessment = "High";
        }else if($scope.corpCaseData.generalType == "Civil" && $scope.corpCaseData.reliefSought){
          $scope.corpCaseData.riskAssessment ="Medium";
        }else if($scope.corpCaseData.generalType == "Civil" && !$scope.corpCaseData.reliefSought){
          $scope.corpCaseData.riskAssessment ="Low";
        }else{
          $scope.corpCaseData.riskAssessment = val;
        } 
        if($scope.corpCaseData.riskAssessment != undefined && $scope.corpCaseData.riskAssessment!=""){
          $scope.isRiskDisable = true;
        }else{
          $scope.isRiskDisable = false;
        }
      }
      $scope.onAdvocateChange= function(item){
        $scope.corpCaseData.advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName;
      }
      // to get logged user location info 
      var getLocationDetails = function(){
        var userId = $rootScope.identity.userName;
        queryObj = { "userID" : userId};
        caseInitiationService.getUserLocationDetails(queryObj).then(function(res){
          $scope.locationData = res.data;
          if($scope.locationData != null){
            $scope.corpCaseData.zone = $scope.locationData.zone[0].description;
            $scope.corpCaseData.region = $scope.locationData.region[0].name;
            $scope.corpCaseData.area = $scope.locationData.area[0].description;
            $scope.corpCaseData.branch = $scope.locationData.branch[0].branchDesc;
          }
          if($scope.corpCaseData.zone != undefined){
            $scope.locationData.isZone = true;
          }else if($scope.corpCaseData.region !=undefined){
            $scope.locationData.isRegion = true;
          }else if($scope.corpCaseData.area !=undefined){
            $scope.locationData.isArea = true;
          }else if($scope.corpCaseData.branch !=undefined){
            $scope.locationData.isBranch = true;
          }
        });
      };
      getLocationDetails();
      // to method to generate query object from initiate form details
      var getFormDetails = function(){
        $scope.queryObj = {
          "casefiledBy":$scope.corpCaseData.caseFiledBy,
          "caseFiledByName" : $scope.corpCaseData.name,
          "customerName": $scope.corpCaseData.custName,
          "courtCaseNo" : $scope.corpCaseData.caseNo,
          "businessType" : $scope.corpCaseData.businessType,
          "agreementNo" : $scope.corpCaseData.agreementNo,
          "disputeNature" : $scope.corpCaseData.disputeNature,
          "caseFilingYear" : $scope.corpCaseData.caseFilingYear,
          "caseTypeGeneral" : $scope.corpCaseData.generalType,
          "subCaseTypeGeneral" : $scope.corpCaseData.subCaseTypeGeneral,
          "noticeServedOn" : $scope.corpCaseData.noticeServedOn ,
          "caseFiledAgainst" : $scope.corpCaseData.caseFileAgainst ,
          "caseCategorySpecific" : $scope.corpCaseData.specificType ,
          "caseNoTypeIndicator" : $scope.corpCaseData.caseNoTypeIndicator ,
          "statusOfCase" : $scope.corpCaseData.caseStatus ,
          "stageOfCase" : $scope.corpCaseData.caseStage ,
          "caseStageID" : $scope.corpCaseData.stageID,
          "subStageOfCase" : $scope.corpCaseData.subStageCase ,
          "injunctionType" : $scope.corpCaseData.injunctionType ,
          "interimReliefSought" : $scope.corpCaseData.reliefSought ,
          "interimOrderPassed" : $scope.corpCaseData.interimOrderPassed ,
          "courtOrder" : $scope.corpCaseData.courtOrder ,
          "orderFavourToCustomer" : $scope.corpCaseData.favCustomer,
          "courtRemarks" : $scope.corpCaseData.courtRemarks,
          "claimAmount" : $scope.corpCaseData.claimAmount ,  
          "approvalFee" : $scope.corpCaseData.approvedFee ,
          "nextHearingDate" : $scope.corpCaseData.nextHearingDate ,
          "firstHearingDate" : $scope.corpCaseData.firstHearingDate ,
          "lastHearingDate" : $scope.corpCaseData.lastHearingDate ,
          "entryOfDate" : $scope.corpCaseData.dateOfEntry ,
          "zone": $scope.dropDownValues.branchDetails.zoneID,
          "region": $scope.dropDownValues.branchDetails.regionID, 
          "area" : $scope.dropDownValues.branchDetails.areaID ,
          "branch" : $scope.dropDownValues.branchDetails.branchID,
          "advocateID" : $scope.corpCaseData.advocate ,
          "courtName" : $scope.corpCaseData.courtName ,
          "miscInfo" : $scope.corpCaseData.miscInfo ,
          "riskAssesement" : $scope.corpCaseData.riskAssessment , 
          "remarks" : $scope.corpCaseData.remarks ,
          "reliefText" : $scope.corpCaseData.reliefText ,
          "assignedTo" : $scope.corpCaseData.assignedTo ,
          "appealOrCAU" : $scope.corpCaseData.cauOrAppeal ,
          "replyFiledStatus": $scope.corpCaseData.replyFiledStatus , 
          "isPaperAvailable" : $scope.corpCaseData.isPaperAvailable ,
          "allotmentFiledStatus" : $scope.corpCaseData.allotmentFileStatus,
          "documentImageRef" :  $scope.corpCaseData.docUpload,
          "contactNumber" : $scope.corpCaseData.contactNo,
          "orderBrief" : $scope.corpCaseData.orderBrief,
          "workDoneBy" : $rootScope.identity.userID
        };
      }

      $scope.getAllotmentLetter = function(){
        var reqObj = {
          "advocate" : $scope.corpCaseData.advocateName,
          "area" : $scope.dropDownValues.branchDetails.areaID,
          "branch" : $scope.dropDownValues.branchDetails.branchID,
          "caseNo": $scope.corpCaseData.caseNo,
          "caseFilingYear" : $scope.corpCaseData.caseFilingYear,
          "courtName" : $scope.corpCaseData.courtName,
          "agreementNo" : $scope.corpCaseData.agreementNo,
          "customerName" : $scope.corpCaseData.custName,
          "stageOfCase" : $scope.corpCaseData.caseStage ,
          "subStageOfCase" : $scope.corpCaseData.subStageCase ,
          "nextHearingDate" : $filter(collectionConstants.DATE)($scope.corpCaseData.nextHearingDate, collectionConstants.DATE_FILTER_STANDARD),
          "year" : $scope.corpCaseData.nextHearingDate.getFullYear(),
          "approvedFee" : $scope.corpCaseData.approvedFee,
          "contactNo" : $scope.corpCaseData.contactNo
        }
        if($scope.corpCaseData.letterType == "true"){
          caseInitiationService.getAllotmentLetter(reqObj,'word');
        }else{
           caseInitiationService.getAllotmentLetter(reqObj,'pdf');
          }
      };
     
      $scope.createCorporateCase = function(){
        getFormDetails();
        caseInitiationService.createCorpLegalCase($scope.queryObj).then(function(res){
          if(res.data != undefined){
            if(res.status=="success"){
              var caseId = res.data.DataInserted[0].caseID;
              dialogService.showAlert('Message', "Message", "Case initiated successfully with "+caseId+".");
            }else if(res.status=="failure") {
              if(res.message.hasOwnProperty("errors")){_
                dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, res.message.errors[0].message);
              }
            }
          }
        });
      };
      /** cancel the case */
      $scope.cancelCase = function() {
        dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.CANCEL).result.then(function() {
          $state.go("collections.corpDashboard");
        }, function() {});
      };
    }; 
    caseInitiation.controller('nonCustomerCaseController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','caseInitiationService','getAdvocateInfo','getManagerInfo','getZones','appFactory','$globalScope','$filter',nonCustomerCaseController]);
    return nonCustomerCaseController;
});