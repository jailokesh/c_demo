define(['require','caseInitiation','constants','collectionConstants','utility','DatePickerConfig'],
  function(r, caseInitiation, constants, collectionConstants, utility, DatePickerConfig ) {
    'use strict';
    var caseAgainstUsPopupController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,$modalInstance) {
      $scope.onSubmit = function (val,remarks){
        $modalInstance.close(
          {
            "cauRadio" : val,
            "courtRemarks" : remarks
          }
        );
      };
      $scope.onCancel = function (){
        $modalInstance.dismiss('cancel');
      };
    };
  caseInitiation.controller('caseAgainstUsPopupController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','$modalInstance',caseAgainstUsPopupController]);
  return caseAgainstUsPopupController;
});