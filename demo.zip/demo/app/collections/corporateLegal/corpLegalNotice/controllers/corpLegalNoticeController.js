define(['require','corpLegalNotice','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpLegalNotice, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants ) {
		'use strict';
		var corpLegalNoticeController = function($scope,$stateParams,$state,$location, $modal, messageBus,dialogService,$rootScope,masterService,lazyModuleLoader,corpLegalNoticeService,getZones,$filter, getAdvocateInfo, $globalScope) {
			$scope.searchResults =[];
			$scope.data = {};
			$scope.hasRecords = false;
			$scope.searchType = corpLegalConstants.Corp_Legal_Notice_Search_Type;
			$scope.placeHolder = $scope.searchType[0].placeHolder;
			$scope.dropDownValues = getZones.locations;
			$scope.userData = {};
			$scope.corpLegalData = {};
			$scope.corpLegalDatas = {};
			var obj = {};
			var resultObj = {};
			$scope.natureArray= corpLegalConstants.disputeNatureArray;
			$scope.advocateList = getAdvocateInfo.advocates; 
			var categoryList = _.findWhere($globalScope.imageCategories, {subCategory : "document images"});
            $scope.categoryDetails = categoryList ? categoryList : {};

			$scope.custNoticeDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
		    $scope.noticeRecdOnDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
		    $scope.intermReplyDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
		    $scope.intermDispachDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
		    $scope.replyDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
		    $scope.replyDispatchDateConfig = new DatePickerConfig({
		      value :  new Date(),
		      readonly : true,
		    });
			$scope.searchChangeHandler = function(value){
				$scope.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
				$scope.searchInput = '';
			};
			$scope.getDetails = function(input, key) {
				if(input != '')
					getSearchData(input, key);
				else{
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Please enter vaild input to search");
				}
			};
			var getSearchData = function(input, key){
				queryObj(input, key);
				corpLegalNoticeService.getSearchDetails(obj).then(function(data) {
					data = data.data;
					if(!(data.hasOwnProperty("msg")) && !(data.hasOwnProperty("errors"))){
						$scope.corpLegalData = data;
						$scope.branchesID = _.where($scope.dropDownValues.branchDetails.branches,{branchDesc: $scope.corpLegalData.branch});
						$scope.advocateID = _.where($scope.advocateList,{AdvocateName: $scope.corpLegalData.advocateID});
						if($scope.branchesID.length > 0) {
							$scope.corpLegalData.branchID = $scope.branchesID[0].branchID;
						}
						if($scope.advocateID.length > 0){
							$scope.corpLegalData.advocateID = $scope.advocateID[0].AdvocateID;
						}
						$scope.hasRecords= true;
						if($scope.corpLegalData.agreementNo){
							corpLegalNoticeService.getHeaderInfo({"agreementNo":$scope.corpLegalData.agreementNo}).then(function(data){
								$scope.headerInfo = data.data;
								$scope.propertyData = $scope.headerInfo.caseDetailInfo.propertyDetails;
								$scope.groupAgreementList = $scope.headerInfo.caseDetailInfo.agreementNos;
								getUserData();
							});
							corpLegalNoticeService.getCorpCaseAsideInfo({"agreementNo":$scope.corpLegalData.agreementNo}).then(function(data){
								$scope.agreementInfo = data.data;
								if($scope.agreementInfo.AsOn !="No Record") {
									$scope.agreementInfo.address =  $scope.agreementInfo.AsOn? $scope.agreementInfo.AsOn.address[0] : "";
								}
								$scope.availability = $scope.agreementInfo.availablityDetails;
							});
						}
					}else if(data.hasOwnProperty("errors")){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,"error");
						$scope.hasRecords= false;
					}else {
						$scope.corpLegalData = [];
						$scope.corpLegalData.branches = null;
						$scope.hasRecords= false;
					}
				});
			};
			var queryObj = function(key,value){
				switch(value){
					case "agreementNo": obj = {"agreementNo":key};
					break;
					case "vehicleNo" : obj = {"vehicleNo":key};
					break;
					case "caseID" : obj = {"caseID":key};
					break;
				}
			};
			var getUserData = function(){
				if($scope.headerInfo.caseDetailInfo != "No Record"){
					if($scope.headerInfo.caseDetailInfo.partyDetails.length>0){
						for(var i=0;i<$scope.headerInfo.caseDetailInfo.partyDetails.length;i++){
							if($scope.headerInfo.caseDetailInfo.partyDetails[i].partyType == "A"){
								$scope.userData = $scope.headerInfo.caseDetailInfo.partyDetails[i];
							}
						}
					}
				}
			};
            var getFormDetails = function() {
            	$scope.queryObj = {
            		"customerName": $scope.corpLegalData.firstName,
	              	"productType": $scope.corpLegalData.productGroup.toUpperCase(),
	              	"agreementNo": $scope.corpLegalData.agreementNo,
	              	"branchID": $scope.corpLegalData.branchID,
	              	"caseID" : $scope.corpLegalData.caseID,
            		"noticeStages" : [{
            			"stageID" : "1.1",
	            	  	"advocateID" : $scope.corpLegalData.advocateID,
					  	"receivedOn": $scope.corpLegalDatas.noticeReceivedOn,
					  	"customerNoticeDate": $scope.corpLegalDatas.customerNoticeDate,
					  	"noticeNature": $scope.corpLegalData.natureOfNotice,
					  	"issues": $scope.corpLegalData.issues,
					  	"remarks": $scope.corpLegalData.remarks,
					  	"noticeAgainstCholaFileRef" : [],
					  	"interimReply": [{
					  	   "description": $scope.corpLegalData.intermReplyDesc,
					  	   "replyDate": $scope.corpLegalDatas.intermReplyDate,
					  	   "courierName": $scope.corpLegalData.intermCourierName,
					  	   "dispatchNumber": $scope.corpLegalData.intermDispatchNumber,
					  	   "dispatchDate": $scope.corpLegalDatas.intermDispatchDate,
					  	   "interimReplyCopyFileRef" : []
					  	}],
					  	"reply": [{
					  	  "description": $scope.corpLegalData.replyDescription,
					  	  "replyDate": $scope.corpLegalDatas.replyDate,
					  	  "courierName": $scope.corpLegalData.replyCourierName,
					  	  "dispatchNumber": $scope.corpLegalData.replyDispatchNumber,
					  	  "dispatchDate": $scope.corpLegalDatas.replyDispatchDate,
					  	  "replyCopyFileRef" : []
					  	}]
				    }]
				};                
				$scope.queryObj["noticeStages"][0]["noticeAgainstCholaFileRef"].push($scope.corpLegalData.noticeAgainstChola);
				$scope.queryObj["noticeStages"][0]["interimReply"][0]["interimReplyCopyFileRef"].push($scope.corpLegalData.intermReplyCopy);
				$scope.queryObj["noticeStages"][0]["reply"][0]["replyCopyFileRef"].push($scope.corpLegalData.replyCopy);
            };
            $scope.createCorpLegal = function(){
		        getFormDetails();
		        corpLegalNoticeService.createCorpLegalNotice($scope.queryObj).then(function(res){
		            if(res.data != undefined){
		                if(res.status=="success"){
		                    dialogService.confirm('Confirm', "Confirm","Corporate Legal Notice created successfully.<br/>"+collectionConstants.ERROR_MSG.PROCEED, true, true).result.then(function() {
						        lazyModuleLoader.loadState('collections.corpLegalRaiseQuery', {
									agreementNo : res.data.DataInserted[0].agreementNo,
								    noticeID : res.data.DataInserted[0].noticeID,
								    isFromNotice: true,
								    isSoaMailNotify: true
								});
							}, function() {
								lazyModuleLoader.loadState('collections.corpLegalRaiseQuery', {
									agreementNo : res.data.DataInserted[0].agreementNo,
								    noticeID : res.data.DataInserted[0].noticeID,
								    isFromNotice: false,
								    isSoaMailNotify: true
								});
							});
		                }else if(res.status=="failure") {
			                if(res.message.hasOwnProperty("errors")){_
				                dialogService.showAlert(constants.ERROR_HEADER.error,constants.ERROR_HEADER.error, res.message.error[0].message);
			                }
			            }

		            } 
	            });
            };
            /** cancel the case */
		    $scope.onCancel = function() {
				dialogService.confirm('Confirm', "Confirm", collectionConstants.ERROR_MSG.CANCEL).result.then(function() {
					lazyModuleLoader.loadState("collections.corpDashboard");
				}, function() {});
		    };
		};

	corpLegalNotice.controller('corpLegalNoticeController', ['$scope','$stateParams', '$state','$location', '$modal', 'messageBus','dialogService','$rootScope', 'masterService','lazyModuleLoader','corpLegalNoticeService', 'getZones', '$filter', 'getAdvocateInfo' ,'$globalScope',corpLegalNoticeController]);
	return corpLegalNoticeController;
});