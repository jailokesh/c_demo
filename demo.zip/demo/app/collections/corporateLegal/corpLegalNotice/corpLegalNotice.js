/** Story Id : Corporate Legal Notice
 * Modified By - OFS
 * Represents Legal Notice screen.
 * @version v1.0 Date: 21-02-2018
 */
define(['require','collectionsApp','corpLegalNoticeResolver'],
   function(require,collectionsApp,corpLegalNoticeResolver) {
   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpLegalNotice/';
       var app = angular.module('corpLegalNotice', ['ui.router', 'collections']);
       var cau = function($stateProvider, $urlRouterProvider) {
		    $stateProvider.state('collections.corpLegalNotice', {
				name : 'collections.corpLegalNotice',
				url : '/LegalNotice',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'corpLegalNotice.html',
						controller : 'corpLegalNoticeController',
						resolve   : corpLegalNoticeResolver
					}
				},data:{'headerText':'Corporate Legal Notice'}
			});
		};
       
        app.config(['$stateProvider', '$urlRouterProvider', cau ]);
	    return app;
  });