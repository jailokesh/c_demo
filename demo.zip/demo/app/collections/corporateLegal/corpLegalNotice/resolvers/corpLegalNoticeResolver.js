/** Story Id : Corp Legal Notice 
 * Created By - OFS
 * Represents a resolver for corporate Legal Notice.
 * @version v1.0 Date:  24-04-2018
 */
define([], function() {
'use strict';

	return {
        getZones : [ 'corpLegalNoticeService', function(corpLegalNoticeService) {
            return corpLegalNoticeService.getUserDataMapping();
        }],
        getAdvocateInfo: ['corpLegalNoticeService',function(corpLegalNoticeService,$stateParams) {
            return corpLegalNoticeService.getAdvocateList().then(function(data){
                return data;
            });
        }]
       
      };
});