/** Story : Corporate Legal Notice.
 * Modified By - OFS
 * Represents a Package file for Corporate Legal Notice.
 * @version v1.0 Date: 21-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the corporate legal notice module file names with their paths.
     * Contains the corporate legal notice module required dependency configuration.
     */
    require.config({
        paths: {
            'corpLegalNotice': 'app/collections/corporateLegal/corpLegalNotice/corpLegalNotice',
            'corpLegalNoticeController': 'app/collections/corporateLegal/corpLegalNotice/controllers/corpLegalNoticeController',
            'corpLegalNoticeService' : 'app/collections/corporateLegal/corpLegalNotice/service/corpLegalNoticeService',
            'corpLegalNoticeResolver': 'app/collections/corporateLegal/corpLegalNotice/resolvers/corpLegalNoticeResolver',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'corpLegalNotice': ['angular', 'angular-ui-router'],
            'corpLegalNoticeController':['corpLegalNotice','corpLegalNoticeService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the PU SearchCases module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpLegalNoticeController', 'workplanController'], callback);
            });
        });
    };
});