define(['require','constants','corpLegalNotice','collectionServiceURLs','utility'],
  function(require,constants,corpLegalNotice,collectionServiceURLs,utility){
	var corpLegalNoticeService = function($q,restProxy,$rootScope,$http,dialogService,masterService,$upload){	
    var header = {
      'Content-Type' : 'application/json',
      'Authorization':getCookie('token'),
      'userID' : $rootScope.identity.userName
    };
    var serviceObj = this;
    this.locations = { 
      branchDetails : {}
    };

    this.getSearchDetails = function(queryObj) {
      collectionServiceURLs.corpLegalServices.GET_CORPLEGAL_NOTICE_SEARCH.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_CORPLEGAL_NOTICE_SEARCH, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };

    this.getHeaderInfo = function(queryObj) {
      collectionServiceURLs.corpLegalServices.GET_HEADER_DETAILS.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_HEADER_DETAILS, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    this.getCorpCaseAsideInfo = function(queryObj){
      collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };
    /**
    * Method to get drop down values for zone,region,area,branch
    */
    this.getUserDataMapping = function() {
      if ($rootScope.identity.zoneIDs.length > 0) {
        masterService.getAreas({
          ZoneID : $rootScope.identity.zoneIDs.toString()
        }, 'zone').then(function(userZones) {
          $rootScope.identity.userZones = userZones;
          serviceObj.locations.branchDetails.zones = userZones;
          serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
        });
      }
      if ($rootScope.identity.regionIDs.length > 0) {
        masterService.getAreas({
          regionID : $rootScope.identity.regionIDs.toString()
        }, 'region').then(function(userRegions) {
          $rootScope.identity.userRegions = userRegions;
          serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
          serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
        });
      }
      if ($rootScope.identity.areaIDs.length > 0) {
        masterService.getAreas({
          areaID : $rootScope.identity.areaIDs.toString()
        }, 'area').then(function(userAreas) {
          $rootScope.identity.userAreas = userAreas;
          serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
          serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
        });
      }
      if ($rootScope.identity.branchIDs.length > 0) {
        masterService.getBranches({
          branchID : $rootScope.identity.branchIDs.toString()
        }).then(function(userBranches) {
          $rootScope.identity.userBranches = userBranches;
          serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
        });
      }
      return serviceObj;
    };
    this.createCorpLegalNotice = function(queryObj){
      collectionServiceURLs.corpLegalServices.CREATE_LEGAL_NOTICE.queryParams = queryObj;
      return restProxy.save('POST',collectionServiceURLs.corpLegalServices.CREATE_LEGAL_NOTICE, queryObj).then(function(response) {
        if(response && response.data) {
          return response;
        } else {
          return [];
        }
      });
    };

    //to get the advocate list
    this.getAdvocateList = function(){
      return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_DETAILS).then(function(data) {
        var advocateList = data.data;
        return advocateList;
      });
    };
  };
  corpLegalNotice.service('corpLegalNoticeService',['$q','restProxy','$rootScope','$http','dialogService','masterService','$upload', corpLegalNoticeService]);
  return corpLegalNoticeService;
});