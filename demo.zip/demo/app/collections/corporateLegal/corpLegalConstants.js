define([ 'require', 'constants', 'utility' ], function(r, constants, utility) {
	'use strict';
	var Enumvalues = utility.Enumvalues;
	var ValueAndText = utility.ValueAndText;
	var constantsObj = {};
	constantsObj.legalConstants = {
		SEARCH_LIMIT : 4,
		LEGAL_VALUES : {
			CASE_TYPE_GENERAL : [
				{
					label : "Civil",
					value : "Civil",
					key : 'CIVIL',
					selected : false
				}, {
					label : "Arbitration",
					value : "Arbitration",
					key : 'ARBITRATION',
					selected : false
				}, {
					label : "Company",
					value : "Company",
					key : 'COMPANY',
					selected : false
				}, {
					label : "Consumer",
					value : "Consumer",
					key : 'CONSUMER',
					selected : false
				}, {
					label : "Contempt petition",
					value : "Contempt petition",
					key : 'CONTEMPT_PATITION',
					selected : false
				}, {
					label : "Criminal",
					value : "Criminal",
					key : 'CRIMINAL',
					selected : false
				}, {
					label : "First Appeal",
					value : "First Appeal",
					key : 'FIRST_APPeal',
					selected : false
				}, {
					label : "Insolvency",
					value : "Insolvency",
					key : 'INSOLVENCY',
					selected : false
				}, {
					label : "Labour",
					value : "Labour",
					key : 'LABOUR',
					selected : false
				}, {
					label : "Lok Adalath",
					value : "Lok Adalath",
					key : 'LOK_ADALATH',
					selected : false
				}, {
					label : "MACT",
					value : "MACT",
					key : 'MACT',
					selected : false
				}, {
					label : "WRIT",
					value : "WRIT",
					key : 'WRIT',
					selected : false
				}
			],
			LEGAL_CASE_MAPPING : [
				{
					caseDesc : 'Section 138',
					caseValue : 'SEC138_STAGES'
				}, {
					caseDesc : 'Section 9 Seizure',
					caseValue : 'SEC9_SEIZURE_STAGES'
				}, {
					caseDesc : 'Section 9 Attachment',
					caseValue : 'SEC9_ATTACHMENT_STAGES'
				}, {
					caseDesc : 'Section 9 Garnishee',
					caseValue : 'SEC9_GARNISHEE_STAGES'
				}, {
					caseDesc : 'Arbitration',
					caseValue : 'ARBITRATION_STAGES'
				}, {
					caseDesc : 'Execution Petition',
					caseValue : 'EXECUTION_PETITION_STAGES'
				}, {
					caseDesc : 'Execution Petition Sale',
					caseValue : 'EXECUTION_PETITION_SALE_STAGES'
				}, {
					caseDesc : 'ROP Court Proceedings',
					caseValue : 'ROP_COURT_PROCEEDINGS_STAGES'
				}, {
					caseDesc : 'ROP Revision/Appeal Cases',
					caseValue : 'ROP_REVISION_APPEAL_CASES_STAGES'
				}, {
					caseDesc : 'ROP Application for Sale',
					caseValue : 'ROP_APPLICATION_FOR_SALES_STAGES'
				}, {
					caseDesc : 'Criminal Origin Petition Cases',
					caseValue : 'CRIMINAL_ORIGIN_PETITION_CASES_STAGES'
				}, {
					caseDesc : 'Complaint through Court',
					caseValue : 'COMPLAINT_THROUGH_COURT'
				}, {
					caseDesc : 'Police Complaint',
					caseValue : 'POLICE_COMPLAINT_STAGES'
				}, {
					caseDesc : 'Writ Applications/High Court Matters',
					caseValue : 'OTHER_STAGES'
				}, {
					caseDesc : 'Caveat',
					caseValue : 'OTHER_STAGES'
				}, {
					caseDesc : 'Lok Adalat',
					caseValue : 'LOK_ADALAT_STAGES'
				}, {
					caseDesc : 'Conciliation',
					caseValue : 'LOK_ADALAT_STAGES'
				}, {
					caseDesc : 'Execution Petition for attachment of Movables',
					caseValue : 'EXECUTION_PETITION_MOVABLE_STAGES'
				}, {
					caseDesc : 'Execution Petition for attachment of Property',
					caseValue : 'EXECUTION_PETITION_PROPERTY_STAGES'
				}, {
					caseDesc : 'Execution Petition for seizure of vehicle',
					caseValue : 'EXECUTION_PETITION_STAGES'
				}, {
					caseDesc : 'Execution petition for arrest',
					caseValue : 'EXECUTION_PETITION_ARREST_STAGES'
				}, {
					caseDesc : 'Insolvency Petition',
					caseValue : 'EXECUTION_PETITION_STAGES'
				}, {
					caseDesc : 'Arbitration Set Aside (Sec. 34)',
					caseValue : 'EXECUTION_PETITION_STAGES'
				}, {
					caseDesc : 'Sec.17 Seizure',
					caseValue : 'SEC17_SEIZURE'
				}, {
					caseDesc : 'Sec.17 Sale',
					caseValue : 'SEC17_SALE'
				}, {
					caseDesc : 'Sec.17-Property Attachment',
					caseValue : 'SEC17_PROPERTY_ATTACHMENT'
				}, {
					caseDesc : 'ROP Revision',
					caseValue : 'ROP_REVISION'
				}, {
					caseDesc : 'ROP Appeal',
					caseValue : 'ROP_REVISION'
				}, {
					caseDesc : 'Sec.9 Redelivery',
					caseValue : 'SEC9_REDELIVERY'
				}, {
					caseDesc : 'Sec.138 Appeal',
					caseValue : 'SEC138_APPEAL'
				}, {
					caseDesc : 'Application For Sale',
					caseValue : 'APPLICATION_FOR_SALE'
				}, {
					caseDesc : 'Sec.156(3)',
					caseValue : 'Sec.156(3)'
				}, {
					caseDesc : 'Others',
					caseValue : 'OTHER_STAGES'
				}
			],
			LEGAL_CASE_MAPPING_HEHL : [
				{
				  caseDesc : 'Section 138',
					caseValue : 'SEC138_STAGES'
				}, {
					caseDesc : 'Section 9 Attachment',
					caseValue : 'SEC9_HEHL_STAGES'
				}, {
					caseDesc : 'Section 9 Bank Guarantee / Court Deposit',
					caseValue : 'HEHEL_SEC_9_BANK_COURT_DEPOSIT_STAGES'
				}, {
					caseDesc : 'Arbitration',
					caseValue : 'ARBITRATION_HEHL_STAGES'
				}, {
					caseDesc : 'Executive Proceedings',
					caseValue : 'EXECUTIVE_PROCEEDINGS_STAGES'
				}, {
					caseDesc : 'Land Acquisition Claims',
					caseValue : 'LAOP_COURT_PROCEEDINGS_STAGES'
				}, {
					caseDesc : 'Police Complaint',
					caseValue : 'POLICE_COMPLAINT_STAGES'
				}, {
					caseDesc : 'Criminal Origin Petition Cases',
					caseValue : 'CRIMINAL_ORIGIN_PETITION_CASES_STAGES'
				}, {
					caseDesc : 'Complaint through Court',
					caseValue : 'COMPLAINT_THROUGH_COURT'
				}, {
					caseDesc : 'Lok  Adalat Conciliation',
					caseValue : 'LOK_ADALAT_STAGES'
				}, {
					caseDesc : 'Others',
					caseValue : 'OTHER_STAGES'
				}
			],
			LEGAL_Q_SEARCH : [ 
				{
					type : "Agreement No",
					value : "agreementNo"
				}, {
					type : "Case ID",
					value : "caseID"
				} 
			],
			LEGAL_NTQ_SEARCH : [
				{
					type : "Notice ID",
					value : "noticeID",
					placeholder: "Enter Notice ID"
				},{
					type : "Query ID",
					value : "queryID",
					placeholder: "Enter Query ID"
				}
			],
			NATURE_OF_NOTICE: [
				{
					label : '138 Dispute',
					value : '138 Dispute',
					key : '138_DISPUTE',
					selected : false
				},{
					label : '3RD Party Accident Claims',
					value : '3RD Party Accident Claims',
					key : '3RD_PARTY_ACCIDENT_CLAIMS',
					selected : false
				},{
					label : 'Appeal',
					value : 'Appeal',
					key : 'APPEAL',
					selected : false
				},{
					label : 'Arbitration Dispute',
					value : 'Arbitration Dispute',
					key : 'ARBITRATION_DISPUTE',
					selected : false
				},{
					label : 'Buyer Dispute',
					value : 'Buyer Dispute',
					key : 'BUYER_DISPUTE',
					selected : false
				},{
					label : 'Collection Staff Harassment Dispute',
					value : 'Collection Staff Harassment Dispute',
					key : 'COLLECTION_STAFF_HRASSMENT_DISPUTE',
					selected : false
				},{
					label : 'Deposit',
					value : 'Deposit',
					key : 'DEPOSIT',
					selected : false
				},{
					label : 'Dispute between 3RD parties',
					value : 'Dispute between 3RD parties',
					key : 'DEPOSIT_BETWEEN_3RD_PARTIES',
					selected : false
				},{
					label : 'EMI Dispute',
					value : 'EMI Dispute',
					key : 'EMI_DISPUTE',
					selected : false
				},{
					label : 'Employee',
					value : 'Employee',
					key : 'EMPLOYEE',
					selected : false
				},{
					label : 'Infra',
					value : 'Infra',
					key : 'INFRA',
					selected : false
				},{
					label : 'Insolvency',
					value : 'Insolvency',
					key : 'INSOLVENCY',
					selected : false
				},{
					label : 'Insurance dispute',
					value : 'Insurance dispute',
					key : 'INSURANCE_DISPUTE',
					selected : false
				},{
					label : 'Investor',
					value : 'Investor',
					key : 'INVESTOR',
					selected : false
				},{
					label : 'NOC/Refund Dispute',
					value : 'NOC/Refund Dispute',
					key : 'NOC/REFUND_DISPUTE',
					selected : false
				},{
					label : 'ORC Dispute',
					value : 'ORC Dispute',
					key : 'ORC_DISPUTE',
					selected : false
				},{
					label : 'Other Disputes',
					value : 'Other Disputes',
					key : 'OTHERS_DISPUTE',
					selected : false
				},{
					label : 'Sales Related Dispute',
					value : 'Sales Related Dispute',
					key : 'SALES_RELATED_DISPUTE',
					selected : false
				},{
					label : 'Seizure Related Dispute',
					value : 'Seizure Related Dispute',
					key : 'SEIZURE_RELATED_DISPUTE',
					selected : false
				},{
					label : 'Shares',
					value : 'Shares',
					key : 'SHARES',
					selected : false
				},{
					label : 'SPDC Dispute',
					value : 'SPDC Dispute',
					key : 'SPDC_DISPUTE',
					selected : false
				},{
					label : 'NA',
					value : 'NA',
					key : 'NA',
					selected : false
				}
			],
			SECTIONS : [ 
				{
					label : "Accident Claims",
					value : "Accident Claims",
					key : 'ACCIDENT_CLAIMS',
					selected : false
				},
				{
					label : "Compensation",
					value : "Compensation",
					key : 'COMPENSATION',
					selected : false
				},
				{
					label : "Court Complaint",
					value : "Court Complaint",
					key : 'COURT_COMPLAINT',
					selected : false
				},
				{
					label : "Execution",
					value : "Execution",
					key : 'EXECUTION',
					selected : false
				},
				{
					label : "First Appeal",
					value : "First Appeal",
					key : 'FIRST_APPEAL',
					selected : false
				},
				{
					label : "Police Complaint",
					value : "Police Complaint",
					key : 'POLICE_COMPLAINT',
					selected : false
				},
				{
					label : "Quash Petition",
					value : "Quash Petition",
					key : 'QUASH_PETITION',
					selected : false
				},
				{
					label : "Second Appeal",
					value : "Second Appeal",
					key : 'SECOND_APPEAL',
					selected : false
				},
				{
					label : "WRIT",
					value : "WRIT",
					key : 'WRIT',
					selected : false
				},
				{
					label : "138",
					value : "138",
					key : '138',
					selected : false
				},
				{
					label : "Arbitration Suit",
					value : "Arbitration Suit",
					key : 'ARBITRATION_SUIT',
					selected : false
				},
				{
					label : "Complaint",
					value : "Complaint",
					key : 'COMPLAINT',
					selected : false
				},
				{
					label : "Contempt Petition",
					value : "Contempt Petition",
					key : 'CONTEMPT_PETITION',
					selected : false
				},
				{
					label : "Petition",
					value : "Petition",
					key : 'PETITION',
					selected : false
				},
				{
					label : "Injunction",
					value : "Injunction",
					key : 'INJUNCTION',
					selected : false
				},
			],
			CHILD_CASE_NATURE : [ 'Revision', 'Appeal' ]
		},
		STAGES : [
			{
				caseStage : 'Appearence',
				value : 'Appearence',
				caseStageID : '1',
				key : 'APPEARENCE',
				selected : false
			},{
				caseStage : 'Argument',
				value : 'Argument',
				caseStageID : '2',
				key : 'ARGUMENT',
				selected : false
			},{
				caseStage : "For Orders",
				value : "For Orders",
				caseStageID : '3',
				key : 'FOR_ORDERS',
				selected : false
			},{
				caseStage : "Order Copy Awaited",
				value : "Order Copy Awaited",
				caseStageID : '4',
				key : 'ORDER_COPY_AWAITED',
				selected : false
			},{
				caseStage : "Ordered",
				value : "Ordered",
				caseStageID : '5',
				key : 'ORDERED',
				selected : false
			},{
				caseStage : "Sec 8 Petition",
				value : "Sec 8 Petition",
				caseStageID : '6',
				key : 'SEC_18_PETITION',
				selected : false
			},{
				caseStage : "Trail",
				value : "Trail",
				caseStageID : '7',
				key : 'TRAIL',
				selected : false
			},{
				caseStage : "Reply",
				value : "Reply",
				caseStageID : '8',
				key : 'REPLY',
				selected : false
			},{
				caseStage : "Enquiry",
				value : "Enquiry",
				caseStageID : '9',
				key : 'ENQUIRY',
				selected : false
			},{
				caseStage : "Stayed",
				value : "Stayed",
				caseStageID : '10',
				key : 'STAYED',
				selected : false
			},{
				caseStage : "Admission",
				value : "Admission",
				caseStageID : '11',
				key : 'ADMISSION',
				selected : false
			},{
				caseStage : "Counter",
				value : "Counter",
				caseStageID : '12',
				key : 'COUNTER',
				selected : false
			}
		],
		BULK_EXCEL_TYPE : [ {
			id : '1',
			value : 'Existing Cases Data Updation'
		}],
		PAYMENT_MODE : ["Cheque", "DD", "FD"],
		BANK_TYPE : ["Nantionalized" , "Private"],
		CORPORATE_REPORT_TYPES : [
		    { name : "MIS ON NEW AND ORDERS CASES", value : "MIS"},
		    { name : "HIGH RISK CAU's", value : "HRC"},
		    { name : "CAU - APPEAL", value : "CAUA"},
		    { name : "CAU AS ON BUSINESS", value : "CAUB"},
		    { name : "LIVE Cases AS ON DATE ", value : "AODLC"},
		    { name : "LIVE CASES WITHOUT BY US", value : "WOBU"},
		    { name : "NEW AND CLOSED REPORTS", value : "NAC"},
		    { name : "BREAKUP FOR OVERALL CASES", value : "BFOC"},
		    { name : "CLIAM AMOUNT BREAKUP", value : "BREAKUPCASES"},],
		DATE_RANGE : ["With Date Range" , "Without Date Range"],
		ZONE_WISE : ["With Zone", "Without Zone"],
		ADDRESS_QUERY_RESPONSE_SEARCH: ['ALL','QUERY INITIATION','QUERY RESPONSE','CLOSED'],
		SUCCESS_MSG : {
			NOTICE_TRACK_ACTIVE_STATUS_UPDATE : "Notice Tracking Queue Status updated successfully",
			NOTICE_TRACK_UPDATE : "Notice Tracking Details updated successfully"
		},
		HIERARCHYSTAGE: {
			"COMP_SEC": 0,
			"CORP_LEGAL_SR_MANAGER": 1,
			"HO_CORP_LEGAL_SUPPORT_EXECUTIVE":2,
			"HO_CORP_LEGAL_JR_MANAGER": 2,
			"ZLM": 3,
			"RLM": 4,
			"ALM": 5
		},
		LEGAL_CASE_MAPPING : [
			{
				caseDesc : 'Accident Claims',
				caseValue : 'ACCIDENT_CLAIMS'
			},
			{
				caseDesc : 'Compensation',
				caseValue : 'COMPENSATION'
			},
			{
				caseDesc : 'Court Complaint',
				caseValue : 'COURT_COMPLAINT'
			},
			{
				caseDesc : 'Execution',
				caseValue : 'EXECUTION'
			},
			{
				caseDesc : 'First Appeal',
				caseValue : 'FIRST_APPEAL'
			},
			{
				caseDesc : 'Police Complaint',
				caseValue : 'POLICE_COMPLAINT'
			},
			{
				caseDesc : 'Quash Petition',
				caseValue : 'QUASH_PETITION'
			},
			{
				caseDesc : 'Second Appeal',
				caseValue : 'SECOND_APPEAL'
			},
			{
				caseDesc : 'WRIT',
				caseValue : 'WRIT'
			},
			{
				caseDesc : '138',
				caseValue : '138'
			},
			{
				caseDesc : 'Arbitration Suit',
				caseValue : 'ARBITRATION_SUIT'
			},
			{
				caseDesc : 'Complaint',
				caseValue : 'COMPLAINT'
			},
			{
				caseDesc : 'Contempt Petition',
				caseValue : 'CONTEMPT_PETITION'
			},
			{
				caseDesc : 'Petition',
				caseValue : 'PETITION'
			},
			{
				caseDesc : 'Injunction',
				caseValue : 'INJUNCTION'
			}
		],
		dashboardZones: ['SOUTH','NORTH','WEST','EAST','HENORTH','HESOUTH','HEHEADOFF','HEEAST','HEWEST','HLSOUTH','HLHEADOFF','HLWEST','HLNORTH','HLEAST','VFHEADOFF'],
		productTypeArray: ['ALL','VF','HE','HL','OTHERS'],
		productGroupOthers: ["CMF","CSEC","DCDL","HR","INFRA","PL","FD","GENERAL","TW"],
		valueWiseCategory: ["> 10 Lac","> 5 Lac < 10 Lac","> 3 Lac < 5 Lac","> 2 Lac < 3 Lac","> 1 Lac < 2 Lac","< 1 Lac" ],
		caseFiledByArray : [{ name :"Customer",value:"customer"},{ name :"Non Customer",value:"nonCustomer"},{name:"Guarantor", value:"guarantor"},{name:"Co-Applicant/Co-Borrower",value:"coApplicant"},{name:"Third Party",value:"thirdParty"}],
		businessTypeArray : ["CMF","CSEC","DCDL","HE","HR","INFRA","PL","VF","FD","GENERAL","TW","HL"],
		disputeNatureArray : ["138 Dispute","3RD Party Accident Claims","Appeal","Arbitration Dispute","Buyer Dispute","Collection Staff Harassment Dispute","Deposit","Dispute between 3RD parties","EMI Dispute","Employee","Infra","Insolvency","Insurance dispute","Investor","NOC/Refund Dispute","ORC Dispute","Other Disputes","Sales Related Dispute","Seizure Related Dispute","Shares","SPDC Dispute","NA"],
		caseTypeGeneralArray : ["Civil","Arbitration","Company","Consumer","Contempt Petition","Criminal","First Appeal","Insolvency","Labour","Lok Adalath","MACT","WRIT"],
		noticeServedOnArray : ["Branch","HO","By Us"],
		caseTypeSpecificArray : ["Accident Claims","Compensation","Court Complaint","Execution","First Appeal","Police Complaint","Quash Petition","Second Appeal","WRIT","138","Arbitration Suit","Complaint","Contempt Petition","Petition","Injunction"],
		statusOfCaseArray : ["Live", "Closed"],
		stageOfCaseArray : ["Appearence","Argument","For Orders","Order Copy Awaited","Ordered","Sec 8 Petition","Trail","Reply","Enquiry","Stayed","Admission","Counter"],
		injunctionTypeArray : ["Injunction not to seize the vehicle","Injunction not to sale","Injunction not to seize and sale order","Injunction not to harass the customer to be captured"],
		courtOrderArray : ["In favour of Customer","In favour of Company","Out of court settlement"],
		riskAssessmentArray : ["High","Low","Medium"],
		courtName : ["CHENNAI HC","Chennai HC","EQWEQW","ERWERWE","EWWER","HE COURT","HIGH COURT","HISAR COURT","MADURAI COURT","TERTER"],
		cauAppealArray : ["VF Appeal", "HE Appeal", "Other Appeal","CAU"],
		orderFavourCustomerArray : ["Appeal to filed against the order","Order to be complied with","Decision to be pending"],
		USER_BASED_REPORT : {
			BRANCH_REPORT : [ 'COLL_REPORT_BRANCH' ],
			AREA_REPORT : [ 'COLL_REPORT_AREA' ],
			REGION_REPORT : [ 'COLL_REPORT_REGION' ],
			ZONE_REPORT : [ 'COLL_REPORT_ZONE' ]
		},
		CORP_LEGAL_CUST_SEARCH_TYPE : [ 
			{
			 	type : 'Agreement Number',
			 	value : 'agreementNo',
			 	placeHolder : "Enter Agreement Number"
			}, {
			 	type : 'Vehicle Number',
			 	value : 'vehicleNo',
			 	placeHolder : 'Enter Vehicle Number'
			}, {
			 	type : 'CIF ID',
			 	value : 'cifId',
			 	placeHolder : 'Enter CIF ID'
			}
		],
		CORP_LEGAL_USER_TYPE : [
			{ name :"Customer", value:"customer" },
			{ name:"Guarantor", value:"guarantor" },
			{ name:"Co-Applicant/Co-Borrower", value:"coApplicant" },
			{ name:"Third Party", value:"thirdParty" }
		],
		DATA_UPDATION_CASES:[
			{
				'Case ID':"",
				'Notice Served On':"",
				'Business Type' : "",
				'Zone ID' : "",
				'Region ID ':"",
				'Branch ID' : "",
				'Agreement Nos' : "",
				'Customer Name' : "",
				'Case Filed Against' : "",
				'Case Type General' : "",
				'Case Specific Category' : "",
				'Case Filing Year' : "",
				'Case No TypeIndicator' : "",
				'Case No' : "",
				'Court Name' : "",
				'Claim Amount' : "",
				'Relief Text' : "",
				'Interim order passed' : "",
				'Risk Assesement' : "",
			    'First Hearing Date (DD-MM-YYYY)' : "",
			    'Last Hearing Date (DD-MM-YYYY)' : "",
			    'Next Hearing Date (DD-MM-YYYY)' : "",
			    'Status of Case' : "",
			    'Stage of Case' : "",
			    'REMARKS' : "",
			    'Advocate' : "",
			    'Approval Fee' : "",
			    'Is Paper Available' : "",
			    'Miscellaneous Information' : "",
			    'Arbitration' : "",'Sec138' : "",
				'Dispute Nature' : "",
				'CAU/Appeal' : "",
				'Date of Entry (DD-MM-YYYY)' : "",
				'Assigned To' : "", 
				'Reply Filed Status' : "",
			    'Allotment Letter / Vakalath Filed Status' : ""
			}
		],
		DATA_MIGRATION:[
			{
				'Notice Served On':"",
				'Business Type' : "",
				'Zone ID' : "",
				'Region ID ':"",
				'Branch ID' : "", 
			    'Agreement Nos' : "",
			    'Customer Name' : "",
			    'Case Filed Against' : "",
			    'Case Type General' : "",
			    'Case Specific Category' : "",
			    'Case Filing Year' : "",
			    'Case No TypeIndicator' : "",
			    'Case No' : "",
			    'Court Name' : "",
			    'Claim Amount' : "",
			    'Relief Text' : "",
			    'Interim order passed' : "",
			    'Risk Assesement' : "",
			    'First Hearing Date (DD-MM-YYYY)' : "",
			    'Last Hearing Date (DD-MM-YYYY)' : "",
			    'Next Hearing Date (DD-MM-YYYY)' : "",
			    'Status of Case' : "",
			    'Stage of Case' : "",
			    'REMARKS' : "",
			    'Advocate' : "",
			    'Approval Fee' : "",
			    'Is Paper Available' : "",
			    'Miscellaneous Information' : "",
			    'Arbitration' : "",
			    'Sec138' : "",
			    'Dispute Nature' : "",
			    'CAU/Appeal' : "",
			    'Date of Entry (DD-MM-YYYY)' : "",
			    'Assigned To' : "",
			    'Reply Filed Status' : "",
			    'Allotment Letter / Vakalath Filed Status' : ""
			}
		],
		BULK_TYPE:[
		    {"id" : 0, "type" : "Corporate Legal Cases Migration"},
		    {"id" : 1, "type" : "Corporate Legal Cases Data Updation"}
		],
		MSG_TO_SELECT_UPLOAD_EXCEL: "Please select the type of excel to upload",
		CORP_LEGAL_ADDRESSQUERY_SEARCH_TYPE : [
			{
			 	type : 'Agreement Number',
			 	value:'agreementNo',
			 	placeHolder : "Enter Agreement Number"
			}, {
			 	type : 'Notice Query ID',
			 	value : 'queryID',
			 	placeHolder : 'Enter Notice Query ID'
			},{
			 	type : 'Corporate Legal Notice ID',
			 	value : 'noticeID',
			 	placeHolder : 'Enter Corporate Legal Notice ID'
			}, {
			 	type : 'Corporate Legal Case ID',
			 	value : 'caseID',
			 	placeHolder : 'Enter Legal Case ID'
			}
		],
		RAISEQUERY_ROLADDRES_SEARCH_TYPE : [
			{
			 	type : 'HO-Corp Legal',
			  	value:'ho_CorpLegal',
			}, {
			  	type : 'ALM',
			  	value : 'alm',
			}, {
			  	type : 'RLM',
			  	value : 'rlm',
			}, {
			  	type : 'BRM',
			  	value: 'brm'
			}
		],
		CORP_LEGAL_USER_TYPE : [
			{ name :"Customer", value:"customer" },
			{ name:"Guarantor", value:"guarantor" },
			{ name:"Co-Applicant/Co-Borrower", value:"coApplicant" },
			{ name:"Third Party", value:"thirdParty" }
		],
		Corp_Legal_Notice_Search_Type : [
			{
				type : 'Agreement Number',
		 	 	value:'agreementNo',
		 	 	placeHolder : "Enter Agreement Number"
		 	 },{
		 	 	type : 'Vehicle Number',
		 	 	value : 'vehicleNo',
		 	 	placeHolder : 'Enter Vehicle Number'
	 	 	},{
	 	 		type : 'Case ID',
		 	 	value : 'caseID',
		 	 	placeHolder : 'Enter Case ID'
		 	}
	 	],
	 	CORP_LEGAL_RAISEQUERY_SEARCH_TYPE : [
		 	{
			 	type : 'Agreement Number',
			 	value:'agreementNo',
			 	placeHolder : "Enter Agreement Number"
			}, {
			 	type : 'Corporate Legal Notice ID',
			 	value : 'noticeID',
			 	placeHolder : 'Enter Corporate Legal Notice ID '
			}, {
			 	type : 'Corporate Legal Case ID',
			 	value : 'caseID',
			 	placeHolder : 'Enter Legal Case ID'
			}
		],
		RAISE_QUERY_ROLES: [
            {
            	name: 'COMP_SEC',
            	isSelected: false,
            	radioClassName:'firstRole'
            },
            {
            	name: 'CORP_LEGAL_SR_MANAGER',
            	isSelected: false,
            	radioClassName:'secondRole'
            },
            {
            	name: 'HO_CORP_LEGAL_JR_MANAGER',
            	isSelected: false,
            	radioClassName:'thirdRole'
            },
            {
            	name: 'HO_CORP_LEGAL_SUPPORT_EXECUTIVE',
            	isSelected: false,
            	radioClassName:'fourthRole'
            },
            {
            	name: 'ZLM',
            	isSelected: false,
            	radioClassName:'fifthRole'
            },
            {
            	name: 'RLM',
            	isSelected: false,
            	radioClassName:'sixthRole'
            },
            {
            	name: 'ALM',
            	isSelected: false,
            	radioClassName:'seventhRole'
            }
        ]
	};
	return constantsObj.legalConstants;
});