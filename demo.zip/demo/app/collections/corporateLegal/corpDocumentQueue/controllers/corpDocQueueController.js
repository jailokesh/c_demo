define(['require','corpDocumentQueue','constants','collectionConstants','utility','legalConstants'],
	function(r, corpDocumentQueue, constants, collectionConstants, utility, legalConstants ) {
		'use strict';
	var corpDocQueueController = function($scope,$stateParams,$state,dialogService,$rootScope,lazyModuleLoader,collectionFactory,$globalScope) {
        console.log("Inside document controllers................")

        $scope.productTypes = $rootScope.identity.productDetails;
		$scope.productType = $rootScope.productType;
		$scope.data = {};
		var params = {},dateRange,dateObj;
		$scope.searchType = angular.copy(legalConstants.LEGAL_VALUES.LEGAL_Q_SEARCH);
		
		$scope.filterPopup = {
			onOpen : function(contentData) {
				contentData.options = angular.copy($scope.data.mainMenu);
				contentData.isAll = $scope.data.isAll;
			},
			isAllSelected : function(options) {
				collectionFactory.isAllSelected(options, $scope.filterPopup.isAll);
			},
			checkAll : function(options) {
				$scope.filterPopup.isAll = collectionFactory.filterCheckAll(options);
			},
			filterQueue : function(options, isDone) {
				$scope.filterPopup.reqObj = {};
				$scope.data.isAll = $scope.filterPopup.isAll;
				$scope.data.mainMenu = angular.copy(options);
				if (typeof $scope.filterPopup.close === 'function') {
					$scope.filterPopup.close();
				}
				if (isDone) {
					$scope.filterPopup.reqObj = collectionFactory.filterQueue(options, $scope.filterPopup.reqObj, $scope.filterPopup.isAll, !isDone);
					if (!$scope.filterPopup.reqObj) {
						return;
					}
				}
				$scope.filterPopup.reqObj.filterSec = $scope.filterPopup.reqObj.legalSections ? $scope.filterPopup.reqObj.legalSections.join() : '';
				$scope.filterPopup.reqObj.filterStatus = $scope.filterPopup.reqObj.workStatus ? $scope.filterPopup.reqObj.workStatus.join() : '';
				$scope.searchBy(1);
			},
			resetAndClose : function() {
				$scope.filterPopup.close();
			}
		};
		$scope.filterPopup.reqObj = {
			legalSections : '',
			workStatus : ''
		};
		
		$scope.searchBy = function(currentPage) {
			params = {};
			$scope.data.pageNo = params.offset = currentPage;
			params.productGroup = $rootScope.productType;
			if ($scope.data.dateRange) {
				params.stDate = $scope.data.dateRange.split(" / ")[0];
				params.endDate = $scope.data.dateRange.split(" / ")[1];
			}
			if ($scope.data.currentSearch.value) {
				params[$scope.data.currentSearch.value] = $scope.data.searchParams;
			}
			if ($scope.filterPopup.reqObj) {
				params.workStatus = $scope.filterPopup.reqObj.filterStatus;
				params.legalSections = $scope.filterPopup.reqObj.filterSec;
			}
			corporateDocumentsQueueService.getFilterLegalCases(params).then(function(response) {
				$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
				if (response.data) {
					$scope.data.legalCases = response.data.length ? response.data : [];
					$scope.data.offset = response.offset;
					$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
				} else {
					$scope.data.legalCases = [];
				}
			});
		};
		var uniqueFilterOptions = function(c){
			var uniqueValues =_.uniq(_.pluck(c.reverse(),'value'));
			uniqueValues.reverse();
			var uniqueObjects = _.filter(c,function(item){
				if(uniqueValues.indexOf(item.value)>-1){
			uniqueValues.splice(uniqueValues.indexOf(item.value),1);
			return true;
			}return false;}) ;
			$scope.legalSections = uniqueObjects.reverse();
		};
		var init = function() {
			var today = new Date();
			var yesterday = new Date(new Date().setDate(today.getDate() - 1));
			if (!$globalScope.isClickedViaMenu) {
				//$scope.data = getLegalCases.data;
				$scope.filterPopup.reqObj = {};
				$scope.filterPopup.reqObj.filterStatus = _.pluck(_.where($scope.data.mainMenu[1].subMenu,{selected : true}),'value');
				$scope.filterPopup.reqObj.filterSec = _.pluck(_.where($scope.data.mainMenu[0].subMenu,{selected : true}),'value');
				$scope.searchBy($scope.data.pageNo); // Calling this service to refresh the status and work flow in the queue.
			} else {
				$scope.data.isAll = false;
				$scope.data.limit = 5;
				$scope.data.offset = 1;
				if ($rootScope.productType === 'VF') {
					$scope.legalSections = _.union(legalConstants.LEGAL_VALUES.SECTIONS,legalConstants.LEGAL_VALUES.CHILD_SECTIONS);
				} else {
					$scope.legalSections = _.union(legalConstants.LEGAL_VALUES.SECTIONS_HEHL,legalConstants.LEGAL_VALUES.CHILD_SECTIONS_HEHL);
				}
				uniqueFilterOptions($scope.legalSections);
				$scope.data.currentSearch = angular.copy(legalConstants.LEGAL_VALUES.LEGAL_STOCK_CURRENT_SEARCH);
				$scope.flagStatus = legalConstants.CASE_STATUS_DOCSQ;
				$scope.data.mainMenu = [ {
					label : "Legal Sections",
					value : "legalSections",
					selected : false,
					subMenu : $scope.legalSections
				}, {
					label : "Status",
					value : "workStatus",
					selected : false,
					subMenu : $scope.flagStatus
				} ];
				//$scope.data.legalCases = getLegalCases.data || [];
				//$scope.data.totalRecord = (getLegalCases.meta && getLegalCases.meta.count) ? parseInt(getLegalCases.meta.count) : 0;
				$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
			}
			dateRange = {
				'today' : [ today, today ],
				'yesterday' : [ yesterday, yesterday ],
				'last7days' : [ new Date(new Date().setDate(today.getDate() - 6)), today ],
				'last30days' : [ new Date(new Date().setDate(today.getDate() - 29)), today ],
				'thisMonth' : [ new Date(new Date().setDate(1)), today ]
			};
			$scope.data.workStatus = legalConstants.LEGAL_WORK_STATUS;
		};
		init();
		/**
		 * Method to display receipts/acknowledgements for the selected date
		 * range
		 */
		$scope.datePopupContent = {
			onOpen : function(contentData) {
				contentData.applyDateRange = function() {
					dateObj = collectionFactory.applyDateRange(contentData);
					$scope.data.dateRange = dateObj.fromDate + ' / ' + dateObj.toDate;
					$scope.searchBy(1);
				};
				contentData.setDateRange = function(key) {
					contentData.fromDate = dateRange[key][0];
					contentData.toDate = dateRange[key][1];
				};
				contentData.init = function() {
					if ($scope.data.dateRange) {
						dateObj = collectionFactory.initDate($scope.data.dateRange);
						contentData.fromDate = dateObj.fromDate;
						contentData.toDate = dateObj.toDate;
					}
				};
				contentData.clear = function(){
					$scope.data.dateRange = '';
					$scope.searchBy(1);
				};
				contentData.init();
			},
			close : function() {
				$scope.datePopupContent.close();
			}
		};
		
		$scope.paginationHandler = function(currentPage) {
			$scope.searchBy(currentPage);
		};
		$scope.legalSearch = function(value) {
			$scope.data.searchParams = '';
			$scope.data.placeholder = value ? _.findWhere($scope.searchType, {value : value}).type : '';
		};
		$scope.searchCorporateCaseAgreements = function(type,val){
			if (!val) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (val.length < legalConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + legalConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
			$scope.searchBy(1);
		};
		$scope.moreHandler = function(legalData) {
			corporateDocumentsQueueService.setPageDetails({data : $scope.data});
			if (legalData.workStatus === 'CORPORATECASEFILED') {
				corporateDocumentsQueueService.setAgreementsList(legalData.workflow[0].agreementNos);
				corporateDocumentsQueueService.setLegalCaseInfo(legalData);
				lazyModuleLoader.loadState('collections.corporateDocument.legalCase', {
					caseID : legalData.caseID,
					agreementNo : legalData.agreementNo
				});
			} else {
				corporateDocumentsQueueService.setAgreementsList(legalData.workflow[0].agreementNos);
				corporateDocumentsQueueService.setLegalCaseInfo(legalData);
				lazyModuleLoader.loadState('collections.corporateDocument.legalCase', {
					caseID : legalData.caseID,
					agreementNo : legalData.agreementNo
				});
			}
		};
		
		/** CIF Id click navigates to Case details summary */
		$scope.navigateToCaseDetails = function(data) {
			var agreementNumber = data.agreementNo;
			$rootScope.agreementList = data.workflow[0].agreementNos;
			corporateDocumentsQueueService.setPageDetails({data : $scope.data});
			lazyModuleLoader.loadState('collections.caseDetail', {
				agreementNo : agreementNumber
			});
		};
		/** Change product type */
		$scope.setProduct = function() {
			$scope.searchBy(1);
		};

      };

corpDocumentQueue.controller('corpDocQueueController', ['$scope','$stateParams', '$state', 'dialogService','$rootScope','lazyModuleLoader','collectionFactory','$globalScope',corpDocQueueController]);
return corpDocQueueController;
});