/** Story : Document Queue for HO Corporate Legal user.
 * Created By - OFS
 * Represents Corporate legal Document.
 * @version v1.0 Date:  21-02-2018
 */
define(['require','collectionsApp'],
   function(require,collectionsApp) {
   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpDocumentQueue/'; 
       var cdQ = {
				name : 'collections.corpDocumentQueue',
				url : '/documentQueue',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'documentQueue.html',
						controller : 'corpDocQueueController',
					}
				},data:{'headerText':'Corporate Case Document Queue'}
			};
       
       var docConfig = function($stateProvider,$urlRouterProvider) {
			$stateProvider.state(cdQ);
       };
		
       return angular.module('corpDocumentQueue', [ 'ui.router','collections' ]).config([ '$stateProvider', '$urlRouterProvider',docConfig ]);
  });