/** Story : Document Queue for Corporate Legal user.
 * Created By - OFS
 * Represents a package file for corporate legal Document Queue.
 * @version v1.0 Date:  21-02-2018
 */
define([], function() {
    'use strict';
    /**
     * Contains the Corporate Document Queue module file names with their paths.
     * Contains the Corporate Document Queue module required dependency configuration.
     */
    require.config({
        paths: {
            'corpDocumentQueue': 'app/collections/corporateLegal/corpDocumentQueue/documentQueue',
            'corpDocQueueController': 'app/collections/corporateLegal/corpDocumentQueue/controllers/corpDocQueueController',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'corpDocumentQueue': ['angular', 'angular-ui-router'],
            'corpDocQueueController':['corpDocumentQueue']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the Document Queue module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpDocQueueController', 'workplanController'], callback);
            });
        });
    };
});