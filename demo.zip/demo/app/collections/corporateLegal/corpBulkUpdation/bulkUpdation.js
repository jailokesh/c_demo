/** Story : Bulk Updation for Corporate Legal user.
 * Created By - OFS
 * Represents Bulk Updation.
 * @version v1.0 Date:  21-02-2018
 */
define(['require','collectionsApp'],
   function(require,collectionsApp) {
   'use strict';
       var baseViewUrl = 'app/collections/corporateLegal/corpBulkUpdation/'; 
       var cau = {
				name : 'collections.corpBulkUpdation',
				url : '/DataMigration',

				views : {
					'mainContent' : {
						templateUrl : baseViewUrl + 'bulkUpdation.html',
						controller : 'corpBulkUpdationController',
					}
				},data:{'headerText':'Corporate Legal - Bulk Updation'}
			};
       
       var dataConfig = function($stateProvider,$urlRouterProvider) {
			$stateProvider.state(cau);
       };
		
       return angular.module('corpDataMigration', [ 'ui.router','collections' ]).config([ '$stateProvider', '$urlRouterProvider',dataConfig ]);
  });