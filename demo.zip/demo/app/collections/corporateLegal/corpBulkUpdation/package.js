/** Story : Bulk Updation for Corporate Legal user.
 * Created By - OFS
 * Represents package file for Bulk Updation.
 * @version v1.0 Date:  21-02-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the Bulk updation module file names with their paths.
     * Contains the Bulk updation module required dependency configuration.
     */
    require.config({
        paths: {
            'corpDataMigration': 'app/collections/corporateLegal/corpBulkUpdation/bulkUpdation',
            'corpBulkUpdationController': 'app/collections/corporateLegal/corpBulkUpdation/controllers/corpBulkUpdationController',
            'corpBulkUpdationService' : 'app/collections/corporateLegal/corpBulkUpdation/services/corpBulkUpdationService',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'corpDataMigration': ['angular', 'angular-ui-router'],
            'corpBulkUpdationController':['corpDataMigration','corpBulkUpdationService']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the bulk updation module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpBulkUpdationController', 'workplanController'], callback);
            });
        });
    };
});