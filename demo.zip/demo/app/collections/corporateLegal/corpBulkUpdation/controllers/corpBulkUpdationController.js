define(['require','corpDataMigration','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpDataMigration, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants) {
		'use strict';
		var corpBulkUpdationController = function($scope,$stateParams,$state, $modal, messageBus,dialogService,$rootScope,masterService,corpBulkUpdationService) {
      var initialize = function(){
        $scope.showUploadSummary =false;
        $scope.showUpload = true;
        $scope.uploadShow = false;
        $scope.uploadStatus = {};
        document.getElementById('userUpload').value = '';
      };
      $scope.bulkType = corpLegalConstants.BULK_TYPE;
      initialize();
      // method for checking file type on upload file selection       
      var file,fileContainer;
      $scope.onFileSelect = function($files) {
       	file=undefined;
       	if ($files && $files.length > 0) { 
       		var extTemp = $files[0].name.split('.');
       		var ext = extTemp[extTemp.length - 1];
       		if (ext.indexOf('csv') === 0) {
       			file = $files[0];
       			fileContainer = $files;
       			$scope.filename = file.name;
       			$scope.fileNotValid = false;
       			$scope.uploadShow = true;
       		} else {
       			dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.UPLOAD_CSV_CHECK); 
       			$scope.filename = '';
       			$scope.uploadShow = false;
       		}
       	}
      };
      //method to upload excel file
      $scope.upload = function(type){
      	if(type == null){
      		dialogService.showAlert("Warning", constants.ERROR_HEADER.error, corpLegalConstants.MSG_TO_SELECT_UPLOAD_EXCEL);
          $scope.uploadShow = true;
      	}else{
            var updateStatus;
            if(type === "Corporate Legal Cases Migration"){
              updateStatus= "";
            }else {
               updateStatus= "UPDATE_STAGE";
            }
            corpBulkUpdationService.excelUpload(file,$rootScope.identity.userName,updateStatus).then(function(data){
               if(!data.data.error) {
                $scope.uploadStatus = data.data;
                $scope.uploadStatus.uploadStatus = "Uploaded Successfully"
                $scope.showUploadSummary =true;
                $scope.showUpload = false;
                $scope.uploadShow = false;
                document.getElementById('userUpload').value = '';
               } else {
                 dialogService.showAlert("Error", constants.ERROR_HEADER.error, data.data.error);
               }
            });     
        }
      }
      //method to navigate upload screen from summary screen
      $scope.backToUpload = function(){
         $scope.filename = '';
         initialize();
      };
      /** show the errors in the upload by downloading the file */
      $scope.errorDownload = function() {
        utility.downloadJSONToCSV($scope.uploadStatus.errorReport, "CorporateLegal-BulkUpdationErrorReport");
      };
      //method to download sample template for migration
      $scope.downloadMigrationTemplate = function() {
        corpBulkUpdationService.downloadJSONToCSV(corpLegalConstants.DATA_MIGRATION, "SampleMigrationTemplate");
      };
      //method to download sample template for data updation
      $scope.downloadTemplate = function() {
        corpBulkUpdationService.downloadJSONToCSV(corpLegalConstants.DATA_UPDATION_CASES, "SampleDataUpdationTemplate");
      };
    };
    corpDataMigration.controller('corpBulkUpdationController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService' , 'corpBulkUpdationService',corpBulkUpdationController]);
    return corpBulkUpdationController;
});