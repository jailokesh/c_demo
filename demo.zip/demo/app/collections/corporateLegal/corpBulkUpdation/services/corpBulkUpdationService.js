/** Story Id : Data Migration .
 * Modified By - OFS
 * Represents a Upload Service for HO Corporate Legal user.
 * @version v1.0 Date:  23-02-2018
 */
define(['require','constants','corpDataMigration','collectionServiceURLs'],function(require,constants,corpDataMigration,collectionServiceURLs){
	var corpBulkUpdationService = function($q,restProxy,$rootScope,$http,dialogService, $upload){	
    this.excelUpload = function(file, userID, updateDataType){
      return $upload.upload({
        url: '/collectionsapi/corpLegalCaseMigration',
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
          'userId': userID,
          'Authorization':getCookie('token')
        },
        //withCredentials: true,
        data: {
          collectionType : {
            type : 'LegalCase',
            updateType : updateDataType
          }
        },
        file: file,
        fileFormDataName: 'CorpCaseMigrationData'
      }).progress(function() {}).success(function(data, status, headers, config) {
        if (status === 200) {   
          return data;
        } else {
          console.log("error")
        }
      });  
    }
    this.downloadJSONToCSV = function(JSONData,ReportTitle) {

      var arrData = (typeof(JSONData) != 'object') ? JSON.parse(JSONData) : JSONData;
      var csv = '';
      var row = '';
      for ( var index in arrData[0]) {
        row += index + ',';
      } 
      row = row.slice(0,-1);
      csv += row + '\r\n';

      for (var i = 0; i<arrData.length; i++) {
        row = '';
        for( var index in arrData[i]) {
          row += '"'+ arrData[i][index] + '",';
        }
        row.slice(0, row.length -1);
        csv += row + '\r\n';
      } 
      if(csv == '') {
        //console.log("Invalid Data");
        return;
      } else {
        var fileName = "CFE_ID Report";
        fileName += ReportTitle.replace(/ /g,"_");  
        var uri = 'data:text/csv;charset=utf-8,' + escape(csv);
        var link = document.createElement("a");
        link.href = uri;
        link.style = "visibility:hidden";
        link.download = fileName + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }        
    }
  };
  corpDataMigration.service('corpBulkUpdationService',['$q','restProxy','$rootScope','$http','dialogService','$upload', corpBulkUpdationService]);
  return corpBulkUpdationService;
});