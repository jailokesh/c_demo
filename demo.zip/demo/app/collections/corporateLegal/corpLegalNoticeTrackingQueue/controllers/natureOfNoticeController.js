/** Story Id : Corporate Legal Notice Tracking Queue
 * Created By - OFS
 * Represents a controller for nature of notice in corporate legal notice tracking queue.
 * @version v1.0 Date:  0-05-2018
 */
define(['require','corpLegalNoticeTrackingQueue','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpLegalNoticeTrackingQueue, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants ) {
		'use strict';
		var natureOfNoticeController = function($scope,$stateParams,$state,$modal,messageBus,dialogService,$rootScope,masterService,$globalScope,lazyModuleLoader,corpLegalNoticeTrackingService,getAdvocateList,getZones) {
			$scope.noticeDetails = {};
			$scope.noticeDetails = corpLegalNoticeTrackingService.getLegalDetails();
			$scope.noticeDetails.productType = $stateParams.productType;
			$scope.stages = {};
			var obj = {};
			$scope.advocateList = getAdvocateList.advocates;
			var queryObj = function(key,value){
				switch(key){
					case "agreementNo": obj = {"agreementNo":value};
					break;
					case "vehicleNo" : obj = {"vehicleNo":value};
					break;
					case "caseID" : obj = {"caseID":value};
					break;
				}
			};
			var getCaseDetails = function(){
		        for(var  i = 0; i < $scope.agreementInfo.caseDetails.length; i++){
		            if($scope.agreementInfo.caseDetails[i].isCaseAgainstChola){
		              $scope.cauInfo.push($scope.agreementInfo.caseDetails[i]);
		            }else{
		               $scope.cfuInfo.push($scope.agreementInfo.caseDetails[i]);
		            }
		        }
		        for (var i = 0; i < $scope.agreementInfo.noticeDetails.length; i++) {
		        	$scope.noticeInfo.push($scope.agreementInfo.noticeDetails[i]);
		        };
	        };

			var params = {};
			params.productType = $stateParams.productType;
			params.agreementNo = $stateParams.agreementNo;
			params.noticeID = $stateParams.noticeID;
			corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQVersion(params).then(function(response) {
				$scope.stages.stageVersions = response.data;
				$scope.stages.natureStages = $scope.stages.stageVersions.res[0].noticeStages;
				if($scope.stages.natureStages[$scope.stages.natureStages.length-1].advocateID){
				$scope.noticeDetails.advocateName = _.findWhere($scope.advocateList, {AdvocateID :$scope.stages.natureStages[$scope.stages.natureStages.length-1].advocateID}).AdvocateName;
				}
				$scope.stages.natureStages.version = $scope.stages.stageVersions.res[0].noticeStages[0].stageID;
				if($stateParams.agreementNo) {
					queryObj("agreementNo",$stateParams.agreementNo);
					corpLegalNoticeTrackingService.getCorpCaseAsideInfo(obj).then(function(data){
						$scope.agreementInfo = data;
						if($scope.agreementInfo.AsOn !="No Record") {
							$scope.agreementInfo.address =  $scope.agreementInfo.AsOn? $scope.agreementInfo.AsOn.address[0] : "";
						}
						$scope.availability = $scope.agreementInfo.availablityDetails;
						$scope.cauInfo = [];
                        $scope.cfuInfo = [];
                        $scope.noticeInfo = [];
						getCaseDetails();
					});
				}
			});
			/**
			 * Method is to get Advocate List with AdvocateName and AdvocateID
			 */
			$scope.onAdvocateChange = function(item) {
				var advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName;
				return advocateName;
			}
			/** selected version stage populates its history */
			$scope.showVersionStage = function(stageID) {
				var loginHierarchyID = $rootScope.identity.primaryHierarchyID;
				var stageVersions = angular.copy($scope.stages.stageVersions);
				var selectedIndex = _.findIndex($scope.stages.natureStages, {stageID : stageID});
				var selectedVersionStage = $scope.stages.natureStages[selectedIndex];
		    	var params = {
					'createdBy': $scope.stages.stageVersions.res[0].createdBy
		    	}
		    	corpLegalNoticeTrackingService.getVersionUserEdit(params).then(function(response) {
		    		$scope.createdByHerID = response;
		    		$scope.isEditHierarchyID = false;
	            	if(corpLegalConstants.HIERARCHYSTAGE[$scope.createdByHerID[0].primaryHierarchyID] >= corpLegalConstants.HIERARCHYSTAGE[loginHierarchyID]){
	            		$scope.isEditHierarchyID = true;
	            	}
	            	else{
	            		$scope.isEditHierarchyID = false;
	            	}
					$modal.open({
						templateUrl : 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/partials/natureVersionHistoryPopup.html',
						controller : 'natureVersionHistoryController',
						size : 'lg',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return {
									version : selectedVersionStage,
									stageVersions : stageVersions,
									isLastElem : (selectedIndex === $scope.stages.stageVersions.res[0].noticeStages.length-1 && $scope.noticeDetails.isNoticeActive === "ACTIVE" && $scope.isEditHierarchyID),
									getAdvocateInfo : getAdvocateList,
									getZones : getZones
								};
							}
						}
					});
		    	});
			};
			/**
			 * Method is to update isNoticeActive state
			 */
			$scope.onUpdateNoticeStatus = function(activeStatus){
            	var params = {
            		noticeID:$scope.stages.stageVersions.res[0].noticeID
            	};
            	var queryObj = {
            		"minorVersion": $scope.stages.stageVersions.res[0].minorVersion,
                    "majorVersion": $scope.stages.stageVersions.res[0].majorVersion,
                    "isNoticeActive": activeStatus
            	};
            	corpLegalNoticeTrackingService.updateNoticeCase(params,queryObj).then(function(response) {
				    if (response.status === collectionConstants.SUCCESS) {
					    dialogService.showAlert(collectionConstants.ALERT, collectionConstants.SUCCESS, corpLegalConstants.SUCCESS_MSG.NOTICE_TRACK_ACTIVE_STATUS_UPDATE);
				    }
			    });
			    $scope.noticeDetails.isNoticeActive = activeStatus;
            }
            $scope.submitCase = function(activeStatus){
            	$scope.onUpdateNoticeStatus(activeStatus);
            }
        };

	corpLegalNoticeTrackingQueue.controller('natureOfNoticeController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader','$globalScope','corpLegalNoticeTrackingService','getAdvocateList','getZones',natureOfNoticeController]);
	return corpLegalNoticeTrackingQueue;
});