/** Story Id : Corporate Legal Notice Tracking Queue
 * Created By - OFS
 * Represents a controller for nature of notice version in corporate legal notice tracking queue.
 * @version v1.0 Date:  15-05-2018
 */
define(['require','corpLegalNoticeTrackingQueue','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpLegalNoticeTrackingQueue, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants ) {
		'use strict';
		var natureVersionHistoryController = function($scope,$stateParams,$state,data,$timeout,$modal,$modalInstance,messageBus,dialogService,$rootScope,masterService,lazyModuleLoader,corpLegalNoticeTrackingService, $globalScope) {
			$scope.versionHistory = {};
			$scope.versionHistory.stages = data.version;
			$scope.versionHistory.stageVersions = data.stageVersions.res[0];
			var noticeStagesArr = data.stageVersions.res[0].noticeStages;
			if (noticeStagesArr.length > 0) {
				var noticeAgainstCholaFileOut = [];
				noticeStagesArr.forEach(function(i, idx, noticeStage){
				    if (idx === noticeStage.length - 1){ 
				        $scope.versionHistory.noticeAgainstChola = i.noticeAgainstCholaFileRef[0];
				        $scope.versionHistory.intermReplyCopy = i.interimReply[0].interimReplyCopyFileRef[0];
				        $scope.versionHistory.replyCopy = i.reply[0].replyCopyFileRef[0];
				    }
				});
			}

			$scope.versionHistory.stageVersions.queryID = data.stageVersions.queryID;
			$scope.versionHistory.stageVersions.cifID = data.stageVersions.cifID;
			$scope.versionHistory.stages.isEdit = false;
			$scope.isLastElem = data.isLastElem;
			$scope.advocateList = data.getAdvocateInfo.advocates; 
			$scope.natureArray= corpLegalConstants.disputeNatureArray;
			$scope.dropDownValues = data.getZones.locations;
			$scope.isEditable = false;
			$scope.corpLegalData = {};
			var categoryList = _.findWhere($globalScope.imageCategories, {subCategory : "document images"});
            $scope.categoryDetails = categoryList ? categoryList : {};

            var postStageVersion, tempVersion = "";
            $scope.versionHistory.stages.advocateName = "";
            if($scope.versionHistory.stages.advocateID){
				$scope.versionHistory.stages.advocateName = _.findWhere($scope.advocateList, {AdvocateID : $scope.versionHistory.stages.advocateID}).AdvocateName;
            }
            tempVersion = $scope.versionHistory.stages.stageID;

			/** close the stages window */
			$scope.close = function() {
				$scope.versionHistory.stages.isEdit = false;
				$modalInstance.dismiss();
			};
			$scope.custNoticeDateConfig = new DatePickerConfig({
			    readonly : true,
		        value : $scope.versionHistory.stages.customerNoticeDate ? new Date($scope.versionHistory.stages.customerNoticeDate) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.customerNoticeDate = value;
				}
		    });
		    $scope.noticeRecdOnDateConfig = new DatePickerConfig({
		        readonly : true,
		        value : $scope.versionHistory.stages.receivedOn ? new Date($scope.versionHistory.stages.receivedOn) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.receivedOn = value;
				}
		    });
		    $scope.intermReplyDateConfig = new DatePickerConfig({
		        readonly : true,
		        value : $scope.versionHistory.stages.interimReply[0].replyDate ? new Date($scope.versionHistory.stages.interimReply[0].replyDate) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.interimReply[0].replyDate = value;
				}
		    });
		    $scope.intermDispachDateConfig = new DatePickerConfig({
		        readonly : true,
		        value : $scope.versionHistory.stages.interimReply[0].dispatchDate ? new Date($scope.versionHistory.stages.interimReply[0].dispatchDate) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.interimReply[0].dispatchDate = value;
				}
		    });
		    $scope.replyDateConfig = new DatePickerConfig({
			    readonly : true,
		        value : $scope.versionHistory.stages.reply[0].replyDate ? new Date($scope.versionHistory.stages.reply[0].replyDate) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.reply[0].replyDate = value;
				}
		    });
		    $scope.replyDispatchDateConfig = new DatePickerConfig({
		        readonly : true,
		        value : $scope.versionHistory.stages.reply[0].dispatchDate ? new Date($scope.versionHistory.stages.reply[0].dispatchDate) : new Date(),
				onchange : function(value) {
					$scope.versionHistory.stages.reply[0].dispatchDate = value;
				}
		    });
		    var getFormDetails = function() {

		    	var noticeAgainstCholaFile = {};
		    	var intermReplyCopyFile = {};
		    	var replyCopyFile ={};

		    	noticeAgainstCholaFile = $scope.versionHistory.noticeAgainstChola;
			    intermReplyCopyFile = $scope.versionHistory.intermReplyCopy;
			    replyCopyFile = $scope.versionHistory.replyCopy;

			    var newObjnoticeAgainstCholaFile = {};
			    var newObjintermReplyCopyFile = {};
			    var newObjreplyCopyFile = {};

				angular.extend(newObjnoticeAgainstCholaFile,noticeAgainstCholaFile);
				angular.extend(newObjintermReplyCopyFile,intermReplyCopyFile);
				angular.extend(newObjreplyCopyFile,replyCopyFile);

		    	var postStageVersion = tempVersion.split('.');
		    	if (postStageVersion[1] == 9) {
		    		postStageVersion[0] = parseInt(postStageVersion[0]) + 1;
		    		postStageVersion = postStageVersion[0] + '.' + '0';
		    	}else{
		    		postStageVersion = postStageVersion[0] + '.' + (postStageVersion[1] ? parseInt(postStageVersion[1]) + 1 : '1');
		    	};
			    
            	$scope.queryObj = {
            		"minorVersion" : $scope.versionHistory.stageVersions.minorVersion,
                    "majorVersion" : $scope.versionHistory.stageVersions.majorVersion,
            		"noticeStages" : [{
            			"stageID" : postStageVersion,
	            	  	"advocateID" : $scope.versionHistory.stages.advocateID,
					  	"receivedOn": $scope.versionHistory.stages.receivedOn,
					  	"customerNoticeDate": $scope.versionHistory.stages.customerNoticeDate,
					  	"noticeNature": $scope.versionHistory.stages.noticeNature,
					  	"issues": $scope.versionHistory.stages.issues,
					  	"remarks": $scope.versionHistory.stages.remarks,
					  	"noticeAgainstCholaFileRef" : [],
					  	"interimReply": [{
					  	   "description": $scope.versionHistory.stages.interimReply[0].description,
					  	   "replyDate": $scope.versionHistory.stages.interimReply[0].replyDate,
					  	   "courierName": $scope.versionHistory.stages.interimReply[0].courierName,
					  	   "dispatchNumber": $scope.versionHistory.stages.interimReply[0].dispatchNumber,
					  	   "dispatchDate": $scope.versionHistory.stages.interimReply[0].dispatchDate,
					  	   "interimReplyCopyFileRef" : []
					  	}],
					  	"reply": [{
					  	  "description": $scope.versionHistory.stages.reply[0].description,
					  	  "replyDate": $scope.versionHistory.stages.reply[0].replyDate,
					  	  "courierName": $scope.versionHistory.stages.reply[0].courierName,
					  	  "dispatchNumber": $scope.versionHistory.stages.reply[0].dispatchNumber,
					  	  "dispatchDate": $scope.versionHistory.stages.reply[0].dispatchDate,
					  	  "replyCopyFileRef" : []
					  	}]
				   }]
				};

				$scope.queryObj["noticeStages"][0]["noticeAgainstCholaFileRef"].push(newObjnoticeAgainstCholaFile);
				$scope.queryObj["noticeStages"][0]["interimReply"][0]["interimReplyCopyFileRef"].push(newObjintermReplyCopyFile);
				$scope.queryObj["noticeStages"][0]["reply"][0]["replyCopyFileRef"].push(newObjreplyCopyFile);
            };
            // on submit
            $scope.updateNoticeCase = function() {
            	getFormDetails();
            	var params = {
            		noticeID: $scope.versionHistory.stageVersions.noticeID
            	};
        		corpLegalNoticeTrackingService.updateNoticeCase(params,$scope.queryObj).then(function(response) {
        			if (response.status === collectionConstants.SUCCESS) {
        				$modalInstance.dismiss();
        				dialogService.showAlert(collectionConstants.ALERT, collectionConstants.SUCCESS, corpLegalConstants.SUCCESS_MSG.NOTICE_TRACK_UPDATE).result.then(function(){},function() {
				    		$state.current.forceReload = true;
			    			$state.transitionTo($state.current,{
					    		productType : $scope.versionHistory.stageVersions.productType, 
					    		agreementNo : $scope.versionHistory.stageVersions.agreementNo,
					    		noticeID : $scope.versionHistory.stageVersions.noticeID 
				    		},{
				    			reload:true
				    		});
				    	});
        			}
        		});
            };
        };
	corpLegalNoticeTrackingQueue.controller('natureVersionHistoryController', ['$scope','$stateParams', '$state','data','$timeout','$modal', '$modalInstance', 'messageBus','dialogService','$rootScope','masterService','lazyModuleLoader','corpLegalNoticeTrackingService','$globalScope',natureVersionHistoryController]);
	return corpLegalNoticeTrackingQueue;
});