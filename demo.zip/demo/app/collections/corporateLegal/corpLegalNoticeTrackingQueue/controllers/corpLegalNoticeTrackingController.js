define(['require','corpLegalNoticeTrackingQueue','constants','collectionConstants','utility','DatePickerConfig','corpLegalConstants'],
	function(r, corpLegalNoticeTrackingQueue, constants, collectionConstants, utility, DatePickerConfig, corpLegalConstants ) {
		'use strict';
		var corpLegalNoticeTrackingController = function($scope,$stateParams,$state,$modal,messageBus,dialogService,$rootScope,masterService,$globalScope,lazyModuleLoader,corpLegalNoticeTrackingService,collectionFactory,getAdvocateList) {
			$rootScope.productType = 'VF';
			$scope.productTypes = angular.copy($rootScope.identity.productDetails);
			$scope.productTypes.push({value: "Others", id: $scope.productTypes.length});
			$scope.productType = $rootScope.productType;
			$scope.data = {};
			var dateRange = {}, params = {},dateObj;
			$scope.searchType = angular.copy(corpLegalConstants.LEGAL_VALUES.LEGAL_NTQ_SEARCH);
			$scope.data.placeholder = $scope.searchType[0].placeholder;
			$scope.filterPopup = {
				onOpen : function(contentData) {
					contentData.options = angular.copy($scope.data.mainMenu);
					contentData.isAll = $scope.data.isAll;
				},
				isAllSelected : function(options) {
					collectionFactory.isAllSelected(options, $scope.filterPopup.isAll);
				},
				checkAll : function(options) {
					$scope.filterPopup.isAll = collectionFactory.filterCheckAll(options);
				},
				filterQueue : function(options, isDone) {
					$scope.filterPopup.reqObj = {};
					$scope.data.isAll = $scope.filterPopup.isAll;
					$scope.data.mainMenu = angular.copy(options);
					if (typeof $scope.filterPopup.close === 'function') {
						$scope.filterPopup.close();
					}
					if (isDone) {
						$scope.filterPopup.reqObj = collectionFactory.filterQueue(options, $scope.filterPopup.reqObj, $scope.filterPopup.isAll, !isDone);
						if (!$scope.filterPopup.reqObj) {
							return;
						}
					}
					$scope.filterPopup.reqObj.filterSec = $scope.filterPopup.reqObj.natureOfNotice ? $scope.filterPopup.reqObj.natureOfNotice.join() : '';
					$scope.data.dateRange = null;
					$scope.data.searchParams = null;
					$scope.searchBy(1);
				},
				resetAndClose : function() {
					$scope.filterPopup.close();
				}
			};
			$scope.filterPopup.reqObj = {
				natureOfNotice : ''
			};
			$scope.advocateList = getAdvocateList.advocates;
			/**
			 * Method to convert date to YYYY-MM-DD format
			 */
			var dateFormater = function(dateVal) {
				if (!dateVal) {
					return '';
				}
				if (typeof dateVal === 'string') {
					var dateArr = dateVal.split('-');
					dateVal = dateArr[2] + '-' + dateArr[1] + '-' + dateArr[0];
				}
				var date = new Date(dateVal);
				var yyyy = date.getFullYear().toString();
				var mm = (date.getMonth() + 1).toString();
				var dd = date.getDate().toString();
				
				return yyyy + '-' + (mm[1] ? mm : "0" + mm[0]) + '-' + (dd[1] ? dd : "0" + dd[0]);
			};
			/**
			 * Method is to make product type based API search
			 */
			var filterValidation = function() {
				var isFill = false;
				if($rootScope.productType) {
					if($scope.data.searchParams || $scope.data.dateRange || $scope.filterPopup.reqObj) {
						isFill = false;
						if($scope.data.searchParams && $scope.data.dateRange && $scope.filterPopup.reqObj ) {
							isFill = true;
						}else if($scope.filterPopup.reqObj){
							if($scope.filterPopup.reqObj.filterSec === "" || $scope.filterPopup.reqObj.natureOfNotice === "") {
								isFill = true;
							}
						}
					}else {
						isFill = true;
					}
				}
				return isFill;
			}
			/**
			 * Method is to get Advocate List with AdvocateName and AdvocateID
			 */
			$scope.onAdvocateChange = function(item) {
				var advocateName = _.findWhere($scope.advocateList, {AdvocateID : item}).AdvocateName;
				return advocateName;
			}
			$scope.searchBy = function(currentPage) {
				var isFilterType = filterValidation();
				var fromDate = "";
				var toDate = "";
				$scope.data.pageNo = currentPage ? currentPage : 1;
				$scope.data.offset = (currentPage - 1) * $scope.data.limit;
				params = {
					offset: $scope.data.offset,
					productType: $rootScope.productType,
					isCount: true,
					limitValue: $scope.data.limit
				};
				if (isFilterType) {
					corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQueue(params).then(function(response) {
						$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						if (response.data) {
							$scope.data.corporateCase = response.data;
							$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
							$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
						} else {
							$scope.data.corporateCase = [];
						}
					});
				}else if($scope.data.searchParams) {
					params[$scope.data.currentSearch.value] = $scope.data.searchParams;
					corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQueue(params).then(function(response) {
						$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						if (response.data) {
							$scope.data.corporateCase = response.data;
						} else {
							$scope.data.corporateCase = [];
						}
					});
				}else if ($scope.data.dateRange) {
					fromDate = $scope.data.dateRange.split(" / ")[0];
					toDate = $scope.data.dateRange.split(" / ")[1];
					params.stDate = dateFormater(fromDate);
					params.endDate = dateFormater(toDate);
					corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQDate(params).then(function(response) {
						$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						if (response.data) {
							$scope.data.corporateCase = response.data;
							$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						    $scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
						} else {
							$scope.data.corporateCase = [];
						}
					});
				}else if($scope.filterPopup.reqObj) {
					params.noticeNature = $scope.filterPopup.reqObj.filterSec;
					corpLegalNoticeTrackingService.getNatureOfNoticeFilter(params).then(function(response) {
						$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						if (response.data) {
							$scope.data.corporateCase = response.data;
						} else {
							$scope.data.corporateCase = [];
						}
					});
				}
			};
			var uniqueFilterOptions = function(c){
				var uniqueValues =_.uniq(_.pluck(c.reverse(),'value'));
				uniqueValues.reverse();
				var uniqueObjects = _.filter(c,function(item){
					if(uniqueValues.indexOf(item.value)>-1){
				uniqueValues.splice(uniqueValues.indexOf(item.value),1);
				return true;
				}return false;}) ;
				$scope.natureofNotice = uniqueObjects.reverse();
			};
			var init = function() {
				var today = new Date();
				var yesterday = new Date(new Date().setDate(today.getDate() - 1));
				$scope.data.limit = 5;
				$scope.data.offset = 0;
				$scope.natureofNotice = corpLegalConstants.LEGAL_VALUES.NATURE_OF_NOTICE;
				uniqueFilterOptions($scope.natureofNotice);
				$scope.data.mainMenu = [ {
					label : "Nature of Notice",
					value : "natureOfNotice",
					selected : false,
					subMenu : $scope.natureofNotice
				}];
				params.offset = $scope.data.offset;
				params.limitValue = $scope.data.limit;
				params.isCount = true;
				params.productType = $rootScope.productType;
				corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQueue(params).then(function(response) {
					if (response.data) {
						$scope.data.corporateCase = response.data || [];
						$scope.data.totalRecord = (response.meta && response.meta.count) ? parseInt(response.meta.count) : 0;
						$scope.data.offsetLast = (($scope.data.offset + $scope.data.limit) > $scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset + ($scope.data.limit - 1);
					} else {
						$scope.data.corporateCase = [];
					}
				});
				dateRange = {
					'today' : [ today, today ],
					'yesterday' : [ yesterday, yesterday ],
					'last7days' : [ new Date(new Date().setDate(today.getDate() - 6)), today ],
					'last30days' : [ new Date(new Date().setDate(today.getDate() - 29)), today ],
					'thisMonth' : [ new Date(new Date().setDate(1)), today ]
				};
			};
			init();
			$scope.legalSearch = function(value) {
				$scope.data.searchParams = '';
				$scope.data.placeholder = value ? _.findWhere($scope.searchType, {value : value}).placeholder : '';
			};
			/** Change product type */
			$scope.setProductType = function() {
				$scope.data.dateRange = null;
				$scope.filterPopup.reqObj = null;
				$scope.data.searchParams = null;
				$scope.searchBy(1);
			};
			/** Method for Pagination */
			$scope.paginationHandler = function(currentPage) {
				$scope.searchBy(currentPage);
			};
			var documentsReceivedCheck = function(legalData) {
				var pageObj = {
					data : $scope.data
				};
				corpLegalNoticeTrackingService.setPageDetails(pageObj);
				corpLegalNoticeTrackingService.setLegalDetails(legalData);
				lazyModuleLoader.loadState('collections.natureOfNotice',{productType: legalData.productType,agreementNo: legalData.agreementNo,noticeID: legalData.noticeID});
			};
			$scope.moreHandler = function(legalData) {
				$globalScope.isClickedViaMenu = true;
				documentsReceivedCheck(legalData);
			};
			/** Method to Search Legal cases by Notice ID & Query ID */
			$scope.searchByNoticeID = function(type, val) {
				if (val === '') {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
					return;
				} else if (val.length < corpLegalConstants.SEARCH_LIMIT) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + corpLegalConstants.SEARCH_LIMIT + " Characters to Search !");
					return;
				}
				$scope.data.dateRange = null;
				$scope.filterPopup.reqObj = null;
				$scope.searchBy(1);
			};
			/**
			 * Method to display Legal cases for the selected date range
			 */
			$scope.datePopupContent = {
				onOpen : function(contentData) {
					contentData.applyDateRange = function() {
						dateObj = collectionFactory.applyDateRange(contentData);
						$scope.data.dateRange = dateObj.fromDate + ' / ' + dateObj.toDate;
						$scope.data.searchParams = null;
						$scope.filterPopup.reqObj = null;
						$scope.searchBy(1);
					};
					contentData.setDateRange = function(key) {
						contentData.fromDate = dateRange[key][0];
						contentData.toDate = dateRange[key][1];
					};
					contentData.init = function() {
						if ($scope.data.dateRange) {
							dateObj = collectionFactory.initDate($scope.data.dateRange);
							contentData.fromDate = dateObj.fromDate;
							contentData.toDate = dateObj.toDate;
						}
					};
					contentData.clear = function(){
						$scope.data.dateRange = '';
						$scope.searchBy(1);
					};
					contentData.init();
				},
				close : function() {
					$scope.datePopupContent.close();
				}
			};
			/** CIF Id click navigates to Case details summary */
			$scope.navigateToCaseDetails = function(data) {
				var pageObj = {
					data : $scope.data,
				};
				corpLegalNoticeTrackingService.setPageDetails(pageObj);
				lazyModuleLoader.loadState('collections.caseDetail', {
					agreementNo : data.agreementNo
				});
			};
        };
	corpLegalNoticeTrackingQueue.controller('corpLegalNoticeTrackingController', ['$scope','$stateParams', '$state', '$modal', 'messageBus','dialogService','$rootScope','masterService','$globalScope','lazyModuleLoader','corpLegalNoticeTrackingService','collectionFactory','getAdvocateList',corpLegalNoticeTrackingController]);
	return corpLegalNoticeTrackingController;
});