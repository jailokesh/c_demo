/** Story Id : Corporate Legal Notice Tracking Queue
 * Modified By - OFS
 * Represents Legal Notice Tracking Queue screen.
 * @version v1.0 Date: 20-02-2018
 */
define([ 'require', 'collectionsApp', 'corpLegalNoticeTrackingResolver'],
   function( require, collectionsApp, corpLegalNoticeTrackingResolver) {
   'use strict';
   var baseViewUrl = 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/';
   var app = angular.module('corpLegalNoticeTrackingQueue', ['ui.router', 'collections']);
   var cau = function($stateProvider, $urlRouterProvider) {
	    $stateProvider.state('collections.corpLegalNoticeTrackingQueue', {
			name : 'collections.corpLegalNoticeTrackingQueue',
			url : '/LegalNoticeTrackingQueue',

			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'corpLegalNoticeTrackingQueue.html',
					controller : 'corpLegalNoticeTrackingController',
					resolve : angular.extend({}, corpLegalNoticeTrackingResolver.getAdvocateList)
				}
			},
			data:{
				'headerText':'Corporate Legal Notice Tacking Queue'
			}
		}).state('collections.natureOfNotice',{
			name : 'collections.natureOfNotice',
			url : '/NatureOfNotice/:productType/:agreementNo/:noticeID',
            
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'partials/natureOfNotice.html',
					controller : 'natureOfNoticeController',
					resolve : angular.extend({}, corpLegalNoticeTrackingResolver.getAdvocateList,corpLegalNoticeTrackingResolver.getZones)
				}
			},
			data : {
				'headerText' : 'Corporate Legal Notice Tacking Queue - Nature Of Notice',
				'backState' : 'collections.corpLegalNoticeTrackingQueue',
			}
		});
	};
   
    app.config(['$stateProvider', '$urlRouterProvider', cau ]);
    return app;
});