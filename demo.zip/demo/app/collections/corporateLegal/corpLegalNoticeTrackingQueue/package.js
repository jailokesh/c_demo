/** Story : Corporate Legal Notice Tracking Queue.
 * Modified By - OFS
 * Represents a Package file for Corporate Legal Notice Tracking Queue.
 * @version v1.0 Date: 20-04-2018
 */
define([], function() {
    'use strict';

    /**
     * Contains the corporate legal notice tracking queue module file names with their paths.
     * Contains the corporate legal notice tracking queue module required dependency configuration.
     */
    require.config({
        paths: {
            'corpLegalNoticeTrackingQueue': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/corpLegalNoticeTrackingQueue',
            'corpLegalNoticeTrackingController': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/controllers/corpLegalNoticeTrackingController',
            'natureOfNoticeController': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/controllers/natureOfNoticeController',
            'natureVersionHistoryController': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/controllers/natureVersionHistoryController',
            'corpLegalNoticeTrackingService': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/services/corpLegalNoticeTrackingService',
            'corpLegalNoticeTrackingResolver': 'app/collections/corporateLegal/corpLegalNoticeTrackingQueue/resolvers/corpLegalNoticeTrackingResolver',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
        },
        shim: {
            'corpLegalNoticeTrackingQueue': ['angular', 'angular-ui-router','corpLegalNoticeTrackingResolver'],
            'corpLegalNoticeTrackingController':['corpLegalNoticeTrackingQueue','corpLegalNoticeTrackingService'],
            'natureOfNoticeController':['corpLegalNoticeTrackingQueue','corpLegalNoticeTrackingService','corpLegalNoticeTrackingResolver'],
            'natureVersionHistoryController':['corpLegalNoticeTrackingQueue','corpLegalNoticeTrackingService','corpLegalNoticeTrackingResolver']
        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the PU SearchCases module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','corpLegalNoticeTrackingController','natureOfNoticeController','natureVersionHistoryController', 'workplanController'], callback);
            });
        });
    };
});