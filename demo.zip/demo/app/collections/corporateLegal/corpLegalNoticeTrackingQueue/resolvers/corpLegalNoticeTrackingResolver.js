/** Story Id : Corporate Legal Notice Tracking Queue
 * Created By - OFS
 * Represents a resolver for corporate legal notice tracking queue.
 * @version v1.0 Date:  09-05-2018
 */
define([], function() {
'use strict';

	/**
	 * Returns the Notice Tracking based info
	 */
	var corpLegalNoticeTrackingResolver = {
		getCorpLegalNoticeTrackingQueue : ['corpLegalNoticeTrackingService','$globalScope','$q', function(corpLegalNoticeTrackingService,$globalScope,$q) {
			console.log("$globalScope From resolver", $globalScope);
			if(!$globalScope.isClickedViaMenu){
				var details = corpLegalNoticeTrackingService.getPageDetails();
				return $q.when(details);
			}
			return corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQueue({}).then(function(data) {
				return data;
			});
		} ]
	};
	/**
	 * Returns the Notice Tracking info based on range of date
	 */
	var corpLegalNoticeTrackingQDate = {
		getCorpLegalNoticeTrackingQDate : ['corpLegalNoticeTrackingService','$globalScope','$q', function(corpLegalNoticeTrackingService,$globalScope,$q) {
			if(!$globalScope.isClickedViaMenu){
				var details = corpLegalNoticeTrackingService.getPageDetails();
				return $q.when(details);
			}
			return corpLegalNoticeTrackingService.getCorpLegalNoticeTrackingQDate({}).then(function(data) {
				return data;
			});
		} ]
	};
	/**
	 * Returns Advocate List
	 */
	var corpLegalGetAdvocateInfo = {
		getAdvocateList : [ 'corpLegalNoticeTrackingService','$globalScope', function(corpLegalNoticeTrackingService, $globalScope) {
			return corpLegalNoticeTrackingService.getAdvocateList({}).then(function(data) {
				return data;
			});
		}]
	};
	 /**
	 * Returns the zone details
	 */
	var zoneDetails = {
     getZones : [ 'corpLegalNoticeTrackingService', function(corpLegalNoticeTrackingService) {
            return corpLegalNoticeTrackingService.getUserDataMapping();
        }]
	};

	return {
		getCorpLegalNoticeTrackingQueue : corpLegalNoticeTrackingResolver,
		getCorpLegalNoticeTrackingQDate : corpLegalNoticeTrackingQDate,
		getAdvocateList : corpLegalGetAdvocateInfo,
		getZones : zoneDetails
	};
});