/** Story Id : Corporate Legal Notice Tracking Queue
 * Created By - OFS
 * Represents a service for corporate legal notice tracking queue.
 * @version v1.0 Date:  03-05-2018
 */
define([ 'require', 'corpLegalNoticeTrackingQueue', 'collectionServiceURLs', 'constants', 'collectionConstants','utility','corpLegalConstants' ], function(require, corpLegalNoticeTrackingQueue, collectionServiceURLs, constants, collectionConstants,utility, corpLegalConstants) {
'use strict';
	var corpLegalNoticeTrackingService = function($q, restProxy, dialogService, $stateParams, $rootScope, $http, masterService ) {
		var limit = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		var legalData, initiationData, productGroup, pageDetails;
		var header = {
           'Content-Type' : 'application/json',
           'Authorization':getCookie('token'),
           'userID' : $rootScope.identity.userName
        };
        var serviceObj = this;
        this.locations = { 
            branchDetails : {}
        };
        // this.isFirstChild = false;
        this.setLegalDetails = function(legalInfo) {
			legalData = legalInfo;
		};
		this.getLegalDetails = function() {
			return legalData;
		};
		this.setPageDetails = function(value){
			pageDetails = value;
		};
		this.getPageDetails = function(){
			return pageDetails;
		};
		/**
		 * Method to get corporate legal tracking queue list for the specific agreement number and notice id |
		 * search by noticeID/queryID
		*/
		this.getCorpLegalNoticeTrackingQueue = function(params) {
			var obj = {
				"offSet": params.offset,
				"noticeID": params.noticeID,
				"queryID": params.queryID,
				"limitValue": params.limitValue
			};
			var queryParams = {
				"productType": params.productType,
				"isCount": params.isCount
			}
			collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE.queryParams = queryParams;
			return restProxy.save('POST', collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE, obj).then(function(data) {
				return data;
			});
		}; 
		/**
		 * Method to get corporate legal tracking queue list for the specific agreement number and notice id |
		 * searched by date range filter
		 */
		this.getCorpLegalNoticeTrackingQDate = function(params) {
			var queryParams = {
				"productType": params.productType,
				"offSet": params.offset,
				"stDate": params.stDate,
				"endDate": params.endDate,
				"isCount": params.isCount,
				"limitValue": params.limitValue
			}
			collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE_DATE.queryParams = queryParams;
			return restProxy.get(collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE_DATE).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to get corporate legal tracking queue version data list for the specific agreement number or notice id
		*/
		this.getCorpLegalNoticeTrackingQVersion = function(params) {
			var queryParams = {
				"productType": params.productType,
				"offSet": params.offset,
				"agreementNo": params.agreementNo,
				"noticeID": params.noticeID 
			}
			params.agreementNo = $stateParams.agreementNo;
			params.noticeID = $stateParams.noticeID;
			collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE_VERSION_DATA.queryParams = queryParams;
			return restProxy.get(collectionServiceURLs.corpLegalNoticeTrackingServices.GET_LEGAL_NOTICE_TRACKING_QUEUE_VERSION_DATA).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to get nature of notice filter data list for the specific natureNotice selected
		*/
		this.getNatureOfNoticeFilter = function(params) {
			var queryParams = {
				"productType": params.productType,
				"noticeNature": params.noticeNature,
				"offset": params.offset,
				"isCount": params.isCount,
				"limitValue": params.limitValue
			}
			collectionServiceURLs.corpLegalNoticeTrackingServices.GET_NATURE_OF_NOTICE_FILTER.queryParams = queryParams;
			return restProxy.get(collectionServiceURLs.corpLegalNoticeTrackingServices.GET_NATURE_OF_NOTICE_FILTER).then(function(data) {
				return data;
			});
		};
		/**
		 * Method to get the advocate list
		 */
        this.getAdvocateList = function(){
          return restProxy.get(collectionServiceURLs.corpLegalServices.GET_ADVOCATE_DETAILS).then(function(data) {
            var advocateList = data.data;
            return advocateList;
          });
        };
        /**
         * Method to get drop down values for zone,region,area,branch
        */
        this.getUserDataMapping = function() {
          if ($rootScope.identity.zoneIDs.length > 0) {
            masterService.getAreas({
              ZoneID : $rootScope.identity.zoneIDs.toString()
            }, 'zone').then(function(userZones) {
              $rootScope.identity.userZones = userZones;
              serviceObj.locations.branchDetails.zones = userZones;
              serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 0);
            });
          }
          if ($rootScope.identity.regionIDs.length > 0) {
            masterService.getAreas({
              regionID : $rootScope.identity.regionIDs.toString()
            }, 'region').then(function(userRegions) {
              $rootScope.identity.userRegions = userRegions;
              serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
              serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.regions.length > 0);
            });
          }
          if ($rootScope.identity.areaIDs.length > 0) {
            masterService.getAreas({
              areaID : $rootScope.identity.areaIDs.toString()
            }, 'area').then(function(userAreas) {
              $rootScope.identity.userAreas = userAreas;
              serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = userAreas;
              serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.areas.length > 0);
            });
          }
          if ($rootScope.identity.branchIDs.length > 0) {
            masterService.getBranches({
              branchID : $rootScope.identity.branchIDs.toString()
            }).then(function(userBranches) {
              $rootScope.identity.userBranches = userBranches;
              serviceObj.locations.branchDetails.filterdBranch = serviceObj.locations.branchDetails.branches = userBranches;
            });
          }
          return serviceObj;
        };
        //To update notice cases
        this.updateNoticeCase = function(params,queryObj){
	       	var paramsObj = {
	       		"noticeID" : params.noticeID
	       	};
            collectionServiceURLs.corpLegalNoticeTrackingServices.CORPORATE_NOTICE_UPDATE.queryParams = paramsObj;
			return restProxy.save('PUT', collectionServiceURLs.corpLegalNoticeTrackingServices.CORPORATE_NOTICE_UPDATE, queryObj).then(function(data) {
				return data;
			});
        };
        //To get AsideInfo
        this.getCorpCaseAsideInfo = function(queryObj){
        	collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS.queryParams = queryObj;
	        return restProxy.save('POST',collectionServiceURLs.corpLegalServices.GET_RIGHT_PANE_DETAILS, queryObj).then(function(response) {
		        if(response && response.data) {
		            return response.data;
		        } else {
			        return [];
		        }
		    });
	    };
	    /**
	     * Method to returns the role based previlage to update records
		*/
		this.getVersionUserEdit = function(params) {
			collectionServiceURLs.corpLegalServices.GET_HIERARCHY_ID.queryParams = {
				"userId": params.createdBy
			};
	        return restProxy.get(collectionServiceURLs.corpLegalServices.GET_HIERARCHY_ID).then(function(response) {
		        if(response && response.data) {
		            return response.data;
		        } else {
			        return [];
		        }
		    });
		};
		

	};
	corpLegalNoticeTrackingQueue.service('corpLegalNoticeTrackingService', [ '$q', 'restProxy', 'dialogService', '$stateParams', '$rootScope', '$http', 'masterService', corpLegalNoticeTrackingService ]);
	return corpLegalNoticeTrackingService;
});