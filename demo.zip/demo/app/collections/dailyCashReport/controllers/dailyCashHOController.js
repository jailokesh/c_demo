/**
 * Daily cash report - EOD created on - 29/5/2015 controller handler
 */
define([ 'require', 'dailyCashReport','collectionConstants','DatePickerConfig'],function(r, dailyCashReport, collectionConstants,DatePickerConfig) {
		'use strict';

		var dailyCashHOController = function($scope,$globalScope,$rootScope,$modal,dailyCashReportService,$state,dialogService,appFactory) {
			$scope.productTypes = angular.copy($rootScope.identity.productDetails);
			$scope.productType = $rootScope.productType;
			$scope.tabClickHandler = function(bol){
				$scope.adjustments = bol;
				if(bol){
					if($scope.dropDownValues.branchDetails.branchID){
						var reqObj = {
								userbranch : $scope.dropDownValues.branchDetails.branchID,
								product : $scope.productType,
								lastDCR :true
						};
						dailyCashReportService.getAdjustment(reqObj).then(function(data){							
							$scope.shortFall_excess = data[0];
							if($scope.shortFall_excess){
								if($scope.shortFall_excess.excessOrShortfallAmount){
									$scope.excess = Math.abs($scope.shortFall_excess.excessOrShortfallAmount);
								}
								if($scope.shortFall_excess.HOAdjustmentAmount){
									$scope.shortFall_excess.HOAdjustmentAmount = Math.abs($scope.shortFall_excess.HOAdjustmentAmount);
								}
							}						
						});
					}					
				}else{
					init();
				}
			};
			$scope.productChangeHandler = function(productType){
				$scope.productType = productType;
				$scope.tabClickHandler(true);
			};
			$scope.getCfeList = function(key,value){
				if($scope.adjustments){
					$scope.tabClickHandler(true);
					return;
				}				
				if(value){
					var reqObj = {};
					reqObj[key] = value;
					dailyCashReportService.getCFEList(reqObj).then(function(data){		
						$scope.manualReceiptEdit = data;
					});
				}else{
					$scope.manualReceiptEdit = [];
				}				
			};
			
			$scope.updateRefNo = function(){
				var reqObj = _.where($scope.manualReceiptEdit, {isChecked: true}),request = [];				
				_.each(reqObj,function(item){
					var obj = {};
					obj.unUsedReceiptCount = item.unUsedReceiptCount;
					obj.unUsedReceiptAmount = item.unUsedReceiptAmount;
					obj.referenceNo = item.referenceNo;
					request.push(obj);
				});
				dailyCashReportService.updateRefNo(request).then(function(data){
					if(data.length){
						dialogService.showAlert('Success','Success','Successfully Updated!').result.then(function(){},function(){
							$scope.selectAllLetters(false);
						});
					}					
				});
			};
			
			$scope.updateAdjustment = function(){				
				dailyCashReportService.updateAmount($scope.shortFall_excess).then(function(data){
					if(data){
						dialogService.showAlert('Success','Success','Successfully Updated!').result.then(function(){},function(){
							$scope.dropDownValues.branchDetails.branchID = "";
							$scope.shortFall_excess.excessOrShortfallAmount = "";
						});						
					}					
				});
			};
			$scope.selectAllLetters = function(isSelectAll) {				
				for (var i = 0; i < $scope.manualReceiptEdit.length; i++) {
					$scope.manualReceiptEdit[i].isChecked = isSelectAll;
					$scope.manualReceiptEdit[i].disabled = isSelectAll;
					$scope.reqObj.push($scope.manualReceiptEdit[i]);
				}
				if(!isSelectAll){
					$scope.reqObj = [];
				}
				$scope.manualReceiptEdit.hasSelectedAll = _.where($scope.manualReceiptEdit, {isChecked: false}).length > 0 ? false : true;				
			};
			
			$scope.CheckHandler = function(receipt,check) {				
				receipt.disabled = check;
				if(check){
					$scope.reqObj.push(receipt);
				}else{
					$scope.reqObj = _.without($scope.reqObj,receipt);					
				}
				$scope.manualReceiptEdit.hasSelectedAll = _.where($scope.manualReceiptEdit, {isChecked: false}).length > 0 ? false : true;				
			};
						
			/**
			 * Method to load related zone,region,area,branch for logged in user.
			 */
			var branchArr, areaArr, regionArr;		
			$scope.changeHandler = function(type,ID) {				
				if (type === 'Zone') {
					if(ID){
						$scope.userSelection({ZoneID : ID,likeSearchType: 0}, 'Region','filteredRegions');					
					}else{					
						$scope.dropDownValues.branchDetails.zoneID = "";					
					}
					$scope.dropDownValues.branchDetails.regionID = "";
					$scope.dropDownValues.branchDetails.areaID = "";
					$scope.dropDownValues.branchDetails.branchID = "";
					$scope.dropDownValues.branchDetails.filteredRegions = [];
					$scope.dropDownValues.branchDetails.filterdAreas = [];
					$scope.dropDownValues.branchDetails.filterdBranch = [];
				}
				if (type === 'Region') {
					if(ID){
						$scope.userSelection({regionID:ID,likeSearchType: 0}, 'Area','filterdAreas');					
					}else{					
						$scope.dropDownValues.branchDetails.regionID = "";					
					}
					$scope.dropDownValues.branchDetails.areaID = "";
					$scope.dropDownValues.branchDetails.branchID = "";
					$scope.dropDownValues.branchDetails.filterdAreas = [];
					$scope.dropDownValues.branchDetails.filterdBranch = [];
				}
				if (type === 'Area') {
					if(ID){
						$scope.userSelection({areaID:ID,likeSearchType: 0}, 'Branch','filterdBranch');					
					}else{					
						$scope.dropDownValues.branchDetails.areaID = "";				
					}
					$scope.dropDownValues.branchDetails.branchID = "";
					$scope.dropDownValues.branchDetails.filterdBranch = [];
				}
				if(type === 'Branch' && !ID){
					$scope.dropDownValues.branchDetails.branchID = "";
				}
				if(type !== "Branch"){
					$scope.getCfeList();					
				}				
			};
			$scope.userSelection = function(reqObj,type,selection){
				dailyCashReportService.getUserSelection(reqObj,type).then(function(data){		
					$scope.dropDownValues.branchDetails[selection] = data;
				});
			};
			var init = function(){
				$scope.dropDownValues = {
						branchDetails : {
							zones : [],
							filteredRegions : [],
							filterdAreas : [],
							filterdBranch : []
						}
				};
				$scope.userSelection('', 'zone','zones');
				$scope.manualReceiptEdit = [];
				$scope.reqObj = [];
				$scope.adjustments = false;
			};
			init();
		};

		dailyCashReport.controller('dailyCashHOController', [ '$scope','$globalScope','$rootScope','$modal','dailyCashReportService', '$state','dialogService','appFactory',dailyCashHOController ]);
		return dailyCashHOController;
	});
