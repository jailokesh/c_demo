/**
 * Daily cash report - EOD created on - 29/5/2015 controller handler
 */
define([ 'require', 'dailyCashReport','collectionConstants','DatePickerConfig'],function(r, dailyCashReport, collectionConstants,DatePickerConfig) {
		'use strict';

		var dailyCashHistoryController = function($scope,$globalScope,$rootScope,$modal,dailyCashReportService,$state,dialogService,appFactory) {
			$scope.productTypes = angular.copy($rootScope.identity.productDetails);
			$scope.productType = $rootScope.productType;			
			var getObjectIndex = function(obj, key, value) {
				for (var i = 0; i < obj.length; i++) {
					if (obj[i][key] === undefined) {
						return undefined;
					}
					if (obj[i][key] === value) {
						return i;
					}
				}
				return -1;
			};

			var resolveCashDenomination = function(cashDenominations) {
				for (var i = 0; i < $scope.cashDenominations.length; i++) {
					if ($scope.cashDenominations[i].denomination !== undefined	&& $scope.cashDenominations[i].denomination !== 0) {
						var index = getObjectIndex(cashDenominations,
								'denomination',
								$scope.cashDenominations[i].denomination);
						if (index > -1) {
							$scope.cashDenominations[i].noOfNotes = cashDenominations[index].noOfNotes;
						}
					} else {
						var coinIndex = getObjectIndex(cashDenominations,
								'denomination', 0);
						if (coinIndex > -1) {
							$scope.cashDenominations[i].noOfCoins = cashDenominations[coinIndex].noOfCoins;
						}
					}
				}

			};

			$scope.calculateTotal = function() {
				$scope.oldDCR = $scope.oldDCR || {};
				$scope.oldDCR.cashInHand = 0;				
				for (var i = $scope.cashDenominations.length - 1; i >= 0; i--) {
					if ($scope.cashDenominations[i].denomination !== undefined && $scope.cashDenominations[i].denomination !== 0) {
						$scope.cashDenominations[i].total = parseInt($scope.cashDenominations[i].denomination * $scope.cashDenominations[i].noOfNotes);
						$scope.oldDCR.cashInHand = $scope.oldDCR.cashInHand + parseInt($scope.cashDenominations[i].total);
					} else {
						$scope.oldDCR.cashInHand = parseInt($scope.oldDCR.cashInHand + $scope.cashDenominations[i].noOfCoins);
						$scope.cashDenominations[i].noOfCoins = $scope.cashDenominations[i].noOfCoins ? $scope.cashDenominations[i].noOfCoins : 0;					
					}
				}				
			};			

			$scope.openReceiptsPopup = function(amountType, receiptsType,data) {
				var reqObj = {};
				if(data === 'obReceipts'){
					var obReceipts = _.reduce(_.pluck($scope.oldDCR.obReceipts, 'amountPaid'), function(memo, num) {return memo + num;}, 0);
					var amt = ($scope.oldDCR.openingBalance || 0) - obReceipts;
					reqObj = {
						manualAmount : amt,
						manual : true	
					};
				}
				reqObj[receiptsType] = $scope.oldDCR[data];
				reqObj.manualReceipts = $scope.oldDCR.lastManualReceipt;		
				reqObj.ExcessShortfallForHistory = $scope.oldDCR.ExcessShortfallForHistory;
				reqObj.HOAdjAmtForHistory = $scope.oldDCR.HOAdjAmtForHistory;
				$modal.open({
					templateUrl : 'app/collections/dailyCashReport/partials/'+ amountType + 'Popup.html',
					controller : 'receiptsPopupController',
					size : 'lg',
					backdrop : 'static',
					resolve : {
						popupData : function() {
							return {
								dcrObject :{totalCash : $scope.totalCash},
								dailyReceipts : reqObj,
								receiptType: receiptsType,
								product : $scope.productType,
								type : "History"								
							};
						}
					}
				});
			};
			
			var oldDCR = function(data){
				$scope.oldDCR = data;
				var initiator = _.where($scope.oldDCR.workflow,{workStatus:'INITIATED'});
				$scope.excessShortfallReason = (initiator && initiator[initiator.length-1]) ? initiator[initiator.length-1].comments:'';
				$scope.oldDCR.totalInflowAmount =  _.reduce(_.pluck(data.inflowReceipts, 'amountPaid'), function(memo, num) {return memo + num;}, 0);
				$scope.oldDCR.totalOutflowAmount = _.reduce(_.pluck(data.outflowChallans, 'receiptAmount'), function(memo, num) {return memo + num;}, 0);				
				var manualReceiptAmt = _.reduce(_.pluck(data.manualReceipt, 'totalAmount'), function(memo, num) {return memo + num;}, 0);
				var obReceipts = _.reduce(_.pluck(data.obReceipts, 'amountPaid'), function(memo, num) {return memo + num;}, 0);
				$scope.oldDCR.todayManualReceipt = [];
				$scope.oldDCR.lastManualReceipt = [];								
				var today = $scope.dateConfig.value.split('/');
				today = new Date($scope.dateConfig.value.split('/')[2],parseInt($scope.dateConfig.value.split('/')[1])-1,$scope.dateConfig.value.split('/')[0]);
				_.each(data.manualReceipt,function(item){
					var CheckDate = new Date(item.enteredDate);
					CheckDate = new Date(CheckDate.getFullYear(),CheckDate.getMonth(),CheckDate.getDate());					
					if(+CheckDate === +today){
						$scope.oldDCR.todayManualReceipt.push(item);
					}else{
						$scope.oldDCR.lastManualReceipt.push(item);
					}
				});
				resolveCashDenomination(data.cashDenominations);
				$scope.calculateTotal();				
				/***************************************TOTAL CASE AS PER THE SYSTEM************************************************************** */					
				var openingBalanceAmt = obReceipts + manualReceiptAmt; 
				$scope.totalCash = (openingBalanceAmt + $scope.oldDCR.totalInflowAmount - $scope.oldDCR.totalOutflowAmount);
				/***************************************TOTAL CASE AS PER THE SYSTEM************************************************************** */				
			};
			var dateDisplay = true;
			$scope.openPrintPopup = function(type){
				var dcrObject = {
					openingBalance : $scope.oldDCR.openingBalance,
					totalCash : $scope.totalCash,
					hoAdjAmt : $scope.oldDCR.lastHOAdjAmt,
					shortfallOrExcess : $scope.oldDCR.lastExcessOrShortfallAmt
				};
				var dailyReceipts = {
					openingBalance : $scope.oldDCR.openingBalance,
					inflow : {totalInflowAmount :$scope.oldDCR.totalInflowAmount},
					outflow : {totalOutflow:$scope.oldDCR.totalOutflowAmount},
					printManualRecipts :  $scope.oldDCR.todayManualReceipt
				};
				if(dcrObject && dailyReceipts){
					$modal.open({
						templateUrl : 'app/collections/dailyCashReport/partials/submitAndPrintPopup.html',
						controller : 'receiptsPopupController',
						size : 'lg',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve: {
							popupData: function() {
								return {
									"dcrObject" : dcrObject,
									'dailyReceipts' : dailyReceipts,
									'cashReceipt' :{cashInHand :$scope.oldDCR.cashInHand,reason:$scope.excessShortfallReason},
									'cashInHand' : $scope.oldDCR.cashInHand,
									'cashDenominations':$scope.cashDenominations,
									'isRefNoGenereated':$scope.isRefNoGenereated,								
									'product' : $scope.productType,
									'today' : $scope.dateConfig.dateValue,
									'type' : type
								};
							}
						}
					}).result.then(function(data){					
					},function(data){
						$state.go('collections.dashboard');
					});
				}				
			};
			$scope.viewHistory = function(){
				$scope.cashDenominations = dailyCashReportService.getDenominations();
				dailyCashReportService.getCashReceipt($scope.productType,$scope.dateConfig.value).then(function(data){
					if(data && data[0]){
						oldDCR(data[0]);
					}else{
						dialogService.showAlert('Alert','Alert','No DCR taken for the day.');
						$scope.oldDCR = {};
						$scope.cashDenominations = dailyCashReportService.getDenominations();
						$scope.calculateTotal();
						$scope.totalCash = 0;
						$scope.excessShortfallReason ='';
					}																														
				});	
			};
			var init = function(){
				$scope.cashDenominations = dailyCashReportService.getDenominations();
				$scope.dateConfig = new DatePickerConfig({
					value : '',
					maxDate : new Date(),
					onchange : function(val) {														
					},
					readonly : true
				});						
			};
			init();			
			$scope.productChangeHandler = function(){
				if($scope.productType !== 'DEALER'){
					$rootScope.productType = $scope.productType;
				}			
			};
			
			
		};

		dailyCashReport.controller('dailyCashHistoryController', [ '$scope','$globalScope','$rootScope','$modal','dailyCashReportService', '$state','dialogService','appFactory',dailyCashHistoryController ]);
		return dailyCashHistoryController;
	});
