	/**
 * Daily cash report - EOD created on - 29/5/2015 controller handler
 */
define([ 'require', 'dailyCashReport','collectionConstants','DatePickerConfig','utility'],function(r, dailyCashReport, collectionConstants,DatePickerConfig,utility) {
		'use strict';

		var dailyCashReportController = function($scope,$timeout,$globalScope,$rootScope,$modal,dailyCashReport, cashReceipt, dailyCashReportService,$state,dialogService,appFactory) {
			$scope.productTypes = angular.copy($rootScope.identity.productDetails);
			$scope.productType = $rootScope.productType;
			$scope.categoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'cash report'});
			var getObjectIndex = function(obj, key, value) {
				for (var i = 0; i < obj.length; i++) {
					if (obj[i][key] === undefined) {
						return undefined;
					}
					if (obj[i][key] === value) {
						return i;
					}
				}
				return -1;
			};

			var resolveCashDenomination = function(cashDenominations) {
				for (var i = 0; i < $scope.cashDenominations.length; i++) {
					if ($scope.cashDenominations[i].denomination !== undefined	&& $scope.cashDenominations[i].denomination !== 0) {
						var index = getObjectIndex(cashDenominations,
								'denomination',
								$scope.cashDenominations[i].denomination);
						if (index > -1) {
							$scope.cashDenominations[i].noOfNotes = cashDenominations[index].noOfNotes;
						}
					} else {
						var coinIndex = getObjectIndex(cashDenominations,
								'denomination', 0);
						if (coinIndex > -1) {
							$scope.cashDenominations[i].noOfCoins = cashDenominations[coinIndex].noOfCoins;
						}
					}
				}

			};

			$scope.calculateTotal = function() {
				$scope.cashReceipt = $scope.cashReceipt || {};
				$scope.cashReceipt.cashInHand = 0;
				$scope.dcrObject.shortfallOrExcess = 0;				
				for (var i = $scope.cashDenominations.length - 1; i >= 0; i--) {
					if ($scope.cashDenominations[i].denomination !== undefined && $scope.cashDenominations[i].denomination !== 0) {
						$scope.cashDenominations[i].total = parseInt($scope.cashDenominations[i].denomination * $scope.cashDenominations[i].noOfNotes);
						$scope.cashReceipt.cashInHand = $scope.cashReceipt.cashInHand + parseInt($scope.cashDenominations[i].total);
					} else {
						$scope.cashReceipt.cashInHand = parseInt($scope.cashReceipt.cashInHand + $scope.cashDenominations[i].noOfCoins);
						$scope.cashDenominations[i].noOfCoins = $scope.cashDenominations[i].noOfCoins ? $scope.cashDenominations[i].noOfCoins : 0;					
					}
				}				
				/**********************************SHORTFALL OR EXCESS************************************************************ */
				$scope.dcrObject.shortfallOrExcess = $scope.cashReceipt.cashInHand - $scope.dcrObject.totalCash;
				/**********************************SHORTFALL OR EXCESS************************************************************ */
			};						

			$scope.openReceiptsPopup = function(amountType, receiptsType) {
				$modal.open({
					templateUrl : 'app/collections/dailyCashReport/partials/'+ amountType + 'Popup.html',
					controller : 'receiptsPopupController',
					size : 'lg',
					backdrop : 'static',
					resolve : {
						popupData : function() {
							return {
								dcrObject : $scope.dcrObject,
								dailyReceipts : $scope.dailyReceipts[amountType],
								receiptType: receiptsType,
								product : $scope.productType,
								type : "New"								
							};
						}
					}
				});
			};

			$scope.getReferenceNo = function(Id,No,Amt) {				
				dailyCashReportService.getReferenceNo($scope.productType).then(function(result) {
					if (result !== undefined) {
						$scope.dcrObject.totalCash += parseInt(Amt);
						$scope.cashInHand += parseInt(Amt);
						$scope.cashReceipt.manualReceipt.referenceNo = result.referenceNo;
                        $scope.isRefNoGenereated = false;
                        _.each($scope.allocatedCFEs,function(item){
                        	if(item.userID === Id){
                    			item.noOfManualReceipt = No;
                    			item.totalAmount = Amt;
								item.unUsedReceiptCount = No;
                    			item.unUsedReceiptAmount = Amt;
                    			item.referenceNo = result.referenceNo;
								item.enteredDate = dailyCashReport.fetchDateTime;
                    		}                        	
                        });                      	
                        $scope.calculateTotal();
					}
				});
			};

			$scope.checkNoOfManualReceipt = function(val){
				return val>0?{status:'success'}:{message:'Receipts should be greater than zero'};
			};
			
			$scope.checkTotalAmount = function(val){
				return val>0?{status:'success'}:{message:'Amount should be greater than zero'};
			};
			var dateDisplay = true;
			var openPrintPopup = function(type){
				$modal.open({
					templateUrl : 'app/collections/dailyCashReport/partials/submitAndPrintPopup.html',
					controller : 'receiptsPopupController',
					size : 'lg',
					backdrop : 'static',
					windowClass : 'modal-custom',
					resolve: {
						popupData: function() {
							return {
								"dcrObject" : $scope.dcrObject,
								'dailyReceipts' : $scope.dailyReceipts,
                                'cashReceipt' : $scope.cashReceipt,
								'cashInHand' : $scope.cashInHand,
                                'cashDenominations':$scope.cashDenominations,
                                'isRefNoGenereated':$scope.isRefNoGenereated,								
                                'product' : $scope.productType,
                                'today' : dateDisplay ? $scope.data.today : new Date().setDate(new Date().getDate() - 1),
								'type' : type
							};
		                }
					}
				}).result.then(function(data){					
				},function(data){
					$state.go('collections.dashboard');
				});
			};
			
			$scope.focusHandler = function(){
				if(parseInt($scope.cashDenominations[$scope.cashDenominations.length-1].noOfCoins) === 0){
					$scope.cashDenominations[$scope.cashDenominations.length-1].noOfCoins = '';
				}
			};
			var previousDayDetails = function(response){
				if(response.message.errors[0].errorCode === 'DCR-1012'){
					dialogService.confirm(collectionConstants.CONFIRM, collectionConstants.CONFIRM,response.message.errors[0].message).result.then(function() {
						var today = new Date();
						var previousDay = new Date(new Date().setDate(today.getDate() - 1));		
						_.each($scope.allocatedCFEs,function(item){                        	
							item.enteredDate = previousDay;                    		
                        });
						$scope.cashReceipt.isPrevious = true;						   
						submitCashReceipt();	
					}, function() {});						
				}else{
					dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE,response.message.errors[0].message).result.then(function() {}, function() {});
				}
			};
			var submitCashReceipt = function(type){				
        		$scope.cashReceipt.productType = $scope.productType;
				$scope.cashReceipt.openingBalance = $scope.dcrObject.openingBalance;
				$scope.cashReceipt.cashDenominations = [];
				//var copyCFE = angular.copy($scope.allocatedCFEs);
				_.each($scope.dailyReceipts.openingBalance.manualReceipts,function(item){
						item.noOfManualReceipt = item.unUsedReceiptCount;
						item.totalAmount = item.unUsedReceiptAmount;						
				});
				var CFE = _.reject($scope.allocatedCFEs, function(num){ return !num.referenceNo; });
				$scope.cashReceipt.manualReceipt = (CFE.length > 0 && CFE[0].referenceNo !== '-') ? _.map(CFE, function(o) { return _.omit(o, '$$hashKey','selected','userName','disabled'); }) : [];				
				$scope.dailyReceipts.printManualRecipts = $scope.cashReceipt.manualReceipt;
				$scope.cashReceipt.manualReceipt = $scope.cashReceipt.manualReceipt.concat($scope.dailyReceipts.openingBalance.manualReceipts);
				$scope.cashReceipt.obReceipts = _.pluck($scope.dailyReceipts.openingBalance.receipts, 'receiptNo') || [];
				$scope.cashReceipt.inflowReceipts = _.pluck($scope.dailyReceipts.inflow.receipts, 'receiptNo') || [];
				$scope.cashReceipt.outflowChallans = _.pluck($scope.dailyReceipts.outflow.challans, 'challanNo') || [];
				$scope.cashReceipt.HOAdjustmentAmount = $scope.dailyReceipts.openingBalance.HOAdjustmentAmount;
				$scope.cashReceipt.HOAdjustmentReason = $scope.dailyReceipts.openingBalance.HOAdjustmentReason;
				$scope.cashReceipt.excessOrShortfallAmount = $scope.dcrObject.shortfallOrExcess;
				_.each($scope.cashDenominations,function(item){
					if(item.noOfNotes !=='' && item.noOfNotes !== 0 || item.noOfCoins !== '' && item.noOfCoins !== 0){
						$scope.cashReceipt.cashDenominations.push({
							'denomination' : item.denomination,
							'noOfNotes' : parseInt(item.noOfNotes),
							'noOfCoins' : parseInt(item.noOfCoins)
						});
					}
				});
				if($scope.dcrObject.totalCash===0 && $scope.dcrObject.shortfallOrExcess===0 || $scope.cashReceipt.cashInHand === 0){
					$scope.cashReceipt.cashDenominations = [{
							'denomination' : 0,
							'noOfNotes' : 0,
							'noOfCoins' : 0
						}];
				}
				/** commend the else condition as per the Rajesh and chola team mail chain
				 *  Previously if all the amount field is zero mean it won't hit the service 
				 *  as per the mail communication now hitting the service 
				 **/			
				$scope.cashReceipt.reportDateTime = dailyCashReport.fetchDateTime;								
				dailyCashReportService.submitCashReceipt($scope.cashReceipt,$scope.productType).then(function(response){
					if(response && response.status === 'failed'){
						dateDisplay = false;
						previousDayDetails(response);
					}else if(response && response.data.length>0){
						$scope.viewMode=true;
						delete $scope.cashReceipt.isPrevious;
						$scope.cashReceipt.majorVersion = response.data[0].majorVersion;
						$scope.cashReceipt.minorVersion = response.data[0].minorVersion;
						$scope.allocatedCFEs = $scope.dailyReceipts.printManualRecipts;							
						openPrintPopup();
						dateDisplay = true;
					}					
				});				
           };
           
			$scope.deleteCashReceipt = function(){	
				dialogService.confirm('Warning','Warning','Are you sure want to delete the cash report?').result.then(function(){
					dailyCashReportService.deleteCashReceipt($scope.productType).then(function(response){
						if(response){
							dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.POPUP_HEADER.SUCCESS_STRING,collectionConstants.DAILY_CASH_REPORT.SUCCESS_DELETE_EOD_DCR).result.then(function(){},function(){
							 		$state.go('collections.dashboard');
							});
						}
					});
				},function(){});				
			};
			var submitcheck = function(type){
				var referenceNoCheck = _.contains(_.pluck($scope.allocatedCFEs, 'referenceNo'), undefined);
				if(referenceNoCheck) {
					dialogService.confirm('','Warning','You have entered values in manual receipt but referenceNo is not generated. Changes to manual receipt will be lost. Do you wish to continue?')
						.result.then(function(){
							submitCashReceipt(type);
						},function(){});
				}else{
					submitCashReceipt(type);
				}
			};
			$scope.reasonValid = function(){
				if($scope.cashReceipt.reason){
					$scope.isReason = false;
				}
			}
			$scope.submit = function(type) {
				$scope.calculateTotal();
				if(type === 'printOnly'){
					if(true || !$scope.dcrApproval.isInitiated || $scope.dcrApproval.isApproved){
						openPrintPopup(true);
					}						
				}else if($scope.dcrObject.shortfallOrExcess){
					if(!$scope.cashReceipt.reason){
						$scope.isReason = true;
						return;
					}
					dialogService.confirm('','Warning','This DCR has Excess/ShortFall ('+utility.currencyFormatter($scope.dcrObject.shortfallOrExcess)+'). Do you want to submit ?')
					.result.then(function(){
						submitcheck(type);
					},function(){});
				}else{
					dialogService.confirm('','Warning','Do you want to submit the daily cash report?')
            		.result.then(function(){            			
            			submitcheck(type);
            		},function(){
            			
            		});
				}
			};
			
			$scope.signedDocUpload = function(imageRef){
				var reqObj = {
					imageRef : imageRef,
					majorVersion : $scope.cashReceipt.majorVersion,
					minorVersion : $scope.cashReceipt.minorVersion
				};
				dailyCashReportService.uploadSignedDoc(reqObj,$scope.productType).then(function(response){
					if(response && response.length){
							dialogService.showAlert('Success','Success','Document uploaded successfully!').result.then(function(){},function(){
								angular.extend(imageRef.imagePathReferences,response[0].imageRef.imagePathReferences);
								//$state.current.forceReload = true;
								//$state.transitionTo($state.current,{},{reload:true});
							});
						}
						else{
							dialogService.showAlert('Error','Error','Error during submission').result.then(function(){},function(){
								angular.extend(imageRef.imagePathReferences,response[0].imageRef.imagePathReferences);
								//$state.current.forceReload = true;
								//$state.transitionTo($state.current,{},{reload:true});
							});
						}
					});
			};
			
			var init = function(){			
				$scope.showUpdateManualReceipts = true;
				$scope.isReason = false;
				$scope.dcrApproval = {
					isInitiated : false,	
					isApproved : false
				};
				
				$scope.viewMode = false;
				//$scope.dcrObject.totalCash = '';
				$scope.cashReceipt = cashReceipt;
				$scope.dailyReceipts = dailyCashReport;
				$scope.dcrObject = {
					onlineReceipts : 0,
					manualReceipts : 0,
					openingBalance : 0,
					totalCash : 0,
					hoAdjAmt : $scope.dailyReceipts.openingBalance.HOAdjustmentAmount,
					shortfallOrExcess :0
				};				
				if($scope.cashReceipt && $scope.cashReceipt.manualReceipt){
					$scope.allocatedCFEs = [];
					var today = new Date($scope.dailyReceipts.fetchDateTime);
					today = new Date(today.getFullYear(),today.getMonth(),today.getDate());
					_.each($scope.cashReceipt.manualReceipt,function(item){
						var CheckDate = new Date(item.enteredDate);
						CheckDate = new Date(CheckDate.getFullYear(),CheckDate.getMonth(),CheckDate.getDate());					
						if(+CheckDate === +today){
							$scope.allocatedCFEs.push(item);
						}
					});
				}else{
					dailyCashReportService.setAllocatedCFEs([]);
					$scope.allocatedCFEs = [{
						userID : '-',
                		noOfManualReceipt : '-',                		
                		totalAmount : '-',                		
                		referenceNo : '-'         	     
					}];
				}
				$scope.data = {};
				$scope.data.today = cashReceipt && cashReceipt.reportDateTime ?cashReceipt.reportDateTime : dailyCashReport ? dailyCashReport.fetchDateTime : new Date();
				
				/*************************************** OPENING BALANCE ************************************************** */
				$scope.dcrObject.onlineReceipts = _.reduce(_.pluck($scope.dailyReceipts.openingBalance.receipts, 'amountPaid'), function(memo, num) {return memo + num;}, 0);
				$scope.dcrObject.manualReceipts = _.reduce(_.pluck($scope.dailyReceipts.openingBalance.manualReceipts, 'unUsedReceiptAmount'), function(memo, num) {return memo + num;}, 0);
				
				$scope.dcrObject.openingBalance += $scope.dcrObject.onlineReceipts;
				$scope.dcrObject.openingBalance += $scope.dcrObject.manualReceipts;
				$scope.dcrObject.openingBalance += $scope.dailyReceipts.openingBalance.lastExcessOrShortfallAmt;
				/*************************************** OPENING BALANCE ************************************************** */

				$scope.dcrApproval = {};
				if($scope.cashReceipt && $scope.cashReceipt.workflow && $scope.cashReceipt.workflow.length){
					var eodIndex = -1;
					eodIndex = _.findLastIndex($scope.cashReceipt.workflow,{workStatus:'INITIATED'});
					$scope.dcrApproval.isInitiated = eodIndex>-1&&eodIndex==$scope.cashReceipt.workflow.length-1;
					$scope.dcrApproval.isApproved = _.findWhere($scope.cashReceipt.workflow,{workStatus:'APPROVED'});
					$scope.cashReceipt = (!$scope.dcrApproval.isInitiated&&!$scope.dcrApproval.isApproved)?'':cashReceipt;
				}
				$scope.cashDenominations = dailyCashReportService.getDenominations();
				if ($scope.dailyReceipts && $scope.dailyReceipts.inflow !== undefined && $scope.dailyReceipts.openingBalance !== undefined && $scope.dailyReceipts.outflow !== undefined){						               
					/***************************************TOTAL CASE AS PER THE SYSTEM************************************************************** */					
					var openingBalanceAmt = $scope.dcrObject.onlineReceipts + $scope.dcrObject.manualReceipts; 
					$scope.dcrObject.totalCash = (openingBalanceAmt + $scope.dailyReceipts.inflow.totalInflowAmount - $scope.dailyReceipts.outflow.totalOutflow);
					/***************************************TOTAL CASE AS PER THE SYSTEM************************************************************** */
	            }           
	            else
	                $scope.viewMode=true;
				if ($scope.cashReceipt && $scope.cashReceipt.cashDenominations) {
					resolveCashDenomination($scope.cashReceipt.cashDenominations);
					$scope.calculateTotal();
					$scope.cashReceipt = cashReceipt;
					if($scope.cashReceipt.manualReceipt!==undefined){
						//$scope.dcrObject.totalCash=$scope.dcrObject.totalCash+$scope.cashReceipt.manualReceipt.totalAmount;
						//$scope.cashReceipt.excessAmount = $scope.dcrObject.totalCash - ($scope.cashReceipt.cashInHand + $scope.dailyReceipts.openingBalance.HOAdjustmentAmount);
					}
					$scope.viewMode = true;
				}else{
					$scope.cashReceipt = {};
					$scope.cashReceipt.manualReceipt = {};
					$scope.cashReceipt.offlineReceipt = {};
				}	
				if ($scope.cashReceipt && $scope.cashReceipt.workflow) {
				var initiator = _.where($scope.cashReceipt.workflow,{workStatus:'INITIATED'});
				$scope.cashReceipt.reason = (initiator && initiator[initiator.length-1]) ? initiator[initiator.length-1].comments:'';
				}
			};
			init();
			$scope.setInScope=function(signed_doc){
 				$scope.signed_doc=signed_doc;
 			};
			$scope.productChangeHandler = function(){
				if($scope.productType !== 'DEALER'){
					$rootScope.productType = $scope.productType;
				}
				dailyCashReportService.getOpeningAmount($scope.productType).then(function(data){
					if(data && data[0]){
						dailyCashReport = data[0];
					}
					else{
						dailyCashReport = {};
					}
					dailyCashReportService.getCashReceipt($scope.productType).then(function(data){
						if(data && data[0]){
							cashReceipt = data[0];
						}
						else{
							cashReceipt = {};
						}
						init();
						$timeout(function(){
							if($scope.signed_doc && $scope.signed_doc.refreshFiles)
								$scope.signed_doc.refreshFiles();
						},200);
						
					});
				});
				$scope.manualreceiptform.resetSubmited();
			};
			
			var getCFEList = function(cfeList){				
				$modal.open({
					templateUrl : 'app/collections/dailyCashReport/partials/allocatedCFEList.html',
					controller : [ '$scope', '$modalInstance','data', function($scope, $modalInstance,data) {
						$scope.disableSubmit = true;
						$scope.selecteAll = {all : false};
						$scope.selectAllCheckbox = function(check){
							_.each($scope.data,function(item){
								if(!item.disabled){
									item.selected = check;
									$scope.disableSubmit = !check;
								}											
							});							
						};
						
						$scope.selectCheckbox = function(check){
							var data = _.where($scope.data,{selected:true});
							if(data.length > 0){
								$scope.disableSubmit = false;
							}else{
								$scope.disableSubmit = true;
							}
							if(data.length === $scope.data.length){
								$scope.selecteAll.all = true;				
							}else{
								$scope.selecteAll.all = false;				
							}							
						};
						var init = function(){							
							$scope.data = data.CFEList;
							_.each($scope.data,function(item){
								item.disabled = item.selected;
							});						
							$scope.noRecords = (!$scope.data||!$scope.data.length)?true:false;
							$scope.selectCheckbox();
						};
						init();
						$scope.close = function(data){
							$modalInstance.close(data);
						};
						$scope.dismiss = function(){
							$modalInstance.dismiss();
						};
					} ],
					size : 'md',
					backdrop : 'static',
					windowClass : 'modal-custom',
					resolve: {
						data: function() {
							return {								
								CFEList : cfeList								
							};
		                }
					}
				}).result.then(function(data){
					$scope.allocatedCFEs = _.where(data,{selected:true});				
				},function(data){});
			};
			$scope.allocatedCFE = function(){
				if($scope.productType !== 'DEALER'){
					$rootScope.productType = $scope.productType;
				}
				var getSelectedCFE = dailyCashReportService.getAllocatedCFEs();
				if(getSelectedCFE && getSelectedCFE.length && $scope.allocatedCFEs && $scope.allocatedCFEs.length){										
					_.each(getSelectedCFE,function(item){
						var list = _.findWhere($scope.allocatedCFEs, {userID: item.userID});
						if(list){
							item.selected = true;
						}
					});
					getCFEList(getSelectedCFE);					
				}else{
					dailyCashReportService.getAllocatedCFE($scope.productType).then(function(data){					
						if(data.length){							
							dailyCashReportService.setAllocatedCFEs(data);
							getCFEList(data);
						}else{
							dialogService.showAlert('Alert','Alert',"No CFE's allocated to this branch.");
						}											
					});
				}				
			};
			$scope.removeSelectedCFE = function(item,$index){
				item.selected = false;
				if(item.totalAmount){
					$scope.dcrObject.totalCash -= parseInt(item.totalAmount);
					$scope.dcrObject.shortfallOrExcess = $scope.dcrObject.shortfallOrExcess > 0 ? $scope.dcrObject.shortfallOrExcess - parseInt(item.totalAmount):$scope.dcrObject.shortfallOrExcess + parseInt(item.totalAmount);
				}				
				item.noOfManualReceipt = '';
				item.totalAmount = '';
				item.referenceNo = '';
				item.unUsedReceiptCount = '';
				item.unUsedReceiptAmount = '';				
				item.enteredDate = '';				
				$scope.allocatedCFEs.splice($index, 1);				
				$scope.allocatedCFEs = _.where($scope.allocatedCFEs,{selected:true});
				if($index === 0 && $scope.allocatedCFEs.length === 0){
					$scope.allocatedCFEs = [{
						userID : '-',
                		noOfManualReceipt : '-',                		
                		totalAmount : '-',                		
                		referenceNo : '-'         	     
					}];
				}
			};
		};

		dailyCashReport.controller('dailyCashReportController', [ '$scope','$timeout','$globalScope','$rootScope','$modal', 'dailyCashReport', 'cashReceipt','dailyCashReportService', '$state','dialogService','appFactory',dailyCashReportController ]);
		return dailyCashReportController;
	});
