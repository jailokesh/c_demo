/** Daily cash report - EOD 
 * created on - 29/5/2015
 * controller handler
 */
define(['require', 'dailyCashReport'],function(r, dailyCashReport) {
        'use strict';

        var receiptsPopupController = function($scope,$state,$modal, $modalInstance,popupData,dailyCashReportService) {                   
            $scope.dailyReceipts = popupData.dailyReceipts;
            $scope.manualReceipt = popupData.dailyReceipts.manualReceipts;
            $scope.cashReceipt = popupData.cashReceipt;
            $scope.cashInHand = popupData.cashInHand;
            $scope.cashDenominations = popupData.cashDenominations;
            $scope.today = popupData.today;
            $scope.productType = popupData.product;
            $scope.type = popupData.type;
            $scope.dcrObject = popupData.dcrObject;         

            $scope.close = function(){            	
                $modalInstance.dismiss();
            };

            $scope.redirectClose = function(){            	
                $modalInstance.close();
            };

            $scope.getReferenceNo = function() {
            	dailyCashReportService.getReferenceNo().then(function(result) {
                    if (result !== undefined) {
                        $scope.cashReceipt.manualReceipt.referenceNo = result.referenceNo;
                    }
                });

            };
        };

        dailyCashReport.controller('receiptsPopupController', ['$scope','$state', '$modal', '$modalInstance','popupData','dailyCashReportService',receiptsPopupController]);
        return receiptsPopupController;
});
