/** dailyCashReport - EOD
 * created on - 29/5/2015 
 *  service calls
 *   */

define(['require','dailyCashReport','collectionServiceURLs','collectionConstants'],function(r,dailyCashReport,collectionServiceURLs,collectionConstants){

	var dailyCashReportService=function($q,$rootScope,restProxy,masterService,dialogService){
		
		var thisObj = this;
		/**
	   	 * Method to get reportee's list for the specific user role (BRM/ARM..)
	   	 */		
		this.getOpeningAmount = function(productType){
			var queryParams = {
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};			
			collectionServiceURLs.dailyCashReportServices.GET_AMOUNT.queryParams = queryParams;			
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_AMOUNT).then(function(response){ 
				return response.data;
			});	

		};
		/**
	   	 * Method to get save/modify target set table data for the current month
	   	 * POST service
	   	 */
		this.getReferenceNo = function(productType){
			collectionServiceURLs.dailyCashReportServices.GET_REFERENCE_NO.queryParams = {
					'product' : productType,
					'referenceMode' : 'manual',
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID
				
			};		
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_REFERENCE_NO).then(function(response){ 
				return response.data[0];
			});	

		};
		
		this.getCFEList = function(reqObj){
			collectionServiceURLs.dailyCashReportServices.GET_PENDING_REFERENCE_BY_ID.queryParams = reqObj;		
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_PENDING_REFERENCE_BY_ID).then(function(response){ 
				return response.data;
			});	

		};

		this.getUserSelection = function(reqObj,type) {
			var identity = $rootScope.identity;
            if (identity.zoneIDs.length > 0) {
				 return masterService.getAreas(reqObj,type).then(function(userZones) {
					return userZones;
				 });
            }
		};
		
		this.getCashReceipt = function(productType,date){
			var queryParams = {
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};
			
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
			if(date){
				collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams.reportDate = date.replace("/", "-").replace("/", "-");
			}
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
				return response.data;
			});	
		};
		
		this.updateRefNo = function(reqObj){			
			return restProxy.save('PUT',collectionServiceURLs.dailyCashReportServices.UPDATE_REF_NUMBER,reqObj).then(function(response){ 
				return response.data;
			});	
		};
		
		this.updateAmount = function(reqObj){			
			var request = {
				    "HOAdjustmentAmount": reqObj.HOAdjustmentAmount,
				    "HOAdjustmentReason": reqObj.HOAdjustmentReason,
				    "branchID": reqObj.branchID,
				    "productType":reqObj.productType,
				    "excessOrShortfallAmount": reqObj.excessOrShortfallAmount,
				    "reportID": reqObj.reportID,
				    "majorVersion" : reqObj.majorVersion, 
				    "minorVersion" : reqObj.minorVersion
			};			
			return restProxy.save('PUT',collectionServiceURLs.dailyCashReportServices.UPDATE_AMOUNT,request).then(function(response){ 
				return response.data;
			});	
		};
		
		this.getAdjustment = function(queryParams){			
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;			
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
				return response.data;
			});	
		};			
					
		thisObj.submitCashReceipt = function(requestBody,productType){
			var queryParams = {
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.notify = false;
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
			return restProxy.save('POST',collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT,requestBody).then(function(response){					
				return response;
			});	
		};
		
		this.deleteCashReceipt = function(productType){
			var queryParams = {
					'userbranch': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};
			
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
			return restProxy.save('DELETE',collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT).then(function(response){ 
				return response.data;
			});	
		};
		
		this.getDenominations = function(){
			return [{
				'denomination' : 2000,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				 total : ''
			},{
				'denomination' : 1000,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 500,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 200,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 100,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 50,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 20,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 10,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 5,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 2,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'denomination' : 1,
				'noOfNotes' : '',
				'noOfCoins' : 0,
				total : ''
			}, {
				'noOfCoins' : '',
				'total' : ''
			}];
		};
		
		this.uploadSignedDoc = function(reqObj,productType){
			var queryParams = {
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType
			};			
			collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT.queryParams = queryParams;
			return restProxy.save('PUT',collectionServiceURLs.dailyCashReportServices.GET_CASH_RECEIPT,reqObj).then(function(response){ 
				return response.data;
			});	
		};
		
		this.getAllocatedCFE = function(productType){
			var queryParams = {
					'branchID': JSON.parse(getCookie('selectedBranch')).branchID,
					'product' : productType,
					'type' : 'cfelist'
			};
			
			collectionServiceURLs.dailyCashReportServices.GET_ALLOCATED_CFE.queryParams = queryParams;
			return restProxy.get(collectionServiceURLs.dailyCashReportServices.GET_ALLOCATED_CFE).then(function(response){ 				
				if(response.data && response.data[0]){
					var cfe = _.uniq(_.pluck(response.data[0].allocatedUserDetails, 'allocatedUserID')),cfeList = [];
					_.each(cfe,function(item){
						var list = _.findWhere(response.data[0].cfeList, {userID: item});
						if(list){
							list.selected = false;
							cfeList.push(list);
						}						
					});
					return cfeList;
				}			
			});	
		};
		var setAllocatedCFE;
		this.setAllocatedCFEs = function(value){
			setAllocatedCFE = value;
		};
		
		this.getAllocatedCFEs = function(){
			return setAllocatedCFE;
		};		
	};

	dailyCashReport.service('dailyCashReportService',['$q','$rootScope','restProxy','masterService','dialogService',dailyCashReportService]);
	return dailyCashReportService;
});