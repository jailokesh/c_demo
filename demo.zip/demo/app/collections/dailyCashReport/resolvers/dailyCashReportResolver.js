/**dailyCashReport
 * created on 29/5/2015
 *	dailyCashReport resolver call 
 *  */
define([], function() {
	'use strict';

	/**
	 */
	return {
		/**
		 * Returns the CFE's reportees list
		 */
		dailyCashReport:['dailyCashReportService','$rootScope',function(dailyCashReportService,$rootScope){
			return dailyCashReportService.getOpeningAmount($rootScope.productType).then(function(data){
				return data[0];
			});
		}],

		cashReceipt:['dailyCashReportService','$rootScope',function(dailyCashReportService,$rootScope){
			return dailyCashReportService.getCashReceipt($rootScope.productType).then(function(data){
				return data[0];
			});
		}]
	};
});
