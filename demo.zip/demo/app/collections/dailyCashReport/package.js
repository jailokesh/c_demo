define([], function() {
'use strict';
   require.config({
      //    baseUrl:'/sales.chola.com/',
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'dailyCashReport': 'app/collections/dailyCashReport/dailyCashReport',
          'dailyCashReportService': 'app/collections/dailyCashReport/services/dailyCashReportService',
          'dailyCashReportController': 'app/collections/dailyCashReport/controllers/dailyCashReportController',
          'dailyCashHistoryController': 'app/collections/dailyCashReport/controllers/dailyCashHistoryController',
          'dailyCashHOController': 'app/collections/dailyCashReport/controllers/dailyCashHOController',
          'receiptsPopupController':'app/collections/dailyCashReport/controllers/receiptsPopupController',
          'dailyCashReportResolver':'app/collections/dailyCashReport/resolvers/dailyCashReportResolver',
          'sharedPackage' : 'app/common/shared/package'
      },
      shim: {
    	  'dailyCashReport': ['angular', 'angular-ui-router','dailyCashReportResolver'],
    	  'dailyCashReportService':['dailyCashReport'],
          'dailyCashReportController': ['dailyCashReportService'],
          'dailyCashHistoryController' : ['dailyCashReportService'],
          'dailyCashHOController' : ['dailyCashReportService'],
          'receiptsPopupController':['dailyCashReportService']
      }
   });
   return function(callback){
	   requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs([ 'dailyCashReportController','dailyCashHistoryController','dailyCashHOController', 'receiptsPopupController' ], callback);
			});
		});
   };
});