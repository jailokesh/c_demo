/** dailyCashReport 
 * created on : 29/5/2015
 * mapped the controller, resolver
 *  */

define(['require','dailyCashReportResolver','collectionsApp'],
   function(require,dailyCashReportResolver,collectionsApp) {
   'use strict';
   	   var baseViewUrl = 'app/collections/dailyCashReport/';
       var app = angular.module('dailyCashReport', ['ui.router','collections']);
       
       var dailyCashReport = function($stateProvider, $urlRouterProvider) {
           $stateProvider
               .state('collections.dailyCashReport', {
            	   name : 'collections.dailyCashReport',
           		   url : 'dailyCashReport',
                   views: {
                      'mainContent': {
                           templateUrl: baseViewUrl + 'dailyCashReport.html',
                           controller: 'dailyCashReportController',
                           resolve: dailyCashReportResolver
                       }
                   },
   					data:{'headerText':'EOD DCR',
   						'stateActivity' : ['COL_EOD_DCR']
                    }
               }).state('collections.dailyCashReportHistory', {
            	   name : 'collections.dailyCashReportHistory',
           		   url : 'dailyCashReport/history',
                   views: {
                      'mainContent': {
                           templateUrl: baseViewUrl + '/partials/dailyCashReportHistory.html',
                           controller: 'dailyCashHistoryController'                          
                       }
                   },
   					data:{'headerText':'History',
   						'stateActivity' : ['COL_EOD_DCR']
                    }
               }).state('collections.dailyCashManualReceipt', {
            	   name : 'collections.dailyCashManualReceipt',
           		   url : 'dailyCashReport/manualReceipt',
                   views: {
                      'mainContent': {
                           templateUrl: baseViewUrl + '/partials/dailyCashManualReceipt.html',
                           controller: 'dailyCashHOController'                          
                       }
                   },
   					data:{'headerText':'Edit DCR',
   						'stateActivity' : ['COL_EOD_DCR_EDIT']
                    }
               });  
       };
       app.config(['$stateProvider', '$urlRouterProvider',dailyCashReport]);
       return app;
  });
