define([ 'require', 'constants', 'utility' ], function(r, constants, utility) {
	'use strict';
	var Enumvalues = utility.Enumvalues;
	var ValueAndText = utility.ValueAndText;
	var backDatedReceiptDays = 3;
	var REPAYMENT_CHARGE = "Repayment Charges";
	var CROSSSELL_CHARGE = "Cross Sell Charges";
	var LOAN_CHARGE = "Loan processing fees";
	var INITIALPAYMENT_CHARGE = "Initial payments";
	var MAX_CASH_LIMIT_PER_DAY = 195000;
	return {
		BACK_DATED_RECEIPT_DAYS : backDatedReceiptDays,
		PROCESSING_FEE : 5,
		SEARCH_LIMIT : 4,
		LEGAL_STOCK_SEARCH_LIMIT : 7,
		HEAD_OFFICE : 'Head Office',
		CUSTOMER_TYPES : [ 'Existing', 'New', 'Dealer', 'Buyer' ],
		HEAD_OFFICE_BRANCH_ID : "3",
		BOOK_CONDITION : "Good Condition",
		VALUATION__DAY_CHECK : 90,
		REPAY_MODES : [ {
			'id' : 'RC',
			'text' : 'RC',
			'documentID' : 277
		}, {
			'id' : 'INVOICE',
			'text' : 'Invoice',
			'documentID' : 280
		}, {
			'id' : 'INSURANCE',
			'text' : 'Insurance',
			'documentID' : 278
		} ],

		CENCEL_RECEIPT_SEARCH_OPTIONS : [ {
			type : "Receipt No",
			value : "receiptNo",
			placeHolder : "Enter Receipt No"
		}, {
			type : "Cheque No",
			value : "chequeNo",
			placeHolder : "Enter Cheque No"
		}, {
			type : "Agreement No",
			value : "agreementNo",
			placeHolder : "Enter Agreement No"
		}, {
			type : "Dealer Agreement No",
			value : "ta",
			placeHolder : "Enter Dealer Agreement No"
		}, {
			type : "Manual Receipt No",
			value : "manual",
			placeHolder : "Enter Manual Receipt No"
		} ],

		BUYER_RECEIPT_SEARCH_OPTIONS : [ {
			type : "All",
			value : "all",
			placeHolder : ""
		}, {
			type : "Receipt No",
			value : "receiptNo",
			placeHolder : "Enter Receipt No"
		}, {
			type : "Agreement No",
			value : "agreementNo",
			placeHolder : "Enter Agreement No"
		} ],
		BUYER_RECEIPT_FILTER_OPTIONS : [ {
			label : "Verified",
			value : "APPROVED",
			selected : false		
		}, {
			label : "Not Verified",
			value : "PENDING",
			selected : false
		} ],
		QUERY_MANAGEMENT_HO_OPTION : [ {
			label : "Verified",
			value : "true",
			selected : true		
		}, {
			label : "Not Verified",
			value : "false",
			selected : true
		} ],
		AMT_TYPE_OPTIONS : [ {
			type : "Total Outstanding",
			value : "totalOS",
			placeHolder : "Total Outstanding"
		}, {
			type : "EMI OD",
			value : "totalEMIODAmount",
			placeHolder : "EMI OD"
		}, {
			type : "Gross Value",
			value : "grossValue",
			placeHolder : "Gross Value"
		}],
		AMT_TYPE_LEGAL_OPTIONS : [{
			type : "EMI OD",
			value : "totalEMIODAmount",
			placeHolder : "EMI OD"
		},{
			type : "Gross Value",
			value : "grossValue",
			placeHolder : "Gross Value"
		}],

		REPO_STAGE_TYPE : [ {
			id : 'AS',
			value : 'Auction Sale-GB'
		}, {
			id : 'TPS',
			value : 'Thirdparty Sale-GB'
		}, {
			id : 'RF',
			value : 'Refinance'		
		}, {
			id : 'RA',
			value : 'Reactivation'
		}, {
			id : 'SLM',
			value : 'Settlement'
		}, {
			id : 'TS',
			value : 'Thirdparty Sale'
		}],

		REPO_BUYER_INDIVIDUAL : ['Aadhar No','Driving License','Voter ID','Passport'],

		REPO_BUYER_CORPORATE : ['TIN','Sales Tax Registration','Certificate of Incorporation','CIN','TAN'],

		HE_HL_RECEIPT_TYPES : [ {
			id : 'OD',
			value : 'OD',
			activityID : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS' ]
		}, {
			id : 'IMD',
			value : 'IMD',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			id : 'INS',
			value : 'INS',
			activityID : [ 'COL_MI_INS_RENEWAL' ]
		}, {
			id : 'FORECLOSURE',
			value : 'FORECLOSURE',
			activityID : [ 'COL_FORECLOSURE_RECEIPTING' ]
		}, {
			id : 'SALE',
			value : 'SALE',
			activityID : [ 'COL_SALE_RECEIPTING' ]
		}, {
			id : 'EMD',
			value : 'EMD',
			activityID : [ 'COL_EMD_RECEIPTING' ]
		}, {
			id : 'RPDC',
			value : 'RPDC',
			activityID : [ 'COL_RPDC_COLL_PAYMENT_CONVERSION' ]
		}, {
			id : 'PART PAYMENT',
			value : 'PART PAYMENT',
			activityID : [ 'COL_FORECLOSURE_RECEIPTING' ]
		}, {
			id : 'ADVANCE EMI',
			value : 'ADVANCE EMI',
			activityID : [ 'COL_FORECLOSURE_RECEIPTING' ]
		} ],

		VF_RECEIPT_TYPES : [ {
			id : 'OD',
			value : 'OD',
			activityID : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS' ]
		}, {
			id : 'IMD',
			value : 'IMD',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			id : 'INS',
			value : 'INS',
			activityID : [ 'COL_MI_INS_RENEWAL' ]
		}, {
			id : 'INS-LEAD',
			value : 'INS-LEAD',
			activityID : [ 'COL_MI_INS_RENEWAL' ]
		}, {
			id : 'FORECLOSURE',
			value : 'FORECLOSURE',
			activityID : [ 'COL_FORECLOSURE_RECEIPTING' ]
		}, {
			id : 'TA',
			value : 'TA',
			activityID : [ 'COL_TA_RECEIPTING' ]
		}, {
			id : 'SALE',
			value : 'SALE',
			activityID : [ 'COL_SALE_RECEIPTING' ]
		}, {
			id : 'EMD',
			value : 'EMD',
			activityID : [ 'COL_EMD_RECEIPTING' ]
		}, {
			id : 'RPDC',
			value : 'RPDC',
			activityID : [ 'COL_RPDC_COLL_PAYMENT_CONVERSION' ]
		}, {
			id : 'PDD',
			value : 'PDD',
			activityID : [ 'COL_PDD_COLLECTION' ]
		}, {
			id : 'SHORTFALL',
			value : 'SHORTFALL',
			activityID : [ 'COL_SHORTFALL_RECOVERY' ]
		} ],

		VF_MANUAL_RECEIPT_TYPES : [ {
			id : 'OD',
			value : 'OD',
			type : 'common',
			activityID : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS' ]
		}, {
			id : 'IMD',
			value : 'IMD',
			type : 'common',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			id : 'INS',
			value : 'INS',
			type : 'common',
			activityID : [ 'COL_MI_INS_RENEWAL' ]
		} /*
			 * , { id : 'TA', value : 'TA', type : 'common', activityID : [ 'COL_TA_RECEIPTING' ] }
			 */],
		HEHL_MANUAL_RECEIPT_TYPES : [ {
			id : 'OD',
			value : 'OD',
			type : 'common',
			activityID : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS' ]
		}, {
			id : 'IMD',
			value : 'IMD',
			type : 'common',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			id : 'INS',
			value : 'INS',
			type : 'common',
			activityID : [ 'COL_MI_INS_RENEWAL' ]
		} ],
		PL_RECEIPT_TYPES : [ {
			id : 'OD',
			value : 'OD',
			activityID : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS' ]
		}, {
			id : 'FORECLOSURE',
			value : 'FORECLOSURE',
			activityID : [ 'COL_FORECLOSURE_RECEIPTING' ]
		} ],
		SEARCH_BY : [ {
			name : 'Agreement Number',
			value : 'agreementNo',
			type : 'common'
		}, {
			name : 'CIFID',
			value : 'cifID',
			type : 'common'
		}, {
			name : 'Vehicle Number',
			value : 'vehicleNo',
			type : 'common'
		}, {
			name : 'Customer Name',
			value : 'customerName',
			type : 'common'
		}, {
			name : 'Mobile Number',
			value : 'mobileNo',
			type : 'common'
		}, {
			name : 'Third party Mobile Number',
			value : 'thirdPartyMobileNo',
			type : 'common'
		}, {
			name : 'Policy Number',
			value : 'policyNo',
			type : 'ins'
		}, {
			name : 'IMD-VF-Applicant Name',
			value : 'customerName',
			type : 'imd',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'IMD-VF-Mobile Number',
			value : 'mobileNo',
			type : 'imd',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'IMD-HEHL-Application ID',
			value : 'formNo',
			type : 'imd',
			product : 'hehl',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'IMD-HEHL-Mobile Number',
			value : 'mobileNo',
			product : 'hehl',
			type : 'imd',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'IMD-VF-LEADID',
			value : 'leadID',
			type : 'imd',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'INS-LEADID',
			value : 'leadID',
			type : 'ins-lead',
			activityID : [ 'COL_IMD_RECEIPTING' ]
		}, {
			name : 'TA-Dealer ID',
			value : 'dealerAgreementNo',
			type : 'ta',
			activityID : [ 'COL_TA_RECEIPTING' ]
		}, {
			name : 'TA-Dealer Agreement Number',
			value : 'agreementNo',
			type : 'ta',
			activityID : [ 'COL_TA_RECEIPTING' ]
		}, {
			name : 'TA-Dealer Name',
			value : 'customerName',
			type : 'ta',
			activityID : [ 'COL_TA_RECEIPTING' ]
		}, {
			name : 'PAN Number',
			value : 'panCardNo',
			type : 'common'
		}, {
			name : 'DOB',
			value : 'DOB',
			type : 'common'
		}, {
			name : 'Non Agreement',
			value : 'NonAgreement',
			type : 'common'
		}, {
			name : 'Closed Agreement',
			value : 'ClosedAgreement',
			type : 'closed'
		}, {
			name : 'Vishesh ID / Parent Agreement No',
			value : 'vishesh',
			type : 'vishesh'
		}, {
            name : 'Trip Loan - Agreement No',
            value : 'trip',
            type : 'trip'
        } ],

		PRODUCT_TYPES : [ {
			id : '1',
			value : 'VF'
		}, {
			id : '2',
			value : 'HE'
		}, {
			id : '3',
			value : 'HL'
		} ],

		ALPHABETS : [ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'A1', 'B1', 'C1', 'D1', 'E1', 'F1', 'G1', 'H1', 'I1', 'J1', 'K1', 'L1', 'M1', 'N1', 'O1', 'P1', 'Q1', 'R1', 'S1', 'T1', 'U1', 'V1', 'W1', 'X1', 'Y1', 'Z1', 'A2', 'B2', 'C2', 'D2', 'E2', 'F2', 'G2', 'H2', 'I2', 'J2', 'K2', 'L2', 'M2', 'N2', 'O2', 'P2', 'Q2', 'R2', 'S2', 'T2', 'U2', 'V2', 'W2', 'X2', 'Y2', 'Z2', 'A3', 'B3', 'C3', 'D3', 'E3', 'F3',
				'G3', 'H3', 'I3', 'J3', 'K3', 'L3', 'M3', 'N3', 'O3', 'P3', 'Q3', 'R3', 'S3', 'T3', 'U3', 'V3', 'W3', 'X3', 'Y3', 'Z3' ],
		PAYER_TYPE : {
			Applicant : 'CUSTOMER',
			ThirdParty : 'THIRD PARTY'
		},
		DAILY_BOOK_STATUS : {
			STATUS1 : "WITHUSER",
			STATUS2 : "WITHBRANCH"
		},

		/** Work Plan constants STARTS */
		WORK_PLAN : {
			PRODUCT_TYPES : [ 'VF', 'HE', 'HL' ],
			ITZ_CHARGE_NAME : "ITZChargeName",
			CHARGE_TYPE_EMI : "EMI",
			CHARGE_TYPE_FVC : "FVC",
			CHARGE_TYPE_CBC : "CBC",
			CHARGE_TYPE_AVC : "AFC",
			WORK_LEVEL : "level",
			HIERARCHY_COLOR : {
				level0 : '#FFF',
				level1 : '#eef9fe',
				level2 : '#e1f4fd',
				level3 : '#ceecfa',
				level4 : '#b8e5fa',
				level5 : '#8ed8f8'
			}
		},
		/** Work Plan constants ENDS */

		/** Manual Reallocation constants STARTS */
		REALLOCATION_VALUES : {
			SEGEMENTATION_GREEN : [ 'Ist emi', 'Rolled back pool', 'Rolled forward pool', 'Stabilised pool' ],
			SEGEMENTATION_ORANGE : [ 'A', 'B', 'C', 'D' ],
			SEGEMENTATION_RED : [ 'Write off', 'Legal', 'Insurance pending', 'Guarantor', 'Fresh Flow', 'Fresh Flow into NPA', 'Opening NPA', 'Rolled back pool', 'Rolled forward pool', 'Stabilised pool' ],
			WORKPLAN_GREEN : [ '3', '9', '10', '12', '15', '20', '23' ],
			WORKPLAN_ORANGE : [ '4', '6', '8', '10', '12', '14', '20', '23', '26' ],
			WORKPLAN_RED : [ '6', '8', '10', '12', '17', '20' ],
			BUCKET_TYPE : [ '0-30 Non-Delinquent', '0-30 Delinquent', 'X', '31-61', '62-91', '92-122', '123-152', 'Fresh NPA 153-183', 'Fresh NPA 184-214', 'Opening NPA 215+' ],
			ROLL_BACK_TYPE : [ 'Roll Forward', 'Roll Back', 'Normalized', 'Stabilized' ],
			TARGET_SEARCH : [ {
				name : 'Employee ID',
				value : 'userId'
			}, {
				name : 'Employee Name',
				value : 'userName'
			} ],
			EMPLOYEE_SEARCH : [ {
				name : 'CFE ID',
				value : 'userId'
			}, {
				name : 'CFE Name',
				value : 'userName'
			} ],
			CASE_SEARCH : [ {
				name : 'Agreement No',
				value : 'agreementNo'
			}, {
				name : 'CIF ID',
				value : 'cifid'
			} ],
			TO_CFE : "CFE",
			USER_ID : 'userId',
			USER_NAME : 'userName',
			AGREEMENT_NO : 'agreementNo',
			CIF_ID : 'cifid',
			PLACEHOLDER_CFE_ID : 'CFE ID',
			PLACEHOLDER_EMPLOYEE_ID : 'Employee ID',
			PLACEHOLDER_CFE_NAME : 'CFE Name',
			PLACEHOLDER_EMPLOYEE_NAME : 'Employee Name',
			PLACEHOLDER_AGREEMENT : 'Agreement No',
			PLACEHOLDER_CIF_ID : 'CIF ID',
			PLACEHOLDER_REPORTEES_STATE : 'CFE ID / CFE Name',
			PLACEHOLDER_AGREEMENTS_STATE : 'Agreement No / CIF ID',
			REPORTEES_STATE : 'reportees',
			AGREEMENTS_STATE : 'agreements',
			AGREEMENTS : 'AGREEMENTS',
			ALL_REPORTEES_STATE : 'allReportees',
			MIN_ZERO : 0,
			MIN_ONE : 1,
			MAX_TEN : 10,
			MAX_FIVE : 5,
			ORANGE_COLOR : 'orange',
			RED_COLOR : 'red',
			GREEN_COLOR : 'green',
			REFER : 'refer',
			ALLOCATE_TO_CFE : 'ALLOCATE_TO_CFE',
			BACK_STATE_AGREEMENTS : 'aggreementsDiv',
			BACK_STATE_ALL_USERS : 'allUserDiv'
		},
		ALERT : 'Alert',
		SUCCESS : 'success',
		CONFIRM : 'Confirm',
		LOAD_SELECTED_AGREEMENTS : 'app/collections/manualReallocation/partials/selectedAgreements.html',
		LOAD_ALLOCATION_CONFIRM_POPUP : 'app/collections/manualReallocation/partials/reallocateConfirmPopup.html',
		LOAD_REALLOCATION_CONTROLLER : 'reallocationPopupController',
		LOAD_SELECTED_CFE : 'app/collections/manualReallocation/partials/selectedCFE.html',
		/** Manual Reallocation constants ENDS */

		/** Target Setting constants STARTS */
		MONTHS_FILTER : [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August','September','October', 'November', 'December' ],
		DATE : 'date',
		DATE_FILTER : "dd MMMM yyyy",
		DATE_MONTH_FILTER : "MMMM",
		DATE_YEAR_MONTH_FILTER : "yyyy-MM",
		DATE_YEAR_FILTER : "yyyy",
		DATE_MON_FILTER : 'MM-dd-yyyy',
		DATE_FILTER_STANDARD : 'dd-MM-yyyy',
		TARGETS : {
			FOCUSTARGETID : 'focusTargetId'
		},
		/** Target Setting constants ENDS */

		REGULAR_EXPRESSION : {
			PINCODE : constants.REGULAR_EXPRESSION.pincode,
			MOBILE_NO : constants.REGULAR_EXPRESSION.mobileNo,
			DRIVING_LIC: /^[a-z]{2}[0-9]{2}[a-z]{1,2}[0-9]{4}$/i,
			MOBILE_NO_11DIGIT : /^[0789]\d{10}$/,
			RECEIPT_NO : /^[BT]{1}[A-Za-z0-9]+$/,
			ACK_NO : /^[A-Za-z0-9]+$/,
			INSTRUMENT_NO : /^[0-9]{6,9}$/,
			NUMBER : /^\d+$/,
			COMMENT : /^[A-z0-9 ]{3,250}$/,
			VEHICLE_NUMBER : /^[a-zA-Z]{2}[0-9]{1,2}(?:[a-zA-Z])?(?:[a-zA-Z]*)?[0-9]{1,4}$/,
			NAME : constants.REGULAR_EXPRESSION.numberSpecialCharValidation,
			ALPHANUMERIC : constants.REGULAR_EXPRESSION.alphaNumeric,
			IFSC_CODE : /[A-Z|a-z]{4}[0][0-9|A-Z|a-z]{6}$/,
			MICR_NO : /^[0-9]{9}$/,
			RECEIPT_OR_CHEQUE : /^(([BT]{1}[A-Za-z0-9]{16})|([0-9]{6,9})|([A-z0-9]{7,16}))$/,
			PAN_NO : /[A-Z]{5}[0-9]{4}[A-Z]{1}/,
			DOBold : /^\d{2}\-\d{2}\-\d{4}$/,
			DOB : /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$/,
			ALPHABETS : /^[A-Za-z]+$/,
			AGREEMENT_NO : /^[A-Za-z0-9]+$/,
			LEADID : /^[a-z|-|A-Z|0-9|\-\s]*$/,
			NUMBER_ONLY : constants.REGULAR_EXPRESSION.number,
			DOOR_NO : /^([A-Za-z0-9 ]+[-/][A-Za-z0-9 ]+[-/]{0,1}[A-Za-z0-9 ]*|[A-Za-z0-9 ]+)$/,
			STREET_NAME : /^([0-9]+[A-Za-z ]+[A-Za-z0-9,' ]*|[A-Za-z ]+[0-9,'A-Za-z ]*)$/,
			GST:/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/
		},
		LMS_RECEIPT_MODE_TYPES : {
			'Cheque' : [ {
				'key' : 'Select',
				'value' : 'Select'
			}, {
				'key' : 'agreementNo',
				'value' : 'Agreement Number'
			}, {
				'key' : 'chequeNo',
				'value' : 'Instrument Number'
			}, {
				'key' : 'receiptNo',
				'value' : 'Receipt Number'
			} ],
			'DD' : [ {
				'key' : 'Select',
				'value' : 'Select'
			}, {
				'key' : 'agreementNo',
				'value' : 'Agreement Number'
			}, {
				'key' : 'chequeNo',
				'value' : 'Instrument Number'
			}, {
				'key' : 'receiptNo',
				'value' : 'Receipt Number'
			} ],
			'POS' : [ {
				'key' : 'Select',
				'value' : 'Select'
			}, {
				'key' : 'agreementNo',
				'value' : 'Agreement Number'
			}, {
				'key' : 'receiptNo',
				'value' : 'Receipt Number'
			}, {
				'key' : 'posTxnID',
				'value' : 'TXN ID'
			} ],
			'RTGS' : [ {
				'key' : 'Select',
				'value' : 'Select'
			}, {
				'key' : 'agreementNo',
				'value' : 'Agreement Number'
			},{
				'key' : 'receiptNo',
				'value' : 'Receipt Number'
			},  {
				'key' : 'utrNo',
				'value' : 'UTR Number'
			} ],
			'ONLINE_PAYMENT' : [ {
				'key' : 'Select',
				'value' : 'Select'
			},  {
				'key' : 'agreementNo',
				'value' : 'Agreement Number'
			}, {
				'key' : 'receiptNo',
				'value' : 'Receipt Number'
			},{
				'key' : 'transactionIdentifier',
				'value' : 'Transaction ID'
			} ]
		},
		ONLINE_PAYMENT_FEATURES : {
			'showLoader' : true,
			'showPGResponseMsg' : false,
			'showDownloadReceipt' : false,
			'enableInstrumentRegistration' : false,
			'payDetailsAtMerchantEnd' : false,
			'authDetailsAtMerchantEnd' : false,
			'payWithSavedInstrument' : false,
			'enableExpressPay' : false,
			'enableInstrumentDeRegistration' : false,
			'showSIConfirmation' : false,
			'hideSIConfirmation' : false,
			'expandSIDetails' : false,
			'hideSavedInstruments' : false,
			'enableSI' : false,
			'siDetailsAtMerchantEnd' : false,
			'showSIResponseMsg' : false
		},
		ERROR_MSG : {
			ERROR_MESSAGE : 'Error',
			INVALID_RECEIPT_NO : 'Invalid Receipt/Cheque Number',
			INVALID_ACK_NO : 'Invalid Acknowledgement No',
			INVALID_NUMBER : 'Invalid numbers',
			INVALID_MOBILE_NO : 'Invalid Contact Number',
			INVALID_INSTRUMENT_NO : 'Invalid Instrument Number',
			INVALID_COMMENT : 'Invalid Comment',
			INVALID_NAME : constants.ERROR_MSG.invalidName,
			INVALID_AGREEMENT_NO : 'Invalid Agreement Number',
			INVALID_VEHICLE_NO : 'Invalid Vehicle Number',
			INVALID_IFSCCODE : 'Invalid IFSC Code',
			INVALID_MICR_NO : 'Invalid MICR Number',
			INVALID_UTR_NO : 'Invalid UTR Number',
			INVALID_POLICY_NO : 'Invalid Policy Number',
			INVALID_AMOUNT : 'Invalid Amount',
			INVALID_SELECT : 'Invalid option',
			INVALID_PAN_NO : 'Invalid Pan Number (First 5 alphabets followed by 4 digits and 1 alphabet)',
			INVALID_APPLICATION_NO : 'Invalid Application No',
			INVALID_DOB : 'Invalid DOB',
			INVALID_LEAD : 'Enter a valid LEAD ID',
			INVALID_ACCNO : "Invalid Account No",
			INVALID_GST:"GST No is invalid format (first two digits should be state code followed by digits 3 – 12 represent PAN number, one number , Z, one number)",

			MANUAL_RECEIPT_VALIDATION : "Enter a Valid Manual Receipt No",
			RECEIPT_BOOK_NOT_ASSIGNED : "Entered receipt book is not allocated to any user cannot proceed",
			VALID_SEARCH : "Please enter a valid search value",
			VALIDATE_DATE : "Select a Valid Manual Receipt Date",
			VALIDATE_RECEIPT_NO : "Enter a valid Manual Receipt No to proceed further.",
			CITY_NO_MAPPING : "No state and pincode is mapped with this city",
			PINCODE_NO_MAPPING : "No State and City is mapped for the entered Pincode",
			VALIDATE_REMARKS : "Enter remarks to cancel the acknowledgement.",
			VALIDATE_UPLOAD_IMG : "Kindly upload the image correct formate.Ex:JPEG,PNG",
			REMARKS_TO_CANCEL : "Enter remarks to cancel the receipt",
			LMS_RECEIPTCANCELLATION_INITIATED : "LMS receipt cancellation request has been raised already for this receipt. Approval is in progress",
			RECEIPTCANCELLATION_INITIATED : "Receipt cancel request has been raised already for this receipt. Approval is in progress",
			RECEIPTMODIFICATION_INITIATED : "Receipt modification request has been raised already for this receipt. Approval is in progress",
			UPLOAD_IMG_CANCEL_RECEIPT : "Please upload a cancelled receipt image",
			MANUAL_RECEIPT_NOT_MATCH : "Entered manual receipt no and selected agreement's product does not match. Cannot proceed receipting.",
			MANUAL_RECEIPT_NOT_MATCH_IMD_HEHL : "Entered manual receipt no and selected application's product does not match. Cannot proceed receipting.",
			MANUAL_RECEIPT_NOT_MATCH_IMD_VF : "Entered manual receipt no and selected lead product does not match. Cannot proceed receipting.",
			LEAD_LOAN_CHECK : "The Lead does not contain the loan details. Please complete the process and try again",
			NO_MARGIN_AMT : "The selected lead does not contain Marginal Amount, Cannot proceed furhter.",
			SUBMIT_PDD : "Please collect all the PDD documents from customer",
			AGREEMENT_REPO : "This agreement is marked for Repossession.",
			AGREEMENT_HAS_OD : "This agreement has OD amount, cannot procced further",
			FC_REQUEST_PENDING : "Foreclosure cannot be done for this agreement since an approval is required",
			FC_LETTER_EXPIRED : "The validity of the foreclosure letter has expired , please initiate a new request to proceed further",
			RECEIPT_FORECLOSED : "Foreclosure has already been done for this agreement",
			RECEIPT_CHANGE_CONFIRM : "Are you sure want to change the receipt type? You will lose the entered data.",
			FORECLOSURE_INITIATE_CHECK : "This Agreement has been foreclosed already.",
			AMOUNT_CHECK : "Please enter amount in the amount collected field",
			EMI_DATE_CHECK : "The EMI Re-payment date should not match with selected Agreement",
			BUYER_CHECK : "The Entered vendor type is not a buyer. Please enter a valid vendor ID",
			BUYER_ID_CHECK : "The Entered ID is not a buyer. Please enter a valid Buyer ID",
			INVALID_IFSC : "Enter a valid 11 digit IFSC code",
			INVALID_MICR : "Enter a valid MICR code",
			SBI_ACCOUNT_NO_PROMPT : "Please ask the customer to provide SBI account",
			BACK_NAVIGATION : "Do you want to go back to previous screen?",
			PAN_VALIDATION_NA : "Currently not able to validate PAN No. Please remove the PAN No. and proceed",
			PDD_FORECLOSURE : "Cannot Foreclose, Please Submit all the PDD documents before Foreclose.",
			INVALID_RPDC_AMT : "RPDC Amount is not valid",
			INVALID_BUYER : "Enter valid Buyer ID",
			NO_AGREEMENT_SELECTED : "No Agreement has been selected, Please select atleast one agreement",
			NO_SECTION_SELECTED : "No Section has been selected, Please select atleast one section",
			INVALID_IMG_FORMAT : "Kindly upload the image correct formate.Ex:JPEG,PNG",
			PRINT_CONFIRMATION : "Are you sure you want to close without printing the receipt?",
			CLOSE_CONFIRMATION : "Are you sure you want to close?",
			EMD_REFUND_INITIATED : "EMD-Refund has been initiated. Request has been sent to CSM",
			INVALID_RECEIPT_EMD : "Enter a valid EMD receipt ID",
			BUYER_NOT_MATCH : "Given buyer ID is not matching with the receipt buyer ID",
			SELECT_OPTION : "Please select an option",
			ENTER_DATA : "Please enter value",
			INVALID_DATE : "Please enter valid date",
			SELECT_RECEIPT : "Please select a receipt",
			UPLOAD_CSV_CHECK : "Please upload a file in CSV format",
			DAMAGED_CHECK : "This book has already been submitted for a damaged book approval",
			INVALID_BOOK_NO : "Please enter a valid Book number",
			ENTER_BOOK_NO : "Please enter Book Number",
			INVALID_DAILY_RETURN : "Your retention request approved.Please submit ReceiptBook next day",
			SELECTED_AGREEMENTS : "Are you sure, want to cancel the selected Agreement(s)?",
			SELECTED_CFE_AGREEMENTS : "Are you sure, want to cancel the selected CFE (s)?",
			RESET : "Are you sure you want to reset?",
			EDIT : "Are you sure you want to edit?",
			SF_LETTER_EXPIRED : "The validity of the shortfall waiver letter has expired",
			SELECT_RECORD : "Please Select any Record",
			SELECT_RECEIPT_BOOK : "Please Select Receipt Book",
			INVALID_ALLOTED_BOOKS : "Please allot valid book(s)",
			INVALID_COURIER_NAME : "Please enter a valid CourierName",
			SELECT_AFTER_ALLOT : "Please select any Record after allotting book(s)",
			SELECT_AFTER_COURIER : "Please select any Record after entering Courier details",
			MANDATORY_FIELDS : "Fields are mandatory",
			NO_BOOKS_BRANCH : "No books in Branch Stock",
			NO_BOOKS_HO : "No books in Head office Stock",
			REMARK_MANDATORY : "Remark(s) is Mandatory",
			BOOK_ALREADY_SELECTED : "Receipt Book Already Selected",
			USERID_MISSING : "UserId missing",
			INVALID_LAST_RECEIPT_NO : "LastUsedReceiptNo is not valid",
			SELECT_CFE_ID_DOWNLOAD : "Please select CFE ID to download allocation",
			SELECT_CFE_ID : "Please enter a valid CFE ID",
			UPLOAD_CHALLAN_IMG : "Please upload challan image",
			UPLOAD_FAKENOTE_IMG : "Please upload fake note/memo image",
			UPLOAD_DAMAGEDINST_IMG : "Please upload damaged instrument image",
			ENTER_FAKENOTE_AMT : "Fake Note Amount cant be zero",
			INVALID_FAKENOTE_AMT : "Fake Note Amount cant be greater than challan amount",
			ENTER_DAMAGEDINST_AMT : "Please upload damaged instrument image",
			INVALID_DAMAGEDINST_AMT : "Damaged Instrument Amount cant be greater than challan amount",
			ENTER_SEARCY_BY : "Please select search by",
			SELECT_CHALLAN_DATE : "Please select the Physical Challan Date",
			INVALID_PHYSICAL_CHALLANNO : "Enter a valid physical challan number",
			SELECT_BANK : "Please select bank",
			ENTER_INSTRUMENT_NO : "Please enter a valid instrument number",
			SELECT_BANKANDBRANCH : "Select bank/branch name",
			SELECT_BATCH : "Please choose a batch to approve",
			PAYMENTLETTER_STATUS : "Part Payment letters have not been collected for the batch(es) ",
			INVALID_EMP_ID : "Please enter a valid Employee ID",
			INVALID_DATE_RANGE : "Please select valid From/To date",
			EDIT_IN_PROGRESS : "Edit is in progress",
			SELECT_CHALLAN_OR_CHEQUE : "Please choose a challan/cheque",
			INVALID_RECEIPT_STATUS : "Please check/raise query against all the receipts to proceed with challan",
			SELECT_ERROR : "Please select an error",
			UNHOLD_CONFIRM : "Are you sure you want to unhold Agreements?",
			UPDATE_CONFIRM : "Are you sure you want to update legal stock?",
			UPDATE_CONFIRM_HOLD : "Are you sure you want to update legal hold?",
			LETTER_SAVE_FAILED : 'Letter saving failed',
			LETTER_PREVIEW_GENERATION : 'Letter preview failed',
			LEGAL_CASE_INITIATED : "Legal case request has been initiated successfully",
			LEGAL_COMPL_INITIATED : " request has been initiated successfully",
			BACK_DATED_RECEIPT : "The manual receipt is older than " + backDatedReceiptDays + " days. An approval will be triggered for the same",
			ENTER_PU_AMOUNT : 'Please enter Pick up Amount',
			ENTER_PTP_AMOUNT : 'Please enter PTP Amount',
			ENTER_PTP_LOCATION : 'Please enter PTP Location',
			ENTER_LOCATION : 'Please enter Location',
			INVALID_TIME : 'Please enter valid Time',
			ENTER_FAMILY_NAME : 'Please enter Family person Name',
			INVALID_DETAILS : 'Please enter valid Details',
			INVALID_TEXT : 'Please enter valid Text',
			MARK_GROUP_AGREEMENTS : 'Do you want the same contact recording to be marked for all group agreements?',
			APPINTMENT_ALREADY_EXISTS : 'Appointments already exists for selected time interval. Click Ok if you want to overlap \n or Cancel to enter other Date and Time',
			CANNOT_COMPLETE_RECORDING : ' You cannot complete recording',
			CLOSE_WITHOUT_RECORDING : "Are you sure you want to close without recording?",
			INVALID_EMPLOYEE_ID : "Please enter valid Employee ID",
			ENTER_ALL_VALUES : "Please enter all the values",
			UNIQUE_BID_RANK : "Please Enter unique value for Bid Rank",
			LEGAL_COMP_DONE : " already done. You can't initiate again ",
			CASE_CLOSED : "Case already closed",
			AUCTION_WITHOUT_REPORT : "Are you sure you want to submit Auction details without uploading report?",
			CANCEL : "Are you sure you want to cancel?",
			PROCEED : "Are you sure you want to proceed?",
			REQUEST_DOCS : 'Please select documents to be requested',
			DISPATCH_DOCS : 'Please select documents to be dispatched',
			ACK_DOCS : 'Please select documents to be acknowledged',
			REJ_DOCS : 'Please select documents to be rejected',
			VAL_SEC : 'Legal Section is not valid ',
			ERR_HISTORY : "No stages are available for the selected caseID",
			CHEQUE_ON_HOLD : "Cheque payment for this agreement is hold, please try other payment option",
			DD_ON_HOLD : "DD payment for this agreement is hold, please try other payment option",
			CANCEL_RECEIPT : "Are you sure want to cancel the receipt?",
			ADDRESS_UPDATE_WITHOUT_PROOF : "Proof is mandatory for address change in LMS. Do you still want to proceed?",
			INVALID_DOCUMENTS_SEND_OPTIONS : "Previous documents were sent to the branch/HO Legal. Please send documents to the same location",
			RECEIPT_APPROVAL_REJECTED : "Approval request is rejected for the last entered back dated receipt. Do you want to re-initiate?",
			RECEIPT_APPROVAL_PENDING : "Approval is pending for last entered manual receipt. Cannot proceed with receipting.",
			RECEIPT_PUNCHED_ALREADY : "Entered Receipt number already punched in the system.",
			AGREEMENT_DETAILS_NOT_FOUND : "Agreement Details are not found. Please try again later ",
			THIRD_PARTY_UPDATE_EXISTING : "Are you sure you want to continue with the existing Third Party Address ?",
			NO_MAPPING_FOUND : "No Mapping found ",
			INVALID_CHEQUE_BOUNCE : "Cheque Bounce cannot be done for this CaseID ",
			SELECT_CHEQUES : "Please select Cheque(s) to Bounce ",
			INSTRUMENT_IMG_UPLOADED : "Instrument image has been saved successfully",
			RECEIPT_UPDATED : "Receipt has been saved succesfully",
			CHANGES_LOST_MSG : "Your changes will be lost   " + "Do you want to proceed?",
			REALLOCATE_ERR : "Not able to allocate cases to the same reportee",
			INVALID_TOTAL_NO_OF_CHEQUES : "The cheque details entered cannot be greater than the total number of cheques",
			INVALID_TOTAL_NO_OF_MICR : "Total number of MICR cheques you entered is not matching with the MICR cheques details entered",
			UNIQUE_CHEQUE_NO : "Please Enter unique cheque number ",
			TA_AGR_CHECK : "Please enter a valid Dealer Agreement No",
			NOT_DEALER_AGR : "Entered agreement is Dealer agreement, cannot view the details",
			TA_POS_CHECK : "Principal Outstanding amount cannot be greater than it's overdue amount",
			MANDATE_DOC_CHECK : "Upload the mandate document",
			ALERT_MANUAL_RECEIPT : "This option is to cancel unused Manual Receipts. Please search with 'Receipt No' to cancel other receipts",
			RTGS_INVALID_MSG : "RTGS payment option is not available for the entered ",
			NO_APPROVER_FOUND : "There is no approver available for this request. Please contact your manager/ admin to include the approver in the system.",
			PDC_NOT_FOUND : "PDC informations are not available for this agreement cannot proceed RPDC",
			PDD_ERROR_OCCUR : "Please fix all the validation errors and submit it again",
			HAS_ERROR_HANDSOFF : "Handsoff approval failed. One or more batches have validation errors. Please resolve to proceed.",
			CHOOSE_CANCEL_REPRINT : "Please select cancel/modify or reprint option",
			CANCEL_RECEIPT_ACCESS : "User do not have access to cancel / modify the receipts",
			REPRINT_RECEIPT_ACCESS : "User do not have access to reprint receipts",
			PAN_FAILED : "PAN verification failed. Please enter a valid PAN Number",
			INSTRUMENT_IMG_VALIDATION : "Upload Instrument image to cancel the receipt",
			FC_WAIVER_PEDNING : "Foreclosure waiver request is pending for this agreement cannot foreclosure",
			LA_APPROVAL_PEDNING : "Foreclosure Linked Agreement request is pending for this agreement cannot foreclosure",
			FC_WAIVER_PEDNING_APP : "Foreclosure waiver request is already raised for this agreement. Cannot proceed further",
			LA_APPROVAL_PEDNING_APP : "Foreclosure Linked Agreement request is already raised for this agreement. Cannot proceed further",
			NEXT_LEVEL_MANAGERS : "No users defined in system for escalate",
			REQUEST_HANDLED : "Escalation is not possible as the selected request is approved/rejected",
			INV_AMT_EXCD : "Fee paid amount shall not exceed fee agreed amount",
			EXP_AMT_EXD : "Fee paid amount should be equal to total expense amount",
			NOTARISED_MSG : "There are one or more notarized documents. The docs will be sent to HO Legal!",
			CIF_ID_NOT_FOUND : "CIF ID is not found for this agreement. Cannot create appointment.",
			REMARKS_MANDATORY : "Remarks field mandatory!",
			NOT_ELIGILBLE_RPDC : "This agreement is not eligible for RPDC collection",
			NON_RPDC_CUSTOMER : "The customer is not a PDC customer. You cannot proceed further",
			NOT_SHORT_FALL_CASE : "This is not a Shortfall case",
			AGREEMENT_CLOSED : "This agreement has been closed already.",
			DUPLICATE_RECEIPT : "Receipt No is already exists in DB",
			DUPLICATE_ACKNOLEDGEMENT : "Acknowledgement No is already exists in DB",
			WAIVER_INITIATED : "Waiver request has been initiated successfully. This has been sent for an approval.",
			INTEREST_TILL_DATE_COMPARISON : "Interest till date should be equal to current date for Foreclosure receipt",
			INTEREST_TILL_DATE_VALIDATION : "Interest till date changed, please click simulate button again before submit",
			CHEQUE_LENGTH : "Cheque Number cannot be less than 6 digits",
			CHEQUE_PENDING : "One or more cheques are with status Pending. Waiver cannot be initiated",
			CHEQUEBOUNCE_CONFIRM : "Are you sure you want to cancel",
			CONFIRM_LEGAL_RESEND : 'Are you sure you want to send the selected documents?',
			RECEIPT_EXISTS : "A receipt was already punched with the same amount for this customer. Do you still want to proceed ?",
			CONTACT_REC_NA_PL : "Contact Recording is not applicable for PL agreements.",
			LEGAL_NA_PL : "Legal initiation is not applicable for PL agreements.",
			LEGAL_NA_VISHESH : "Legal initiation is not applicable for Vishesh / Trip loan agreements.",
			WAIVER_NA_VISHESH : "Waiver initiation is not applicable for Vishesh / Trip loan agreements.",
			FOR_WAIVER_NA_VISHESH : "Forclosure Waiver initiation is not applicable for Vishesh / Trip loan agreements.",
			SURRENDER_NA_VISHESH : "Surrender Expense initiation is not applicable for Vishesh / Trip loan agreements.",
			INVALID_RECEIPT_CHEQUE_NO : "Provide a valid Receipt/Cheque/DD Number!",
			CHEQUE_DD_SELECT : "Please select atleast one option from Mode of Payment",
			FC_NET_RECEIVABLE_CHECK : "Collected amount should not be less than the Net Receivable amount",
			CORPORATE_NA_PL : "Corporate Legal Initiation is not applicable for PL agreements.",
			CORPORATE_NA_VISHESH : "Corporate Legal Initiation is not applicable for Vishesh / Trip loan agreements.",
			AGR_CLOSED : "This agreement is Closed. You cannot proceed with Receipting",
			AGR_CANCELLED : "This agreement is Cancelled. You cannot proceed with Receipting",
			INVALID_AGR : "Entered Agreement No is not valid. Cannot proceed further",
			VERIFY_EMAIL : "Please verify the E-Mail attachment to proceed",
			VERIFY_PROOF : "Please verify the proof image to proceed",
			AGREEMENT_EXIST : "Entered Agreement is already in the list",
			PRIMARY_AGR_NOT_ALLOCATED : "Please allocate amount to the primary agreement before selecting the non-linked agreement",
			PRIMARY_AGR_NOT_ALLOCATED_SUBMIT : "Amount has not been allocated to primary agreement, receipting cannot be done only with non linked agreement.",
			LINKED_AGR_SELECTED : "Amount has not allocated to Primary Agreement. You will lost the entered data. Are you sure want to proceed?",
			EMD_APPROVAL_PENDING : "Since EMD receipt is pending for approval, Sale receipt cannot be done for this agreement",
			SALE_EMD_SWITCH : "Amount collected is equal or greater than approved sale amount. You can only do SALE receipting. Are you sure want to proceed?",
			FC_NET_NOT_MATCH : "The total net receviable amount does not match with simulation amount.",
			VERIFY_LMS_RECEIPT : "Please verify the LMS cancelled receipt to proceed",
			ONLINE_PAYMENT_PENDING : "Online Payment has already been pending for the same agreement. Do you want to punch a new receipt again ?",
			CLOSED_BOUNCE_NA : "Cheque Bounce cannot be initiated for Closed Agreement",
			DELETE_RULE_CONFIRMATION : "Are you sure you want to delete existing Repo Rule ?",
			UPDATE_LETTER_COUNT_CONFIRMATION : " Are you sure you want to update Letter Count ?",
			CHOLA_MS_POLICY_EXPIRED : "Max Renewal date is less than the today’s date, cannot proceed with renewal activity",
			CHOLA_MS_DATA_NOT_FOUND : "CholaMS renewal details are not found for the selected agreement. Cannot proceed INS receipting.",
			INVALID_AADHAR : "AADHAR No should be 12 digits numeric",
			INVALID_PASSPORT : "Invalid Passport No (first digit alphabet followed by 7 numbers)",
			INVALID_TAN : "TAN No is invalid format (first 4 alphabets followed by 5 numbers and 1 alphabet)",
			INVALID_TIN : "TIN No is invalid format (should be 11 digit numeric)",
			INVALID_CIN : "CIN No is invalid format (first letter L or U followed by 5 numbers, 2 aplhabets, 4 numbers, 3 alphabets and 6 numbers)",
			INVALID_DL : "Invalid Driving License No",
			INVALID_VOTER : "Voter ID is invalid format (first 3 alphabets followed by 6-9 numbers",
			KYC_VERIFICATION : "Kindly verify the buyer data, following details matching with an existing buyer.Do you want to update with existing buyer ",
			VERIFY_KYC_PROOF : "Please verify the buyer Pan Image and KYC document before submit",
			NORMAL_WAIVER_INVALID : "Normal waiver is pending for this agreement, further OD receipting will cancel the existing waiver",
			CASH_AMT_RESTRICT_OTHER_CHAGRES : 'You cannot collect total charges in "others" greater than 49,999 per month in cash. Please collect through CHEQUE/DD/POS/RTGS.',
			CASH_AMT_RESTRICT_OTHER_CHAGRES_EMD : "You cannot collect  cash greater than Rs.49,999  from a buyer for the agreement no AGREEMENTNO. Please collect through DD / POS / RTGS / Cheque.",
            REPO_MARKING_REMOVE_REQUEST :"You cannot remove this vehicle no, since further process has been initiated by the Chola branch",
            INVALID_SALE_EMD_AGR : "Sale Receipt cannot be done. This is not a valid sale agreement.",
			TA_AGR_CLOSED : "This agreement is Closed. You cannot proceed with Receipting",
			OTAL_OS_ZERO: "You cannot proceed with Receipting. The total outstanding is zero.",
			TA_AGR_CANCELLED : "This agreement is Cancelled. You cannot proceed with Receipting",
			VISHESH_TOTAL_OS_ZERO: "You cannot proceed with Receipting. The total outstanding is zero.",
			SALE_REFUND_INITIATED : "This agreement is Initiated for Sale Refund. You cannot proceed with Receipting",
			SHORTFALL_CHILDAGR : "Child/Topup agreements are not allowed for shortfall receipting, please try again with parent agreement",
			IS_PROFIT_AGR_CHECK : "You cannot  Initiate Shortfall Waiver for this Profit case",
			IS_PROFIT_SOA_CHECK : "You cannot Download Shortfall SOA for this Profit case",
            RECEIPT_CANCELLATION_VALIDATION : "Receipt cancellation approval is STATUS for this receipt. Cannot proceed further.",
        	DUPLICATE_RESTRICT : 'Document has been requested already hence cannot raise request',
			BORROWER_DEVIATION : 'Case is being filed against borrower but borrower availability has been confirmed as not available hence the same will go for deviation approval. Do you want to proceed. If yes provide deviation reasons',
       		RETURNED_DOCS : 'Please select documents to be returned',
       		AGREEMENT_MANDATORY : 'Please select atleast one Agreement No.',
       		WANT_TO_INITIATE:". Do you still want to initiate?",
            CASE_INIT_FAILED:"Case Initiation failed",
            CHOOSE_CASE_LOC:"Choose a Case Filing Location",
            CHOOSE_DOC_LOC:"Choose a Document Dispatch Location",
            RECEPIENT_MANDATORY:"Recipient Name is Mandatory",
            CASE_DOC_LOC_DIFF:"Case Filing Location and Document Dispatch Location are different. Do you want to proceed?",
            CASE_SUCCESS:"Case Initiated Successfully",
            AGR_BLOCKED_MSG:"The agreements are blocked from case initiation",
            NO_AGR_TO_DOWNLOAD:"No Agreements to download",
            DOWNLOAD_AGREEMENTS_CONFIRM:"Are you sure, you want to download All Agreements",
            SELECT_AFTER_PAGINATION:"The selection made will not be available after pagination.",
            CASE_DOC_HOLEGAL:"One or more Case Filing/ Document Dispatch Location is HO_LEGAL.Do you want to select Local Branch ?",
            CASEFILINGLOCATIONEDIT:"You are about to change the 'Case Filing Location or Dispatch Location' Do you want to Proceed?",
            MIN_MAX_MANDATORY_MSG:"Minimum Amount and Maximum Amount are Mandatory for an amount category",
            VERNACULAR_MSG:"IS THE DOCUMENT IN VERNACULAR AND IF TRANSLATION HAS BEEN PROVIDED. IF NOT UPLOAD THE SAME ALSO",
            BORROWER_AVAIL_MAND:"Borrower available field is Mandatory",
            BORROWER_NOT_AVAIL_MSG:"This cases is auto rejected by the system since 'No Borrower Available'.If you still want to initiate legal Action Please Enter deviation remarks and proceed.",
        	VEHICLE_AVAIL_MAND:"Vehicle available field is mandatory",
        	VEHICLE_NOT_AVAIL_MSG:"This cases is auto rejected by the system since 'No Vehicle Available'.If you still want to initiate legal Action Please Enter deviation remarks and proceed.",
        	PURSUED_MANDATORY:"Being Pursued or Not field is Mandatory",
        	ARBITRATOR_MAND:"Arbitrator's Name is Mandatory",
        	INITIATE_OTHER_SEC:"Do you want to initiate some other section for the same Agreements ?",
       		SAMPLE_TEMPLATE_DWND_SUCC:"Sample template Downloaded successfully",
       		CLOSE_CONFIRM:"Are you sure you want to close without initiating Legal Case", 
       		BRANCH_ID_MISSING:"Branch ID is missing for one or more Records",
       		NO_CASE_TO_DOWNLOAD:"No Case to download",
			DOWNLOAD_CASES_CONFIRM:"Are you sure, you want to download All Cases",
			SUB_SECTION_CHANGE:"Are you sure want to change the sub section of Legal Case ?",
			CHOOSE_CASE_SECTION:"Choose a Legal Section",
			ACTIVE_TO_CLOSE_MSG:"Agreement Status Changed. Cannot be Processed",
			COPY_OF_DOCUMENT:"Copy of document shouldn't be more than Rs.750",
			RATE_RESET_CHARGES:"Reset rate charges should be 1% of POS plus 18% GST"
        },

		SUCCESS_MSG : {
			SUCCESS_SUBMIT : 'Successfully Submitted',
			SUCCESS_REJECT : 'Successfully Rejected',
			SUCCESS_UPDATE : 'Successfully Updated',
			SUCCESS_RECALL : 'Successfully Recalled',
			SUCCESS_RETURN : 'Successfully Returned',
			SUCCESS_DELETE : 'Successfully Deleted',
			SUCCESS_REINIT : 'Successfully Re-Initiated',
			REQUEST_SUCCESS_SUBMIT : 'Request Submitted Successfully',
			CUSTOMER_PHOTO_UPLOAD : 'Customer photo uploaded successfully',
			DAMAGED_SUBMIT_SUCCESS : "Damaged Book details sent for approval successfully",
			DETAILS_SUBMIT_SUCCESS : "Details modified successfully",
			POD_SUBMIT_SUCCESS : "POD details updated successfully",
			RECEIPT_CHECK : "Selected receipt(s) are checked",
			CHALLAN_CHECK : "Challan check is successful",
			QUERY_RAISED : "Query raised successfuly",
			TARGET_SET : "Target set successfully",
			CREATE_CORPORATE_CASE : "Created Corporate Case :",
			APPROVAL_REQUEST : "Approval request triggered successfully",
			SALE_REFUND_APPROVAL_REQUEST : "Sale Refund Approvals initiated successfully",
			SALE_REFUND_REINITIATE_REQUEST : "Sale Refund Approvals Re-Initiated successfully",
			BOOK_RETURN : "Book returned to CFE successfully",
			BOOK_ACCEPT : "Book accepted successfully",
			SUCCESS_AUCTION_DETAILS : "Auction details submitted successfully",
			CHILD_CASE : "Child case request has been initiated successfully",
			EXPENSE : "Expense details are updated successfully",
			WITHDRAW_CASE : "Request is successfully initiated for case withdrawal",
			CLOSE_CASE : "Case has been closed successfully",
			REOPEN : "Case has been reopened successfully",
			FILE_CASE : "Case has been filed successfully",
			UPDATE_CORP : "Updated Corporate Case successfully",
			CORP_CHILD_CASE : "Corporate Child case request has been initiated successfully",
			CORP_CLOSE_CASE : "Closed Corporate case successfully",
			IS_CHILD : "Child case is available for the selected case",
			EXIST_REOPEN : "Case has been reopened already",
			CURRES_ADDRESS_SUCCESS : "Current Address details has been updated successfully",
			PERRES_ADDRESS_SUCCESS : "Permanent Address details has been updated successfully",
			OFFICE_ADDRESS_SUCCESS : "Office Address details has been updated successfully",
			THIRDPARTY_ADDRESS_SUCCESS : "Third party address details has been updated successfully",
			THIRDPARTY_ADDRESS_REQUEST : "A request is initiated for updating the thirdparty address details",
			DELETE_MAN_RECEIPT : "Manual Receipt has been deleted successfully",
			CORP_REOPEN_CASE : 'Reopened Case - ',
			NEXT_LEVEL_ESCALATION : "Request is successfully escalated to the chosen managerial level",
			CASE_TRACK_UPDATE : "Case Tracking Details updated successfully",
			RECEIPT_UPDATE_MSG : "Receipt has been updated sucessfully.",
			RECEIPT_UPDATE_APPROVAL_MSG : "Approval has been initiated since the ",
			REFERENCE_NO_UPDATE : "Approval has been initiated for Reference No has changed",
			LA_POST_SUCCESSFULLY : "Foreclosure Linked Agreement Details have been submitted successfully. This has been sent for an approval.",
			RBM_REQUEST : "Approval has been initiated for Receipt Book request",
			WITHDRAWN_STAGE : "Please WITHDRAWN the current case.",
			ADVOCATE_FEE_CHANGE : "Advocate Fee changed and it will go for DOA approval.",
			ADVOCATE_ID_CHANGE : "Advocate changed and it will go for DOA approval.",
			ADVOCATE_ID_AND_FEE_CHANGE : "Advocate Name and Fee changed and it will go for DOA approval."
		},

		POPUP_HEADER : {
			MESSAGE_STRING : 'Message',
			SUCCESS_STRING : 'Success',
			CONFIRM_STRING : "Confirm"
		},

		PAYMENT_TYPES : {
			DD : 'DD',
			RTGS : 'RTGS',
			CHEQUE : 'CHEQUE',
			NON_CHEQUE : 'CHEQUE-NON-MICR',
			LOCAL_CHQ : 'LOCAL',
			OUT_CHQ : 'OUTSTATION',
			DRAFT : 'DRAFT'
		},
		CHARGE_IDS : {
			EMI : '9',
			CBC : '8',
			AFC : '7',
			FVC : '110249',
			EXCESS : '37',
			SHORT_FALL : '110265',
			MARGINAL : '3',
			SWAP : '110038',
			PRE_AMOUNT : '110331',
			PROCESSING_FEE : '110246',
			AMT_FINANCED : '265',
			INTEREST_COMPONENT : '22',
			PART_PAY_CHARGE : '100056',
			MINI_SOA_CHARGE : '110040',
			FOUR_PERCENT_POS : '112'
		},
		LEAP_DESC_CHARGES : {
			PRIMARY_CHARGES : [ 'EMI', 'CBC', 'AFC', 'FVC' ],
			PRIMARY_CHARGE_IDS : [ '9', '8', '7', '110249','110331'],
			FC_INCLUDE_CHARGES : [ '9', '8', '7', '110249', '240', '110158', '110165', '242' ],
			SHORT_FALL : 'SHORTFALL RECOVERY'
		},
		RECEIPT_TYPE : {
			OD : 'OD',
			EMD : 'EMD',
			FORECLOSURE : 'FORECLOSURE',
			SALE : 'SALE',
			PDD : 'PDD',
			RPDC : 'RPDC',
			SWAP : 'SWAPCHARGES',
			PART : 'PART PAYMENT',
			IMD : 'IMD',
			INS : 'INS'
		},
		OTHERS : {
			APPLICANT : 'APPLICANT',
			CUSTOMER : 'CUSTOMER',
			CHALLANED : 'CHALLANED',
			OTHER_OD : 'OTHER OD',
			FULLY_DISBURSED : 'F',
			BUYER : [ "BUYERS_OF_AUCTIONED_ASSET", "BUYERS OF AUCTIONED ASSET" ],
			CUSTOMER_IMAGE_PATH : 'content/images/profile_avetar.png',
			PART_PAY_SERVICE_TAX_PERCENTAGE : 0.145,
			PART_PAY_OWN_PERCENTAGE : 0.02,
			PART_PAY_DIFF_PERCENTAGE : 0.04,
			PART_PAY_PERCENTAGE : 0.25,
			SERVICE_TAX_PERCENTAGE : 0.05,
			TA_AGR_PREFIX : 'LDF',
			TA_CHARGES : [ {
				chargeID : '265',
				chargeType : 'Principal outstanding'
			}, {
				chargeID : '22',
				chargeType : 'Interest'
			} ],
			PART_PAY_CHARGES : [ 'Part Payment Amount', 'Part Payment Charge', 'Service Tax' ],
			EXCLUDE_OTHER_CHARGES : [ '37' ],
			MAX_CHEQUE_EXPIRY_DAY : 85,
			RTGS_VALUE_DATE_DAYS_RANGE : 60,
			POS_VALUE_DATE_DAYS_RANGE : 3,
			REPO_MARKED : 'REPO',
			FC_POS_PERCENTAGE : 0.04,
			MAX_CASH_LIMIT_PER_DAY : MAX_CASH_LIMIT_PER_DAY,
			BUYERS : "BUYERS_OF_AUCTIONED_ASSET"
		},
		EMIT_MESSAGE : {
			TEN_LAKHS : 'CASH_TENLAKH_APPROVAL',
			PAN_APPROVE : 'PAN_APPROVAL',
			CANNOT_FORECLOSE : 'CANNOT_FORECLOSE',
			SWAP_OPTION : 'SWAP_SELECTED_OPTION'
		},
		NONEMPANELAGENTS : ["NON-EMPANELED-REPO"],
		PLACEHOLDER_TEXT : [ {
			type : 'agreementNo',
			value : 'Enter Agreement No',
			maxLength : '18',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'cifID',
			value : 'Enter Customer Identification No',
			maxLength : '20',
			capitalize : false
		}, {
			type : 'applicationNumber',
			value : 'Enter Application No',
			maxLength : '18',
			capitalize : false
		}, {
			type : 'vehicleNo',
			value : 'Enter Vehicle No',
			maxLength : '15',
			capitalize : false
		}, {
			type : 'customerName',
			value : 'Enter Customer Name',
			maxLength : '50',
			capitalize : false
		}, {
			type : 'customername',
			value : 'Enter Customer Name',
			maxLength : '50',
			capitalize : false
		}, {
			type : 'mobileNo',
			value : 'Enter Mobile No',
			maxLength : '11',
			capitalize : false
		}, {
			type : 'thirdPartyMobileNo',
			value : 'Enter Thirdparty Mobile No',
			maxLength : '11',
			capitalize : false
		}, {
			type : 'policyNo',
			value : 'Enter policy No',
			maxLength : '20',
			capitalize : false
		}, {
			type : 'leadID',
			value : 'Enter Lead ID',
			maxLength : '50',
			capitalize : false
		}, {
			type : 'dealerAgreementNo',
			value : 'Enter Dealer ID',
			maxLength : '18',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'ta',
			value : 'Enter Dealer Agreement No',
			maxLength : '18',
			pattern : '^[A-Za-z0-9_]+$',
			capitalize : true
		}, {
			type : 'policyNo',
			value : 'Enter policy No',
			maxLength : '20',
			capitalize : false
		}, {
			type : 'DOB',
			value : 'Enter DOB (dd-mm-yyyy)',
			maxLength : '25',
			capitalize : false
		}, {
			type : 'panCardNo',
			value : 'Enter PAN No',
			maxLength : '10',
			capitalize : false
		}, {
			type : 'phoneno',
			value : 'Enter Mobile No',
			maxLength : '11',
			capitalize : false
		}, {
			type : 'receiptNo',
			value : 'Enter Receipt No',
			maxLength : '20',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : "manual",
			value : "Enter Manual Receipt No",
			maxLength : '20',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'chequeNo',
			value : 'Enter Cheque No',
			maxLength : '9',
			pattern : '^[0-9]+$',
			capitalize : true
		}, {
			type : 'instrumentNo',
			value : 'Enter Cheque/DD No',
			maxLength : '9',
			pattern : '^[0-9]+$',
			capitalize : true
		}, {
			type : 'formNo',
			value : 'Enter Application No',
			maxLength : '9',
			pattern : '^[0-9]+$',
			capitalize : false
		}, {
			type : 'NonAgreement',
			value : 'Enter Reference No',
			maxLength : '25',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'ClosedAgreement',
			value : 'Enter Closed Agreement No',
			maxLength : '25',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'vishesh',
			value : 'Enter Vishes ID / Parent Agr No',
			maxLength : '18',
			pattern : '^[A-Za-z0-9]+$',
			capitalize : true
		}, {
			type : 'chequeNo',
			value : 'Enter Cheque/DD No',
			maxLength : '9',
			pattern : '^[0-9]+$',
			capitalize : true
		}, {
			type : 'posTxnID',
			value : 'Enter TXN ID / Reference No',
			pattern : '^[A-Za-z0-9]+$',
			maxLength : '22',
			capitalize : false
		}, {
			type : 'utrNo',
			value : 'Enter UTR No',
			pattern : '^[A-Za-z0-9]+$',
			maxLength : '22',
			capitalize : false
		}, {
			type : 'transactionIdentifier',
			value : 'Enter Transaction ID',
			pattern : '^[A-Za-z0-9]+$',
			maxLength : '22',
			capitalize : false
		}, {
			type : 'receiptBookNo',
			value : 'Enter Receipt Book No',
			capitalize : false
		},{
            type : 'trip',
            value : 'Enter Trip Loan Agreement No',
            maxLength : '18',
            pattern : '^[A-Za-z0-9]+$',
            capitalize : true
        }
		],
		PAGINATION_CONFIG : constants.PAGINATION_CONFIG,
		RPDC_REPAY_MODES : [ 'RPDC', 'ECS', 'ACH', 'SI' ],

		COLL_MODULE_ACTIVITIES : {
			MYCUSTOMER : 'COL_MY_CUSTOMER',
			CUSTOMER_SUMMARY : {
				PRINT_MINISTATEMENT : [ 'COL_MINI_STATEMENT_RECEIPTING' ],
				CONTACT_RECORDING : [ 'COL_RECORD_ACTION_CODE' ],
				VIEW_SUMMARY : [ 'COL_AGREEMENT_SUMMARY_PAGE' ],
				APPOINTMENT : [ 'COL_VIEW_CALENDAR' ],
				RECEIPTING : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS', 'COL_EMD_RECEIPTING', 'COL_SALE_RECEIPTING', 'COL_IMD_RECEIPTING', 'COL_TA_RECEIPTING', 'COL_FORECLOSURE_RECEIPTING' ],
				CASEDETAILS : [ 'COL_VIEW_FINANCIAL_DETAILS', 'COL_VIEW_NON_FINANCIAL_DETAILS', 'COL_VIEW_APPROVALS' ]
			},
			CASE_DETAILS : {
				FINANCIAL_DETAILS : [ 'COL_VIEW_FINANCIAL_DETAILS' ],
				NON_FINANCIAL_DETAILS : [ 'COL_VIEW_NON_FINANCIAL_DETAILS' ],
				APPROVALS : [ 'COL_VIEW_APPROVALS' ]
			},
			RECEIPT : {
				MODIFY : [ 'COL_RECEIPT_CANCELLATION_MODIFICATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ],
				REPRINT : [ 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ],
				CANCEL : [ 'COL_RECEIPT_CANCELLATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT', 'COL_RECEIPT_CANCELLATION_MODIFICATION' ],
				WAIVER : [ 'COL_WAIVER_REQUESTS_INITIATION' ],
				TA_RECEIPT : [ 'COL_TA_RECEIPTING' ]
			},
			CHALLANING : {
				HANDS_OFF : [ 'COL_APPROVE_HANDSOFF' ],
				PENDING_RECEIPT : [ 'COL_VIEW_PENDING_RECEIPTS' ],
				CHALLAN_AUTH : [ 'COL_CFE_CHALLAN_AUTHORIZATION' ],
				TELLER_CHALLAN : [ 'COL_TELLER_CHALLANING' ]
			},
			BATCHING : {
				GENERATE_BATCHES : [ 'COL_CREATE_BATCHES' ]
			},
			RECEIPT_BOOK : {
				HISTORY : [ 'COL_RECEIPT_BOOK_ISSUANCE_HISTORY' ],
				REQUEST : [ 'COL_REQUEST_RECEIPT_BOOKS_USERWISE' ]
			},
			REPO : {
				REPO_AGENT : [ 'COL_REPO_AGENT_QUEUE' ]
			},
			CHEQUE_BOUNCE : {
				BOUNCE : [ 'COL_MARKING_A_CHEQUE_BOUNCE' ],
				HOLD_UNMARK : [ 'COL_HEHL_REMOVE_HOLD_ON_CHEQUE' ]
			},
			LEGAL : {
				REQUEST_DOCS : [ 'COL_REQUEST_FOR_LEGAL_DOCUMENTS' ],
				DISPATCH_DOCS : [ 'COL_DISPATCH_LEGAL_DOCUMENTS' ],
				DISPATCH_DOCS_BRANCH : [ 'COL_DISPATCH_LEGAL_DOCUMENTS_BRANCH' ],
				ACKNOWLEDGE_DOCS : [ 'COL_ACK_LEGAL_DOCUMENTS_SENT_BY_HO_OPS' ],
				RETURN_DOCS : [ 'COL_ACK_LEGAL_DOCUMENTS_SENT_BY_HO_OPS' ],
				PRINT_LETTER : [ 'COL_LEGAL_LETTER_GENERATION' ],
				CASE_TRACK_VIEW : ['COL_CASE_STAGE_TRACKING_VIEW']
			},TELECALLING : {
				TCM_DASHBOARD : [ 'COL_TC_MANAGER_DASHBOARD' ],
			},NM : {
				MASTERRULE_LEGAL : [ 'COL_AUTOMATION_MASTER_LEGAL_READ_WRITE' ],				
			}
		},
		PARTY_TYPE_APPLICANT : 'A',
		PARTY_TYPE_GUARANTOR : 'G',
		PARTY_TYPE_CO_APPLICANT : 'C',

		LOAD_CASE_DETAIL : 'collections.caseDetail',
		LOAD_SUMMARY_PAGE : 'collections.myCustomers.summary',
		LOAD_RECEIPT_PAGE : 'collections.receipt.eReceipt',
		THREE_MONTHS : '3',
		SIX_MONTHS : '6',
		TWELVE_MONTHS : '12',
		NINE_MONTHS : '9',
		CURRENT_ADDRESS : 'CURRES',
		PERMANENT_ADDRESS : 'PERRES',
		PERMANENT_ADDRESS_ADDED : 'PERMNENT',
		OFFICE : 'OFFICE',
		THIRDPARTY : 'ThirdParty',
		CASE_DETAILS_TABS : {
			FINANCIAL : 'Financial Details',
			NON_FINACIAL : 'Non-Financial Details',
			APPROVALS : 'Approvals Details'
		},
		FIANCIAL_TABS : {
			LOAN_DETAILS : 'Loan Details',
			REPAYMENT_HISTORY : 'Repayment History',
			RECEIPT_DETAILS : 'Receipt Details',
			OD_DETAILS : 'OD Details',
			CHEQUE_BOUNCE : 'Cheque/ECS/ACH/DD Bounce',
			PDC_ECS_HISTORY : 'PDC ECS History',
			MINI_STATEMENT : 'Mini Statement',
			REPO_STATUS : 'Repo Status',
			FOLLOW_UP_TRIALS : 'Follow up Trials',
			EXPENSE_DETAILS : 'Expense Details',
			REPAYMENT_SCHEDULE : 'Repayment Schedule',
			FORE_CLOSURE_DETAILS : 'Foreclosure Details',
			FIELD_INVESTIGATION : 'Field Investigation',
			UNDERWRITING_INFORMATION : 'Underwriting Information'
		},
		NON_FINANCIAL_TABS : {
			ASSET_DETAILS : 'Asset Details',
			PROPERTY_DETAILS : 'Property Details',
			CONTACT_INFO : 'Contact Info',
			EMPLOYMENT : 'Employment',
			INCOME_DETAILS : 'Income Details',
			BANK_DETAILS : 'Bank Details',
			INSURANCE_DETAILS : 'Insurance Details',
			LIABILITY : 'Liability',
			LEGAL : 'Legal',
			DISBURSAL_INFORMATION : 'Disbursal Information',
			REFERENCE_DETAILS : 'Reference Details',
			GUARANTOR_AND_CO_APPLICANT : 'Co-Applicant/Guarantor',
			REFERRAL_HISTORY : 'Referral History',
			ALLOCATION_HISTORY : 'Allocation History',
			SR_HISTORY : 'SR History',
			SCANNED_COPIES : 'Scanned Copies',
			TELECALLING : 'TeleCalling Status', 
			KYC_DETAILS : 'KYC Details',
			SHORTFALL_WAIVER :'Shortfall Waiver History',
			SHORTFALL_LETTER :'Shortfall Notices History',
			SHORTFALL_BREAKUP :'Shortfall Breakup'
		},
		DAYS : [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ],
		MONTHS : [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
		MY_ACTIVITY_MSG : {
			NAME : /^[a-z|-|A-Z|0-9|\-\s]*$/,
			ALREADY_EXIST : 'Appointment already exists during this time. Do you want to Proceed?',
			EXIST_APPOINTMENT : 'Are you sure, want to update the existing appointment?',
			DELETE_EXIST : 'Are you sure, want to delete the existing appointment?',
			CREATED : "Appointment created successfully",
			UPDATED : "Appointment updated successfully",
			DELETED : "Appointment deleted successfully",
			STOP_CREATE : 'Do you want to stop creating the existing appointment?',
			ERROR : 'Error',
			SUCCESS : 'success',
			CREATE : 'create',
			START : 'start',
			END : 'end'
		},
		REPO_MSG : {
			MENU_HIDE : [ 'AUCTIONEER', 'REPO_AGENT', 'YARD_EMPLOYEE' ],
			CONFIRM : 'Confirm',
			ERROR : 'Error',
			SUCCESS : 'Success',
			ALERT : 'Alert',
			WARNING : 'Warning',
			ANSWER : 'Please Answer ',
			MESSAGE : "Message",
			DATE_CONSTANT : 180,
			VEHICLE_IMAGE_COUNT : 6,
			PANINDIA_AGENT : "Are you sure you want to download PANINDIA AGENTS?",
			DOWNLOAD_AGREEMENTS : "Are you sure you want to download all the selected agreements?",
			BATTERY_CONDITION : 'Battery Condition',
			BATTERY_MAKE : 'Battery Make',
			CHOOSE_NAME : "Please choose agency name",
			SEIZURE_UPDATED : "Seizure details updated Successfully",
			SELECT_ASSET : "Please select whether the Asset is in working condition or not.",
			CONFIRM_CLOSE : "Are you sure you want to close?",
			AGENT_SUCCESS_MSG : "Repo Agents allocated successfully.",
			POD_SUCCESS_MSG : "POD details submitted successfully.",
			DUPLICATE_MSG : "Duplicate Repo Agent/Agency found",
			INTITATED_MSG : "Surrender request has been intitated successfully.",
			NOT_INTITATED_MSG : "Reposession is not initiated for the selected agreement",
			CLOSE_MSG : "Are you sure you want to close without printing letter?",
			VEHICLE_VALUATION_SUBMITTED : "Vehicle valuation details submitted successfully.",
			VEHICLE_SUBMITTED : "Vehicle details submitted successfully.",
			BUCKET_LIST : [ '0-30', '31-60', '61-90', '91-120', '121-150', '151-180', '>180' ],
			ASISWHEREIS : 'ASISWHEREIS',
			ASISWHEREISLETTER : 'ASISWHEREISLETTER',
			VEHICLE_SPOTTED : 'VEHICLE_SPOTTED',
			SURRENDER : 'SURRENDER',
			SURRENDERLETTER : 'SURRENDERLETTER',
			REPO_AGENT_ALLOCATED : 'REPO_AGENT_ALLOCATED',
			AUTHORIZATIONLETTER : 'AUTHORIZATIONLETTER',
			FINALCALLLETTER : 'FINALCALLLETTER',
			PRESEIZURELETTERTOPOLICE : 'PRESEIZURELETTERTOPOLICE',
			VEHICLE_SEIZED : 'VEHICLE_SEIZED',
			INVENTORY_SHEET_UPDATED : 'INVENTORY_SHEET_UPDATED',
			POSTSEIZURELETTER : 'POSTSEIZURELETTER',
			CONSIGNEELETTER : 'CONSIGNEELETTER',
			PRESALELETTER : 'PRESALELETTER',
			INDEMNITYLETTER : 'INDEMNITYLETTER',
			ACCEPTANCEOFSALELETTER : 'ACCEPTANCEOFSALELETTER',
			RELEASELETTER : 'RELEASELETTER',
			SALE_MARKING_AUTHORED : 'SALE_MARKING_AUTHORED',
			INITIATE_SALE : "Are you sure you want to initiate sale?",
			VEHICLE_SUCCESS_MSG : "Successfully initiated vehicle valuation.",
			NOT_INITIATE_SALE : "Sale is not initiated for the selected agreement",
			AUCTION_SUCCESS_MSG : "Successfully initiated Auction.",
			INITIATE_SALE_SUCCESS : 'Sale Initiation successfull',
			workStatus : 'workStatus',
			PRE_SALE_LETTER_PRINTED : 'PRE_SALE_LETTER_PRINTED',
			RELEASE_LETTER_PRINTED : 'RELEASE_LETTER_PRINTED',
			ACCEPTANCEOFSALELETTER_MSG : 'Acceptance of sale letter uploaded successfully',
			INDEMNITYLETTER_MSG : 'Indemnity letter uploaded successfully',
			VALUATION : 'VALUATION',
			INITIATED : 'INITIATED',
			BUYER_QUOTES : 'BUYER_QUOTES',
			DONE : 'DONE',
			ASSET_SALE : 'ASSET_SALE',
			NORMAL : 'NORMAL',
			SHORTFALLWAIVER : 'SHORTFALLWAIVER',
			SALEREFUND : 'SALEREFUND',
			Seizure : 'Seizure',
			preSale : 'preSale',
			buyerQuotes : 'buyerQuotes',
			assetSale : 'assetSale',
			Vehicle_Details : 'Vehicle Details',
			PRE_SEIZURE : 'PRE_SEIZURE',
			CHOOSE : 'Please choose a ',
			SELECT : 'Please select an option',
			NOOPTION : 'No letter type to select',
			SELECTLETTERTYPE :'Please select letter type, upload document and proceed',
			REPOAGENCY : 'REPOSSESSION_AGENTS',
			YARDAGENCY : 'YARD_MANAGERS',
			SURRENDER_REQUEST_PENDING : 'Approval request has been initiated for surrender. Cannot proceed further.',
			repoStates : {
				finalCallLetter : {
					name : 'Final Call Letter',
					value : 'FINALCALLLETTER',
					isDisabled : true,
					isOpen : false,
					letterObj : {
						imageRef : {
							imagePathReferences : []
						}
					}
				},
				repoAgent : {
					name : 'Repo Agent',
					value : '',
					isOpen : false,
					letterObj : {}
				},
				preSeizureLetter : {
					name : 'Pre-Seizure Letter Police',
					value : 'PRESEIZURELETTERTOPOLICE',
					isOpen : false,
					letterObj : {}
				},
				authorizationLetter : {
					name : 'Authorization Letter',
					value : 'AUTHORIZATIONLETTER',
					isOpen : false,
					letterObj : {}
				},
				surrenderLetter : {
					name : 'Surrender Letter',
					value : 'SURRENDERLETTER',
					surrender : false,
					isOpen : false,
					letterObj : {}
				},
				asIsWhereIsLetter : {
					name : 'As Is Where Is Letter',
					value : 'ASISWHEREISLETTER',
					isDisabled : true,
					isOpen : false,
					letterObj : {}
				}
			},
			seizureRepoStates : {
				seizureDetails : {
					name : 'Seizure Details',
					value : 'SEIZUREDETAILS',
					isDisabled : true,
					isOpen : false
				},
				postSeizureLetter : {
					name : 'Post-Seizure Letter',
					value : 'POSTSEIZURELETTER',
					isOpen : false,
					letterObj : {},
					imagePathReferences : []
				},
				consigneeLetter : {
					name : 'Consignee Letter',
					value : 'CONSIGNEELETTER',
					isOpen : false,
					letterObj : {},
					imagePathReferences : []
				},
				vehicleDetails : {
					name : 'Vehicle Details',
					value : 'VEHICLEDETAILS',
					isOpen : false,
					isEdit : true
				},
				authorizationLetter : {
					value : 'AUTHORIZATIONLETTER',
					letterObj : {}
				}
			},
			yardInventoryTabs : [{
				name : 'vehicleDocumments',
				heading : 'Vehicle Documents',
				url : 'app/collections/repossession/yardInventory/partials/vehicleDocumentsTab.html',
				isOpen : false,
				index : 0
			}, {
				name : 'vehcileDetails',
				heading : 'Vehicle Details',
				url : 'app/collections/repossession/yardInventory/partials/vehicleDetailsTab.html',
				isOpen : false,
				index : 1
			} ],
			yardMainMenu : [ {
				label : "Repo Type",
				value : "repoType",
				selected : false,
				subMenu : [ {
					label : "Seizure",
					value : "SEIZURE",
					selected : false
				}, {
					label : "As Is Where Is",
					value : "ASISWHEREIS",
					selected : false
				}, {
					label : "Surrender",
					value : "SURRENDER",
					selected : false
				}, {
					label : "Stop and Release",
					value : "STOPANDRELEASE",
					selected : false
				} ]
			}, {
				label : "Vehicle Type",
				value : "vehicleType",
				selected : false,
				subMenu : []
			} ],
			mainMenu : [ {
				label : "Repo Type",
				value : "repoType",
				selected : false,
				subMenu : [ {
					label : "Seizure",
					value : "SEIZURE",
					selected : false
				}, {
					label : "As Is Where Is",
					value : "ASISWHEREIS,ASISWHEREISWOV",
					selected : false
				}, {
					label : "Surrender",
					value : "SURRENDER",
					selected : false
				}, {
					label : "Stop and Release",
					value : "STOPANDRELEASE",
					selected : false
				}, {
                    label : "SEC 9/ROP/Legal",
                    value : "SEC9/ROP/Legal",
                    selected : false
                } ]
			}]
		},
		TCM_REPORT_TYPES : [{
			name : 'Trial Gap Report',
			value : 'trialGapReport',
			excelName:'TrialGapReport',
			activityID : [ 'COL_TRIAL_GAP_REPORT' ]
		},{
			name : 'Disposition Wise Report',
			value : 'dispositionWiseReport',
			excelName:'DispositionWiseReport',
			activityID : [ 'COL_DISPOSITION_WISE_REPORT' ]
		},{
			name : 'PU Report',
			value : 'puReport',
			excelName:'PickUpReport',
			activityID : [ 'COL_PU_TYPE_REPORT' ]
		},{
			name : 'TC Productivity Report',
			value : 'tcProductivityReport',
			excelName:'TCProductivityReport',
			activityID : [ 'COL_TC_PRODUCTIVITY_REPORT' ]
		}],
		PU_REPORT_TYPES : [{
			name : 'PickUp cases Report',
			value : 'pickupCasesReport',
			excelName:'PickUpCasesReport',
			activityID : [ 'COL_PU_COORDINATOR_REPORT' ]
		}],
		/* Reports list */
		REPORT_TYPES : [ {
			name : 'Allocation History',
			value : 'allocationhistory',
			excelName : 'AllocationHistoryReport',
			activityID : [ 'COL_ALLOCATION_HISTORY_REPORT' ]
		}, {
			name : 'Branch Delinquency',
			value : 'branchdelinquency',
			excelName : 'BranchDelinquencyReport',
			activityID : [ 'COL_BRANCH_DELINQUENCY_REPORT' ]
		}, {
			name : 'Branch Receipt',
			value : 'branchreceipt',
			excelName : 'BranchReceiptReport',
			activityID : [ 'COL_BRANCH_RECEIPTS_REPORT' ]
		}, {
			name : 'Cancelled Receipt',
			value : 'cancelledreceipt',
			excelName : 'CancelledReceiptReport',
			activityID : [ 'COL_CANCEL_RECEIPTS_REPORT' ]
		}, {
			name : 'Cash Receipt Book',
			value : 'unusedcashreceipt',
			excelName : 'CashReceiptBookReport',
			activityID : [ 'COL_UNUSED_CASH_RECEIPT_REPORT' ]
		}, {
			name : 'Cheque/DD Bounce',
			value : 'chequebounce',
			excelName : 'Cheque/DDBounceReport',
			activityID : [ 'COL_CHEQUE_BOUNCE_REPORT' ]
		}, 
		{
			name : 'CholaMS Report',
			value : 'msintreport',
			excelName : 'CholaMSReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},
		{
			name : 'Collection Report',
			value : 'collection',
			excelName : 'CollectionReport',
			activityID : [ 'COL_COLLECTION_REPORT' ]
		}, {
			name : 'Contact Recording',
			value : 'contactrecording',
			excelName : 'ContactRecordingReport',
			activityID : [ 'COL_CONTACT_RECORDING_REPORT' ]
		}, 
		/*{
			name : 'Daily Cash Report',
			value : 'dcr',
			excelName : 'DailyCashReport',
			activityID : [ 'COL_DAILY_CASH_REPORT' ]
		},*/ 
		{
			name : 'Daily Collection',
			value : 'dailycollection',
			excelName : 'DailyCollectionReport',
			activityID : [ 'COL_DAILY_COLLECTION_REPORT' ]
		}, {
			name : 'Damaged/Lost',
			value : 'damagedlost',
			excelName : 'Damaged/LostReport',
			activityID : [ 'COL_DAMAGED_OR_UNUSED_RECEIPTS_REPORT' ]
		},{
			name : 'Delay Notification',
			value : 'delaynotification',
			excelName : 'DelayNotification',
			activityID : [ 'COL_DELAY_NOTIFICATION_REPORT' ]
		}, {
			name : 'Disposition Wise Report',
			value : 'dispositionWise',
			excelName : 'DispositionWiseReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		},{
			name : 'Excess/Shortfall',
			value : 'excessshortfall',
			excelName : 'Excess/ShortfallReport',
			activityID : [ 'COL_EXCESS_OR_SHORTFALL_REPORT' ]
		},{
			name : 'GC MIS Report',
			value : 'gcMis',
			excelName : 'GCMISReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		}, {
			name : 'Monthly Bill Tracking',
			value : 'monthlybilltracking',
			excelName : 'MonthlyBillTrackingReport',
			activityID : [ 'COL_MONTHLY_BILL_REPORT' ]
		}, {
			name : 'Notice management POD details',
			value : 'nmpoddetails',
			excelName : 'NMPODDetails',
			activityID : [ 'COL_REPORT_NM_POD_DETAILS' ]
		}, {
			name : 'Notice management Rejected letters',
			value : 'nmrejectedletters',
			excelName : 'NMRejectedLetters',
			activityID : [ 'COL_REPORT_NM_REJECTED_LETTERS' ]
		},{
			name : 'Online Payment',
			value : 'onlinepayment',
			excelName : 'onlinePaymentReport',
			activityID : [ 'COL_ONLINE_PAYMENT_REPORT' ]
		}, {
			name : 'Pickup Cases Report',
			value : 'pickupCasesreport',
			excelName : 'pickupCasesReport',
			activityID : [ 'COL_PU_COORDINATOR_REPORTS' ]
		}, {
			name : 'PU Report',
			value : 'pureport',
			excelName : 'puReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		},
		/*{
			name : 'QC Reports',
			value : 'qc',
			excelName : 'QCReport',
			activityID : [ 'COL_QUALITY_CONTROL_REPORT' ]
		},*/ 
		{
			name : 'ReceiptControl',
			value : 'receiptcontrol',
			excelName : 'ReceiptControlReport',
			activityID : [ 'COL_RECEIPT_CONTROL_REPORT' ]
		}, {
			name : 'Receipts Cash',
			value : 'receiptcash',
			excelName : 'ReceiptsCashReport',
			activityID : [ 'COL_RECEIPTS_CASH_REPORT' ]
		}, {
			name : 'Receipts DD/Cheque',
			value : 'receiptcheque',
			excelName : 'ReceiptsDD/ChequeReport',
			activityID : [ 'COL_RECEIPTS_CHEQUE_REPORT' ]
		}, {
			name : 'Receipts Made',
			value : 'receiptmade',
			excelName : 'ReceiptsMadeReport',
			activityID : [ 'COL_RMR_REPORT' ]
		}, {
			name : 'Returned Receipt Books by Branch (Unacknowledged at HO)',
			value : 'rbnotacknowledgedbyho',
			excelName : 'ReturnedRBUnacknowledgedAtHOReport',
			activityID : [ 'COL_RECEIPT_BOOK_REPORT' ]
		}, {
			name : 'Receipt Book dispatched by HO (Unacknowledged at Branch)',
			value : 'rbnotacknowledgedbybranch',
			excelName : 'RBDispatchedUnacknowledgedAtBranchReport',
			activityID : [ 'COL_RECEIPT_BOOK_REPORT' ]
		},{
			name : 'Repo Marked',
			value : 'reporeport',
			excelName : 'RepoMarkedReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},{
			name : 'Repo Marking Stock',
			value : 'repostockzone',
			excelName : 'RepoMarkingStock',
			activityID : [ 'COL_REPO_MARKING_STOCK_REPORT' ]
		},/*{
			name : 'Repo Stock',
			value : 'repostockreport',
			excelName : 'RepoStockReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},{
			name : 'Repo Stock Outgo',
			value : 'repostockoutgoreport',
			excelName : 'RepoStockOutgoReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},{
			name : 'Repo Notices Sent',
			value : 'reponoticessentreport',
			excelName : 'RepoNoticesSentReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},*/{
			name : 'Sale & EMD Report',
			value : 'saleemd',
			excelName : 'Sale&EMDReport',
			activityID : [ 'COL_RMR_REPORT' ]
		},{
			name : 'TC Productivity Report',
			value : 'tcProducivityreport',
			excelName : 'tcProducivityReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		}, {
			name : 'Trial Gap Report',
			value : 'trialGapreport',
			excelName : 'trialGapReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		}, {
			name : 'Un-deposited Receipts (CFE/Agencies who have not deposited receipts at the branch, but no hands off or banked )',
			value : 'undepositednothandsoff',
			excelName : 'Un-depositedReceiptsNotHandsoffReport',
			activityID : [ 'COL_UNDEPOSITED_RECEIPTS_NOT_HANDEDOFF_REPORT' ]
		}, {
			name : 'Un-deposited Receipts (Hands off done by CFE/Agencies, but it isnot challaned)',
			value : 'undepositednotchallaned',
			excelName : 'Un-depositedReceiptsNotChallanedReport',
			activityID : [ 'COL_UNDEPOSITED_RECEIPTS_NOT_CHALLANED_REPORT' ]
		}, {
			name : 'Untouched Cases Report',
			value : 'untouchedCasesreport',
			excelName : 'untouchedCasesReport',
			activityID : [ 'COL_TC_MANAGER_REPORTS' ]
		}, {
			name : 'Vendor Renewal',
			value : 'vendorrenewal',
			excelName : 'VendorRenewalReport',
			activityID : [ 'COL_VENDOR_RENEWAL_REPORT' ]
		}, {
			name : 'Vishesh Allocation History',
			value : 'visheshallocationhistory',
			excelName : 'VisheshAllocationHistoryReport',
			activityID : [ 'COL_VISHESH_RMR_REPORT' ]
		}, {
			name : 'Vishesh Contact Recording',
			value : 'visheshcontactrecording',
			excelName : 'VisheshContactRecordingReport',
			activityID : [ 'COL_VISHESH_RMR_REPORT' ]
		}, {
			name : 'Vishesh Receipt Made',
			value : 'visheshreceiptmade',
			excelName : 'VisheshReceiptMadeReport',
			activityID : [ 'COL_VISHESH_RMR_REPORT' ]
		}, {
			name : 'Vishesh Cancelled Receipt',
			value : 'visheshcancelledreceipt',
			excelName : 'VisheshCancelledReceiptReport',
			activityID : [ 'COL_VISHESH_RMR_REPORT' ]
		}, {
			name : 'Vishesh Cheque/DD Bounce',
			value : 'visheshchequebounce',
			excelName : 'VisheshCheque/DDBounceReport',
			activityID : [ 'COL_VISHESH_RMR_REPORT' ]
		},{
			name : 'Trip Allocation History',
			value : 'tripallocationhistory',
			excelName : 'TripAllocationHistoryReport',
			activityID : [ 'COL_TRIP_LOAN_REPORTS' ]
		}, {
			name : 'Trip Contact Recording',
			value : 'tripcontactrecording',
			excelName : 'TripContactRecordingReport',
			activityID : [ 'COL_TRIP_LOAN_REPORTS' ]
		}, {
			name : 'Trip Receipt Made',
			value : 'tripreceiptmade',
			excelName : 'TripReceiptMadeReport',
			activityID : [ 'COL_TRIP_LOAN_REPORTS' ]
		}, {
			name : 'Trip Cancelled Receipt',
			value : 'tripcancelledreceipt',
			excelName : 'TripCancelledReceiptReport',
			activityID : [ 'COL_TRIP_LOAN_REPORTS' ]
		}, {
			name : 'Yard Inventory',
			value : 'yardinventory',
			excelName : 'YardInventoryReport',
			activityID : [ 'COL_YARD_INVENTORY_REPORT' ]
		},
		{
			name : 'CH Inventory',
			value : 'yardinventory',
			excelName : 'YardInventoryReport',
			activityID : [ 'COL_YARD_INVENTORY_REPORT' ]
		},
		{
			name : 'Repo Is Sellable',
			value : 'issellable',
			excelName : 'RepoIsSellableReport',
			activityID : [ 'COL_REPO_IS_SELLABLE_REPORT' ]
		},{
			name : 'Pending Request',
			value : 'pendingrequest',
			excelName : 'pendingRequest',
			activityID : [ 'COL_LEGAL_PENDING_REQUEST_REPORTS' ]
		} ,
		{
			name : 'Legal Blocked Case',
			value : 'legalblockreport',
			excelName : 'LegalBlockedCasesReport',
			activityID : [ 'COL_LEGAL_BLOCK_REPORT' ]
		} ,
		{
			name : 'Legal Document Status',
			value : 'legaldocreport',
			excelName : 'LegalDocumentStatusReport',
			activityID : [ 'COL_LEGAL_DOC_DISP_REPORT' ]
		} ,{
			name : 'Legal Deviation Cases',
			value : 'casedeviationreport',
			excelName : 'LegalDeviationReport',
			activityID : [ 'COL_LEGAL_DEVIATION_REPORT' ]
		} ,{
			name : 'Legal Automation Report',
			value : 'legalautomationreport',
			excelName : 'LegalAutomationReport',
			activityID : [ 'COL_LEGAL_BLOCK_REPORT' ]
		},{
		 	name : 'Legal System Rejected Document',
		 	value : 'docautoremovereport',
			excelName : 'SystemRejectDocReport',
		 	activityID : [ 'COL_LEGAL_DOC_SYS_REJECTED_REPORT' ]
		},{
		 	name : 'Legal Requested Document Status',
		 	value : 'legaldocreqreport',
			excelName : 'LegalDocumentRequestdReport',
		 	activityID : [ 'COL_LEGAL_DOC_REQUESTED_REPORT' ]
		},{
			name : 'Legal Case Tracking Report',
			value : 'legalcasetrackingreport',
			excelName : 'LegalCaseTrackingReport',
			activityID : [ 'CASE_TRACKING_REPORT' ]
		},{
			name : 'Sale Refund Report',
			value : 'salerefundreport',
			excelName : 'SaleRefundReport',
			activityID : [ 'COL_SALE_REFUND_REPORT' ]
		},{
			name : 'Shortfall Allocation Report',
			value : 'shortfallallocationreport',
			excelName : 'ShortfallAllocationReport',
			activityID : [ 'COL_SHORTFALL_ALLOCATION_REPORT' ]
		},{
			name : 'Shortfall Notice Report',
			value : 'shortfallnoticereport',
			excelName : 'ShortfallNoticeReport',
			activityID : [ 'COL_SHORTFALL_NOTICE_REPORT' ]
		},{
			name : 'Shortfall Efficiency Userwise Report',
			value : 'shortfallefficiencyuserwise',
			excelName : 'ShortfallEfficiencyUserwise',
			activityID : [ 'COL_SHORTFALL_EFFICIENCY_USER_REPORT' ]
		},{
			name : 'Shortfall Efficiency Agreementwise Report',
			value : 'shortfallefficiencyagreementwise',
			excelName : 'ShortfallEfficiencyAgreementwise',
			activityID : [ 'COL_SHORTFALL_EFFICIENCY_AGRMNT_REPORT' ]
		},{
			name : 'Shortfall Waiver Approval Report',
			value : 'shortfallwavierapproval',
			excelName : 'ShortfallWavierApproval',
			activityID : [ 'COL_SHORTFALL_WAIVER_APPROVAL_REPORT' ]
		}],
		USER_BASED_REPORT : {
			BRANCH_REPORT : [ 'COLL_REPORT_BRANCH' ],
			AREA_REPORT : [ 'COLL_REPORT_AREA' ],
			REGION_REPORT : [ 'COLL_REPORT_REGION' ],
			ZONE_REPORT : [ 'COLL_REPORT_ZONE' ]
		},
		REPORT_DATE_DIFFERENCE : 31,
		REPORT_TYPE_DATA : [ {
			name : 'Not Challaned',
			value : 'notchallaned'
		}, {
			name : 'Challaned image not upload',
			value : 'challanedimgnotupload'
		} ],

		/* Reports list */
		/* caseDetails */
		INSURANCE_TYPE : new Enumvalues([ new ValueAndText('LIFE', 'LIFE'), new ValueAndText('MOTOR', 'MOTOR') ]),
		HEHL_ARRAY : [ {
			label : "RPDC",
			value : "RPDC",
			selected : false
		}, {
			label : "OD",
			value : "OD",
			selected : false
		}, {
			label : "Charges",
			value : "CH",
			selected : false
		}, {
			label : "Insurance",
			value : "IR",
			selected : false
		} ],
		VF_ARRAY : [ {
			label : "PDD",
			value : "PDD",
			selected : false
		}, {
			label : "RPDC",
			value : "RPDC",
			selected : false
		}, {
			label : "OD",
			value : "OD",
			selected : false
		}, {
			label : "Charges",
			value : "CH",
			selected : false
		}, {
			label : "MIRenewals",
			value : "MI",
			selected : false
		}, {
			label : "ShortFall",
			value : "SF",
			selected : false
		} ],
		/* caseDetails */
		APPROVALS_INIT_PAGE : {
			normalWaiver : {
				pageName : 'waiverRequest',
				requestType : 'Normal',
				headerText : 'Approvals - Initiate Normal Waiver'
			},
			shortfallWaiver : {
				pageName : 'waiverRequest',
				requestType : 'shortfallwaiver',
				headerText : 'Approvals - Initiate Shortfall Waiver'
			},			
			saleRefundApproval : {
				pageName : 'saleRefundApproval',
				requestType : 'saleRefundApproval',
				headerText : 'Approvals - Initiate Sale Refund'
			},
			foreclosureWaiver : {
				pageName : 'waiverRequest',
				requestType : 'ForeClosure',
				headerText : 'Approvals - Initiate Foreclosure Waiver'
			},
			customerSurrender : {
				pageName : 'surrenderExpense',
				requestType : '',
				headerText : 'Approvals - Initiate Surrender Expense'
			},
			legalInitiation : {
				pageName : 'initiateLegal',
				requestType : '',
				headerText : 'Approvals - Initiate Legal'
			},			
			foreclosureHEHL : {
			pageName : 'foreclosureHEHL',
				requestType : '',
				headerText : 'Approvals - Initiate Foreclosure'
			},
			legalCompliance : {
				pageName : 'legalCompliance',
				requestType : '',
				headerText : 'Approvals - Legal Appeal/Compliance'
            },
			standByTeller : {
				pageName : 'standByTeller',
				requestType : 'standByTeller',
				headerText : 'Approvals - Initiate Stand By Teller'				
			},
			shortfallWaiverInitiate : {
                pageName : 'shortfallWaiverInitiate',
                requestType : '',
                headerText : 'Approvals - Initiate Shortfall Waiver'
            },
            saleRefund : {
                pageName : 'saleRefund',
                requestType : '',
                headerText : 'Approvals - Initiate Sale Refund'
			}
		},
		//removed legalInitiate from approvals
		// {
		// 	activityID : [ 'COL_INITIATE_LEGAL' ],
		// 	label : 'Initiate Legal',
		// 	type : 'legalInitiation'
		// },
		APPROVAL_ACTIVITIES : [{
			activityID : [ 'COL_INITIATE_FORECLOSURE_WAIVER' ],
			label : 'Initiate Foreclosure Waiver',
			type : 'foreclosureWaiver'
		}, {
			activityID : [ 'COL_INITIATE_SURRENDER_EXPENSE' ],
			label : 'Initiate Surrender Expense',
			type : 'customerSurrender'
		}, {			
			activityID : [ 'COL_INITIATE_NORMAL_WAIVER' ],
			label : 'Initiate Waiver',
			type : 'normalWaiver'
		}, {
			activityID : [ 'COL_INITIATE_LEGAL_APPEAL_COMPLIANCE_REQUEST' ],
			label : 'Initiate Legal Compliance/Appeal',
			type : 'legalCompliance'
		}, {
			activityID : [ 'COL_HEHL_INITIATE_FORECLOSURE' ],
			label : 'Initiate Foreclosure (HEHL)',
			type : 'foreclosureHEHL'
		},{
            activityID : [ 'COL_INITIATE_SHORTFALL_WAIVER' ],
            label : 'Initiate Shortfall waiver',
            type : 'shortfallWaiverInitiate'
        },{
            activityID : [ 'COL_INITIATE_SALE_REFUND' ],
            label : 'Initiate Sale Refund',
            type : 'saleRefund'
		} ],
		APPROVALS_GV : {
			RECEIPTBOOKISSUANCE : '',
			DAMAGEDRECEIPTBOOKS : '',
			PANCARD : 'receiptAmount',
			BACKDATEDRECEIPT : 'receiptAmount',
			RECEIPTCANCELLATION : 'receiptAmount',
			NOMEMOUPLOAD : 'fakeAmount',
			RECEIPTBOOKRETENTION : '',
			ORANGECUSTOMER : 'grossValue',
			CASHTENLAKHS : 'receiptAmount',
			EXCESSSHORTFALL : '',
			REPO : 'grossValue',
			SURRENDERCUSTOMER : 'grossValue',
			SURRENDEREXPENSE : 'totalExpenseAmount',
			SALEAPPROVAL : 'grossValue',
			LEGALCASE : 'grossValue',
			RELEASELETTER : '',
			LEGALCOMPLIANCE : 'grossValue',
			LEGALAPPEAL : 'grossValue',
			FORECLOSUREHEHL : 'foreClosureAmount',
			RTGS : 'receiptAmount',
			THIRDPARTY : '',
			REPOMARKINGLMS : 'grossValue',
			REPOWRONGMARKING : 'grossValue'
		},
		REQUEST_TYPES : {
			NORMAL : {
				template : 'waiver',
				title : 'Normal Waiver'
			},
			SHORTFALLWAIVER : {
				template : 'shortfallWaiver',
				title : 'Shortfall Waiver'
			},			
			SALEREFUND : {
				template : 'saleRefundApproval',
				title : 'Sale Refund'
			},	
			FORECLOSURE : {
				template : 'waiver',
				title : 'Foreclosure Waiver'
			},
			FORECLOSURELA : {
				template : 'foreclosurela',
				title : 'Foreclosure LA'
			},
			RECEIPTBOOKISSUANCE : {
				template : 'receiptBook',
				title : 'Receipt Book Issuance'
			},
			DAMAGEDRECEIPTBOOKS : {
				template : 'receiptBook',
				title : 'Damaged Receipt Books'
			},
			PANCARD : {
				template : 'panCard',
				title : 'PAN Card Unavailability'
			},
			BACKDATEDRECEIPT : {
				template : 'backDatedReceipting',
				title : 'Back Dated Receipting'
			},
			RECEIPTCANCELLATION : {
				template : 'panCard',
				title : 'Receipt Cancellation'
			},
			LMSCANCELLATIONRECEIPT : {
				template : 'panCard',
				title : 'LMS Receipt Cancellation'
			},
			RECEIPTMODIFICATION : {
				template : 'panCard',
				title : 'Manual Receipt Modification'
			},
			NOMEMOUPLOAD : {
				template : 'noMemoUpload',
				title : 'No Memo Upload'
			},
			RECEIPTBOOKREQUEST : {
				template : 'receiptBook',
				title : 'Receipt Book Request'
			},
			ORANGECUSTOMER : {
				template : 'orangeCustCategory',
				title : 'Orange Customer Categorization'
			},
			CASHTENLAKHS : {
				template : 'panCard',
				title : 'Cash Collection > 10 Lakhs'
			},
			EXCESSSHORTFALL : {
				template : 'eodDcr',
				title : 'EOD DCR'
			},
			REPO : {
				template : 'repoRequest',
				title : 'Repo Initiation'
			},
			SURRENDERCUSTOMER : {
				template : 'surrenderRequest',
				title : 'Repo Surrender Request'
			},
			SURRENDEREXPENSE : {
				template : 'surrenderExpense',
				title : 'Repo Surrender Expense Request'
			},
			SALEAPPROVAL : {
				template : 'saleRequest',
				title : 'Repo Sale Request'
			},
			LEGALCASE : {
				template : 'approveLegal',
				title : 'Legal Case Initiation'
			},
			REPORELEASELETTER : {
				template : 'releaseLetter',
				title : 'Release Letter Request'
			},
			SALERELEASELETTER : {
				template : 'releaseLetter',
				title : 'Release Letter Request'
			},
			LEGALCOMPLIANCE : {
				template : 'approveLegalCompliance',
				title : 'Legal Compliance'
			},
			LEGALAPPEAL : {
				template : 'approveLegalCompliance',
				title : 'Legal Appeal'
			},
			FORECLOSUREHEHL : {
				template : 'foreclosureHEHL',
				title : 'Foreclosure HEHL'
			},
			RTGS : {
				template : 'panCard',
				title : 'RTGS Receipting'
			},
			POS : {
				template : 'panCard',
				title : 'POS Receipting'
			},
			THIRDPARTY : {
				template : 'thirdPartyAddress',
				title : 'Third Party Address Change'
			},
			LEGALWITHDRAWN : {
				template : 'legalWithdrawal',
				title : 'Legal Case Withdrawal'
			},
			LEGALCHILDCASE : {
				template : 'legalChildCase',
				title : 'Legal Child Case'
			},
			DUPLICATELETTERDISPATCH : {
				template : 'noticeManagement',
				title : 'Notice Management'
			},
			NONEMPANELLEDAGENT : {
				template : 'nonEmpanelledAgent',
				title : 'Non Empanelled Agent / Seizure Charges'
			},
			REPOMARKINGLMS:{
				template : 'repoMarkingLMS',
				title : 'Repo Marking LMS' 
			},
			REPOWRONGMARKING:{  
				template : 'wrongRepoMarkingLMS',
				title : 'Wrong Repo Marking LMS' 
			},
			STANDBYTELLER : {
				template : 'standByTeller',
				title : 'Stand by Teller'
			},
			NATIVETELLER : {
				template : 'nativeTeller',
				title : 'Native Teller'
			},
			DOCUMENTWAIVER:{  
				template : 'documentWaiver',
				title : 'Document Waiver' 
			},
			LEGALREOPENCASE : {
				template : 'legalReopenCase',
				title : 'Legal Reopen Case'
			},
			DOCUMENTREQUEST :{
				template : 'duplicateDocumentRequested',
				title : 'Duplicate Document Requested' 
			},
			LEGALADVOCATECHANGE :{
				template : 'advocateApproveLegal',
				title : 'Legal Advocate Change' 
			},
			LEGALADVOCATEFEECHANGE :{
				template : 'advocateApprovalRequestFeeChange',
				title : 'Legal Advocate Fee Change' 
			},
			LEGALAGREEMENTBLOCK :{
				template : 'agreementBlockApproveLegal',
				title : 'Legal Agreement Block' 
			},
			LEGALAGREEMENTEPHOLD : {
				template : 'approveLegalEPHold',
				title : 'Legal Agreement EP Hold'
			},
			DUPLICATEDOCUMENTREQUEST : {
				template : 'duplicateDocRequest',
				title : 'Duplicate Document Request'
			}
		},
		APPLICATION_STATUS : {
			STATUS7 : "Registered",
			STATUS8 : "Initiate Termination",
			STATUS9 : "Termination Approved",
			STATUS12 : "Renewed"
		},
		ISREFINANCED : [ {
			status : "Y",
			value : "Yes"
		}, {
			status : "N",
			value : "No"
		} ],
		AGREEMENTSTATUS : [ {
			status : "A",
			value : "Active"
		}, {
			status : "C",
			value : "Closed"
		}, {
			status : "X",
			value : "Cancelled"
		}, {
			status : "NA",
			value : "Non Agreement"
		} ],
		QC_ACTIVITIES : {
			ARCHIVE_HO : [ 'COL_QUERY_ARCHIVES' ],
			RESPONSE_HO : [ 'COL_RESPOND_TO_QUERY_HO' ],
			RESPONSE_BRANCH : [ 'COL_RESPOND_TO_A_QUERY' ],
			RAISE_QUERY : [ 'COL_QUALITY_CONTROL' ]
		},
		ALLOCATION_TYPES : [ {
			label : "PDD Collected",
			value : "PDD"
		}, {
			label : "RPDC Collected",
			value : "RPDC"
		}, {
			label : "OD Collected",
			value : "OD"
		}, {
			label : "Charges Collected",
			value : "CH"
		}, {
			label : "MI Renewed",
			value : "MI"
		}, {
			label : "ShortFall Collected",
			value : "SF"
		}, {
			label : "PTP Collected",
			value : "collectedptps"
		}, {
			label : "Insurance Collected",
			value : "IR"
		} ],

		NON_DELEQUENCY_DATA : [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ],
		MY_CUSTOMER_VALUES : {
			COLLECTED_PTP : "collectedptps"
		},
		CONTACT_RECORDING : {
			FREE_TEXT : 'FREE_TEXT',
			SINGLE_VALUE_TEXT : 'SINGLE_VALUE_TEXT',
			SINGLE_VALUE_DATE : 'SINGLE_VALUE_DATE',
			SINGLE_VALUE_DATE_TIME : 'SINGLE_VALUE_DATE_TIME',
			SINGLE_VALUE_NUMBER : 'SINGLE_VALUE_NUMBER',
			SINGLE_VALUE_MOBILE_NUMBER : 'SINGLE_VALUE_MOBILE_NUMBER',
			SINGLE_VALUE_NUMBER_TEXT : 'SINGLE_VALUE_NUMBER_TEXT',
			SINGLE_CHOICE_WITH_CHECKBOX : 'SINGLE_CHOICE_WITH_CHECKBOX',
			MULTIPLE_CHOICE_WITH_CHECKBOX : 'MULTIPLE_CHOICE_WITH_CHECKBOX',
			SINGLE_CHOICE_WITH_RADIO_BUTTON : 'SINGLE_CHOICE_WITH_RADIO_BUTTON',
			LIST_ITEM : 'LIST_ITEM',
			IMAGE_WITH_MULTIPLE_CHOICE : 'IMAGE_WITH_MULTIPLE_CHOICE',
			LOAD_MY_CUSTOMER_PAGE : 'collections.myCustomers',
			LOAD_MY_ACTIVITY_PAGE : 'collections.myActivity',
			LOAD_EPAYMENT : 'collections.ePayment',
			LOAD_CASE_DETAIL : 'collections.caseDetail',
			RTP_DATE_TIME : 'Next Action Date and Time',
			PTP_DATE_TIME : 'PTP Date and Time',
			ORANGE_CUSTOMER_ACTION_CODE : 'ORANGECUSTOMER',
			PTP : 'PTP',
			RTP : 'RTP',
			PICK_UP_DATE_TIME : 'Date and Time of Pickup',
			PU : 'TC_PU'
		},
		PDD_TYPES : {
			RC : '277',
			INVOICE : '280',
			INSURANCE : '278'
		},
		SUGGESTED_RATING : [ 'A', 'B', 'C', 'D' ],
		CASE_DETAILS_RANKS : {
			'Report Ref No' : 1,
			'Name of Hirer' : 2,
			'Age' : 3,
			'Residential Address' : 4,
			'Standard of Living' : 5,
			'Martial Status' : 6,
			'Asset Value' : 7,
			'No of yrs Stayed in Current Residence' : 8,
			'Total no of interior items present' : 9,
			'Permanent Gas Connection?' : 10,
			'Property Deviation ?' : 11,
			'Co-borrower Deviation ?' : 12
		},
		AUTOINSPEKT : {
			id : "V219",
			name : 'AUTOINSPEKT'
		},
		CASE_FLAGGING : [ {
			'flagName' : 'REPO',
			'flagStatus' : false
		}, {
			'flagName' : 'LEGAL',
			'flagStatus' : false
		}, {
			'flagName' : 'THIRD PARTY',
			'flagStatus' : false
		}, {
			'flagName' : 'VIP CASE',
			'flagStatus' : false
		}, {
			'flagName' : 'ED',
			'flagStatus' : false
		}, {
			'flagName' : 'ACCIDENT',
			'flagStatus' : false
		} ],
		PENDING_TASKS : {
			'challanForAuth' : 'handsOff',
			'chequesForDisposition' : 'challaning',
			'manualReceipt' : '',
			'receiptForChallan' : 'challaning',
			'receiptForDispatch' : 'receiptsToBeDispatched',
			'repoScan' : 'repoQueue',
			'unUsedReceiptBookNotAccepted' : 'branchReturn',
			'usedReceiptBookForDispatch' : 'branchReturn',
			'usedReceiptBookNotAccepted' : 'branchReturn',
			'fakeNotesInfo' : ''
		},
		ACTION_CODES : [ {
			"name" : "PTP",
			"code" : "PTP"
		}, {
			"name" : "RTP",
			"code" : "RTP"
		}, {
			"name" : "Out of Station",
			"code" : "OUTOFSTATION"
		}, {
			"name" : "Skip Tracing",
			"code" : "SKIPTRACING"
		}, {
			"name" : "Reposition",
			"code" : "REPO"
		}, {
			"name" : "Legal",
			"code" : "LEGAL"
		}, {
			"name" : "Fraud",
			"code" : "FRAUD"
		}, {
			"name" : "Orange Customer",
			"code" : "ORANGECUSTOMER"
		}, {
			"name" : "Deal Cancelled",
			"code" : "DEALCANCELLED"
		}, {
			"name" : "Dispute",
			"code" : "DISPUTE"
		}, {
			"name" : "Customer Expired",
			"code" : "CUSTOMEREXPIRED"
		}, {
			"name" : "House Locked",
			"code" : "HOUSELOCKED"
		}, {
			"name" : "Shifted",
			"code" : "SHIFTED"
		}, {
			"name" : "Motor Insurance Pickup",
			"code" : "MOTORINSURANCEPICKUP"
		}, {
			"name" : "Topup Pickup",
			"code" : "TOPUPPICKUP"
		} ],
		CHALLAN_FILTERS : [ {
			label : "Pending",
			value : "PENDING",
			selected : true
		}, {
			label : "Completed",
			value : "COMPLETED",
			selected : true
		} ],
		GLOBAL_ATTRS_VALUES : {
			agreementNo : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Agreement No',
				maxLength : '18',
				capitalize : true
			},
			receiptNo : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Receipt No',
				maxLength : '12',
				capitalize : true
			},
			customerName : {
				patternVal : '^[A-Za-z ]+$',
				placeHolder : 'Enter Customer Name',
				maxLength : '30',
				capitalize : false
			},
			userId : {
				patternVal : '^[a-zA-Z0-9-_ ]+$',
				placeHolder : 'Enter User Id',
				maxLength : '20',
				capitalize : true
			},
			vehicleNo : {
				patternVal : '^[A-Za-z0-9-]+$',
				placeHolder : 'Enter Vehicle No',
				maxLength : '13',
				capitalize : true
			},
			courierName : {
				patternVal : '^[a-zA-Z0-9-_ ]+$',
				placeHolder : 'ENTER COURIER NAME',
				maxLength : '30',
				capitalize : false
			},
			batchID : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Batch ID/Job ID',
				maxLength : '25',
				capitalize : true
			},
			podNo : {
				patternVal : '^[a-zA-Z0-9]+$',
				placeHolder : 'ENTER POD NO',
				maxLength : '20',
				capitalize : false
			},
			postalRefNo : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'ENTER POSTAL REF NO',
				maxLength : '30',
				capitalize : false
			},
			letterType : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Letter Type',
				maxLength : '30',
				capitalize : true
			},
			'Aadhar No' : {
				patternVal : '^[0-9]+$',
				regEx : constants.REGULAR_EXPRESSION.aadharCard,
				placeHolder : 'Enter Aadhar No',
				maxLength : '12',
				capitalize : true,
				msg : "AADHAR"
			},
			'Driving License' : {
				patternVal : '[A-Za-z0-9/-]+$',
				regEx : /[A-Za-z0-9]+$/,
				placeHolder : 'Enter Driving License',
				maxLength : '30',
				capitalize : true,
				msg : "DL"
			},
			'Voter ID' : {
				patternVal : '^[A-Za-z0-9/]+$',
				regEx : constants.REGULAR_EXPRESSION.voterProof,
				placeHolder : 'Enter Voter ID',
				maxLength : '14',
				capitalize : true,
				msg : "VOTER"
			},
			Passport : {
				patternVal : '^[A-Za-z0-9/]+$',
				regEx : constants.REGULAR_EXPRESSION.passport,
				placeHolder : 'Enter Passport No',
				maxLength : '8',
				capitalize : true,
				msg : "PASSPORT"
			},
			TIN : {
				patternVal : '^[0-9]+$',
				regEx : constants.REGULAR_EXPRESSION.tinNo,
				placeHolder : 'Enter TIN No',
				maxLength : '11',
				capitalize : true,
				msg : "TIN"
			},
			'Sales Tax Registration' : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Sales Tax Registration',
				maxLength : '30',
				capitalize : true,
				regEx:/^[A-Za-z0-9]+$/
			},
			'Certificate of Incorporation' : {
				patternVal : '^[A-Za-z0-9]+$',
				placeHolder : 'Enter Certificate of Incorporation',
				maxLength : '30',
				capitalize : true,
				regEx:/^[A-Za-z0-9]+$/
			},
			CIN : {
				patternVal : '^[A-Za-z0-9]+$',
				regEx : constants.REGULAR_EXPRESSION.cin,
				placeHolder : 'Enter CIN No',
				maxLength : '21',
				capitalize : true,
				msg : "CIN"
			},
			TAN : {
				patternVal : '^[A-Za-z0-9]+$',
				regEx : constants.REGULAR_EXPRESSION.tanNo,
				placeHolder : 'Enter TAN No',
				maxLength : '10',
				capitalize : true,
				msg : "TAN"
			},
			chequeNo : {
				type : 'chequeNo',
				value : 'Enter Cheque No',
                placeHolder :'ChequeNo',
                maxLength : '9',
				pattern : '^[0-9]+$',
                capitalize : true
			},
		    utrNo :{
        		type : 'utrNo',
				value : 'Enter UTR No',
                placeHolder :'UTR No',
                pattern : '^[A-Za-z0-9]+$',
				maxLength : '22',
                capitalize : false
    			}
		},
        VISHESH_CHARGE_DETAILS:[{
            chargeType: "Total Outstanding",
            chargeAmount : "totalOS",
            actual : "amountPaid",
            chargeID : '1000000128',
            isLink: true
        },{
            chargeType: "Minimum Due",
            chargeAmount : "totalEMIODAmount",
            isLink: false
        }],
        TRIP_CHARGE_DETAILS :[ {
            chargeType: "Total Balance Outstanding",
            chargeAmount : "balanceOS",
            actual : "amountPaid",
            chargeID : '1000000128',
            isLink: false
        },
		{
			chargeType: "Total Interest Outstanding",
			chargeAmount : "interestOS",
			isLink: false
		},
		{
			chargeType: "Total Interest OD",
			chargeAmount : "totalInterestOD",
			isLink: false
		},
		{
			chargeType : "Total Principal OD",
			chargeAmount : "totalPrincipalOD",
			isLink: false
		},
		{
            chargeType : "Total AFC OD Amount",
			chargeAmount : "totalAFCODAmount",
			isLink: false
		}],
		RECEIPT_BOOK_ALLOCATION_PER_USER : 2,
		NEXT_LEVEL_ACTIONS : {
			RECOMMEND : 'RECOMMENDED',
			APPROVE : 'APPROVED'
		},
		SKIP_RECEIPT_GENERATION : [ '5389', '5390' ],
		IMD_CHARGES : [ {
			shortName : "MA",
			name : "Margin Amount",
			group : INITIALPAYMENT_CHARGE,
			chargeID : "3"
		}, {
			shortName : "FEMI",
			chargeID : "9",
			group : INITIALPAYMENT_CHARGE,
			name : "First Installment Amount (EMI amount)"
		}, {
			shortName : "PAC",
			chargeID : "110153",
			group : CROSSSELL_CHARGE,
			name : "PAC Premium"
		}, {
			shortName : "LI",
			chargeID : "110307",
			group : CROSSSELL_CHARGE,
			name : "Life Insurance Preminum"
		}, {
			shortName : "HI",
			chargeID : "110305",
			group : CROSSSELL_CHARGE,
			name : "Health Insurance Premium"
		}, {
			shortName : "MI",
			chargeID : "110147",
			group : CROSSSELL_CHARGE,
			name : "Motor Insurance Premium"
		}, {
			shortName : "COMP",
			chargeID : "110103",
			group : REPAYMENT_CHARGE,
			name : "Compensation Charges"
		}, {
			shortName : "DD",
			chargeID : "37",
			group : REPAYMENT_CHARGE,
			name : "DD charges"
		}, {
			shortName : "NPDC",
			chargeID : "110066",
			group : REPAYMENT_CHARGE,
			name : "NPDC charges"
		}, {
			shortName : "ROLL",
			chargeID : "110137",
			group : REPAYMENT_CHARGE,
			name : "Roll Over Charges"
		}, {
			shortName : "OS",
			chargeID : "37",
			group : REPAYMENT_CHARGE,
			name : "Outstation"
		}, {
			shortName : "DS",
			chargeID : "110110",
			group : REPAYMENT_CHARGE,
			name : "Dealer Subvention"
		}, {
			shortName : "DF",
			chargeID : "110108",
			group : REPAYMENT_CHARGE,
			name : "Delfund Charges"
		}, {
			shortName : "BTPP",
			chargeID : "110144",
			group : REPAYMENT_CHARGE,
			name : "BTTP"
		}, {
			shortName : "FC",
			chargeID : "37",
			group : REPAYMENT_CHARGE,
			name : "Foreclosure Charges"
		}, {
			shortName : "TA",
			chargeID : "110157",
			group : REPAYMENT_CHARGE,
			name : "Trade ADVANCE"
		}, {
			shortName : "SC",
			chargeID : "110140",
			group : LOAN_CHARGE,
			name : "Service charge"
		}, {
			shortName : "DOC",
			chargeID : "110115",
			group : LOAN_CHARGE,
			name : "Document Charges"
		}, {
			shortName : "SCERI",
			chargeID : "110156",
			group : LOAN_CHARGE,
			name : "Service(ERI) Charges"
		} ],
		ACCOUNT_TYPES : [ {
			"value" : "Savings",
			"ID" : "10"
		}, {
			"value" : "Current",
			"ID" : "11"
		} ],
		CASHTYPE : {
			'C' : 'Credit',
			'D' : 'Debit'
		},
		DAILY_CASH_REPORT : {
			DELETE_DCR_MSG : "<div><ul class='DCR_style'>" + "<li>YOU HAVE ALREADY SUBMITTED EOD DCR FOR THE DAY.</li>" + "<li>PLEASE CANCEL THE SAME TO PROCEED FURTHER.</li>" + "<li>MANUAL REFERENCE NUMBERS WILL BE REMOVED.</li>" + "</ul>" + "<div class='margin-left-15 pad-top-8 bold-text'>DO YOU WANT TO CANCEL ALREADY SUBMITTED EOD DCR?</div>" + "</div>",
			DCR_MSG : "<div><ul class='DCR_style'><li>YOU HAVE NOT COMPLETED PREVIOUS DAY EOD DCR.</li><li>PLEASE DO COMPLETE EOD DCR TO PROCEED WITH THIS ACTION.</li></ul></div>",
			SUCCESS_DELETE_EOD_DCR : 'Last generated EOD DCR has been deleted succesfully',
			DCR_APPROVAL_MSG : 'Last generated EOD DCR sent for Approval. Cash transactions cannot be proceed.',
			IGNORE_DCR_MSG : ['HO_OPS_PROCESS_SUPPORT_EXECUTIVE']
		},
		FORECLOSURE_WAIVER_CONFIG : [ {
			chargeID : '9',
			receiptChargeType : 'EMI',
			key : 'installments',
			isDisabled : false
		}, {
			chargeID : '7',
			receiptChargeType : 'AFC',
			key : 'lpi',
			isDisabled : false
		}, {
			chargeID : '8',
			receiptChargeType : 'CBC',
			isDisabled : false
		}, {
			chargeID : '110249',
			receiptChargeType : 'FVC',
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : 'POS',
			key : 'balancePrincipal',
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : 'Prepayment Penalty',
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : 'Current AFC',
			key : 'currentLpi',
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : 'Current Month Interest',
			key : 'currentLpi',
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : "Other OD",
			isDisabled : false
		}, {
			chargeID : '37',
			receiptChargeType : "Refunds",
			isDisabled : true
		}, ],
		LEGAL_AVAILABILITY_CONFIG : {
			borowerID : 'LEGAL1',
			coApplicantID : 'LEGAL2',
			guarantorID : 'LEGAL3',
			vehicleID : 'LEGAL4',
			propertyID : 'LEGAL6'
		},
		SOFT_DPD_CATEGORY : ["X","0-30","31-61","62-91"],
		HARD_DPD_CATEGORY : ["92-122","123-152","Fresh NPA 153-183","Fresh NPA 184-214","Opening NPA 215+","REPO"],
		REPO_FILTER :[
		{
			label : "Category",
			value : "catagory",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
				label : "Soft",
				value : "SOFT_DPD_CATEGORY",
				selected : false
			}, {
				label : "Hard",
				value : "HARD_DPD_CATEGORY",
				selected : false
			} ]
		}, 
		{
			label : "Allocation DPD",
			value : "allocationDPD",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
					label: 'X',
					value: 'X',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '0-30',
					value: '0-30',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '31-61',
					value: '31-61',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '62-91',
					value: '62-91',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '92-122',
					value: '92-122',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '123-152',
					value: '123-152',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Fresh NPA 153-183',
					value: 'Fresh NPA 153-183',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Fresh NPA 184-214',
					value: 'Fresh NPA 184-214',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Opening NPA 215+',
					value: 'Opening NPA 215+',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'REPO',
					value: 'REPO',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			}]

		}, {
			label : "Vehicle Category ",
			value : "vehicleCategory",
			inputType : "checkbox",
			selected : false,
			subMenu : ""
		}, {
			label : "Product Category ",
			value : "productCategory",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
				label : "All",
				value : "All",
				selected : false,
				isLegal:true
			}, {
				label : "CMF",
				value : "CMF",
				selected : false,
				isLegal:false
			}, {
				label : "VFPRIME",
				value : "VFPRIME",
				selected : false,
				isLegal:true
			}, {
				label : "HE",
				value : "HE",
				selected : false,
				isLegal:false
			}, {
				label : "EBIKE",
				value : "EBIKE",
				selected : false,
				isLegal:true
			}, {
				label : "SHUBH",
				value : "SHUBH",
				selected : false,
				isLegal:true
			}, {
				label : "TRACTOR",
				value : "TRACTOR",
				selected : false,
				isLegal:true
			}, {
				label : "SEGC",
				value : "SEGC",
				selected : false,
				isLegal:true
			}, {
				label : "PRIME",
				value : "PRIME",
				selected : false,
				isLegal:true
			}, {
				label : "SEGD",
				value : "SEGD",
				selected : false,
				isLegal:true
			}, {
				label : "SEG F",
				value : "SEG F",
				selected : false,
				isLegal:true
			}, {
				label : "HL",
				value : "HL",
				selected : false,
				isLegal:false
			}, {
				label : "2WHEELER",
				value : "2WHEELER",
				selected : false,
				isLegal:true
			}, {
				label : "SEGB",
				value : "SEGB",
				selected : false,
				isLegal:true
			}, {
				label : "CE",
				value : "CE",
				selected : false,
				isLegal:true
			},{
				label : "SEGE",
				value : "SEGE",
				selected : false,
				isLegal:true
			} ]
		}, {
			label : "Loan To Value",
			value : "loanToValue",
			inputType : "number",
			selected : false,
			subMenu : [ {
				label : "Minimum",
				value : "",
				selected : false
			}, {
				label : "Maximum",
				value : "",
				selected : false
			} ]
		},
		{
			label : "Payment Pattern",
			value : "paymentPattern",
			inputType : "checkbox",
			selected : false,
			subMenu : [ {
				label : "0/4",
				value : "0/4",
				selected : false
			}, {
				label : "1/4",
				value : "1/4",
				selected : false
			}, {
				label : "2/4",
				value : "2/4",
				selected : false
			}, {
				label : "3/4",
				value : "3/4",
				selected : false
			}, {
				label : "4/4",
				value : "4/4",
				selected : false
			} ]
		},
		{
			label : "Seasoning",
			value : "seasoning",
			inputType : "checkbox",
			selected : false,
			subMenu : [ {
				label : "0-6",
				value : [0,6],
				selected : false
			},{
				label : "7-12",
				value : [7,12],
				selected : false
			}, {
				label : "13-24",
				value : [13,24],
				selected : false
			}, {
				label : "25-30",
				value : [25,30],
				selected : false
			}, {
				label : "31-36",
				value : [31,36],
				selected : false
			}, {
				label : "36+",
				value : [36],
				selected : false
			} ]
		},{
			label : "Dispatched To",
			value : "dispatchedTo",
			inputType : "checkbox",
			selected : false,
			subMenu : [ {
				label : "Customer",
				value : "A",
				selected : false,
				disabled : false
			}, {
				label : "Co-Applicant",
				value : "C",
				selected : false,
				disabled : false
			},{
				label : "Guarantor",
				value : "G",
				selected : false,
				disabled : false
			},{
				label : "Others",
				value : "O",
				selected : false,
				disabled : false
			}  ]
		},
		{
			label : "POS Comfort",
			value : "posComfort",
			inputType : "radio",
			selected : "FALSE",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}]
		},
		{
			label : "Legal Stock",
			value : "legalStock",
			inputType : "radio",
			selected : "NA",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}, {
				label : "Not Applicable",
				value : "NA",
				selected : false
			} ]
		},{
			label : "Legal Hold",
			value : "legalHold",
			inputType : "radio",
			selected : "NA",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}, {
				label : "Not Applicable",
				value : "NA",
				selected : false
			} ]
		},{
			label : "CAU Flag",
			value : "cauFlag",
			inputType : "radio",
			selected : "NA",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}, {
				label : "Not Applicable",
				value : "NA",
				selected : false
			} ]
		},{
			label : "Contact Recording -Repo",
			value : "contactRecordingRepo",
			inputType : "radio",
			selected : "NA",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}, {
				label : "Not Applicable",
				value : "NA",
				selected : false
			} ]
		},{
			label : "Repo Approved",
			value : "repoApproved",
			inputType : "radio",
			selected : "NA",
			subMenu : [ {
				label : "Yes",
				value : "TRUE",
				selected : false
			}, {
				label : "No",
				value : "FALSE",
				selected : false
			}, {
				label : "Not Applicable",
				value : "NA",
				selected : false
			} ]
		}
		// ,{
		// 	label : "Repo Authorized",
		// 	value : "repoAuthorized",
		// 	inputType : "radio",
		// 	selected : "FALSE",
		// 	subMenu : [ {
		// 		label : "Yes",
		// 		value : "TRUE",
		// 		selected : false
		// 	}, {
		// 		label : "No",
		// 		value : "FALSE",
		// 		selected : false
		// 	}]
		// }
		],
		REPO_QUEUE_BUTTONS:{
			"SEIZURE":[{"label":"Final Call Letter","green":false,"value":"FINALCALLLETTER"},{"label":"Pre-Seizure Letter","green":false,"value":"PRESEIZURELETTER"},{"label":"Post-Seizure Letter","green":false,"value":"POSTSEIZURELETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"}],
			"NORMAL":[{"label":"Final Call Letter","green":false,"value":"FINALCALLLETTER"},{"label":"Pre-Seizure Letter","green":false,"value":"PRESEIZURELETTER"},{"label":"Post-Seizure Letter","green":false,"value":"POSTSEIZURELETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"}],
			"ASISWHEREIS":[{"label":"AS-IS-WHERE-IS Letter","green":false,"value":"ASISWHEREISLETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"}],
			"ASISWHEREISWOV":[{"label":"AS-IS-WHERE-IS Letter","green":false,"value":"ASISWHEREISWOVLETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"}],
			"SURRENDER":[{"label":"Surrender Letter","green":false,"value":"SURRENDERLETTER"},{"label":"Pre-Seizure Letter","green":false,"value":"PRESEIZURELETTER"},{"label":"Post-Seizure Letter","green":false,"value":"POSTSEIZURELETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"}],
			"STOPANDRELEASE":[{"label":"Final Call Letter","green":false,"value":"FINALCALLLETTER"},{"label":"Pre-Seizure Letter","green":false,"value":"PRESEIZURELETTER"},{"label":"Post-Seizure Letter","green":false,"value":"POSTSEIZURELETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"},{"label":"Consignee Letter","green":false,"value":"CONSIGNEELETTER"}],
            "SEC9/ROP/Legal":[{"label":"Final Call Letter","green":false,"value":"FINALCALLLETTER"},{"label":"Pre-Seizure Letter","green":false,"value":"PRESEIZURELETTER"},{"label":"Post-Seizure Letter","green":false,"value":"POSTSEIZURELETTER"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"},{"label":"Consignee Letter","green":false,"value":"CONSIGNEELETTER"},{"label":"Surrender Letter","green":false,"value":"SURRENDERLETTER"},{"label":"AS-IS-WHERE-IS Letter","green":false,"value":"ASISWHEREISLETTER"},{"label":"Release Letter","green":false,"value" : "RELEASELETTER"}],
        },
        REPO_QUEUE_DOC_TYPES:{
			"SEIZURE":[{"label":"Inventory","green":false,"value":"INVENTORY"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"},{"label":"Pre seizure/ Final call letter","green":false,"value":"PRESEIZUREFINALCALLLETTER"},{"label":"Post  seizure/ Pre Sale Letter","green":false,"value":"POSTSEIZUREFINALCALLLETTER"},{"label":"Pre intimation to police letter","green":false,"value":"PREPOLICELETTER"},{"label":"Post intimation to police letter","green":false,"value":"POSTPOLICELETTER"},{"label":"Seizure Agency Bill","green":false,"value":"SEIZUREAGENCYBILL"},{"label":"Payment Requisation","green":false,"value":"PAYMENTREQUISATION"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}],
			"SURRENDER":[{"label":"Inventory","green":false,"value":"INVENTORY"},{"label":"Surrender Letter","green":false,"value":"SURRENDERLETTER"},{"label":"Pre Sale Letter","green":false,"value":"PRESALELETTER"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}],
			"SEC9/ROP/Legal":[{"label":"Inventory","green":false,"value":"INVENTORY"},{"label":"Court Order","green":false,"value":"COURTORDER"},{"label":"Pre Sale Letter","green":false,"value":"PRESALELETTER"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}],
			"ASISWHEREIS": [{"label":"Sale Intimation","green":false,"value":"SALEINTIMATION"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}],
			"ASISWHEREISWOV": [{"label":"Sale Intimation","green":false,"value":"SALEINTIMATION"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}],
			"STOPANDRELEASE": [{"label":"Inventory","green":false,"value":"INVENTORY"},{"label":"Authorization Letter","green":false,"value":"AUTHORIZATIONLETTER"},{"label":"Pre seizure/ Final call letter","green":false,"value":"PRESEIZUREFINALCALLLETTER"},{"label":"Post  seizure/ Pre Sale Letter","green":false,"value":"POSTSEIZUREFINALCALLLETTER"},{"label":"Pre intimation to police letter","green":false,"value":"PREPOLICELETTER"},{"label":"Post intimation to police letter","green":false,"value":"POSTPOLICELETTER"},{"label":"Seizure Agency Bill","green":false,"value":"SEIZUREAGENCYBILL"},{"label":"Payment Requisation","green":false,"value":"PAYMENTREQUISATION"},{"label":"Approval mail","green":false,"value":"APPROVALMAIL"}]
        },
        REPO_MANDATORY_DOC : {
			"SEIZURE":["INVENTORY","PRESEIZUREFINALCALLLETTER", "POSTSEIZUREFINALCALLLETTER","PREPOLICELETTER","POSTPOLICELETTER"],
			"ASISWHEREIS":["SALEINTIMATION"],
			"ASISWHEREISWOV":["SALEINTIMATION"],
			"SURRENDER":["INVENTORY","SURRENDERLETTER","PRESALELETTER"],
			"STOPANDRELEASE": ["INVENTORY","PRESEIZUREFINALCALLLETTER", "POSTSEIZUREFINALCALLLETTER","PREPOLICELETTER","POSTPOLICELETTER"],
			"SEC9/ROP/Legal":["INVENTORY", "COURTORDER", "PRESALELETTER"]
		},
        SALE_DOC_TYPES:[
        {"label":"Sale Indemnity","green":false,"value":"SALE_INDEMNITY"},
        {"label":"Sale Acceptance","green":false,"value":"SALE_ACCEPTANCE"},
        {"label":"Approval Mail","green":false,"value":"APPROVALMAIL"},
        {"label":"Valuation Report","green":false,"value":"VALUATION_REPORT"},
        {"label":"Quotation Report","green":false,"value":"QUOTATION_REPORT"}],
		REPO_QUERY_MANAGEMENT:{
			WORK_STATUS : {"DOCUMENT_UPLOAD":"DOCUMENTUPLOAD","DOCUMENT_WAIVER":"DOCUMENTWAIVER","MAIL_APPROVAL":"MAILAPPROVAL"},
			"REQ_TYPES":[{"label":"Document Upload","status":false,"value":"DOCUMENTUPLOAD"},{"label":"Waiver Request","status":false,"value":"WAIVERREQUEST"},{"label":"Mail Approval Attachment","status":false,"value":"MAILAPPROVAL"},{"label":"Extend Submission Date","status":false,"value":"EXTENDSUBMISSIONDATE"}],
			"SALE_CLOSURE":[{"label":"Document Upload","status":false,"value":"DOCUMENTUPLOAD"},{"label":"Waiver Request","status":false,"value":"WAIVERREQUEST"}]
        },     
        QRM_VERIFY_DOC:"Are you sure you want to verify this document?",
		QRM_RETURN_DOC:"Are you sure you want return this document?", 
		NOTICE_MANAGEMENT_CONSTANTS : {
			MONTH_VALIDITY_CHECK : 12,
			VALID_MONTH_MSG:"Enter valid month from 1 to 12",
			IMAGE_UPLOAD_COUNT : 2,
			DEFAULT_GENERATION_COUNT : 100,
			MAXIMUM_LETTER_GENERATION : 500,
			DISPATCHED_TO_ALL_LETTERS : ["FINALCALLLETTER","90DPDLETTER","UNREGISTEREDSOFTLETTER","UNREGISTEREDHARDLETTER"],
			NOT_DISPATCHED_TO_ALL_LETTERS : ["PRESEIZURELETTER","POSTSEIZURELETTER","SURRENDERLETTER","AUTHORIZATIONLETTER"],
			SMS :'SMS triggered succesfully',
			LETTER:"Successfully downloaded ",
			GENERATED_BY : [{generated_name : 'Repo Agent',generated_value:'REPOSSESSION_AGENTS'}],
			ALERT_MESSAGES :{				
				INVALID_FILE : "Kindly upload valid file",
				VALIDATION : "Please enter mandatory fields with valid information to proceed further",
				SELECT_AGREEMENTS_MSG:"Kindly select agreements ",
				DOWNLOAD_SUCCESS_MSG_ALL:"Downloaded all cases successfully",
				UPLOAD_SUCCESS_MSG_ALL:"Successfully uploaded all cases",
				POD_UPDATE_SUCCESS_MSG:"Successfully updated POD details ",
				YARD_DETAILS_SUCCESS_MSG:"Successfully updated Yard details ",
				YARD_FIELDS_MANDATORY:"Please provide valid fields to update",
				FILES_DOWNLOAD_SUCCESS:"Selected files downloaded successfully ",
				REPO_AGENT_ALLOCATED_SUCCESS:"Repo agent(s) allocated successfully",
				PAN_INDIA_DOWNLOAD_SUCCESS:"Pan India agents file downloaded successfully",
				REPRINT_LETTER_CONFIRM_MSG:"This Letter may not have the latest updated financials. If you want to print the letter with latest financials, please go to Notice Management – Manual Page",
				REPRINT_LETTER_NOTICE:"Are you sure you want Re-print selected notice?",
				DOWNLOAD_ALL_CONFIRM_MSG:"Are your sure want to download all agreements? ",
				MIN_GREATER_MAX_MSG:"Maximum amount should be greater than minimum amount in ",
				MIN_MAX_RANGE_1_TO_100_MSG:"Minimum amount and maximum amount should range from 1 to 100 in loan to value ",
				MIN_MAX_MANDATORY_MSG:"Minimum amount and maximum amount are mandatory should be greater than zero in ",
				DOWNLOAD_THIS_FILE_CONFIRM_MSG:"Are your sure want to download this ",
				UPLOAD_SUCCESS_MSG:"Uploaded successfully",
				DOWNLOAD_SUCCESS_MSG:"Successfully downloaded ",
				MANDATORY_FIELDS_MSG:"This field value is mandatory",
				VALID_CSV_UPLOAD_MSG:"Please upload a valid CSV file.",
				BROWSER_NO_HTML5_SUPPORT_MSG:"This browser does not support HTML5. ",
				SELECTED_LETTER_MANDATORY_MSG:"Select letter value is mandatory ",
				NO_AGREEMENT_NUM_IN_FILE_MSG:"Agreement number not present in uploaded file ",
				RULE_SUBMIT_SUCCESS_MSG:"Master rule submitted successfully ",
				INTIMATION_CONFIRM_MSG:"Are you sure you want to perform ",
				RULE_DELETE_SUCCESS_MSG:"Master rule deleted successfully ",
				LETTER_COUNT_UPDATE_SUCCESS_MSG:"Letter count updated successfully ",
				ALL_MANDATORY_FIELD_MSG:"Enter all mandatory fields ",
				NO_AGREEMENTS_FOUND:"No cases found to download",
				SEIZURE_CHARGES_APPROVAL:"Repo seizure charges approval has already been pending for this agreement. Cannot proceed Repo Wrong marking",
				WRONG_MARKING_APPROVAL:"Repo wrong marking approval has already been pending for this agreement. Cannot proceed Repo Wrong marking",
				DOWNLOAD_SUCCESS_MSG_REQ:"Downloaded requested cases successfully",
				DOWNLOAD_SUCCESS_MSG_DIS:"Downloaded dispatched cases successfully",
				DOWNLOAD_SUCCESS_MSG_REJ:"Downloaded rejected cases successfully",
				DOWNLOAD_SUCCESS_MSG_ACK:"Downloaded acknowledged cases successfully",
				CHOLA_LETTER_HEAD_CONFIRM_MSG :"Make sure that you are printing this letter in CHOLA Letter Head"
			},
			SMS_APPLICABLE: ['30DPDLETTER','60DPDLETTER','90DPDLETTER','FINALCALLLETTER','ASISWHEREISLETTER','ASISWHEREISWOVLETTER','CONSIGNEELETTER'],
			REPO_CATEGORIES:[
				{
					key : "Seizure through repo agent",
					value : "SEIZURE_THROUGH_REPO_AGENT",
					placeHolder : "Seizure through repo agent",
					letters: [{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Authorization Letter",
							value : "AUTHORIZATIONLETTER",
							placeHolder : "Authorization Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, 
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						},
						/*
						{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						},
						*/
						{
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						}]
				}, {
					key : "Seizure through repo In House team",
					value : "SEIZURE_THROUGH_REPO_INHOUSE", 
					placeHolder : "Seizure through repo In House team",
					letters:[{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, 
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						},
						/*{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						},
*/

						{
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						}]
				}, {
					key : "Surrender",
					value : "SURRENDER",
					placeHolder : "Surrender",
					letters: [{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Surrender Letter",
							value : "SURRENDERLETTER",
							placeHolder : "Surrender Letter"
						}, 
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						},
						/*{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						},
*/
						{
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						}]
				}, {
					key : "Seizure through court",
					value : "SEIZURE_THROUGH_COURT",
					placeHolder : "Seizure through court",
					letters:[{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, {
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						}, {
							key : "repo",
							type : "Customer Satisfaction Letter Post release",
							value : "CUSTOMERSATISFACTIONLETTER",
							placeHolder : "Customer Satisfaction Letter Post release"
						},
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						}
						/*{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						}
*/						
						]
				},{
					key : "As is Where is Sale",
					value : "AS_IS_WHERE_IS_SALE",
					placeHolder : "As is Where is Sale",
					letters:[{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, {
							key : "repo",
							type : "As Is Where Is Letter",
							value : "ASISWHEREISLETTER",
							placeHolder : "As Is Where Is Letter"
						}, {
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						},						
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						}
						/*,{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						}, {
							key : "repo",
							type : "Customer Satisfaction Letter Post release",
							value : "CUSTOMERSATISFACTIONLETTER",
							placeHolder : "Customer Satisfaction Letter Post release"
						}
*/
						]
				},{
					key : "Seizure through repo agent with goods",
					value : "SEIZURE_THROUGH_REPO_AGENT_WITH_GOODS",
					placeHolder : "Seizure through repo agent with goods",
					letters:[{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Authorization Letter",
							value : "AUTHORIZATIONLETTER",
							placeHolder : "Authorization Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, 
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						},
						/* {
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						},
*/
						{
							key : "repo",
							type : "Pre Sale Letter",
							value : "PRESALELETTER",
							placeHolder : "Pre Sale Letter"
						}]
				},{
					key : "Stop and Release",
					value : "STOP_AND_RELEASE",
					placeHolder : "Stop and Release",
					letters:[{
							key : "repo",
							type : "Final Call Letter",
							value : "FINALCALLLETTER",
							placeHolder : "Final Call Letter"
						}, {
							key : "repo",
							type : "Pre Seizure Letter",
							value : "PRESEIZURELETTER", 
							placeHolder : "Pre Seizure Letter"
						}, {
							key : "repo",
							type : "Post Seizure Letter",
							value : "POSTSEIZURELETTER",
							placeHolder : "Post Seizure Letter"
						}, 
/*
						{
							key : "repo",
							type : "Consignee Letter",
							value : "CONSIGNEELETTER",
							placeHolder : "Consignee Letter"
						},{
							key : "repo",
							type : "Release Letter",
							value : "RELEASELETTER",
							placeHolder : "Release Letter"
						},
*/
						{
							key : "repo",
							type : "Customer Satisfaction Letter Post release",
							value : "CUSTOMERSATISFACTIONLETTER",
							placeHolder : "Customer Satisfaction Letter Post release"
						}]
				}
			],
			REPO_LETTER_OPTIONS : [ 
				{
					key : "repo",
					type : "Final Call Letter",
					value : "FINALCALLLETTER",
					placeHolder : "Final Call Letter"
				}, {
					key : "repo",
					type : "Pre Seizure Letter",
					value : "PRESEIZURELETTER", 
					placeHolder : "Pre Seizure Letter"
				}, {
					key : "repo",
					type : "Authorization Letter",
					value : "AUTHORIZATIONLETTER",
					placeHolder : "Authorization Letter"
				}, {
					key : "repo",
					type : "Post Seizure Letter",
					value : "POSTSEIZURELETTER",
					placeHolder : "Post Seizure Letter"
				},{
					key : "repo",
					type : "Surrender Letter",
					value : "SURRENDERLETTER",
					placeHolder : "Surrender Letter"
				}, {
					key : "repo",
					type : "As Is Where Is Letter",
					value : "ASISWHEREISLETTER",
					placeHolder : "As Is Where Is Letter"
				}, {
					key : "repo",
					type : "Consignee Letter",
					value : "CONSIGNEELETTER",
					placeHolder : "Consignee Letter"
				},{
					key : "repo",
					type : "Release Letter",
					value : "RELEASELETTER",
					placeHolder : "Release Letter"
				},{
					key : "dpd",
					type : "30 DPD Letter",
					value : "30DPDLETTER",
					placeHolder : "30 DPD Letter"
				} ,{
					key : "dpd",
					type : "60 DPD Letter",
					value : "60DPDLETTER",
					placeHolder : "60 DPD Letter"
				} ,{
					key : "dpd",
					type : "90 DPD Letter",
					value : "90DPDLETTER",
					placeHolder : "90 DPD Letter"
				} ,{
					key : "shortfall",
					type : "Shortfall Settlement Letter",
					value : "SHORTFALLSETTLEMENTLETTER",
					placeHolder : "Shortfall Settlement Letter"
				}, {
					key : "shortfall",
					type : "Shortfall Notice Letter",
					value : "SHORTFALLNOTICELETTER",
					placeHolder : "Shortfall Notice Letter"
				}, {
					key : "shortfall",
					type : "Shortfall Sett-Offer Letter",
					value : "SHORTFALLSETTLEMENTOFFERLETTER",
					placeHolder : "Shortfall Sett-Offer Letter"
				}, {	
					key : "others",
					type : "Unregistered Hard Letter",
					value : "UNREGISTEREDHARDLETTER",
					placeHolder : "Unregistered Hard Letter"
				},
				{
					key : "others",
					type : "Unregistered Soft Letter",
					value : "UNREGISTEREDSOFTLETTER",
					placeHolder : "Unregistered Soft Letter"
				} 	

		 ],
		 LEGAL_BORROWER_RESTRICT : ['ARBITRATION_LIVE','ARBITRATION_SHORTFALL','LOK_ADALAT','CONCILIATION'],
		 LEGAL_ACTION_OPTIONS : [ 
				{
					key : "legal",
					type : "Section 138 - Live",
					value : "SECTION_138_LIVE",
					placeHolder : "Section 138 - Live"
				}, {
					key : "legal",
					type : "Section 138 - ShortFall",
					value : "SECTION_138_SHORTFALL",
					placeHolder : "Section 138 - ShortFall"
				},{
					key : "legal",
					type : "Arbitration - Live",
					value : "ARBITRATION_LIVE", 
					placeHolder : "Arbitration - Live"
				},{
					key : "legal",
					type : "Arbitration - ShortFall",
					value : "ARBITRATION_SHORTFALL", 
					placeHolder : "Arbitration - ShortFall"
				},
				{
					key : "legal",
					type : "Lok - Adalat",
					value : "LOK_ADALAT", 
					placeHolder : "Lok - Adalat"
				},
				{
					key : "legal",
					type : "Conciliation",
					value : "CONCILIATION", 
					placeHolder : "Conciliation"
				}
		 ],
		MASTER_RULE_ALLOCATION_DPD:{
			UNREGISTEREDSOFTLETTER:{key:"SOFT_DPD_CATEGORY"},
			UNREGISTEREDHARDLETTER:{key:"HARD_DPD_CATEGORY"},		
		}, 
		REPO_TYPES : [ {
            type : "Seizure",
            value : "SEIZURE",
            selected : false,
            placeHolder : "Seizure"
        },{
            type : "As Is Where Is Sale - with vehicle",
            value : "ASISWHEREIS",
            selected : false,
            placeHolder : "AsIsWhereIs"
        },
        {
            type : "As Is Where Is Sale - without vehicle",
            value : "ASISWHEREISWOV",
            selected : false,
            placeHolder : "AsIsWhereIs"
        },
		{
			type : "Surrender",
			value : "SURRENDER",
			selected : false,
			placeHolder : "Surrender"
		},
		{	type : "Stop and release",
			value : "STOPANDRELEASE",
			selected : false,
			placeHolder : "Stop and release"
		},
		{
			type : "SEC 9/ROP/Legal",
			value : "SEC9/ROP/Legal",
			selected : false,
			placeHolder : "SEC 9/ROP/Legal"
		}],
		VEHICLE_CONDITION:[
			{
			type : "Good",
			value : "GOOD",
			selected : false,
			placeHolder : "Good"
		},{
			type : "Bad",
			value : "BAD",
			selected : false,
			placeHolder : "Bad"
		},
		{
			type : "Accident",
			value : "ACCIDENT",
			selected : false,
			placeHolder : "Accident"
		},
		{	type : "Scrap",
			value : "SCRAP",
			selected : false,
			placeHolder : "Scrap"
		},
		{	type : "Others",
			value : "OTHERS",
			selected : false,
			placeHolder : "Others"
		}
		],
		ASSET_CONDITION:[
            {
                type : "Working",
                value : "WORKING",
                selected : false,
                placeHolder : "Working"
            },
            {	type : "Running",
                value : "RUNNING",
                selected : false,
                placeHolder : "Running"
            },
            {	type : "Towing",
                value : "TOWING",
                selected : false,
                placeHolder : "Towing"
            }
		],
		REPO_KIT_OPTIONS : [ {
			type : "Repo",
			value : "repo",
			selected : false,
			placeHolder : "Repo",
			iconName : "content/images/icon-sprite.svg#hook-icon"
		},
		{	type : "Shortfall",
			value : "shortfall",
			selected : false,
			placeHolder : "Shortfall",
			iconName : "content/images/icon-sprite.svg#tie-icon"
		},
		{
		 	type : "DPD",
		 	value : "dpd",
		 	selected : false,
		 	placeHolder : "DPD",
		 	iconName : "content/images/icon-sprite.svg#car-icon"
		},{	type : "Others",
			value : "others",
			selected : false,
			placeHolder : "Others",
			iconName : "content/images/icon-sprite.svg#other-icon"
		}],
		REPO_KIT_OPTIONS_LEGAL : [ {
			type : "Repo",
			value : "repo",
			selected : false,
			placeHolder : "Repo",
			iconName : "content/images/icon-sprite.svg#hook-icon"
		},
		{
			type : "Legal",
			value : "legal",
			selected : false,
			placeHolder : "Legal",
			iconName : "content/images/icon-sprite.svg#tie-icon"
		},
		{	type : "Shortfall",
			value : "shortfall",
			selected : false,
			placeHolder : "Shortfall",
			iconName : "content/images/icon-sprite.svg#tie-icon"
		},
		{
		 	type : "DPD",
		 	value : "dpd",
		 	selected : false,
		 	placeHolder : "DPD",
		 	iconName : "content/images/icon-sprite.svg#car-icon"
		},{	type : "Others",
			value : "others",
			selected : false,
			placeHolder : "Others",
			iconName : "content/images/icon-sprite.svg#other-icon"
		}]

		
		},
		REPO_LETTER_LABEL:{
			"FINALCALLLETTER":'Final Call Letter',
			"INVENTORY":'Inventory',
			"SALEINTIMATION":'Sale Intimation',
			"PRESALELETTER":'Pre Sale Letter',
			"PRESEIZURELETTER":'Pre Seizure Letter',
			"AUTHORIZATIONLETTER":'Authorization Letter',
			"POSTSEIZURELETTER":'Post Seizure Letter',
			"SURRENDERLETTER":'Surrender Letter',
			"COURTORDER":'Court Order',
			"ASISWHEREISLETTER":'As Is Where Is Letter',
			"ASISWHEREISWOVLETTER":'As Is Where Is Letter',
			"RELEASELETTER":'Release Letter',
			"UNREGISTEREDSOFTLETTER":'Unregistered Soft Letter',
			"UNREGISTEREDHARDLETTER":'Unregistered Hard Letter',
			"90DPDLETTER":'90 DPD Letter',
			"60DPDLETTER":'60 DPD Letter',
			"PRESEIZUREFINALCALLLETTER":'Pre seizure/ Final call letter',
			"POSTSEIZUREFINALCALLLETTER":'Post  seizure/ Pre Sale Letter',
			"PREPOLICELETTER":'Pre intimation to police letter',
			"POSTPOLICELETTER":'Post intimation to police letter',
			"APPROVALMAIL":'Approval mail',
			"SALE_ACCEPTANCE":"Sale Acceptance",
			"SALE_INDEMNITY":"Sale Indemnity",
			"DOCUMENTUPLOAD":"Document Upload",
			"DOCUMENTWAIVER":"Document Deviation",
			"MAILAPPROVAL":"Mail Approval",
			"SEIZUREAGENCYBILL" : "Seizure Agency Bill",
			"PAYMENTREQUISATION" : "Payment Requisation",
			"VALUATION_REPORT" : "Valuation Report",
			"QUOTATION_REPORT" : "Quotation Report",
		},
		INIT_SALE:{pending:['SALE_INITIATED'],approved:['SALE_APPROVED']},
		INIT_VALUE:{pending:['VALUATION_INITIATED'],approved:['VALUATION_LEAP_ENTERED','VALUATION_GAADIBAZAAR_ENTERED']},
		INTIMATE_TO_CHOLA:{
		
			vehicleCondition:{					
			subMenu:[
			{
			value:"GOOD",			
			type:"Good"	
			},{
			value:"BAD",
			type:"Bad"
			},{
			value:"ACCIDENT",
			type:"Accident"
			},{
			value:"SCRAP",
			type:"Scrap"
			},{
			value:"OTHERS",
			type:"Others"	
			}],
			comments:""	
		},insuranceStatus:{
			subMenu:[
			{
			value:"YES",
			type:"Yes"
			},{
			value:"NO",
			type:"No"
			},{
			value:"OTHERS",
			type:"Others"
			}],
			comments:""	

		},fitnessCertificate:{
				
			subMenu:[
			{
			value:"YES",
			type:"Yes"
			},{
			value:"NO",
			type:"No"
			},{
			value:"OTHERS",
			type:"Others"
			}],
			comments:""	
		},cholaRepresentative:{
						
			subMenu:[
			{
			value:"YES",
			type:"Yes"
			},{
			value:"NO",
			type:"No",
			},{
			value:"OTHERS",
			type:"Others"
			}],
			comments:""	

		},ORCAvailable:{						
			subMenu:[
			{
			value:"YES",
			type:"Yes"
			},{
			value:"NO",
			type:"No",
			}]	
		},
		RCBookStatus:{
			subMenu:[
			{
			value:"YES",
			type:"Yes"
			},{
			value:"NO",
			type:"No",
			},{
			value:"OTHERS",
			type:"Others"
			}],
			comments:""	
		}
		},
		MARKING_LMS_CHARGES:[{
				chargeID:"110160" ,
				chargeDescription:"Towing Charges",
				ExpArr:[],
				selected:false,
				amount:0
			},{
				chargeID:"240" ,
				chargeDescription:"Seizure Charges",
				ExpArr:[],
				selected:false,
				amount:0
			},{
				chargeID:"30000",
				chargeDescription:"Driver Charges",
				ExpArr:[],
				selected:false,
				amount:0
			},{
				chargeID:"40000",
				chargeDescription:"Diesel Charges",
				ExpArr:[],
				selected:false,
				amount:0
			},{
				chargeID:"110165",
				chargeDescription:"Sec 9/Sec 17 Charges (Legal Charges)",
				ExpArr:[],
				selected:false,
				amount:0
			},{
				chargeID:"50000" ,
				chargeDescription:"Other Charges",
				ExpArr:[],
				selected:false,
				amount:0
			}],
		charges:[{
			value:true,
			type:"With Bill",			
		},{
			value:false,
			type:"Without Bill"
		}],
		LEGAL_FILTER1:[
		{
			label : "Category",
			value : "catagory",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
				label : "Soft",
				value : "SOFT_DPD_CATEGORY",
				selected : false
			}, {
				label : "Hard",
				value : "HARD_DPD_CATEGORY",
				selected : false
			} ]
		},
		 {
			label : "Allocation DPD",
			value : "allocationDPD",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
					label: 'X',
					value: 'X',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '0-30',
					value: '0-30',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '31-61',
					value: '31-61',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '62-91',
					value: '62-91',
					selected: false,
					key: 'SOFT_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '92-122',
					value: '92-122',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: '123-152',
					value: '123-152',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Fresh NPA 153-183',
					value: 'Fresh NPA 153-183',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Fresh NPA 184-214',
					value: 'Fresh NPA 184-214',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'Opening NPA 215+',
					value: 'Opening NPA 215+',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			},{
					label: 'REPO',
					value: 'REPO',
					selected: false,
					key: 'HARD_DPD_CATEGORY',
					isDisabled: false,
					checked: false
			}]

		}, {
			label : "Vehicle Category ",
			value : "vehicleCategory",
			inputType : "checkbox",
			selected : false,
			subMenu : ""
		}, {
			label : "Product Category ",
			value : "productCategory",
			inputType : "checkbox",
			selected : false,
			subMenu : [
			//  {
			// 	label : "CMF",
			// 	value : "CMF",
			// 	selected : false
			// }, 
			{
				label : "VFPRIME",
				value : "VFPRIME",
				selected : false
			}, 
			// {
			// 	label : "HE",
			// 	value : "HE",
			// 	selected : false
			// }, 
			{
				label : "EBIKE",
				value : "EBIKE",
				selected : false
			}, {
				label : "SHUBH",
				value : "SHUBH",
				selected : false
			}, {
				label : "TRACTOR",
				value : "TRACTOR",
				selected : false
			}, {
				label : "SEGC",
				value : "SEGC",
				selected : false
			}, {
				label : "PRIME",
				value : "PRIME",
				selected : false
			}, {
				label : "SEGD",
				value : "SEGD",
				selected : false
			}, {
				label : "SEG F",
				value : "SEG F",
				selected : false
			}, 
			// {
			// 	label : "HL",
			// 	value : "HL",
			// 	selected : false
			// }, 
			{
				label : "2WHEELER",
				value : "2WHEELER",
				selected : false
			}, {
				label : "SEGB",
				value : "SEGB",
				selected : false
			}, {
				label : "CE",
				value : "CE",
				selected : false
			},{
				label : "SEGE",
				value : "SEGE",
				selected : false
			} ]
		}, {
			label : "Loan To Value",
			value : "loanToValue",
			inputType : "number",
			selected : false,
			subMenu : [ {
				label : "Minimum",
				value : "",
				selected : false
			}, {
				label : "Maximum",
				value : "",
				selected : false
			} ]
		},
		{
			label : "Payment Pattern",
			value : "paymentPattern",
			inputType : "checkbox",
			selected : false,
			subMenu : [ {
				label : "0/4",
				value : "0/4",
				selected : false
			}, {
				label : "1/4",
				value : "1/4",
				selected : false
			}, {
				label : "2/4",
				value : "2/4",
				selected : false
			}, {
				label : "3/4",
				value : "3/4",
				selected : false
			}, {
				label : "4/4",
				value : "4/4",
				selected : false
			} ]
		},
		{
			label : "Seasoning",
			value : "seasoning",
			inputType : "checkbox",
			selected : false,
			subMenu : [ {
				label : "0-6",
				value : [0,6],
				selected : false
			},{
				label : "7-12",
				value : [7,12],
				selected : false
			}, {
				label : "13-24",
				value : [13,24],
				selected : false
			}, {
				label : "25-30",
				value : [25,30],
				selected : false
			}, {
				label : "31-36",
				value : [31,36],
				selected : false
			}, {
				label : "36+",
				value : [36],
				selected : false
			},{
				label : "POS Comfort",
				value : ["posComfort"],
				selected : false
			},{
				label : "Charges Only Cases",
				value : ["chargesOnlyCases"],
				selected : false
			},{
				label : "Matured Cases",
				value : ["maturedCases"],
				selected : false
			},{
				label : "Writeoff Cases",
				value : ["writeoffCases"],
				selected : false
			}  ]
		},{
			label : "Gross Value",
			value : "grossValue",
			inputType : "checkbox",
			selected : false,
			subMenu : [{
				label : "<50,000",
				value : "<50000",
				selected : false
			},{
				label : "50,000 - 1,00,000",
				value : "50000 - 100000",
				selected : false
			}, {
				label : ">1,00,000",
				value : ">100000",
				selected : false
			}]
		}],
		LEGAL_FILTER2:[{
			label : "CAU Flag",
			value : "cauFlag",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : true,
				isDisabled:true
			}
		},{
			label : "Legal Stock",
			value : "legalStock",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : true,
				isDisabled:false
			}
		},{
			label : "Legal Hold",
			value : "legalHold",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : true,
				isDisabled:false
			}
		},
		/*,{
			label : "POS Comfort",
			value : "posComfort",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : "FALSE",
				isDisabled:false
			}
		},*/
		{
			label : "Repo Approved",
			value : "repoApproved",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : true,
				isDisabled:false
			}
		}
		/*,{
			label : "Charges Only Cases",
			value : "chargesOnlyCases",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : "NA",
				isDisabled:false
			}
		},{
			label : "Matured Cases",
			value : "maturedCases",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : "NA",
				isDisabled:false
			}
		},{
			label : "Writeoff Cases",
			value : "writeoffCases",
			inputType : "checkbox",
			selected : false,
			subMenu : {
				label : "",
				value : "",
				selected : "NA",
				isDisabled:false
			}
		}*/
		// ,{
		// 	label : "Legal Already Initiated",
		// 	value : "legalAlreadyInitiated",
		// 	inputType : "checkbox",
		// 	selected : false,
		// 	subMenu : {
		// 		label : "",
		// 		value : "",
		// 		selected : "NA",
		// 		isDisabled:false
		// 	}
		// }
			// subMenu : [{
			// 	label : "CAU Flag",
			// 	value : "cauFlag",
			// 	selected : false
			// },{
			// 	label : "Legal Stock",
			// 	value : "legalStock",
			// 	selected : false
			// },{
			// 	label : "Legal Hold",
			// 	value : "legalHold",
			// 	selected : false
			// },{
			// 	label : "POS Comfort",
			// 	value : "posComfort",
			// 	selected : false
			// },{
			// 	label : "Repo Approved",
			// 	value : "repoApproved",
			// 	selected : false
			// },{
			// 	label : "Charges Only Cases",
			// 	value : "chargesOnlyCases",
			// 	selected : false
			// },{
			// 	label : "Matured Cases",
			// 	value : "maturedCases",
			// 	selected : false
			// },{
			// 	label : "Writeoff Cases",
			// 	value : "writeoffCases",
			// 	selected : false
			// }]
		],
		DOC_DISPATCH_DETAILS:[{
			label : "Case Filing Location",
			value : "caseFilingLocation",
			inputType : "radio",
			selected : "LOCAL",
			subMenu : [ {
				label : "HO_LEGAL",
				value : "HO_LEGAL",
				selected : false
			}, {
				label : "Local Branch",
				value : "LOCAL",
				selected : false
			}]
		},{
			label : "Document Dispatch Location",
			value : "documentDispatchLocation",
			inputType : "radio",
			selected : "LOCAL",
			subMenu : [ {
				label : "HO_LEGAL",
				value : "HO_LEGAL",
				selected : false
			}, {
				label : "Local Branch",
				value : "LOCAL",
				selected : false
			}]
		}],
		MARKING_LMS_SEIZURE_DURATION:2,
		REPO_AUTO_AUTHORIZE : true,
		APPROVAL_LAND_DATE_DIFF : 6,
		APPROVAL_DATE_DIFF : 30,
		CLOSED_AGR_CHARGES : {
			SALE : ['110265','110267'],
			REGULAR : ['110267','110040','110331']
		},
		ASSET_CONDITION:["Working","Running","Towing"],
		VEHICLE_INSPECTED_BY:["branch incharge","Mktg Staff","CFE","SFE","COE","Others"],
		CASH_AMT_RESTRICT_OTHER_CHAGRES : 49999,
		CHARGES_EXCLUDE : ['7','9','37','110331','110265','110038','150089','110040','110165','241','110039','110329','110357','110267','110306','110354','110104','110265','120018','110323','110338'],
		INSURANCE_VALIDITY_REPO:3,
		CHARGES_MAX_LIMIT:[{'chargeID':'110038','maxLimit':2500},{'chargeID':'150089','maxLimit':2500},{'chargeID':'110040','maxLimit':500},{'chargeID':'110331','maxLimit':100000},{'chargeID':'110165','maxLimit':4000},{'chargeID':'241','maxLimit':6000},{'chargeID':'37','maxLimit':49999}],
		REPO_DOC_TYPES : {
			"SEIZURE":["FINALCALLLETTER", "PRESEIZURELETTER", "POSTSEIZURELETTER", "AUTHORIZATIONLETTER"],
			"NORMAL":["FINALCALLLETTER", "PRESEIZURELETTER", "POSTSEIZURELETTER", "AUTHORIZATIONLETTER"],
			"ASISWHEREIS":["ASISWHEREISLETTER", "AUTHORIZATIONLETTER"],
			"ASISWHEREISWOV":["ASISWHEREISLETTER", "AUTHORIZATIONLETTER"],
			"SURRENDER":["SURRENDERLETTER", "PRESEIZURELETTER", "POSTSEIZURELETTER", "AUTHORIZATIONLETTER"],
			"STOPANDRELEASE":["FINALCALLLETTER", "PRESEIZURELETTER", "POSTSEIZURELETTER", "AUTHORIZATIONLETTER", "CONSIGNEELETTER"],
			"SEC9/ROP/Legal":["FINALCALLLETTER", "PRESEIZURELETTER", "POSTSEIZURELETTER", "AUTHORIZATIONLETTER", "CONSIGNEELETTER", "SURRENDERLETTER", "ASISWHEREISLETTER", "RELEASELETTER"],
		},
		IMG_DOC_LIST : [{ "imageName": "PAN No", "categoryName": "PAN CARD" }, { "imageName": "Aadhar No", "categoryName": "AADHAR CARD(U-ID)" }, { "imageName": "VOTER ID", "categoryName": "VOTER ID" }, { "imageName": "Passport", "categoryName": "PASSPORT" }, { "imageName": "Driving License", "categoryName": "Driving licence" }],
		SHOW_OTHER_CHARGES : ['110039','110329','110357','110267','110306','110354','110104','110038','150089','110040','110165','110265','241','240','120018','37','5'],
		SHOW_OTHER_CHARGES_HE_HL : ['110039','110329','110357','110267','110306','110354','110104','110038','150089','110040','110165','110265','241','240','120018','37','5','110338', '110323'],
		APPROVAL_QUEUE_SEARCH_OPTIONS : [ {
			name : "Receipt No",
			value : "receiptNo",
			searchBy : "receiptNo"
		}, {
			name : "Trip Loan Agreement No",
			value : "trip",
			searchBy : "tripAgreementNo"
		}, {
			name : "Visesh Agreement No",
			value : "vishesh",
			searchBy : "visheshAgreementNo"
		}, {
			name : "Dealer Agreement No",
			value : "ta",
			searchBy : "dealerAgreementNo"
		},{
			name : "Agreement No",
			value : "agreementNo",
			searchBy : "agreementNo"
		},{
			name : 'IMD-HEHL Application ID',
			value : 'formNo',
			searchBy : "applicationID"
		},{
			name : 'IMD-VF LEADID',
			value : 'leadID',
			searchBy : "leadID"
		}],
		LEGAL_ZONE_LIST : ["all","south","north","east","west"],
		SHORTFALL_AMT_TYPE_OPTIONS : [ {
			type : "AV Loss",
			value : "AVLoss",
			placeHolder : "AV Loss"
		}, {
			type : "BV Loss",
			value : "BVLoss",
			placeHolder : "BV Loss"
		}],
		REPORT_STATUS_DATA : [{
			name : "All",
			value : "ALLSTATUS"
		}, {
			name : "NOT INITIATED",
			value : "ACTIVE"
		}, {
			name : "APPROVED",
			value : "APPROVED"
		}, {
			name : "LEGALINITIATED",
			value : "LEGALINITIATED"
		} , {
			name : "REJECTED",
			value : "REJECTED"
		}],
		HO_BRANCH_ID:"3",
		LEGAL_REPORT_TYPE : ["LEGALBLOCKREPORT", "LEGALDISPATCHREPORT", "CASEDEVIATIONREPORT","LEGALAUTOMATIONREPORT","DOCAUTOREMOVEREPORT","LEGALDOCREPORT","LEGALDOCREQREPORT","LEGALCASETRACKINGREPORT"],
		REPORT_DATE_DIFF : 30,
		REPORT_DATE_DIFFERENCE_MSG : 31,
		LEGAL_REPORT_DATE_DIFF : 364,
		LEGAL_REPORT_DATE_DIFF_MSG :365,
		DELETE_GROSS_VALUE:"Are you sure you want to delete this record",
		LEGAL_SOA_SEARCH:[{
				name : 'Agreement No',
				value : 'agreementNo'
			}, {
				name : 'Case ID',
				value : 'caseID'
			} 
		],
		MINIMUM_CHEQUE_AMOUNT:'10000',
		REPO_MARKING_STATUS : ['Sale','Customer Release','Customer Settlement'],
		REPO_MARKING_REMARKS : {
			'SALE' : ['Already Sold', 'Sale Before 10th', 'Sale Before 15th', 'Sale Before 20th', 'Sale After 20th'],
			'CUSTOMER RELEASE' : ['Already Released', 'Release Before 10th', 'Release Before 15th', 'Release Before 20th', 'Release After 20th'],
			'CUSTOMER SETTLEMENT' : ['Already Settled', 'Settlement Before 10th', 'Settlement Before 15th', 'Settlement Before 20th', 'Settlement After 20th']
		}
		};
	});
