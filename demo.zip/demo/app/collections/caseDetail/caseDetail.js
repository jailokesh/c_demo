define(['require','collectionsApp','caseDetailResolver'],function(r,collectionsApp,caseDetailResolver) {
	'use strict';
	
	/**
	 * Contains the caseDetail routing information.
	 * Create and return the case details module.
	 */		
	var baseViewUrl = 'app/collections/caseDetail/';
	var app = angular.module('caseDetail', [ 'common','ui.router','collections']);

	var caseDetails = {
		name : 'collections.caseDetail',
		url : '/caseDetail/:agreementNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + "caseDetail.html",
                controller: 'caseDetailController',
                resolve: caseDetailResolver
			}
		},
		data:{'headerText':'Case Details', 'backState':'collections.myCustomers.summary',
			'stateActivity' : ['COL_VIEW_FINANCIAL_DETAILS','COL_VIEW_NON_FINANCIAL_DETAILS','COL_VIEW_APPROVALS']}
	};
	
	/**
	 * Contains the caseDetail configuration details.
	 */		
	
	var caseDetailsConfiguration = function($stateProvider) {
		$stateProvider.state(caseDetails);
	};

	app.config([ '$stateProvider',caseDetailsConfiguration ]);
	return app;
});
