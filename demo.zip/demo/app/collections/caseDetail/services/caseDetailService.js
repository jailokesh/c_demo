/**
 * Represents a CaseDetails Service.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'caseDetail', 'collectionConstants', 'constants', 'collectionServiceURLs', 'utility','DatePickerConfig' ], function(require, caseDetail, collectionConstants, constants, collectionsServiceURL, utility,DatePickerConfig) {
	'use strict';
	/**
	 * Represents a CaseDetails Service. CaseDetail Service function Dependency injection $q,restAngularProxy,restProxy as a parameter.
	 */
	var caseDetailService = function($q, restProxy, $rootScope, masterService,$modal, environmentConfig) {
		var url = "";
		var queryParams;
		var delequencyString = [];
		var product;
		var defaultCharges = [],chargeObj={};
		/**
		 *  @OFS - 13-Nov-2018
		 * legal sent Notice pdf download.
		 */
		var loginDetails = function (queryObj) {
			queryObj = queryObj || {};
			switch ($rootScope.identity.hierarchyName.toUpperCase()) {
				case 'TELLER':
				case 'BRM':
					queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				case 'ARM':
				case 'ALM':
					queryObj.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					break;
				case 'RRM':
				case 'RLM':
					queryObj.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					break;
				case 'ZRM':
				case 'ZLM':
					queryObj.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
					break;
				case 'REPO_AGENT':
				case 'YARD_MANAGER':
					break;
				default:
					queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;					
					break;
			}
			return queryObj;
		};
		/**
		 * Method to retrieve the case detail info for the Agreement No..
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getCaseDetailInfo = function(agreementNo) {
			collectionsServiceURL.receiptingServices.ENTRY_FORM.queryParams = {
				agreementNos : agreementNo,
				view : "receiptDetail"
			};
			collectionsServiceURL.receiptingServices.ENTRY_FORM.urlParams = {};
			return restProxy.get(collectionsServiceURL.receiptingServices.ENTRY_FORM).then(function(data) {
				if (data.data && data.data[0]) {
					product = data.data[0].productGroup;
					return data.data[0];
				} else {
					return $q.reject(data);
				}

			});
		};
		var initService = function() {
			queryParams = {
				product : product
			};
		};
		
		var setODDetails = function(data){
			 defaultCharges = [];
				data.data[0].otherODCharges = [];
				_.each(collectionConstants.LEAP_DESC_CHARGES.PRIMARY_CHARGES,function(value){
	  				chargeObj = _.findWhere(data.data[0].ODDetails,{receiptChargeType : value});
	  				if(chargeObj && chargeObj.chargeID && chargeObj.isCollectible){
		  				defaultCharges.push({receiptChargeType:value,chargeID:chargeObj.chargeID,chargeAmount:0,paidAmount:0});
	  				}
	  			});
				var chargesDesc = _.pluck(defaultCharges,'chargeID'),chargeAmount,index;
				_.each(data.data[0].ODDetails,function(item){
				var obj = {};
				index = chargesDesc.indexOf(item.chargeID);
				var charge,paid;
				charge = item.chargeAmount ? item.chargeAmount:0;
				paid = item.paidAmount ? item.paidAmount:0;
	  			if(index > -1){
	  				obj = defaultCharges[index];
	  				chargeAmount = Math.round(Number(charge) - Number(paid));
		  			obj.actual = (chargeAmount < 0 ) ? 0 : chargeAmount;
	  			}else{
	  				if(item.isCollectible){
	  					chargeAmount = Math.round(Number(charge) - Number(paid));
			  			obj.chargeAmount = (chargeAmount < 0 ) ? 0 : chargeAmount;
			  			if(obj.chargeAmount > 0){
			  				data.data[0].otherODCharges.push(obj.chargeAmount);
			  			}
	  				}
	  			}
				});
		};
		
		this.getLoanDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.FINANCIAL.LOAN_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.LOAN_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.LOAN_DETAILS, "loandetails").then(function(data) {
				if (data.data && data.data[0]) {
					//data.data[0].totalPaymentOD = Number(data.data[0].totalFVCODAmount) + Number(data.data[0].totalCBCODAmount) + Number(data.data[0].totalAFCODAmount) + Number(data.data[0].totalOtherOD) + Number(data.data[0].totalEMIODAmount);
					data.data[0].ltv = data.data[0].ltv ? Math.round(data.data[0].ltv):0;
					setODDetails(data);
					if (data.meta && data.meta.totalCount) {
						data.data[0].totalCount = data.meta.totalCount;
					} else {
						data.data[0].totalCount = 0;
					}
					var month_year = new Date().getMonth()+1 +'-'+new Date().getFullYear(); 
					if(data.data[0].delinquencyString && data.data[0].delinquencyString.length > 0){
						data.data[0].delinquency = utility.handleDelequency(true,data.data[0].delinquencyString,collectionConstants.NON_DELEQUENCY_DATA);
					}else{
						data.data[0].delinquency = utility.handleDelequency(false,[],collectionConstants.NON_DELEQUENCY_DATA);
					}
					data.data[0].ODDetails = defaultCharges;
					return data.data[0];
				} else {
					return $q.reject(data);
				}
			});
		};
		/**
		 * Method to retrieve the EMI outstanding info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getEMIOutstandingDetail = function(agreementNo) {
			initService();
			/*var queryParams = {
					product : $rootScope.productType
				};*/
			collectionsServiceURL.caseDetailServices.FINANCIAL.OD_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.OD_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.OD_DETAILS, "emioutstanding").then(function(data) {
				var tempArr = [];
				if (data.data[0] && data.data[0].ODDetails && data.data[0].ODDetails.length === 1) {
					for ( var prop in data.data[0].ODDetails[0]) {
						if (data.data[0].ODDetails[0].hasOwnProperty(prop)) {
							tempArr.push(prop);
						}
					}
					if (tempArr.length === 0) {
						data.data[0].ODDetails = [];
					}
				}else{
					setODDetails(data);
					/* defaultCharges = [],chargeObj={};
					data.data[0].otherODCharges = [];
					_.each(collectionConstants.LEAP_DESC_CHARGES.PRIMARY_CHARGES,function(value){
		  				chargeObj = _.findWhere(data.data[0].ODDetails,{receiptChargeType : value});
		  				if(chargeObj && chargeObj.chargeID && chargeObj.isCollectible){
			  				defaultCharges.push({receiptChargeType:value,chargeID:chargeObj.chargeID,chargeAmount:0,paidAmount:0});
		  				}
		  			});
					var chargesDesc = _.pluck(defaultCharges,'chargeID'),chargeAmount,index;
					_.each(data.data[0].ODDetails,function(item){
					var obj = {};
					index = chargesDesc.indexOf(item.chargeID);
					var charge,paid;
					charge = item.chargeAmount ? item.chargeAmount:0;
	  				paid = item.paidAmount ? item.paidAmount:0;
		  			if(index > -1){
		  				obj = defaultCharges[index];
		  				chargeAmount = Math.round(Number(charge) - Number(paid));
			  			obj.actual = (chargeAmount < 0 ) ? 0 : chargeAmount;
		  			}else{
		  				if(item.isCollectible){
		  					chargeAmount = Math.round(Number(charge) - Number(paid));
				  			obj.chargeAmount = (chargeAmount < 0 ) ? 0 : chargeAmount;
				  			if(obj.chargeAmount > 0){
				  				data.data[0].otherODCharges.push(obj.chargeAmount);
				  			}
		  				}
		  			}
					});*/
				}
				data.data[0].ODDetails = defaultCharges;
				return data.data[0];
			});
		};
		var formatResoponse = function(response){
			if(response.data && response.data[0]){
				response.data[0].totalCount = (response.meta && response.meta.totalCount) ? response.meta.totalCount : 0;
				return response.data[0];
			}else{
				return {};
			}
		};
		/**
		 * Method to retrieve the Re payment schedule info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getRepaymentScheduleDetail = function(agreementNo, limit, offset) {
			initService();
			 queryParams.limit = limit;
			 queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.FINANCIAL.REPAYMENT_SCHEDULE_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.REPAYMENT_SCHEDULE_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.REPAYMENT_SCHEDULE_DETAILS, "repaymentschedules").then(function(data) {
				return formatResoponse(data);
			});
		};
		var chargeList = [];
		/**
		 * Method to retrieve the mini statement info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getMiniStatementDetail = function(agreementNo,months) {
			initService();
			queryParams.months = months;
			collectionsServiceURL.caseDetailServices.FINANCIAL.MINI_STATEMENT.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.MINI_STATEMENT.urlParams = {
				'agreementNo' : agreementNo
			};
			
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.MINI_STATEMENT, "miniSOA").then(function(data) {
				return formatResoponse(data);
			});
		};

		/**
		 * Method to retrieve the Repayment History info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getRepayHistoryDetail = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.FINANCIAL.REPAY_HISTORY.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.REPAY_HISTORY, agreementNo + '/repaymenthistory').then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Expense details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.expenseDetails = function(agreementNo, limit, offset) {
			var queryParams = {
				limit : limit,
				offset : offset
			};
			collectionsServiceURL.caseDetailServices.FINANCIAL.EXPENSE_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.EXPENSE_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.EXPENSE_DETAILS, "expensedetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Receipt details info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getReceiptDetails = function(agreementNo, limit, offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.FINANCIAL.RECEIPT_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.RECEIPT_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.RECEIPT_DETAILS, "receiptdetails").then(function(data) {
				if(data.data && data.data[0] && data.data[0].items){
					_.each(data.data[0].items , function(item){
						item.status = 'Cleared';
						item.isCash = true;
						if((item.modeOfPayment.toUpperCase().indexOf("R") > -1) && item.workflow && item.workflow.length > 0){
							if(item.workflow[item.workflow.length-1].workStatus ==='INITIATED'){
								item.status = 'Pending';
							}else if(item.workflow[item.workflow.length-1].workStatus ==='REJECTED'){
								item.status = '';
							}
						}else if(item.modeOfPayment.toUpperCase() != "CASH" && item.instrumentDetail && item.instrumentDetail.status){
							item.status = item.instrumentDetail.status;
							item.isCash = false;
						}
					});
				}
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Cheque bounce info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getChequeBounceDetails = function(agreementNo, limit, offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.FINANCIAL.CHEQUE_BOUNCE_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.CHEQUE_BOUNCE_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.CHEQUE_BOUNCE_DETAILS, "chequebounces").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Follow up trials info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getFollowUpTrialDetails = function(agreementNo, limit, offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.FINANCIAL.FOLLOW_UP_TRIALS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.FOLLOW_UP_TRIALS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.FOLLOW_UP_TRIALS, "followuptrials").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Bank details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getBankDetails = function(agreementNo, limit, offset) {
			var queryParams = {
				limit : limit,
				offset : offset
			};

			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.BANK_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.BANK_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.BANK_DETAILS, "bankdetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Legal details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getLegalDetail = function(agreementNo,limit,offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.LEGAL_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.LEGAL_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.LEGAL_DETAILS, "legaldetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Asset info for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getAssetDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ASSET_DETAILS, "assetdetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the contact info details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getContactInfoDetail = function(agreementNo, limit, offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			queryParams.view = "web";
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS, "contactdetails").then(function(data) {

				if (data && data.length !== 0 && data.data[0] && data.data[0].length !== 0) {
					var contactData = data.data[0];
					contactData.totalCount = data.meta.totalCount;
					contactData.contactInfo = [];
					_.each(contactData.data, function(item) {
						if (item.type === collectionConstants.THIRDPARTY) {
							item.addressType = 'Thirdparty';
						}
						contactData.contactInfo.push(item);
					});
					return contactData;
				}
				return data.data;
			});
		};
		/**
		 * Method to retrieve the disbursal details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getDisbursalDetails = function(agreementNo, limit, offset) {
			var queryParams = {
				limit : limit,
				offset : offset
			};

			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.DISBURSALINFO_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.DISBURSALINFO_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.DISBURSALINFO_DETAILS, "disbursaldetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the reference details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getReferenceDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERANCE_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERANCE_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERANCE_DETAILS, "referencedetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the insurance details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getInsuranceDetails = function(agreementNo) {
			initService();
			/*var queryParams = {
					product : $rootScope.productType
				};*/
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INSURANCE_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INSURANCE_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INSURANCE_DETAILS, "insurancedetails").then(function(data) {
				var insData = data.data[0];
				var insuranceData = {
					motorData : [],
					lifeData : [],
					partyDetails:{}
				};
				if (insData.insuranceDetail) {
					_.each(insData.insuranceDetail, function(item) {
						if (item.policyNo) {
							item.policyType = item.policyType ? item.policyType.toUpperCase() : '';
							if (item.policyType.search(collectionConstants.INSURANCE_TYPE.LIFE) !== -1) {
								insuranceData.lifeData.push(item);
							} else {
								insuranceData.motorData.push(item);
							}
						}
					});
				}
				insuranceData.partyDetails = insData.partyDetails;
				return insuranceData;
			});
		};
		/**
		 * Method to retrieve the income details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getIncomeDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INCOME_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INCOME_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.INCOME_DETAILS, "incomedetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Referral details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getReferralHistoryDetails = function(agreementNo, limit, offset) {
			var queryParams = {
				limit : limit,
				offset : offset
			};
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERAL_HISTORY.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERAL_HISTORY.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.REFERAL_HISTORY, "referralhistory").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Guarantor details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getGuarantorDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.GUARANTOR_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.GUARANTOR_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.GUARANTOR_DETAILS, "guarantordetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Party details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getEmploymentDetails = function(agreementNo) {
			initService();
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.EMPLOYMENT_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.EMPLOYMENT_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.EMPLOYMENT_DETAILS, "employmentdetails").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Allocation history details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.allocationHistoryDetails = function(agreementNo, limit, offset, fromDate, toDate) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			queryParams.fromdate = fromDate;
			queryParams.todate = toDate;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ALLOCATION_HISTORY.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ALLOCATION_HISTORY.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.ALLOCATION_HISTORY, "allocationhistories").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the SR history details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getSRHistory = function(agreementNo, limit, offset) {
			var queryParams = {
				limit : limit,
				offset : offset
			};
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SR_HISTORY.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SR_HISTORY.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SR_HISTORY, "srhistory").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the PDECS history details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getPDCECSHistory = function(agreementNo, limit, offset) {

			var queryParams = {
				limit : limit,
				offset : offset
			};
			collectionsServiceURL.caseDetailServices.FINANCIAL.PDC_ECS_HISTORY.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.FINANCIAL.PDC_ECS_HISTORY.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.PDC_ECS_HISTORY, "pdcecshistory").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the Scanned copies details for the Agreement No.
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getScannedCopyDetails = function(reqObj,limit,offset) {
			initService();
			queryParams.limit = limit;
			queryParams.offset = offset;
			queryParams.section = reqObj.section;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SCANNED_COPIES.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SCANNED_COPIES.urlParams = {
				'agreementNo' : reqObj.agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SCANNED_COPIES, "scannedcopies").then(function(data) {
				if (data.data && data.data[0] && data.data[0].data) {
					var scannedCopies = [];
					if (data.meta && data.meta.totalCount) {
						scannedCopies.totalCount = data.meta.totalCount;
					} else {
						scannedCopies.totalCount = 0;
					}					
					_.each(data.data[0].data, function(item) {
						var copy = {
							category : item.category,
							imagePathReferences : [item]
						};
						scannedCopies.push(copy);
					});
					return scannedCopies;
				} else {
					return {};
				}
			});
		};
		this.getApprovalRequest = function(agreementNo, offset, limit) {
			collectionsServiceURL.caseDetailServices.APPROVAL_REQUEST.queryParams = {
				offset : offset,
				limit : limit,
				agreementNo : agreementNo,
				view : 'casedetails'
			};
			collectionsServiceURL.caseDetailServices.APPROVAL_REQUEST.urlParams = {};
			return restProxy.get(collectionsServiceURL.caseDetailServices.APPROVAL_REQUEST).then(function(data) {
				if(data.data && data.data.length){
					_.each(data.data,function(request){
						if(request.requestType === 'NORMAL' || request.requestType === 'FORECLOSURE'){
							request.grossValue = request.approvalDetails.waiverAmount;
						}
						else{
							request.grossValue = request[collectionConstants.APPROVALS_GV[request.requestType]];
						}
					});
				}
				return data;
			});
		};
		/**
		 * Method to retrieve the case detail info for the Agreement No..
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getFIDetails = function(agreementNo) {
			collectionsServiceURL.caseDetailServices.FINANCIAL.FI_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.FI_DETAILS, "fieldinvestigation").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the underwriting info info for the Agreement No..
		 * 
		 * @param {string}
		 *            agreementNO - Agreement No.
		 */
		this.getUnderwritingInfo = function(agreementNo) {

			collectionsServiceURL.caseDetailServices.FINANCIAL.UNDERWRITING_INFO.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.UNDERWRITING_INFO, "underwritinginfo").then(function(data) {
				return formatResoponse(data);
			});
		};
		/**
		 * Method to retrieve the legal sent notice details for the Agreement No.
		 * @ofs
		 * @param {string}
		 *  agreementNO - Agreement No.
		 */
		this.getLegalSentNoticeDetails = function(agreementNo) {
			var queryParams = {
				'agreementNo' : agreementNo
			};
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.LEGAL_SENT_NOTICE_DETAILS.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.LEGAL_SENT_NOTICE_DETAILS).then(function(data) {
				if(!data){
					data = {data : {}};
				} 
				return data;
			});
		};
		/**
		 * Holding the last selected tab from case details page getLastSelectedTab method will return the last selected tab.
		 * 
		 * @param {object}
		 *            value
		 */
		this.lastSelectedTab = {};
		this.setCurrentTab = function(value) {
			this.lastSelectedTab = value;
		};
		this.getLastSelectedTab = function() {
			return this.lastSelectedTab;
		};
		
		this.downLoadFullSOA = function(fromDate,toDate){
			collectionsServiceURL.receiptingServices.GET_FULL_STATEMENT.urlParams = {
					agreementNo : soaAgrNo,
					port : 'soareport'
			};
			collectionsServiceURL.receiptingServices.GET_FULL_STATEMENT.queryParams = {
				fromdate : utility.formDateString(fromDate, true),
				todate : utility.formDateString(toDate, true)
			};
			restProxy.getBlobReport(collectionsServiceURL.receiptingServices.GET_FULL_STATEMENT).then(function(result) {
				if (result.status === "success") {
					var dateObj = new Date(),dateStr;
					dateStr = dateObj.getDate() +''+(dateObj.getMonth()+1)+''+dateObj.getFullYear()+''+dateObj.getHours()+''+dateObj.getMinutes();
					var blob = new Blob([ result.data ], {
						type : "application/pdf"
					});
					if (navigator.appVersion.toString().indexOf('.NET') > 0) {
						window.navigator.msSaveOrOpenBlob(blob, soaAgrNo+'_soa_'+dateStr+'.pdf');
					} else {
						var url = URL.createObjectURL(blob);
						var link = document.createElement("a");
						if (link.download !== undefined) {
							link.setAttribute("href", url);
							link.setAttribute("download", soaAgrNo+'_soa_'+dateStr+'.pdf');
							link.style.visibility = 'hidden';
							link.click();
							return result;
						}
					}
				}
			});
		};
		var businessDate = '';
		this.getBusinessDate = function(){
			return restProxy.get(collectionsServiceURL.caseDetailServices.FINANCIAL.GET_BUSSINESS_DATE).then(function(data) {
				if(data.data && data.data.length){
					businessDate = data.data[0].businessDate;
				}
				return businessDate;
			});
		};
		this.returnbusinessDate = function(){
			return businessDate;
		};
		var soaAgrNo;
		this.getFullStatement = function(agreementNo) {
			soaAgrNo = agreementNo;
			var maxDate;
			this.getBusinessDate().then(function(data){
				if(data){
					maxDate = data;
					$modal.open({
		                templateUrl: 'app/collections/caseDetail/partials/SOADateSelection.html',
		                controller: ['$scope','caseDetailService','$modalInstance',function($scope,caseDetailService,$modalInstance){
		                	$scope.dateObj = {};
		                	$scope.dateObj.toDateConfig = new DatePickerConfig({
		                		value : new Date(maxDate),
		                		minDate : $scope.dateObj.fromDate,
		                		maxDate : new Date(maxDate),
		                		onchange:function(val){
		        					$scope.dateObj.toDate = val;
		        					$scope.dateObj.fromDateConfig.maxDate = new Date(val.getFullYear(),val.getMonth(),val.getDate());
		        				}
		                	});
		                	$scope.dateObj.fromDateConfig = new DatePickerConfig({
		                		value : new Date(maxDate),
		                		maxDate : new Date(maxDate),
		                		onchange:function(val){
		        					$scope.dateObj.fromDate = val;
		        					$scope.dateObj.toDateConfig.minDate = new Date(val.getFullYear(),val.getMonth(),val.getDate());
		        				}
		                	});
		                	$scope.close = function(){
		                		$modalInstance.close();
		                	};
		                	$scope.getFullSOA = function(fromDate,toDate){
		                		caseDetailService.downLoadFullSOA(new Date(fromDate),new Date(toDate));
		                		$scope.close();
		                	};
		                }],
		                size: 'sm',
		                backdrop : 'static'
		            });
				}
			});
			
		};
		
		
		/**
		 * Method to retrieve the agreement list for the specific
		 * customer.
		 * 
		 * @param {string}
		 *            customer id. Response will be array of agreement
		 *            object. Storing the agreement list in the local
		 *            variable. Will be used in summary controller.
		 */
		this.getAgreementListDetails = function(cifId,agreementNo) {
			if(!cifId){
				$rootScope.agreementList = [];
				$rootScope.agreementList.push(agreementNo);
			}
			if ($rootScope.agreementList && $rootScope.agreementList.length > 0) {
				return $q.when($rootScope.agreementList);
			}
			collectionsServiceURL.myCustomerServices.AGREEMENT_LIST.queryParams = {cifID:cifId,productGroup:product};
			return restProxy.get(collectionsServiceURL.myCustomerServices.AGREEMENT_LIST).then(function(data) {						
				$rootScope.agreementList = [];
				if (data.data && data.data.length) {
					_.each(data.data, function(item) {
						if(item.agreementNo){
							$rootScope.agreementList.push(item.agreementNo);
						}
					});
				}else{
					$rootScope.agreementList.push(agreementNo);							
				}						
				return $rootScope.agreementList;
			});
		};
		
		this.getFullName = function(obj){
			var str;
			str = (!obj.firstName) ? '' : obj.firstName+ ' ';
			str += (!obj.middleName) ? '' : obj.middleName+ ' ';
			str += (!obj.lastName) ? '' : obj.lastName;
			return str;
		};
		
		this.printMiniSOA = function(miniSOAObj){
			miniSOAObj.currentDateTime = new Date();
			miniSOAObj.branchID = JSON.parse(getCookie('selectedBranch')).branchDesc;
			var paramObj = {
				templateUrl: 'app/collections/caseDetail/partials/miniSOADetails.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.miniStatement = data;
					$scope.close = function(){
						$modalInstance.close();
					};
				}],
				size : 'sm',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return miniSOAObj;
	                }
				}
			};
			return $modal.open(paramObj);
		};

		this.getshortfallWaiver = function(agreementNo,limit,offset) {
			queryParams.limit = limit;
			queryParams.offset = offset;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_WAIVER_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_WAIVER_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_WAIVER_DETAILS,'shortfallWaiver').then(function(data) {
				if (data.meta && data.meta.totalCount) {
						data.totalCount = data.meta.totalCount;
				} else {
						data.totalCount = 0;
				}
				if(data && data.data){
					_.each(data.data,function(item){
						 var approvedObj = [];
						 item.initObj = _.findWhere(item.workflow,{workStatus: "INITIATED"});
						 if(item.initObj){
						 	item.initObj.user = item.initObj ? (item.initObj.workDoneBy ? item.initObj.workDoneBy : "" ) + (item.initObj.userName ? ( '/' + item.initObj.userName) : "") : "";
						 	item.remarks = item.initObj.comments;
						 }
						 approvedObj = _.findWhere(item.workflow,{workStatus: "APPROVED"});
						 if(!approvedObj || approvedObj.length === 0){
						 	approvedObj = _.findWhere(item.workflow,{workStatus: "REJECTED"});
						 }
						 if(approvedObj){
						 	item.approvedObj = approvedObj ;
						 	item.approvedObj.user = item.approvedObj ? (item.approvedObj.workDoneBy ? item.approvedObj.workDoneBy : "" ) + (item.approvedObj.userName ? ( '/' + item.approvedObj.userName) : "") : "";
						 	item.remarks = item.approvedObj.comments;
						 }
						  
					});
					return data;
				}else {
					return [];
				}

				
			});
		};
		this.getshortfallLetter = function(agreementNo) {
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_LETTER_DETAILS.urlParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_LETTER_DETAILS,'shortfallLetters').then(function(data) {
				return data;
			});
		};

		this.getshortfallBreakup = function(agreementNo) {
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_BREAKUP_DETAILS.queryParams = {
				'agreementNo' : agreementNo
			};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.SHORT_BREAKUP_DETAILS).then(function(data) {
				return data;
			});
		};

		/**
		 * @OFS - 13-Nov-2018
		 * legal sent Notice pdf download.
		 * downloadAllLetters Function
		 */
		this.downloadAllLetters = function (requestBody, requestObj) {
			var queryObj = {
					type: requestObj.type
				},
				extn = requestObj.extn;
			var headers = {"Content-Type": "application/json;charset=UTF-8"},selectedValue = loginDetails();
			var keyName = Object.keys(selectedValue)[0];	
			var valueName = Object.keys(selectedValue).map(function(key) {return selectedValue[key];});
			headers["selected" + keyName.charAt(0).toUpperCase()+ keyName.slice(1)] = valueName[0];				
			collectionsServiceURL.noticeManagementServices.DOWNLOAD_ALL_LETTERS.EDS = environmentConfig.baseURL + '/NMLetters/' + requestObj.URL;
			collectionsServiceURL.noticeManagementServices.DOWNLOAD_ALL_LETTERS.queryParams = loginDetails(queryObj);
			return restProxy.getBlob(collectionsServiceURL.noticeManagementServices.DOWNLOAD_ALL_LETTERS, requestBody, headers, false, requestObj.dataType, false, "POST").then(function (result) {
				if (result.status === "success") {
					if (navigator.appVersion.toString().indexOf('.NET') > 0) {
						window.navigator.msSaveOrOpenBlob(result.data, requestObj.fileName+extn); //get the default name from chola for download csv file						
					} else {
						if (result.data.size > 0) {
							var url = URL.createObjectURL(result.data);
							var link = document.createElement("a");
							if (link.download !== undefined) {
								link.setAttribute("href", url);
								link.setAttribute("download", requestObj.fileName);
								link.style.visibility = 'hidden';
								link.click();
								reportblobRef.push(url);
							}
						}						
					}
				}
				return result;
			});
		};
	};
	caseDetail.service('caseDetailService', [ '$q', 'restProxy', '$rootScope', 'masterService','$modal', 'environmentConfig', caseDetailService ]);
});