define([], function() {
	'use strict';
	
	/**
	 * Contains the case detail module files name with path.
	 * Contains the case detail module required dependency configuration.
	 */	
    require.config({
        paths: {
        	'collectionsApp':'app/collections/collections',
        	'caseDetail': 'app/collections/caseDetail/caseDetail',
        	'caseDetailController': 'app/collections/caseDetail/controllers/caseDetailController',
        	'caseDetailResolver' : 'app/collections/caseDetail/resolvers/caseDetailResolver',
        	'caseDetailService' : 'app/collections/caseDetail/services/caseDetailService',
            'sharedPackage' : 'app/common/shared/package'
        },

        shim: {
        	'caseDetail': ['angular', 'angular-ui-router','caseDetailResolver'],
        	'caseDetailController': ['caseDetailService'],
        	'caseDetailService' : ['caseDetail']
        }
    });
    
    /**
	 * Call back method will get trigger once the dependency files gets loaded for the case detail module. 
	 *  @param {method} call back.
	 */
    return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs([ 'caseDetailController' ], callback);
			});
		});
	};
});