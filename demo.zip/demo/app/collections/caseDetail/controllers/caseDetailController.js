/**
 * Represents a CaseDetails Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'caseDetail', 'constants', 'utility', 'collectionConstants', 'DatePickerConfig' ], function(require, caseDetail, constants, utility, collectionConstants, DatePickerConfig) {
	'use strict';
	/**
	 * CaseDetail Controller function.getCaseDetailInfo is method in a
	 * Casedetail resolver to get the casedetail info before the page
	 * load.Dependency injection $stateparam,$scope,caseDetailService as a
	 * parameter.
	 */
	var caseDetailController = function($stateParams, $scope, $rootScope, $modal, caseDetailService, lazyModuleLoader, getCaseDetailInfo, getLoanDetailsInfo, dialogService, authService, appFactory, $globalScope, $state) {
		$scope.agreementNo = $stateParams.agreementNo;
		$scope.caseDetailModel = (!getCaseDetailInfo) ? {} : getCaseDetailInfo;
		$scope.customerInfo = angular.copy(utility.getCustomerInfo(getCaseDetailInfo));
		$scope.loanDetails = (!getLoanDetailsInfo) ? {} : getLoanDetailsInfo;
		$scope.activity = {};
        $scope.activity.isVishesh = ($scope.caseDetailModel.productCode === 'VISHESH' || $scope.caseDetailModel.productCode === 'TRIP');
		$scope.applicantDetails = _.findWhere($scope.caseDetailModel.partyDetails, {
			"partyType" : collectionConstants.PARTY_TYPE_APPLICANT
		});
		$scope.currentTab = caseDetailService.getLastSelectedTab();
		$scope.bgStyle = {
			'border-top-color' : $scope.caseDetailModel.colourCode
		};
		$scope.miniStatementInfo = {};
		var emiOD,fvcOD,afcOD,cbcOD,totalChargesOD,totalPaymentOD,otherOD;
		$scope.pagination = {
			pageMaxSize : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
			tenRecordsPerPage : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
			maxSize : constants.PAGINATION_CONFIG.MAX_SIZE_TEN,
			approval : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			repayment : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			receipt : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			disbursal : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			pdcECSHistory : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			chequeBounce : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			expense : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			contactInfo : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			followUpTrial : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			bank : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			allocationHistory : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			legal : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			referralHistory : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			SRHistory : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			scannedCopy : {
				currentPage : 1,
				offsetLast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset : 1
			},
			shortfallWaiver: {
				currentPage: 1,
				offsetLast: constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
				offset: 1
			}
		};
		
		/* Pagination ends here */
		$scope.chequeStatus = constants.CHEQUE_STATUS;
		$scope.interestType = constants.INTERESTTYPE;
		$scope.instalmentplan = constants.INSTALMENT_PLAN;
		$scope.paymentModeRev = constants.PAYMENT_MODE_REVERSE;
		$scope.relationsType = constants.RELATIONS;
		$scope.caseTypes = constants.CASE_TYPES;
		$scope.installmentMode = constants.INSTALLMENT_MODE;
		$scope.caseValue = $scope.caseTypes[0];
		$scope.cashType = collectionConstants.CASHTYPE;
		$globalScope.goPreviousState = {
			name : 'collections.myCustomers.summary',
			params : $state.params
		};
		var initController = function() {
			$scope.activity.miniStatement = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.PRINT_MINISTATEMENT);
			$scope.activity.appointment = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.APPOINTMENT);
			$scope.activity.contactRecording = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.CONTACT_RECORDING);
			$scope.activity.receipting = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.RECEIPTING);
			$scope.activity.summary = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.VIEW_SUMMARY);
		};
		initController();
		var getApplicanInfo = function(partyDetails) {
			var partyObj = _.findWhere(partyDetails, {
				'partyType' : 'Applicant'
			});
			if (!partyObj) {
				partyObj = _.findWhere(partyDetails, {
					'partyType' : 'A'
				});
			}
			return partyObj;
		};
		$scope.applicant = getApplicanInfo($scope.caseDetailModel.partyDetails);
		$scope.agreementNo = $stateParams.agreementNo;
		if ($scope.applicant && $scope.applicant.cifID !== '' && !$scope.activity.isVishesh) {
			caseDetailService.getAgreementListDetails($scope.applicant.cifID, $stateParams.agreementNo).then(function(agreementList) {
				$scope.agreementList = agreementList;
				$scope.agreementNo = $stateParams.agreementNo;
			});
		}
		/** Method to retrieve the  ODDetails for loan details/Emi Outstandings. */
		var setODDetails = function(data){
			emiOD = _.findWhere(data.ODDetails, {
				"receiptChargeType" : "EMI"
			});
			emiOD = emiOD && emiOD.actual ? emiOD.actual : 0;
			fvcOD = _.findWhere(data.ODDetails, {
				"receiptChargeType" : "FVC"
			});
			fvcOD = fvcOD && fvcOD.actual ? fvcOD.actual : 0;
			afcOD = _.findWhere(data.ODDetails, {
				"receiptChargeType" : "AFC"
			});
			afcOD = afcOD && afcOD.actual ? afcOD.actual : 0;
			cbcOD = _.findWhere(data.ODDetails, {
				"receiptChargeType" : "CBC"
			});
			cbcOD = cbcOD && cbcOD.actual ? cbcOD.actual : 0;
			var otherOD = 0;
			_.each(data.otherODCharges,function(item) {
				otherOD = otherOD + item;
			});
			 totalChargesOD = Number(fvcOD) + Number(cbcOD) + Number(afcOD) + Number(otherOD);
			 totalPaymentOD = Number(emiOD) + totalChargesOD;
		};
		
		/** Method to retrieve the preEmiOd from ODDetails for loan details. */
		var getEmiInLoanDetails = function(){
			if ($scope.loanDetails && $scope.loanDetails.ODInfo && $scope.loanDetails.ODInfo.ODDetails) {
				setODDetails($scope.loanDetails.ODInfo);
				$scope.loanDetails.preEmiOd = 0;
				$scope.loanDetails.emiOD = 0;
				var preEmi,emi;
				preEmi = _.findWhere($scope.loanDetails.ODInfo.ODDetails, {
					"chargeType" : "PREEMIOD"
				});
				preEmi = (preEmi) ? preEmi.chargeAmount - preEmi.paidAmount : 0;
				$scope.loanDetails.preEmiOd = preEmi;
				emi = _.findWhere($scope.loanDetails.ODInfo.ODDetails, {
					"receiptChargeType" : "EMI"
				});
				emi = (emi) ? Number(emi.chargeAmount) - Number(emi.paidAmount) : 0;
				$scope.loanDetails.emiOD = emi < 0 ? 0 : emi;
				$scope.loanDetails.totalPaymentOD = totalPaymentOD;
			}
		};
		getEmiInLoanDetails();
		/** Method to check loan detials delinquency is empty* */
		$scope.loanDetails.delinquencyString = $scope.loanDetails.delinquency ? $scope.loanDetails.delinquency :[];
		
		/**
		 * Date handling directive input configuration for the From date field
		 */
		$scope.fromDate_picker_config = new DatePickerConfig({
			value : ''
		});
		/**
		 * Date handling directive input configuration for the To date field
		 */
		$scope.toDate_picker_config = new DatePickerConfig({
			value : '',
			maxDate : new Date()
		});
		/**
		 * min date restriction for to date when from date is changed
		 */
		$scope.fromDate_picker_config.onchange = function(value) {
			$scope.toDate_picker_config.minDate = value;
			$scope.fromDate = value;
		};
		/**
		 * max date restriction for from date when to date is changed
		 */
		$scope.toDate_picker_config.onchange = function(value) {
			$scope.fromDate_picker_config.maxDate = value;
			$scope.toDate = value;
		};
		/**
		 * Method to retrieve the case detail info for the Agreement No.
		 */
		$scope.agreementChangeHandler = function(agreementNo) {
			if (!$scope.currentTab) {
				$scope.currentTab = $scope.caseDetailTabs[0];
			}
			$scope.currentTab.isSelected = true;
			caseDetailService.setCurrentTab($scope.currentTab);
			var params = {
				agreementNo : agreementNo
			};
			$globalScope.removeAndResetLastState('agreementNo', agreementNo);
			lazyModuleLoader.loadState(collectionConstants.LOAD_CASE_DETAIL, params);
		};
		/**
		 * Method to retrieve the loan details info for the Agreement No.
		 */
		$scope.frequency = constants.FREQUENCY;
				
		$scope.getLoanDetails = function() {
			caseDetailService.getLoanDetails($scope.agreementNo, $scope.caseDetailModel.productID).then(function(data) {
				$scope.loanDetails = data;
				$scope.loanDetails.delinquencyString = $scope.loanDetails.delinquency ? $scope.loanDetails.delinquency :[];
				getEmiInLoanDetails();
			});
		};
		/**
		 * Method to retrieve the EMI outstanding info for the Agreement No.
		 */
		$scope.getEMIOutstandingInfo = function() {
			caseDetailService.getEMIOutstandingDetail($scope.agreementNo).then(function(data) {
				if (data && data.ODDetails) {
					setODDetails(data);
					$scope.caseDetailModel.emiOutStanding = {};
					otherOD = 0;
					$scope.caseDetailModel.emiOutStanding = {
						emiOD : $scope.activity.isVishesh ?  data.totalEMIODAmount : emiOD,
						POS : data.principalOS,
						otherOD : $scope.activity.isVishesh ?  data.totalOtherOD : otherOD,
						cbcOD : $scope.activity.isVishesh ?  data.totalCBCODAmount : cbcOD,
						afcOD : $scope.activity.isVishesh ?  data.totalAFCODAmount : afcOD,
						fvcOD : $scope.activity.isVishesh ?  data.totalFVCODAmount : fvcOD,
						principleOD : data.totalPrincipalOD,
						interestOD : $scope.activity.isVishesh ?  data.totalInterestOD : data.totalInterestOD,
						tenure : data.tenure,
						emiAmount : data.emiAmount,
						totalChargesOD : totalChargesOD,
						totalPaymentOD : totalPaymentOD
					};
					$scope.currentTab.noRecordFound = ($scope.caseDetailModel.emiOutStanding.length === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Repayment schedule info for the Agreement No.
		 */
		$scope.getRepaymentDetails = function() {
			$scope.repayScheduleInfo = [];
			caseDetailService.getRepaymentScheduleDetail($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.repayment.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.repayScheduleInfo = data.items;
					$scope.pagination.repayment.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.repayment.offsetLast = ($scope.pagination.repayment.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.repayment.totalRecordCount : $scope.pagination.repayment.offsetLast;
					$scope.currentTab.noRecordFound = ($scope.pagination.repayment.totalRecordCount === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the mini statement info for the Agreement No.
		 * Getting response as list of charges with amount, type and date.
		 * Forming an array it has month and charges array.
		 */

		var getMiniStatementData = function() {
			if ($scope.miniStatementInfo.data && $scope.miniStatementInfo.data.chargeDtl) {
				$scope.emiOutstandings = {};
				var emiOD, otherOD, instmntOD;
				emiOD = _.findWhere($scope.miniStatementInfo.data.chargeDtl, {
					"chargeID" : "EMIOD"
				});
				emiOD = (emiOD) ? emiOD.chargeAmount : 0;
				$scope.emiOutstandings.emiOD = emiOD;
				$scope.miniStatementInfo.data.emiOD = emiOD;
				otherOD = _.findWhere($scope.miniStatementInfo.data.chargeDtl, {
					"chargeID" : "OTHEROD"
				});
				otherOD = (otherOD) ? otherOD.chargeAmount : 0;
				$scope.emiOutstandings.otherOD = otherOD;
				$scope.miniStatementInfo.data.otherOD = otherOD;
				instmntOD = _.findWhere($scope.miniStatementInfo.data.chargeDtl, {
					"chargeID" : "INSTALLMENTOD"
				});
				instmntOD = (instmntOD) ? instmntOD.chargeAmount : 0;
				$scope.emiOutstandings.instmntOD = instmntOD;
			}
		};

		var monthStr;
		
		var fetchMiniStatementInfo = function(months,toDate) {
			months = (!months) ? collectionConstants.THREE_MONTHS : months;
			monthStr = (months === '3') ? 't' : (months === '6') ? 's' : 'y';
			/*if ($scope.miniStatementInfo[monthStr + 'monthsInfo']) {
				$scope.printCheck = (months === collectionConstants.TWELVE_MONTHS)? true :(!$scope.miniStatementInfo[monthStr + 'monthsInfo'].length);
				return;
			}*/
			caseDetailService.getMiniStatementDetail($scope.agreementNo,months).then(function(data) {
				if (!data.miniStateDtl) {
					$scope.printCheck = true;
					$scope.miniStatementInfo[monthStr + 'monthsInfo'] = [];
					return;
				}
				$scope.miniStatementInfo.data = data;
				$scope.miniStatementInfo.data.monthInfo = months;
				$scope.miniStatementInfo.data.cifID = $scope.applicantDetails.cifID;
				var dayDifference = utility.dateDifference(new Date(data.miniStateDtl.installmentFrom), new Date());
				if (dayDifference > 180) {
					$scope.miniStatementInfo.tabs = collectionConstants.NINE_MONTHS;
				} else if (dayDifference > 90) {
					$scope.miniStatementInfo.tabs = collectionConstants.SIX_MONTHS;
				} else {
					$scope.miniStatementInfo.tabs = collectionConstants.THREE_MONTHS;
				}
				getMiniStatementData();
				$scope.miniStatementInfo[monthStr + 'monthsInfo'] = [];
				$scope.printCheck = (data.chargeDtl && data.chargeDtl.length > 0 && months !== collectionConstants.TWELVE_MONTHS) ? false : true;
				$scope.miniStatementInfo[monthStr + 'monthsInfo'] = data.chargeDtl;
				/*var chargeList = caseDetailService.getChargesList(), charge;
				_.each($scope.miniStatementInfo[monthStr + 'monthsInfo'], function(item) {
					charge = _.findWhere(chargeList, {
						chargeID : item.chargeID
					});
					item.chargeDesc = (charge) ? charge.chargeDesc : item.chargeID;
				});*/
			});
		};
		
		$scope.getMiniStatementInfo = function(months) {
			var businessDate = caseDetailService.returnbusinessDate();
			if(businessDate){
				fetchMiniStatementInfo(months,businessDate);
			}
			else{
				caseDetailService.getBusinessDate().then(function(data){
					if(data){
						fetchMiniStatementInfo(months,data);
					}
				});
			}			
		};
		
		/**
		 * Method to retrieve the Receipt info for the Agreement No.
		 */
		$scope.chequeBounce = constants.CHEQUE_BOUNCED;
		$scope.getReceiptDetails = function() {
			$scope.receiptInfoModel = [];
			caseDetailService.getReceiptDetails($scope.agreementNo, $scope.pagination.tenRecordsPerPage, $scope.pagination.receipt.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.receiptInfoModel = data.items;
					$scope.pagination.receipt.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.receipt.offsetLast = ($scope.pagination.receipt.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.receipt.totalRecordCount : $scope.pagination.receipt.offsetLast;
					$scope.currentTab.noRecordFound = ($scope.pagination.receipt.totalRecordCount === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Cheque bounce info for the Agreement No.
		 */
		$scope.getChequeBounceDetails = function() {
			$scope.chequeBounceInfo = [];
			caseDetailService.getChequeBounceDetails($scope.agreementNo,$scope.pagination.pageMaxSize, $scope.pagination.chequeBounce.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.chequeBounceInfo = data.items;
					$scope.pagination.chequeBounce.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.chequeBounce.offsetLast = ($scope.pagination.chequeBounce.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.chequeBounce.totalRecordCount : $scope.pagination.chequeBounce.offsetLast;
					$scope.currentTab.noRecordFound = ($scope.pagination.chequeBounce.totalRecordCount === 0 || $scope.chequeBounceInfo.length === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the follow up trials for the Agreement No.
		 */
		$scope.getFollowUpTrialDetails = function() {
			$scope.followUpTrialInfo = [];
			caseDetailService.getFollowUpTrialDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.followUpTrial.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.followUpTrialInfo = data.items;
					$scope.pagination.followUpTrial.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.followUpTrial.offsetLast = ($scope.pagination.followUpTrial.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.followUpTrial.totalRecordCount : $scope.pagination.followUpTrial.offsetLast;
					$scope.currentTab.noRecordFound = ($scope.pagination.followUpTrial.totalRecordCount === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Expense detail for the Agreement No.
		 */
		$scope.getExpenseDetails = function() {
			$scope.expenseDetail = [];
			caseDetailService.expenseDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.expense.offset).then(function(data) {
				if (data.totalCount) {
					$scope.expenseDetail = data;
					$scope.pagination.expense.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.expense.offsetLast = ($scope.pagination.expense.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.expense.totalRecordCount : $scope.pagination.expense.offsetLast;
					$scope.currentTab.noRecordFound = (data.length === 0 || $scope.pagination.expense.totalRecordCount === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the party details info for the Agreement No.
		 */
		$scope.maritalStatus = constants.MARITAL_STATUS;
		$scope.getEmploymentDetails = function() {
			caseDetailService.getEmploymentDetails($scope.agreementNo).then(function(data) {
				$scope.employmentInfo = data;
				var applicant = getApplicanInfo(data.partyDetails);
				$scope.employmentInfo.applicantDetails = applicant || {};
				$scope.employmentInfo.applicantDetails.fullName = caseDetailService.getFullName($scope.employmentInfo.applicantDetails);
				if ($rootScope.productType === 'HE' || $rootScope.productType === 'HL') {
					var coApplicants = _.where(data.partyDetails, {
						partyType : 'C'
					});
					_.each(coApplicants,function(item){
						item.fullName = caseDetailService.getFullName(item);
					});
					$scope.employmentInfo.coApplications = coApplicants;
				}

			});
		};
		
		var getCurrentAddress = function(){
			if($scope.caseDetailModel && $scope.caseDetailModel.addressDetails){
			var currentAddress = _.findWhere($scope.caseDetailModel.addressDetails, {
				'addressType' : collectionConstants.CURRENT_ADDRESS,
				isMailingAddress : true
				//isActive : true
			});
			if (!currentAddress) {
				currentAddress = _.findWhere($scope.caseDetailModel.addressDetails, {
					'addressType' : collectionConstants.PERMANENT_ADDRESS,
					isMailingAddress : true
					//isActive : true
				});
			}
			if (!currentAddress) {
				currentAddress = _.findWhere($scope.caseDetailModel.addressDetails, {
					'addressType' : collectionConstants.OFFICE,
					isMailingAddress : true
					//isActive : true
				});
			} 
			if(currentAddress){
				var addressData = [];
				$scope.caseDetailModel.currentAddress = currentAddress;
				if(currentAddress.addressLine1){
					addressData.push(currentAddress.addressLine1);
				}if(currentAddress.addressLine2){
					addressData.push(currentAddress.addressLine2);
				}if(currentAddress.addressLine3){
					addressData.push(currentAddress.addressLine3);
				}if(currentAddress.landmark){
					addressData.push(currentAddress.landmark);
				}if(currentAddress.cityDesc){
					addressData.push(currentAddress.cityDesc);
				}if(currentAddress.stateDesc){
					addressData.push(currentAddress.stateDesc);
				}if(currentAddress.pincode){
					addressData.push(currentAddress.pincode);
				}
				$scope.caseDetailModel.currentAddress.address = addressData.length ? addressData.toString():{};
			}else{
				$scope.caseDetailModel.currentAddress = '';
			}
			}
			if($scope.caseDetailModel && $scope.caseDetailModel.thirdPartyDetails && $scope.caseDetailModel.thirdPartyDetails.length){
				$scope.caseDetailModel.thirdParty = $scope.caseDetailModel.thirdPartyDetails[0];
				$scope.caseDetailModel.thirdParty.address = ($scope.caseDetailModel.thirdParty && $scope.caseDetailModel.thirdParty.thirdPartyAddresses && $scope.caseDetailModel.thirdParty.thirdPartyAddresses[0]) ? utility.setAddress($scope.caseDetailModel.thirdParty.thirdPartyAddresses[0],true).toString():{};
			}
		};
		getCurrentAddress();
		/**
		 * Method to retrieve the Contact info for the Agreement No.
		 */
		$scope.getContactInfoDetails = function() {
			caseDetailService.getContactInfoDetail($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.contactInfo.offset).then(function(data) {
				if (data) {
					if (!$scope.contactInfo || !$scope.contactInfo.currentAddress) {
						$scope.contactInfo = data;
						$scope.pagination.contactInfo.totalRecordCount = $scope.contactInfo.totalCount;
						$scope.pagination.contactInfo.offsetLast = ($scope.pagination.contactInfo.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.contactInfo.totalRecordCount : $scope.pagination.contactInfo.offsetLast;
					} else {
						$scope.contactInfo.contactInfo = data.contactInfo;
					}
					getPropertyDetails($scope.contactInfo.contactInfo ? $scope.contactInfo.contactInfo :[]);
					$scope.currentTab.noRecordFound = ($scope.contactInfo.totalCount && $scope.contactInfo.totalCount > 0) ? false : true;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Bank details for the Agreement No.
		 */
		$scope.getBankDetails = function() {
			$scope.caseDetailModel.bankDetail = [];
			caseDetailService.getBankDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.bank.offset).then(function(data) {
				$scope.currentTab.noRecordFound = false;
				$scope.caseDetailModel.bankDetail = data.bankDetails;
				if (data && (!data.bankDetails || data.bankDetails.length === 0)) {
					$scope.currentTab.noRecordFound = true;
				}
				if (!data) {
					$scope.currentTab.noRecordFound = true;
				} else {
					$scope.pagination.bank.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.bank.offsetLast = ($scope.pagination.bank.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.bank.totalRecordCount : $scope.pagination.bank.offsetLast;
				}
			});
		};
	
		var getPropertyDetails = function(assetDetails){
			if(assetDetails && assetDetails.length>0){
				_.each(assetDetails,function(item){
					item.address = utility.setAddress(item,true).toString();//(dataItem && dataItem.length)?dataItem.toString():'';
				});
			}
		};
		/**
		 * Method to retrieve the Asset info for VF for the Agreement No.
		 */
		$scope.getAssetDetals = function() {
			$scope.caseDetailModel.assetDetail = {};
			if ($scope.caseDetailModel.productGroup === 'VF') {
				$scope.nonFinancialTabs[0].title = 'Asset Details';
			}else if($scope.caseDetailModel.productGroup === 'HE' || $scope.caseDetailModel.productGroup === 'HL'){
				$scope.nonFinancialTabs[0].title = 'Property Details';
			}
			caseDetailService.getAssetDetails($scope.agreementNo).then(function(data) {
				$scope.caseDetailModel.assetDetail = data;
				if ($scope.caseDetailModel.productGroup === 'HE' || $scope.caseDetailModel.productGroup === 'HL') {
					getPropertyDetails($scope.caseDetailModel.assetDetail.items);
					$scope.currentTab.noRecordFound = (!$scope.caseDetailModel.assetDetail.items || $scope.caseDetailModel.assetDetail.items.length === 0) ? true : false;
				}
			});
		};
		/**
		 * Method to retrieve the Disubursal details for the Agreement No.
		 */
		$scope.getDisbursalDetails = function() {
			$scope.caseDetailModel.disbursalInformation = {};
			caseDetailService.getDisbursalDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.disbursal.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.caseDetailModel.disbursalInformation = data.disbursalInformation;
					$scope.pagination.disbursal.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.disbursal.offsetLast = ($scope.pagination.disbursal.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.disbursal.totalRecordCount : $scope.pagination.disbursal.offsetLast;
					$scope.currentTab.noRecordFound = (data.disbursalInformation.length === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the reference details for the Agreement No.
		 */
		$scope.getReferenceDetails = function() {
			$scope.caseDetailModel.referenceDetail = {};
			//$scope.currentTab.noRecordFound = false;
			caseDetailService.getReferenceDetails($scope.agreementNo).then(function(data) {
				if (data && data.referenceDetails && data.referenceDetails.length !== 0) {
					$scope.caseDetailModel.referenceDetail = data.referenceDetails;
					$scope.currentTab.noRecordFound = (data.referenceDetails.length === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Insurance details for the Agreement No.
		 */
		$scope.getInsuranceDetails = function() {
			//$scope.currentTab.noRecordFound = false;
			caseDetailService.getInsuranceDetails($scope.agreementNo).then(function(data) {
				if (data) {
					$scope.insuranceDetail = data;
					// no record found is handled in html
				}
			});
		};
		/**
		 * Method to retrieve the Insurance details for the Agreement No.
		 */
		$scope.getIncomeDetails = function() {
			caseDetailService.getIncomeDetails($scope.agreementNo).then(function(data) {
				$scope.applicantInfo = _.findWhere(data.partyDetails, {
					partyType : 'A'
				}) || {};
				$scope.applicantInfo.fullName = caseDetailService.getFullName($scope.applicantInfo);
				
				var coApplicants = _.where(data.partyDetails, {
					partyType : 'C'
				});
				_.each(coApplicants,function(item){
					item.fullName = caseDetailService.getFullName(item);
				});
				$scope.coApplicantsInfo = coApplicants;
				
			});
		};
		/**
		 * Method to retrieve the Referral history for the Agreement No.
		 */
		$scope.getReferralHistoryDetails = function() {
			$scope.caseDetailModel.referralDetail = {};
			caseDetailService.getReferralHistoryDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.referralHistory.offset).then(function(data) {
				// to be uncommented when service is received
				/*
				 * if(data){
				 * caseDetailService.masterServiceBranchDetails(function(branchData){
				 * $scope.caseDetailModel.referralDetail = data;
				 * $scope.caseDetailModel.referralDetail.branchName =
				 * branchData; console.log('controller',branchData);
				 * $scope.currentTab.noRecordFound =
				 * ($scope.caseDetailModel.referralDetail.referralDetails.length
				 * === 0);
				 * 
				 * }); }
				 */
				if (data && data.referralDetails && data.referralDetails.length > 0) {
					$scope.caseDetailModel.referralDetail = data;
					$scope.pagination.referralHistory.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.referralHistory.offsetLast = ($scope.pagination.referralHistory.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.referralHistory.totalRecordCount : $scope.pagination.referralHistory.offsetLast;
					$scope.currentTab.noRecordFound = (!$scope.caseDetailModel.referralDetail || $scope.caseDetailModel.referralDetail.referralDetails.length === 0);

				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};

		/**
		 * Method to retrieve the Guarantor details for the Agreement No.
		 */
		$scope.shortGender = constants.SHORT_GENDER;
		$scope.getGuarantorDetails = function() {
			caseDetailService.getGuarantorDetails($scope.agreementNo).then(function(data) {
				$scope.applicantInfo = _.findWhere(data.partyDetails, {
					partyType : 'G'
				}) || {};
				$scope.applicantInfo.fullName = caseDetailService.getFullName($scope.applicantInfo);
				var coApplicantArr = _.where(data.partyDetails, {
					partyType : 'C'
				});
				_.each(coApplicantArr, function(item) {
					item.customerAddress = utility.setAddress(item.addressDetails[0]);
					item.fullName = caseDetailService.getFullName(item);
				});
				$scope.coApplicantsInfo = coApplicantArr;
				if($scope.applicantInfo){
					$scope.applicantInfo.guarantorAddress = ($scope.applicantInfo && $scope.applicantInfo.addressDetails && $scope.applicantInfo.addressDetails[0]) ? utility.setAddress($scope.applicantInfo.addressDetails[0]):'';
				}
			});
		};

		/**
		 * Method to retrieve the mini statement info for the Agreement No.
		 */
		$scope.gotoMiniStatementPage = function() {
			$scope.caseDetailTabs[0].active = true;
			var miniStatementTab = _.findWhere($scope.financialTabs, {
				title : collectionConstants.FIANCIAL_TABS.MINI_STATEMENT
			});
			miniStatementTab.active = true;
			var index = utility.getItemIndex($scope.financialTabs, miniStatementTab);
			$scope.tabChangeHandler($scope.financialTabs[index]);
		};

		$scope.viewSummaryHandler = function() {
			var params = {
				agreementNo : $scope.agreementNo,
				filter: 'All'
			};
			lazyModuleLoader.loadState(collectionConstants.LOAD_SUMMARY_PAGE, params);
		};

		$scope.receiptClickHandler = function() {
			$rootScope.agreementNo = $scope.agreementNo;
			$globalScope.goPreviousState = {
				name : $state.current.name,
				params : $state.params
			};
			$globalScope.isClickedViaMenu = false;
			lazyModuleLoader.loadState('collections.ePayment', {
				agreementNo : $scope.agreementNo,
				receiptType : $scope.activity.isVishesh ? $scope.caseDetailModel.productCode :'OD'
			});
		};

		$scope.viewContactRecording = function() {
			$globalScope.goPreviousState = {
				name : $state.current.name,
				params : $state.params
			};
			$rootScope.agreementNo = $scope.agreementNo;
			lazyModuleLoader.loadState('collections.contactRecording', {
				agreementNo : $rootScope.agreementNo
			});
		};

		/**
		 * Method to retrieve the Allocation history info for the Agreement No.
		 */
		$scope.getAllocationHistoryDetails = function(type) {
			var fromDateStr = "";
			var toDateStr = "";
			$scope.allocationHistoryInfo = [];
				if (!$scope.fromDate_picker_config.value && !$scope.toDate_picker_config.value && type) {
					
						$scope.pagination.allocationHistory.offset = $scope.pagination.allocationHistory.currentPage = 1 ;
						
				}else if($scope.fromDate_picker_config.value !== "" && $scope.fromDate_picker_config.value !== null && $scope.toDate_picker_config.value !== "" && $scope.toDate_picker_config.value !== null){
						
					var fromDate = $scope.fromDate_picker_config.value.split('/');
					fromDateStr = fromDate[2] + '/' + fromDate[1] + '/' + fromDate[0];
					var toDate = $scope.toDate_picker_config.value.split('/');
					toDateStr = toDate[2] + '/' + toDate[1] + '/' + toDate[0];
				}
			caseDetailService.allocationHistoryDetails($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.allocationHistory.offset, fromDateStr, toDateStr).then(function(data) {
				if (data && data.totalCount) {
					$scope.allocationHistoryInfo = data;
					$scope.pagination.allocationHistory.totalRecordCount = data.totalCount;
					$scope.allHistory = data.items;
					$scope.pagination.allocationHistory.offsetLast = ($scope.pagination.allocationHistory.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.allocationHistory.totalRecordCount : $scope.pagination.allocationHistory.offsetLast;
					$scope.currentTab.noRecordFound = (data.length === 0 || data.totalCount === 0 || data.items.length === 0) ? true : false;

				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Legal details for the Agreement No.
		 */
		$scope.getLegalDetails = function() {
			/*Legal Sent Notice Details */
			/**
			 * Method to retrieve the legal sent notice details info for the Agreement No..
			 */
			$scope.getLegalSentNoticeDetails = function(agreements) {
				caseDetailService.getLegalSentNoticeDetails(agreements).then(function(responseData) {
					if(responseData.data && responseData.data.noticeManagementLetter.length > 0 &&  responseData.data.noticeManagementLetter[0].letters.length > 0){
						/**
						 * @OFS - 13-Nov-2018
						 * Method to retrieve the legal sent notice details for the Agreement No.
						 * getLegalDetails Function for Non-Financial Legal modal popup.
						 */
						$modal.open({
							templateUrl: 'app/collections/caseDetail/partials/nonFinancial/legalNoticePopup.html',
							controller: ['$scope', '$modalInstance', 'dialogService', 'data', '$globalScope', '$rootScope', '$upload', 'environmentConfig', function ($scope, $modalInstance, dialogService, data, $globalScope, $rootScope, $upload, environmentConfig) {
								$scope.close = function () {
									$modalInstance.close();
								};
								$scope.uploadClose = function () {
									$modalInstance.close(true);
								};
								if (data.data && data.data.noticeManagementLetter.length > 0 &&  data.data.noticeManagementLetter[0].letters.length > 0) {
									$scope.data = data;
									$scope.noRecordFound = false;
								} else {
									$scope.noRecordFound = true;
								}
								$scope.downloadSelectedNotice = function (item) {
									var requestBody = [];
									var object = {
										"runID": item.referenceNo,
										"agreementNo": data.agreements,
										"dispatchedTo": item.dispatchedTo
									};
									requestBody.push(object);
									var queryObj = {
										extn: '.pdf',
										fileName: data.agreements,
										URL: 'getReferenceDetail',
										dataType: 'application/pdf'
									};
									dialogService.confirm(collectionConstants.REPO_MSG.CONFIRM, collectionConstants.REPO_MSG.CONFIRM, collectionConstants.NOTICE_MANAGEMENT_CONSTANTS.ALERT_MESSAGES.REPRINT_LETTER_NOTICE).result.then(function () {
										caseDetailService.downloadAllLetters(requestBody, queryObj).then(function (result) {
											if (result && result.status.toUpperCase() === 'SUCCESS') {
												$modalInstance.dismiss();
											}
										});
									}, function () {});
								};
							}],
							backdrop: 'static',
							size: 'lg',
							resolve: {
								data: function () {
									return {
										agreements: $scope.agreementNo,
										data: responseData.data
									};
								}
							}
						}).result.then(function () {}, function () {
							if(data && data!='escape key press'){
							}					
						});
					}
				});
			};
			$scope.getLegalSentNoticeDetails($scope.agreementNo);
			$scope.legalData = [];
			caseDetailService.getLegalDetail($scope.agreementNo,$scope.pagination.pageMaxSize, $scope.pagination.legal.offset).then(function(data) {
				
				if (data && data.totalCount) {
					$scope.legalData = data.data;
					$scope.pagination.legal.totalRecordCount = data.totalCount;
					$scope.pagination.legal.offsetLast = ($scope.pagination.legal.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.legal.totalRecordCount : $scope.pagination.legal.offsetLast;
					$scope.currentTab.noRecordFound = (data.totalCount === 0) ? true : false;

				}else{
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		var lastOpendItem = {};
		/** Expand/Collapse action for Expense history tab */
		$scope.openInvoice = function(item) {
			console.log(item);
			lastOpendItem.isOpen = false;
			item.isOpen = true;
			lastOpendItem = item;				
		};

		/**
		 * Method to retrieve the SR History info for the Agreement No.
		 */
		$scope.getSRHistoryDetails = function() {
			$scope.srHistory = [];
			caseDetailService.getSRHistory($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.SRHistory.offset).then(function(data) {
				if (data && data.SRHistories && data.SRHistories.length > 0) {
					$scope.srHistorys = data.SRHistories;
					$scope.pagination.SRHistory.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.SRHistory.offsetLast = ($scope.pagination.SRHistory.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.SRHistory.totalRecordCount : $scope.pagination.SRHistory.offsetLast;
					$scope.currentTab.noRecordFound = (data.SRHistories.length === 0);
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the ECS History for the Agreement No..
		 */
		$scope.getpdcECSHistoryDetails = function() {
			$scope.pdcECSHistory = [];
			caseDetailService.getPDCECSHistory($scope.agreementNo, $scope.pagination.pageMaxSize, $scope.pagination.pdcECSHistory.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.pdcECSHistory = data.items;
					$scope.pagination.pdcECSHistory.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.pdcECSHistory.offsetLast = ($scope.pagination.pdcECSHistory.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.pdcECSHistory.totalRecordCount : $scope.pagination.pdcECSHistory.offsetLast;
					$scope.currentTab.noRecordFound = (data.totalCount === 0) ? true : false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};

		/**
		 * Method to retrieve the Repayment History for the Agreement No..
		 */
		$scope.getRepaymentHistory = function() {
			$scope.repaymentHistory = [];
			caseDetailService.getRepayHistoryDetail($scope.agreementNo).then(function(data) {
				$scope.repaymentHistory = data;
				$scope.currentTab.noRecordFound = (data.totalCount === 0);
			});
		};
		/* Fi starts here */
		/* Method to sort data from the service */
		var sortGeneralDet = function() {
			var residenceParamsArr = _.where($scope.fieldInvDetails, {
				"type" : "Residence"
			});
			$scope.businessParamsArr = _.where($scope.fieldInvDetails, {
				"type" : "Business"
			});
			var rank = collectionConstants.CASE_DETAILS_RANKS;
			// filter the data general data from residence params
			$scope.genralDataArr = _.filter(residenceParamsArr.value, function(item) {
				return _.contains(Object.keys(rank), item.investigationParameter);
			});
			// sort the general data according to the rank object
			$scope.genralDataArr = _.sortBy($scope.genralDataArr, function(item) {
				return rank[item.investigationParameter];
			});
			// filter thr residence data
			$scope.filteredResidenceArr = _.reject(residenceParamsArr.value, function(item) {
				return _.contains(Object.keys(rank), item.investigationParameter);
			});
			$scope.residenceParams = (residenceParamsArr.value.length === 0) ? true : false;
			$scope.businessParams = ($scope.businessParamsArr.value.length === 0) ? true : false;
			$scope.generalParams = ($scope.genralDataArr.length === 0) ? true : false;
		};
		/**
		 * Method to retrieve the Field Investigation details for the Agreement
		 * No..
		 */
		$scope.getFIDetails = function() {
			caseDetailService.getFIDetails($scope.agreementNo).then(function(data) {
				$scope.currentTab.noRecordFound = false;
				if (data && data.investigationDetails) {
					$scope.fieldInvDetails = data.investigationDetails;
					//sortGeneralDet();
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/* Fi ends here */
		/**
		 * Method to retrieve the underwriting info for the Agreement No..
		 */
		$scope.getUnderwritingInfo = function() {
			caseDetailService.getUnderwritingInfo($scope.agreementNo).then(function(data) {
				if (data && data.totalCount) {
					$scope.underwritingInfo = data;
					$scope.currentTab.noRecordFound = false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Scanned copy details for the Agreement No..
		 */
		$scope.getScannedCopyDetails = function() {
			$scope.scannedCopies = [];
			var reqObj = {
				agreementNo : $scope.agreementNo,
				section : $scope.caseValue.value
			};
			caseDetailService.getScannedCopyDetails(reqObj, $scope.pagination.pageMaxSize, $scope.pagination.scannedCopy.offset).then(function(data) {
				if (data && data.totalCount) {
					$scope.scannedCopies = data;
					$scope.pagination.scannedCopy.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.scannedCopy.offsetLast = ($scope.pagination.scannedCopy.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.scannedCopy.totalRecordCount : $scope.pagination.scannedCopy.offsetLast;
					$scope.currentTab.noRecordFound = false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Shortfall Waiver details for the Agreement No.
		 */
		$scope.getShortfallWaiverDetails = function () {
			caseDetailService.getshortfallWaiver($scope.agreementNo,$scope.pagination.pageMaxSize, $scope.pagination.shortfallWaiver.offset).then(function (data) {
				if (data && data.data && data.data.length) {
					$scope.shortfallWaiverList = data.data;
					$scope.pagination.shortfallWaiver.totalRecordCount = parseInt(data.totalCount);
					$scope.pagination.shortfallWaiver.offsetLast = ($scope.pagination.shortfallWaiver.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.shortfallWaiver.totalRecordCount : $scope.pagination.shortfallWaiver.offsetLast;
					$scope.currentTab.noRecordFound = false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Shortfall Letter details for the Agreement No.
		 */
		$scope.getshortfallLetter  = function () {
			caseDetailService.getshortfallLetter($scope.agreementNo).then(function (data) {
				if (data && data.data && data.data.length) {
					$scope.shortfallLetters = data.data;
					$scope.currentTab.noRecordFound = false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Shortfall Breakup details for the Agreement No.
		 */
		$scope.getShortfallBreakupDetails = function () {
			caseDetailService.getshortfallBreakup($scope.agreementNo).then(function (data) {
				if (data && data.data && data.data.length) {
					$scope.shortfallBreakupList = data.data;
					$scope.currentTab.noRecordFound = false;
				} else {
					$scope.currentTab.noRecordFound = true;
				}
			});
		};
		/**
		 * Method to retrieve the Approval info for the Agreement No.
		 */
		$scope.getApprovalDetails = function() {
			caseDetailService.getApprovalRequest($scope.agreementNo, $scope.pagination.approval.offset, $scope.pagination.pageMaxSize).then(function(data) {
				$scope.approvalRequest = data.data;
				$scope.approvalHeader = collectionConstants.REQUEST_TYPES;
				$scope.pagination.approval.totalRecordCount = data.meta ? data.meta.totalCount : 0;
				$scope.pagination.approval.offsetLast = ($scope.pagination.approval.totalRecordCount < constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE) ? $scope.pagination.approval.totalRecordCount : $scope.pagination.approval.offsetLast;
				$scope.currentTab.noRecordFound = (data.data && data.data.length === 0);
			});
		};
		$scope.filterByCaseType = function(caseType) {
			$scope.caseValue = caseType;
			$scope.pagination.scannedCopy.currentPage=$scope.pagination.scannedCopy.offset=1;
			$scope.pagination.scannedCopy.offsetLast = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			$scope.getScannedCopyDetails();
		};
		$scope.caseDetailTabs = [ {
			title : collectionConstants.CASE_DETAILS_TABS.FINANCIAL,
			template : "app/collections/caseDetail/partials/financialDetails.html",
			select : "",
			isSelected : true,
			noRecordFound : false,
			isVisible : ($scope.caseDetailModel.productCode === 'VISHESH') ? false :appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CASE_DETAILS.FINANCIAL_DETAILS)
		}, {
			title : collectionConstants.CASE_DETAILS_TABS.NON_FINACIAL,
			template : "app/collections/caseDetail/partials/nonFinancialDetails.html",
			select : "",
			disabled : false,
			isSelected : false,
			noRecordFound : false,
			isVisible : ($scope.caseDetailModel.productCode === 'VISHESH') ? true :appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CASE_DETAILS.NON_FINANCIAL_DETAILS)
		}, {
			title : collectionConstants.CASE_DETAILS_TABS.APPROVALS,
			template : "app/collections/caseDetail/partials/approvals.html",
			select : $scope.getApprovalDetails,
			disabled : false,
			isSelected : false,
			noRecordFound : false,
			isVisible : appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CASE_DETAILS.APPROVALS)
		} ];
		$scope.financialTabs = [ {
			title : collectionConstants.FIANCIAL_TABS.LOAN_DETAILS,
			template : "app/collections/caseDetail/partials/financial/loanDetails.html",
			select : $scope.getLoanDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.REPAYMENT_SCHEDULE,
			template : "app/collections/caseDetail/partials/financial/repaymentSchedule.html",
			select : $scope.getRepaymentDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.RECEIPT_DETAILS,
			template : "app/collections/caseDetail/partials/financial/receiptDetails.html",
			select : $scope.getReceiptDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.DISBURSAL_INFORMATION,
			template : "app/collections/caseDetail/partials/nonFinancial/disbursalInfo.html",
			select : $scope.getDisbursalDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.PDC_ECS_HISTORY,
			template : "app/collections/caseDetail/partials/financial/PDCECSHistory.html",
			select : $scope.getpdcECSHistoryDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.OD_DETAILS,
			template : "app/collections/caseDetail/partials/financial/EMIOutstanding.html",
			select : $scope.getEMIOutstandingInfo,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.CHEQUE_BOUNCE,
			template : "app/collections/caseDetail/partials/financial/chequeBounce.html",
			select : $scope.getChequeBounceDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.MINI_STATEMENT,
			template : "app/collections/caseDetail/partials/financial/miniStatment.html",
			select : $scope.getMiniStatementInfo,
			active : false,
			isSelected : false,
			isSelectRequired : true,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.EXPENSE_DETAILS,
			template : "app/collections/caseDetail/partials/financial/expenseDetails.html",
			select : $scope.getExpenseDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.FIELD_INVESTIGATION,
			template : "app/collections/caseDetail/partials/financial/FIDetails.html",
			select : $scope.getFIDetails,
			active : false,
			isSelected : false,
			isSelectRequired : true,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.UNDERWRITING_INFORMATION,
			template : "app/collections/caseDetail/partials/financial/underWritingInfo.html",
			select : $scope.getUnderwritingInfo,
			active : false,
			isSelected : false,
			isSelectRequired : true,
			noRecordFound : false
		} ];
		$scope.nonFinancialTabs = [{
			//title : collectionConstants.NON_FINANCIAL_TABS.ASSET_DETAILS,
			template : "app/collections/caseDetail/partials/nonFinancial/assetDetails.html",
			select : $scope.getAssetDetals,
			active : false,
			isSelected : false,
			noRecordFound : false
		},{
			title : collectionConstants.NON_FINANCIAL_TABS.CONTACT_INFO,
			template : "app/collections/caseDetail/partials/nonFinancial/contactInfo.html",
			select : $scope.getContactInfoDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.FIANCIAL_TABS.FOLLOW_UP_TRIALS,
			template : "app/collections/caseDetail/partials/financial/followUpTrials.html",
			select : $scope.getFollowUpTrialDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.EMPLOYMENT,
			template : "app/collections/caseDetail/partials/nonFinancial/employment.html",
			select : $scope.getEmploymentDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.INCOME_DETAILS,
			template : "app/collections/caseDetail/partials/nonFinancial/incomeDetails.html",
			select : $scope.getIncomeDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.BANK_DETAILS,
			template : "app/collections/caseDetail/partials/nonFinancial/bankDetails.html",
			select : $scope.getBankDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.INSURANCE_DETAILS,
			template : "app/collections/caseDetail/partials/nonFinancial/insuranceDetails.html",
			select : $scope.getInsuranceDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.LEGAL,
			template : "app/collections/caseDetail/partials/nonFinancial/legal.html",
			select : $scope.getLegalDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.REFERENCE_DETAILS,
			template : "app/collections/caseDetail/partials/nonFinancial/referenceDetails.html",
			select : $scope.getReferenceDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.GUARANTOR_AND_CO_APPLICANT,
			template : "app/collections/caseDetail/partials/nonFinancial/guarantorDetails.html",
			select : $scope.getGuarantorDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.ALLOCATION_HISTORY,
			template : "app/collections/caseDetail/partials/nonFinancial/allocationHistory.html",
			select : $scope.getAllocationHistoryDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.REFERRAL_HISTORY,
			template : "app/collections/caseDetail/partials/nonFinancial/referralHistory.html",
			select : $scope.getReferralHistoryDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.SR_HISTORY,
			template : "app/collections/caseDetail/partials/nonFinancial/SRHistory.html",
			select : $scope.getSRHistoryDetails,
			active : false,
			isSelected : false,
			noRecordFound : false,
			isHide : $scope.activity.isVishesh
		}, {
			title : collectionConstants.NON_FINANCIAL_TABS.SCANNED_COPIES,
			template : "app/collections/caseDetail/partials/nonFinancial/scannedCopies.html",
			select : $scope.getScannedCopyDetails,
			active : false,
			isSelected : false,
			noRecordFound : false
		}, {
			title: collectionConstants.NON_FINANCIAL_TABS.SHORTFALL_WAIVER,
			template: "app/collections/caseDetail/partials/nonFinancial/shortfallWaiver.html",
			select: $scope.getShortfallWaiverDetails,
			active: false,
			isSelected: false,
			noRecordFound: false
		}, {
			title: collectionConstants.NON_FINANCIAL_TABS.SHORTFALL_LETTER,
			template: "app/collections/caseDetail/partials/nonFinancial/shortfallLetter.html",
			select: $scope.getshortfallLetter,
			active: false,
			isSelected: false,
			noRecordFound: false
		}, {
			title: collectionConstants.NON_FINANCIAL_TABS.SHORTFALL_BREAKUP,
			template: "app/collections/caseDetail/partials/nonFinancial/shortfallBreakup.html",
			select: $scope.getShortfallBreakupDetails,
			active: false,
			isSelected: false,
			noRecordFound: false
		} ];
		
		if ($scope.currentTab) {
			var activeTab = _.findWhere($scope.caseDetailTabs, {
				title : $scope.currentTab.title
			});
			if (activeTab) {
				activeTab.active = true;
				activeTab.isSelected = true;
			} else {
				activeTab = _.findWhere($scope.financialTabs, {
					title : $scope.currentTab.title
				});
				if (activeTab) {
					$scope.caseDetailTabs[0].active = true;
					activeTab.active = true;
					activeTab.isSelected = true;
					activeTab.noRecordFound = false;
				} else {
					activeTab = _.findWhere($scope.nonFinancialTabs, {
						title : $scope.currentTab.title
					});
					if (activeTab) {
						$scope.caseDetailTabs[1].active = true;
						$scope.caseDetailTabs[1].isSelected = true;
						activeTab.active = true;
						activeTab.isSelected = true;
						activeTab.noRecordFound = false;
					}
				}
			}
			$scope.currentTab = activeTab;
			if ($scope.currentTab && $scope.currentTab.select !== "") {
				$scope.currentTab.select();
			}
		} else {
			$scope.currentTab = $scope.caseDetailTabs[0];
		}
		/**
		 * Method to change the tab
		 * 
		 * @param {tab}
		 *            Tab - Clicked/Selected Tab
		 */
		$scope.tabChangeHandler = function(tab) {
			if (!tab.isSelected && tab.select !== "") {
				tab.isSelected = true;
				if(tab.title != 'Legal'){
					tab.select();
				}
				//tab = tab;
			}
			if (tab.title === 'Financial Details') {
				_.each($scope.financialTabs, function(element) {
					if (element.active) {
						element.select();
						tab = element;
					}
				});
			} else if (tab.title === 'Non-Financial Details') {
				_.each($scope.nonFinancialTabs, function(element) {
					if (element.active) {
						element.select();
						tab = element;
					}
				});
			} else if (tab.title === collectionConstants.CASE_DETAILS_TABS.APPROVALS) {
				$scope.getApprovalDetails();
			} else if (tab.title === 'Legal') {
				$scope.getLegalDetails();				
			}
			$scope.currentTab = tab;
		};
		/**
		 * Method to call the service once the pagination buttons has been
		 * clicked.
		 * 
		 * @param {pageNo}
		 *            Current page no.
		 * @param {pageName}
		 *            Current page name.
		 */
		$scope.paginationHandler = function(pageNo, pageName) {
			$scope.pagination[pageName].currentPage = pageNo;
			if (pageNo === 1) {
				$scope.pagination[pageName].offset = pageNo;
				$scope.pagination[pageName].offsetLast = $scope.pagination.tenRecordsPerPage;

			} else {
				$scope.pagination[pageName].offset  = $scope.pagination.tenRecordsPerPage * (pageNo - 1) + 1;
				$scope.pagination[pageName].offsetLast  = (pageNo * $scope.pagination.tenRecordsPerPage < $scope.pagination[pageName].totalRecordCount) ? pageNo * $scope.pagination.tenRecordsPerPage : $scope.pagination[pageName].totalRecordCount;
			}

			var currentMethod = "get" + pageName[0].toUpperCase() + pageName.slice(1) + "Details";
			$scope[currentMethod]();
		};
		$scope.printMiniStatement = function() {
			var obj = angular.copy($scope.miniStatementInfo);
			obj.info = $scope.miniStatementInfo[monthStr + 'monthsInfo'];
			if($rootScope.isMiniSOAReceipt){
				authService.setMiniStatement(obj);
				$globalScope.goPreviousState = {
					name : $state.current.name,
					params : $state.params
				};
				$globalScope.isClickedViaMenu = false;
				lazyModuleLoader.loadState('collections.ePayment', {
					agreementNo : $scope.agreementNo,
					receiptType : 'miniStatement'
				});
			}else{
				obj.customerName = $scope.customerInfo.name;
				obj.productType = $scope.caseDetailModel.productGroup;
				obj.cifID = $scope.customerInfo.APPLICANT.cifID;
				obj.payerID = $scope.applicantDetails.customerID;
				obj.agreementNo = $scope.caseDetailModel.agreementNo;
				obj.registrationNo = $scope.caseDetailModel.assetDetail ? $scope.caseDetailModel.assetDetail.lmsRegistrationNo : '';
				caseDetailService.printMiniSOA(obj);
			}
		};
		if ($rootScope.print && $rootScope.print === "printMiniStatement") {
			$scope.gotoMiniStatementPage();
			$rootScope.print = "";
		}

		$scope.downLoadStatement = function() {
			caseDetailService.getFullStatement($scope.agreementNo);
		};
		$scope.openModalPendingWith = function (pendingUserDetails) {
			$modal.open({
				templateUrl: 'app/collections/caseDetail/partials/pendingUserDetails.html',
				controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {
					$scope.pendingUserDetails = pendingUserDetails;
					$scope.close = function () {
						$modalInstance.dismiss();
					};
				}],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};
		if($scope.caseDetailModel.productCode === 'VISHESH'){
			$scope.getAssetDetals();

		}
	};
	caseDetail.controller('caseDetailController', [ '$stateParams', '$scope', '$rootScope', '$modal', 'caseDetailService', 'lazyModuleLoader', 'getCaseDetailInfo', 'getLoanDetailsInfo', 'dialogService', 'authService', 'appFactory', '$globalScope', '$state', caseDetailController ]);
});