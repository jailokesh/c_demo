define([], function() {
	'use strict';
	
	/**
	 * Represents a CaseDetails Resolver.
	 * Dependency injection caseDetailService,$stateParams as a parameter.
	 * Return the case details response data.
	 */
    return {
        getCaseDetailInfo: ['caseDetailService','$stateParams',
            function(caseDetailService,$stateParams) {
                return caseDetailService.getCaseDetailInfo($stateParams.agreementNo).then(function(data){
                	return data;
                });
            }],
        getLoanDetailsInfo:['caseDetailService','$stateParams',
            function(caseDetailService,$stateParams) {
                return caseDetailService.getLoanDetails($stateParams.agreementNo).then(function(data){
                	return data;
                });
         }]
    };

});