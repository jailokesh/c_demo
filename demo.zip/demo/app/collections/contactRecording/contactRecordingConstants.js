define(['require', 'constants'], function(r, sharedConstants) {
    'use strict';
    
    return {
      
       
       SEARCH_BY:[{name:'Agreement Number',value:'agreementNo',type:'common'},
                  {name:'CIFID',value:'cifID',type:'common'},
                  {name:'Vehicle Number',value:'vehicleNo',type:'common'},
                  {name:'Customer Name',value:'customerName',type:'common'},
                  {name:'Mobile Number',value:'mobileNo',type:'common'},
                  {name : 'Vishesh ID / Parent Agreement No',value : 'vishesh',type : 'vishesh'},
                  {name : 'Trip Loan - Agreement No',value : 'trip',type : 'trip'}],
                  
        ALPHABETS:['A','B','C','D','E','F','G','H','I','J'],
        CURRENT_ADDRESS : 'CURRES',
        REGULAR_EXPRESSION: {
            PINCODE: sharedConstants.REGULAR_EXPRESSION.pincode,
            MOBILE_NO:sharedConstants.REGULAR_EXPRESSION.mobileNo,
            MOBILE_NO_11DIGIT:/^[0789]\d{10}$/,
            RECEIPT_NO:/^[BT]{1}[A-Za-z0-9]+$/,
            ACK_NO:/^[A-Za-z0-9]+$/,
            INSTRUMENT_NO:/^[0-9]{6,9}$/,
            NUMBER : /^\d+$/,
            COMMENT:/^[A-z0-9 ]{3,250}$/,
            VEHICLE_NUMBER:/^[a-zA-Z]{2}[ -][0-9]{1,2}(?: [a-zA-Z])?(?: [a-zA-Z]*)? [0-9]{4}$/,
            NAME:sharedConstants.REGULAR_EXPRESSION.numberSpecialCharValidation,
            ALPHANUMERIC: sharedConstants.REGULAR_EXPRESSION.alphaNumeric,
            IFSC_CODE:/[A-Z|a-z]{4}[0][\d]{6}$/,
            MICR_NO:/^[0-9]{9}$/,
            RECEIPT_OR_CHEQUE : /^(([BT]{1}[A-Za-z0-9]{16})|([0-9]{6,9}))$/,
            PAN_NO: /[A-Z]{5}[0-9]{4}[A-Z]{1}/,
            DOBold:/^\d{2}\-\d{2}\-\d{4}$/,
            DOB: /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$/,
            ALPHABETS: /^[A-Za-z]+$/,
            AGREEMENT_NO: /^[A-Za-z0-9]+$/,
            LEADID:/^[a-z|-|A-Z|0-9|\-\s]*$/,
            NUMBER_ONLY:sharedConstants.REGULAR_EXPRESSION.number
        },
        ERROR_MSG: {
        	INVALID_RECEIPT_NO : 'Invalid Receipt/Cheque Number',
        	INVALID_ACK_NO : 'Invalid Acknowledgement No',
        	INVALID_NUMBER : 'Invalid numbers',
        	INVALID_MOBILE_NO : 'Invalid Contact Number',
        	INVALID_INSTRUMENT_NO : 'Invalid Instrument Number',
        	INVALID_COMMENT : 'Invalid Comment',
        	INVALID_NAME:sharedConstants.ERROR_MSG.invalidName,
        	INVALID_AGREEMENT_NO : 'Invalid Agreement Number',
        	INVALID_VEHICLE_NO : 'Invalid Vehicle Number',
        	INVALID_IFSCCODE: 'Invalid IFSC Code',
        	INVALID_MICR_NO: 'Invalid MICR Number',
        	INVALID_UTR_NO: 'Invalid UTR Number',
        	INVALID_POLICY_NO : 'Invalid Policy Number',
        	INVALID_AMOUNT : 'Invalid Amount',
        	INVALID_SELECT : 'Invalid option',
        	INVALID_PAN_NO : 'Invalid Pan Number (First 5 alphabets followed by 4 digits and 1 alphabet)',
        	INVALID_APPLICATION_NO  :'Invalid Application No',
        	INVALID_DOB  :'Invalid DOB',
        	INVALID_LEAD : 'Enter a valid LEAD ID'
        },
        PLACEHOLDER_TEXT: [{type:'agreementNo',value:'Enter Agreement Number',maxLength:'18'},{type:'cifID',value:'Enter Customer Identification Number',maxLength:'20'},
                           {type:'applicationNumber',value:'Enter Application Number',maxLength:'18'},
                           {type:'vehicleNo',value:'Enter Vehicle Number',maxLength:'15'},{type:'customerName',value:'Enter Customer Name',maxLength:'50'},
                           {type:'mobileNo',value:'Enter Mobile Number',maxLength:'11'},{type:'thirdPartyMobileNo',value:'Enter Thirdparty Mobile Number',maxLength:'11'},{type:'policyNo',value:'Enter policy Number',maxLength:'20'},
                           {type:'leadID',value:'Enter Lead ID',maxLength:'50'},{type:'dealerAgreementNo',value:'Enter Dealer ID',maxLength:'10'},
                           {type:'policyNo',value:'Enter policy Number',maxLength:'20'},{type:'DOB',value:'Enter DOB (dd-mm-yyy)',maxLength:'25'},
                           {type:'panCardNo',value:'Enter PAN Number',maxLength:'10'},
                           {type : 'vishesh',value : 'Enter Vishes ID / Parent Agr No',maxLength : '18'},
                           {type : 'trip',value : 'Enter Trip Loan No',maxLength : '18'}]
    };
});
