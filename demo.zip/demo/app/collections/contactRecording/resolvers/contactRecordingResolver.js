define([], function() {
'use strict';
	/**
	 */	
	return {
		
		getCustomerDetails: ['contactRecordingService','$stateParams',function(contactRecordingService,$stateParams) {
        	return contactRecordingService.getCustomerInformation($stateParams.agreementNo).then(function(data){        		
              	return data;
           });
        }]
		/*
		getActions : [ 'contactRecordingService', function(contactRecordingService) {
			return contactRecordingService.getActions(productGroup).then(function(data){
				return data;
			});
		}]*/
		
		/*getAgreementInfo: ['contactRecordingService','$stateParams',
           function(contactRecordingService,$stateParams) {
			return contactRecordingService.getAgreementSummary($stateParams.agreementNo).then(function(data){
               	return data;
            });
        }],*/
        
        
		
	};
});