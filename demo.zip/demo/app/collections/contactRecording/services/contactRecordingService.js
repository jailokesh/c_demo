define(['require','contactRecording','collectionServiceURLs','contactRecordingModel','contactRecordingThirdPartyModel','collectionConstants'],function(r,contactRecording,collectionsServiceURL,ContactRecordingModel,contactRecordingThirdPartyModel,collectionConstants){

	var contactRecordingService=function($q,restProxy,$rootScope,dialogService)
	{
		this.getContactPostModel = function(){
			return new ContactRecordingModel();
		};
		
		this.getThirdPartyModel = function(){
	  		return new contactRecordingThirdPartyModel();
	  	};
		
		this.getActions = function(productGroup,vendorType) {
			collectionsServiceURL.contactRecording.GET_ACTIONS.queryParams = {'productGroup':productGroup,'vendorType' :vendorType,'status':'A'};
			return restProxy.get(collectionsServiceURL.contactRecording.GET_ACTIONS).then(function(data){
				var auctions = {};
				auctions.actionCodes = data.data;
				
				/* sorting Action codes */
				data.data.sort(function(a, b) {
				    var textA = a.actionCodeDesc.toUpperCase();
				    var textB = b.actionCodeDesc.toUpperCase();
				    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
				});

				return auctions;
			});
		};		
		this.getOrangeDetails = function(aggrementNo) {
			collectionsServiceURL.contactRecording.GET_ORANGE_DETAILS.urlParams = {'agreementNo':aggrementNo};
			return restProxy.get(collectionsServiceURL.contactRecording.GET_ORANGE_DETAILS,'categorization').then(function(data){
				return data.data[0];
			});
		};
		
		this.getQuestions = function(actionCode,productGroup) {
			collectionsServiceURL.contactRecording.GET_QUESTIONS.queryParams = {'roleID':$rootScope.identity.hierarchyName === 'THIRD_PARTY' ? 'TC_DIALER' : $rootScope.identity.hierarchyName,'actionCode':actionCode,'productGroup':productGroup,'source':'web'};
			return restProxy.get(collectionsServiceURL.contactRecording.GET_QUESTIONS).then(function(data){		

				/*	 include contacted 	*/
				if( $rootScope.identity.hierarchyName === 'THIRD_PARTY' ){

					/*
						var questionID = actionCode + "0";
						var nextQuestionID = actionCode + "1"; 
						var actionType = actionCode + "_TC_DIALER_VF_" + questionID;
					*/

					var defaultData = {
	    	            	  "actionType": actionCode + "_TC_DIALER_VF_" + actionCode + "0",
	    	            	  "overAllResponseUiFormat" : "SINGLE_VALUE_MOBILE_NUMBER",
	    	            	  "possibleResponses":[{
	    	            	                      		"responseID": "RES001", 
			    	            	                    "responseDesc": "", 
			    	            	                    "nextQuestionID": actionCode + "1", 
			    	            	                    "uiFormat": "WEB", 
			    	            	                    "insightID": ""
	    	            	                  	  }],
								"productGroup": "VF",
								"questionDesc": "Contacted Mobile No",
								"questionID": actionCode + "0"
	    	              };

	    	        data.data.unshift(defaultData);      
			
				}

				return data.data;
			});
		};
		this.postQuestions = function(aggrementNo,data) {
			collectionsServiceURL.contactRecording.POST_QUESTIONS.notify = false;
			collectionsServiceURL.contactRecording.POST_QUESTIONS.urlParams = {'agreementNo':aggrementNo};
			return restProxy.save('POST',collectionsServiceURL.contactRecording.POST_QUESTIONS,data,'feedback').then(function(data){
				if(data.status === 'failed'){
					return data;
				} else{
					return data.data;
				}
			});
		};
		this.postThirdPartyAddress = function(addressObject){
			return restProxy.save('POST',collectionsServiceURL.receiptingServices.POST_THIRD_ADDRESS,addressObject).then(function(data){
				return data;
			});
		};
		this.postCustomerAddress = function(addressObject){
			return restProxy.save('POST',collectionsServiceURL.receiptingServices.POST_CUST_ADDRESS,addressObject).then(function(data){
				if(data.status === "success"){
					return data.data[0];
				}
				else{
					return data;
				}
			});
		};
		
		var objectToUrl=function(obj){
			var string='';
            for (var item in obj) {
               if(obj[item]){
               	string += item + '=' + obj[item] + '&';
               }
           }
           return string;
        };
        
		this.getFilteredData = function(type, items) {
            var urlString = 'commonapi/mastersapi/masters/' + type + '?';
            urlString+=objectToUrl(items);
            return restProxy.getnode(urlString.slice(0, -1), undefined).then(function(response) {
                return response.data;
            });
        };
		
		this.getMyCustomers = function(searchParams) {
			searchParamsObj = {
					searchBy:searchParams.searchBy.value,
					searchKey:searchParams.searchKey
			};
			searchParamsObj.view = 'search';
			searchParamsObj.limit = searchParams.limit;
			searchParamsObj.offset = searchParams.offset;
			
			collectionsServiceURL.receiptingServices.SEARCH_RECEIPTS.queryParams = searchParamsObj;
			return restProxy.get(collectionsServiceURL.receiptingServices.SEARCH_RECEIPTS).then(function(data){
				if(data.status === 'failed'){
					return [];
				}
				_.each(data.data,function(item){
					var applicantObj = _.findWhere(item.partyDetails,{partyType:'A'});
					//applicantObj.fullName = (applicantObj.salutation) ? applicantObj.salutation+' ' : '';
					applicantObj.fullName = (!applicantObj.firstName) ? '' : applicantObj.firstName+' ';
					applicantObj.fullName += (!applicantObj.middleName) ? '' : applicantObj.middleName+' ';
					applicantObj.fullName += (!applicantObj.lastName) ? '' : applicantObj.lastName;
					if(searchParamsObj.searchBy === 'mobileNo'){
						var tempArr =  _.filter(applicantObj.mobileNos, function(mobile) {
						    return mobile.toString().indexOf(searchParamsObj.searchKey) > -1;
						});
						applicantObj.mobileNo =  tempArr[0];
					}
					if(!applicantObj.mobileNo && applicantObj.mobileNos && applicantObj.mobileNos.length >0){
						mobileObj = applicantObj.mobileNos[applicantObj.mobileNos.length-1];
						applicantObj.mobileNo = (typeof mobileObj === 'string' || typeof mobileObj === 'number' ) ? mobileObj : mobileObj.mobileNo;
					}
					
					item.partyDetails = applicantObj || {};
				});
				return data;
			});
		};
		
		var agreementList = [];
		var getAgreementListDetails = function(cifId,agreementNo,productType) {
			if(!cifId){
				$rootScope.agreementList = [];
				$rootScope.agreementList.push(agreementNo);
			}
			if ($rootScope.agreementList && $rootScope.agreementList.length > 0) {
				return $q.when($rootScope.agreementList);
			}
			collectionsServiceURL.myCustomerServices.AGREEMENT_LIST.queryParams = {cifID:cifId,productGroup:productType};
			return restProxy.get(collectionsServiceURL.myCustomerServices.AGREEMENT_LIST).then(function(data) {						
				$rootScope.agreementList = [];
				if (data.data && data.data.length) {
					_.each(data.data, function(item) {
						if(item.agreementNo){
							$rootScope.agreementList.push(item.agreementNo);
						}
					});
				}else{
					$rootScope.agreementList.push(agreementNo);							
				}						
				return $rootScope.agreementList;
			});						
		};
		
		this.getAgreementList = function(){
			return agreementList;
		};
		this.getAgreementSummary = function(agreementNo) {
			var queryParams = {
					agreementNos:agreementNo,
					view :"detail"
			};
			collectionsServiceURL.myCustomerServices.CUSTOMER_SUMMARY.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.myCustomerServices.CUSTOMER_SUMMARY).then(function(data) {
				if(data.data && data.data[0]){
					var responseObj = data.data[0];
					var thisApplicantCustomer = _.findWhere(responseObj.partyDetails, {
						partyType : 'A'
					});
					$rootScope.agreementList = [];
					return getAgreementListDetails(thisApplicantCustomer.cifID,agreementNo).then(function(){
						return responseObj;
					});
				}
				else{
					return $q.reject(data.data);
				}
			});
		};
		
		var setPDDStatus = function(response){
			response.pddStatus = []; 
			if(response.pddDocuments){
				var documentObj;
				_.each(response.pddDocuments,function(element){
					documentObj = _.findWhere(collectionConstants.REPAY_MODES,{'documentID' : element.documentID});
					if(documentObj){
						element.pddAcknowledgementType = documentObj.id;
						if(documentObj.documentID === 278 && element.status ==="C"){
							element.insuranceDetail = (response.insuranceDetail && response.insuranceDetail.length) ? response.insuranceDetail[0] : {};
						}else if(documentObj.documentID === 277 && element.status ==="C"){
							element.RCDetail = response.assetDetail;
						}else if(documentObj.documentID === 280 && element.status ==="C"){
							element.invoiceDetail = response.invoiceDetails;
						}
						response.pddStatus.push(element);
					}
				});
			}
			response.pddStatus = _.union(response.pddStatus,response.pddAcknowledgementDetails);
			return response;
		};
		
		this.getCustomerInformation = function(agreementNo) {
			collectionsServiceURL.receiptingServices.ENTRY_FORM.queryParams = {
					agreementNos: agreementNo,
					view :"receiptDetail"
			};
			collectionsServiceURL.receiptingServices.ENTRY_FORM.urlParams = {};
			return restProxy.get(collectionsServiceURL.receiptingServices.ENTRY_FORM).then(function(data) {
				if(data.data && data.data[0]){
					var responseObj = setPDDStatus(data.data[0]);
					var thisApplicantCustomer = _.findWhere(responseObj.partyDetails, {
						partyType : 'A'
					});
					$rootScope.agreementList = [];
					responseObj.flagStatus = _.uniq(responseObj.flagStatus);
					if(responseObj.productCode === 'VISHESH'){
						return responseObj;
					}
					return getAgreementListDetails(thisApplicantCustomer.cifID,agreementNo,responseObj.productGroup).then(function(){
						return responseObj;
					});
				}
				else{
					dialogService.showAlert('Error', "Message", collectionConstants.ERROR_MSG.AGREEMENT_DETAILS_NOT_FOUND);
					return $q.reject(data.data);
				}
			});
		};
		
		this.getContactInfoDetail = function(agreementNo,limit,offset){
			var queryParams = {
					limit:limit,
					offset:offset,
					product:$rootScope.productType,
					view : 'addressHistory'
			};
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS.queryParams = queryParams;
			collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS.urlParams = {'agreementNo':agreementNo};
			return restProxy.get(collectionsServiceURL.caseDetailServices.NON_FINANCIAL.CONTACT_DETAILS,"contactdetails").then(function(data){
				return data;
			});
		};
		
		this.getDefaultQuestions = [
    	              {
    	            	  "questionID": "D0",
    	            	  "questionDesc": "Mode of Visit",
    	            	  "possibleResponses": [
    	            	                      {
    	            	                          "responseDesc":"Field",
    	            	                          "nextQuestionID":"D1"
    	            	                      },
    	            	                      {
    	            	                    	  "responseDesc":"Phone",
    	            	                          "nextQuestionID":"D1"
    	            	                       },
    	            	                       {
    	            	                    	   "responseDesc":"Walk-in",
    		            	                       "nextQuestionID":"D1"
    	            	                       },{
    	            	                    	   "responseDesc":"Telecalling",
    		            	                       "nextQuestionID":"D1",
    		            	                       "selected" :true
    	            	                       }],
    	                  "selectedContent": "",
    	                  "overAllResponseUiFormat": "SINGLE_CHOICE_WITH_RADIO_BUTTON"
    	              },
    	              {
    	            	  "questionID": "D1",
    	            	  "questionDesc": "Met Whom",
    	            	  "possibleResponses": [
    	            	                      {
    	            	                          "responseDesc":"Customer",
    	            	                          "nextQuestionID":"D2",
    	            	                          "isDisabled":false
    	            	                      },
    	            	                      {
    	            	                    	  "responseDesc":"Family",
    	            	                          "nextQuestionID":"D2",
    	            	                          "isDisabled":false
    	            	                       },
    	            	                       {
    	            	                    	   "responseDesc":"Third Party",
    		            	                       "nextQuestionID":"D2",
    		            	                       "isDisabled":false
    	            	                       },
    	            	                       {
    	            	                    	   "responseDesc":"Not Available",
    		            	                       "nextQuestionID":"D2",
    		            	                       "isDisabled":false
    	            	                       }],
    	                  "selectedContent": "",
    	                  "overAllResponseUiFormat": "SINGLE_CHOICE_WITH_RADIO_BUTTON"
    	              },
    	              {
    	            	  "questionID": "D2",
    	            	  "questionDesc": "Place of Visit",
    	            	  "possibleResponses": [
    	            	                      {
    	            	                          "responseDesc":"Home",
    	            	                          "nextQuestionID":"D3"
    	            	                      },
    	            	                      {
    	            	                    	  "responseDesc":"Office",
    	            	                          "nextQuestionID":"D3"
    	            	                       },
    	            	                       {
    	            	                    	   "responseDesc":"Outside",
    		            	                       "nextQuestionID":"D3"
    	            	                       }],
    	                  "selectedContent": "",
    	                  "overAllResponseUiFormat": "SINGLE_CHOICE_WITH_RADIO_BUTTON"
    	              },
    	              {
    	            	  "questionID": "D3",
    	            	  "questionDesc": "Action Code",
    	            	  "possibleResponses": [],
    	                  "selectedContent": "",
    	                  "overAllResponseUiFormat": "SINGLE_CHOICE_WITH_RADIO_BUTTON"
    	              },
    	              {
      	            	  "questionID": "D4",
      	            	  "questionDesc": "PTP Date and Time",
      	            	  "possibleResponses": [],
      	                  "selectedContent": "",
      	                  "overAllResponseUiFormat": "SINGLE_VALUE_DATE_TIME_PTP"
      	              }
    	              
    	       ];
		
		this.uploadPhoto = function(url,obj) {					
			collectionsServiceURL.myCustomerServices.UPLOAD_PHOTO.urlParams = url;					
			return restProxy.save('POST',collectionsServiceURL.myCustomerServices.UPLOAD_PHOTO,obj).then(function(data) {
				return data;
			});
		};
		
		var pageDetails;
		this.setPageValues = function(value){
			pageDetails = value;
		};
		this.getPageValues = function(){
			return pageDetails;
		};
		this.updateCaseFlagging = function(aggrementNo,data) {
			collectionsServiceURL.contactRecording.UPDATE_CASE_FLAGGING.urlParams = {'agreementNo':aggrementNo};
			return restProxy.save('PUT',collectionsServiceURL.contactRecording.UPDATE_CASE_FLAGGING,data,'flagstatus').then(function(data){
				if(data.status === 'failed'){
					return data;
				} else{
					return data.data;
				}
			});
		};
		
		this.getAddressFromPincode = function(currentObj){
			if(currentObj){
				currentObj.cityDesc = (currentObj.city && isNaN(currentObj.city)) ? currentObj.city : currentObj.cityDesc;
				currentObj.stateDesc = (currentObj.state && isNaN(currentObj.state)) ? currentObj.state : currentObj.stateDesc;
				currentObj.state = (currentObj.state && isNaN(currentObj.state)) ? '' : currentObj.state;
				currentObj.city = (currentObj.city && isNaN(currentObj.city))  ? '' : currentObj.city;
			}
			return currentObj;
		};
	};

	contactRecording.service('contactRecordingService',['$q','restProxy','$rootScope','dialogService',contactRecordingService]);
	return contactRecordingService;
});