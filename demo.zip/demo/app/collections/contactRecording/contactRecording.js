define(['require','collectionsApp','contactRecordingResolver'],
   function(require,collectionsApp,contactRecordingResolver) {
 'use strict';
   	   var baseViewUrl = 'app/collections/contactRecording/';
       var app = angular.module('contactRecording', ['ui.router','collections']);
       var contactRecording = function($stateProvider) {
           $stateProvider
               .state('collections.contactRecording', {
            	   name : 'contactRecording',
           		   url : 'contactRecording/:agreementNo',
                   views: {
                      'mainContent': {
                           templateUrl: baseViewUrl + '/partials/questions.html',
                           controller: 'contactRecordingController',
                           resolve : contactRecordingResolver
                       }
                   },
   					data:{
   						'headerText':'Visit Recording',
   						'backState': 'collections.searchContactRecording',
   						'stateActivity' : ['COL_RECORD_ACTION_CODE','COL_UPDATE_ADDRESS_CONTACT_DETAILS']
   					}
               }).state('collections.searchContactRecording', {
            	   name : 'contactRecording',
           		   url : 'contactRecording',
                   views: {
                      'mainContent': {
                           templateUrl: baseViewUrl + 'contactRecording.html',
                           controller: 'contactRecordingSearchController'
                       }
                   },
   					data:{'headerText':'Visit Recording',
   						'stateActivity' : ['COL_RECORD_ACTION_CODE','COL_UPDATE_ADDRESS_CONTACT_DETAILS']
                   }
               });
       };
       app.config(['$stateProvider', contactRecording]);
       return app;
  });
