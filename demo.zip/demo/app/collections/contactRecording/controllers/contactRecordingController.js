define([ 'require', 'contactRecording', 'constants', 'collectionConstants', 'DatePickerConfig', 'contactRecordingConstants', 'utility' ],
		function(r, contactRecording, constants, collectionConstants, DatePickerConfig, contactRecordingConstants, utility) {
			'use strict';
			var contactRecordingController = function($scope, $globalScope, $timeout, $rootScope, contactRecordingService, $state, $modal, dialogService, lazyModuleLoader, messageBus, getCustomerDetails, $stateParams, appFactory) {
				/* Alert when data has following scenarios */
				var categoryList = _.findWhere($globalScope.imageCategories, {
					subCategory : "Customer photo"
				});
		
				$rootScope.setCustomerDetails = '';			
				$scope.categoryDetails = categoryList ? categoryList : {};
				$scope.swingButtons = {
					backQuestion : false,
					nextQuestion : false
				};
				$scope.tabSet = {
					isEdit : false,
					noEdit : true
				};
				$scope.submitFlow = {
					isSubmit : false,
					submitDirect : false
				};
				$scope.action = {
					isPTP : false,
					isRTP : false
				};
				$scope.family = {
					familyPersonName : '',
					FamilyFields : false
				};
				$scope.orangeCustomer = {
					isOrange : false,
					showOrange : false
				};
				$scope.details = {
					agreementNo : '',
					customerName : '',
					currentAddress : '',
					isRefinance : '',
					agreementStatus : ''
				};
				$scope.startsWith = function(state, viewValue) {					
					if(state && typeof state !== 'object'){
						return state.substr(0, viewValue.length).toLowerCase() == viewValue.toLowerCase();
					}					  
				}; 
				$scope.myCustomers = [];
				//$scope.myCustomerSummary = getAgreementInfo;
				
				$scope.customerInfo = utility.getCustomerInfo(getCustomerDetails);
				$scope.customerInfo.upload = true;
				var colourCodeCheck = false;
				var insuranceCheck = false;
				var insuranceExpiry;
				var rcCheck = false;
				var invoiceCheck = false;
				var PreEligibleLoanOffer = false;
				var npdcType = false;
				var showDialogMessage = function(title, messageStr) {
					dialogService.showAlert('info', title, messageStr, true).result.then(function() {
					});
				};
				var isTellerActivity  = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CHALLANING.TELLER_CHALLAN);
				var isPhone = false;
				var thisGroupID,getActions;		
				$scope.activity = {};
				$scope.activity.appointment = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.APPOINTMENT);
				$scope.activity.caseDetail = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.CASEDETAILS);
				$scope.activity.receipting = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.RECEIPTING);
				$scope.activity.miniStatement = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.CUSTOMER_SUMMARY.PRINT_MINISTATEMENT);
				
				var isTextField = function(){
					return ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT || 
							$scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER || 
							$scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER_TEXT || 
							$scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER || 
							$scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT);
				};

				var init = function(bol) {
					// Current Address						
					if ($scope.customerInfo && getActions) {
						$scope.activity.isVishesh = (getCustomerDetails.productCode === 'VISHESH' || getCustomerDetails.productCode === 'TRIP');
						$scope.activity.trip = (getCustomerDetails.productCode === 'TRIP');
						$scope.customerPartyDetails = _.findWhere($scope.customerInfo.partyDetails, {
							partyType : 'A'
						});
						if ($scope.customerPartyDetails) {
							var customerFullName = $scope.customerPartyDetails.firstName ? $scope.customerPartyDetails.firstName : '';
							customerFullName += $scope.customerPartyDetails.middleName ? (' ' + $scope.customerPartyDetails.middleName) : ' ';
							customerFullName += $scope.customerPartyDetails.lastName ? (' ' + $scope.customerPartyDetails.lastName) : ' ';
							$scope.details.customerName = customerFullName;
						}
						if ($scope.customerInfo.addressDetails && $scope.customerInfo.addressDetails.length > 0) {
							var customerFullAddress = [];
							var thisApplicantCurrentAddress = _.findWhere($scope.customerInfo.addressDetails, {
								'addressType' : collectionConstants.CURRENT_ADDRESS
							});
							if (!thisApplicantCurrentAddress) {
								thisApplicantCurrentAddress = _.findWhere($scope.customerInfo.addressDetails, {
									'addressType' : collectionConstants.PERMANENT_ADDRESS
								});
							}
							if (!thisApplicantCurrentAddress) {
								thisApplicantCurrentAddress = _.findWhere($scope.customerInfo.addressDetails, {
									'addressType' : collectionConstants.PERMANENT_ADDRESS_ADDED
								});
							}
							if (!thisApplicantCurrentAddress) {
								thisApplicantCurrentAddress = _.findWhere($scope.customerInfo.addressDetails, {
									'addressType' : collectionConstants.OFFICE
								});
							}else{
								thisApplicantCurrentAddress = contactRecordingService.getAddressFromPincode(thisApplicantCurrentAddress);
							}
							customerFullAddress = utility.setAddress(thisApplicantCurrentAddress);
							if (customerFullAddress && customerFullAddress.length && thisApplicantCurrentAddress && thisApplicantCurrentAddress.mobileNo) {
								customerFullAddress.push('Mobile : ' + thisApplicantCurrentAddress.mobileNo);
							}
							$scope.details.currentAddress = customerFullAddress;
						}
						if ($scope.customerInfo.isRefinanced && _.findWhere(collectionConstants.ISREFINANCED, {
							'status' : $scope.customerInfo.isRefinanced
						})) {
							$scope.details.isRefinance = _.findWhere(collectionConstants.ISREFINANCED, {
								'status' : $scope.customerInfo.isRefinanced
							}).value;
						}
						if ($scope.customerInfo.agreementStatus && _.findWhere(collectionConstants.AGREEMENTSTATUS, {
							'status' : $scope.customerInfo.agreementStatus
						})) {
							$scope.details.agreementStatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
								'status' : $scope.customerInfo.agreementStatus
							}).value;
						}
					}
					if (getCustomerDetails && getCustomerDetails.colourCode === 'RED' && getCustomerDetails.colourSubCategory === 'GU') {
						colourCodeCheck = true;
					}
					if (getCustomerDetails && getCustomerDetails.partyDetails) {
						thisGroupID = _.findWhere(getCustomerDetails.partyDetails, {
							partyType : 'A'
						}).groupID;
					}
					
					if (getCustomerDetails && getCustomerDetails.colourCode && getCustomerDetails.colourCode.toUpperCase() === 'ORANGE' && !isTellerActivity) {
						$scope.orangeCustomer.isOrange = true;
						contactRecordingService.getOrangeDetails(getCustomerDetails.agreementNo).then(function(response) {
							$scope.orangeCustomer.orangeDetails = response;
							$scope.orangeCustomer.yearsOfStay = ($scope.orangeCustomer.orangeDetails && $scope.orangeCustomer.orangeDetails.yearsOfStay !== 0) ? (new Date().getFullYear() - $scope.orangeCustomer.orangeDetails.yearsOfStay) : 0;
						});
					} else {
						$scope.orangeCustomer.isOrange = false;
						var thisOrangeIndex = _.findIndex(getActions.actionCodes,{actionCode:collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE});
						//var thisOrangeIndex = getActions.actionCodes.indexOf(collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE);
						if(thisOrangeIndex > -1){
							getActions.actionCodes.splice(thisOrangeIndex, 1);
						}
					}
					if (getCustomerDetails && getCustomerDetails.productGroup === 'VF' && getCustomerDetails.pddStatus) {
						_.each(getCustomerDetails.pddStatus, function(element) {
							if (element.pddAcknowledgementType.toUpperCase() === "INSURANCE" && element.insuranceDetail && element.insuranceDetail.policyNo) {
								insuranceCheck = true;
								var diffDate = utility.dateDifference(new Date(), new Date(element.insuranceDetail.expiryDate));
								if (diffDate < 0) {
									insuranceExpiry = '<li>Insurance expired ' + Math.abs(diffDate) + ' days before</li>';
								} else if (diffDate === 0) {
									insuranceExpiry = '<li>Insurance expires today</li>';
								} else {
									insuranceExpiry = '<li>Insurance expires in next ' + diffDate + ' days.</li>';
								}
							} else if (element.pddAcknowledgementType.toUpperCase() === "RC" && element.RCDetail && element.RCDetail.registrationNo) {
								rcCheck = true;
							} else if (element.pddAcknowledgementType.toUpperCase() === "INVOICE" && element.invoiceDetail && element.invoiceDetail.invoiceNo) {
								invoiceCheck = true;
							}
						});
					}
					if ($scope.customerPartyDetails.PreEligibleLoanOffer && $scope.customerPartyDetails.PreEligibleLoanOffer.toUpperCase() === 'YES') {
						PreEligibleLoanOffer = true;
					}
					if (getCustomerDetails.installmentMode && getCustomerDetails.installmentMode.toUpperCase() === "NPDC") {
						npdcType = true;
					}
					/* Constructing Message for initial Popup */
					var initialAlert = '<ul class="text-left">';
					var pddStatusCheck = '';
					if (colourCodeCheck) {
						initialAlert = "<li>Follow up with the guarantor for collection.</li>";
					}
					if (insuranceCheck && insuranceExpiry) {
						initialAlert = initialAlert + insuranceExpiry;
					} else {
						pddStatusCheck = pddStatusCheck + ' PDD-Insurance,';
					}
					if (!rcCheck) {
						pddStatusCheck = pddStatusCheck + ' PDD-RC,';
					}
					if (!invoiceCheck) {
						pddStatusCheck = pddStatusCheck + ' PDD-Invoice,';
					}
					if (pddStatusCheck && getCustomerDetails.productGroup === 'VF') {
						pddStatusCheck = pddStatusCheck.slice(0, -1);
						pddStatusCheck = pddStatusCheck + ' not collected.';
						initialAlert = initialAlert + "<li>" + pddStatusCheck + "</li>";
					}
					if (PreEligibleLoanOffer) {
						initialAlert = initialAlert + '<li>Customer is eligible for a PAL.</li>';
					}
					if (npdcType) {
						initialAlert = initialAlert + '<li>Customer’s repayment mode is NPDC.</li>';
					}
					initialAlert = initialAlert + '</ul>';
					if (initialAlert !== '<ul class="text-left"></ul>') {
						showDialogMessage('Alert', initialAlert);
					}
					// fetch related agreements
					
					$scope.details.agreementNo = $stateParams.agreementNo;
					$scope.details.agreementList = contactRecordingService.getAgreementList();
					$scope.questions = angular.copy(contactRecordingService.getDefaultQuestions);
					var i = 0;
					if($scope.isTeleCalling){ // Removed walk in and field for telecalling users
						for (i = $scope.questions[0].possibleResponses.length-1; i > -1; i--) {
							if($scope.questions[0].possibleResponses[i].responseDesc === 'Walk-in' || $scope.questions[0].possibleResponses[i].responseDesc === 'Field'){
								$scope.questions[0].possibleResponses.splice(i, 1);
							}
						}
					}
					for (i = 0; i < getActions.actionCodes.length; i++) {
						$scope.questions[3].possibleResponses.push({
							"responseDesc" : getActions.actionCodes[i].actionCodeDesc,
							"code" : getActions.actionCodes[i].actionCode,
							"nextQuestionID" : "D4"
						});
					}					
					$scope.currentQuestionNumber = 1;
					$scope.currentQuestion = $scope.questions[0];
					$scope.currentQuestion.addressObj = {
						addressLine1: '',
						addressLine2: '',
						addressLine3: '',
						city: '',
						pincode: '',
						state: ''
					};
					$scope.indexFlow = [ $scope.questions[0] ];
					/* PTP Date and time configuration */
					var DateTime = new Date(); //new Date().getTime() + 24 * 60 * 60 * 1000 fixed defect #1041					
					$scope.startDateTime = DateTime;
					$scope.ptpDate = {
						date : DateTime,
						time : angular.copy(DateTime)
					};
					$scope.dateTime = {
							date : DateTime,
							time : angular.copy(DateTime)
					};
					$scope.dateTimeField = new DatePickerConfig({
						value : DateTime,
						minDate : DateTime,
						maxDate : new Date(new Date().getTime() + (24 * 60 * 60 * 1000 * 91)),
						readonly : true,
						DateTime : DateTime
					});
					$scope.dateTimeFieldForCustomMaxDate = new DatePickerConfig({
						value : DateTime,
						minDate : DateTime,
						maxDate : new Date().setDate(new Date().getDate() + 4),
						readonly : true,
						DateTime : DateTime
					});					
					$scope.dateTimeFieldForPastDate = new DatePickerConfig({
						value : DateTime,
						maxDate : DateTime,
						readonly : true,
						DateTime : DateTime
					});					
					$scope.startDate = new DatePickerConfig({
						value : DateTime,
						minDate : DateTime,
						maxDate : new Date(new Date().getTime() + (24 * 60 * 60 * 1000 * 91)),
						readonly : true,
						DateTime : DateTime
					});
					$scope.contactDate = new DatePickerConfig({
						value : new Date(),
						onChange : function() {
						},
						readonly : true
					});
					/* Variable declaration for thirdParty post data */
					$scope.thirdParty = contactRecordingService.getThirdPartyModel();
					/* Variable declaration for post data */
					$scope.postObj = contactRecordingService.getContactPostModel();
				};
				$scope.addressFormat = function(address){
					if(address){
						$scope.currentQuestion.possibleResponses[0]['enteredValue'] = JSON.stringify(address);
					}
				};
				/*** Based on the hierarchyName displaying the mode of visit****/
				$scope.isTeleCalling = $rootScope.identity.hierarchyName === 'THIRD_PARTY' ? true :false;
				var getActionsCode = function(vendorType,bol){
					contactRecordingService.getActions($scope.customerInfo.productGroup,vendorType).then(function(response) {
						getActions = response;
						if(bol){
							init();
							if(vendorType === 'TELECALLING'){
								$scope.swingButtons.nextQuestion = true;
								$scope.currentQuestion.selectedContent = 'Telecalling';
							}							
						}else{
							if (getCustomerDetails && getCustomerDetails.colourCode && getCustomerDetails.colourCode.toUpperCase() === 'ORANGE' && !isTellerActivity) {
								$scope.orangeCustomer.isOrange = true;
								contactRecordingService.getOrangeDetails(getCustomerDetails.agreementNo).then(function(response) {
									$scope.orangeCustomer.orangeDetails = response;
									$scope.orangeCustomer.yearsOfStay = ($scope.orangeCustomer.orangeDetails && $scope.orangeCustomer.orangeDetails.yearsOfStay !== 0) ? (new Date().getFullYear() - $scope.orangeCustomer.orangeDetails.yearsOfStay) : 0;
								});
							} else {
								$scope.orangeCustomer.isOrange = false;
								var thisOrangeIndex = _.findIndex(getActions.actionCodes,{actionCode:collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE});
								//var thisOrangeIndex = getActions.actionCodes.indexOf(collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE);
								if(thisOrangeIndex > -1){
									getActions.actionCodes.splice(thisOrangeIndex, 1);
								}
							}
							$scope.questions = angular.copy(contactRecordingService.getDefaultQuestions);	
							$scope.questions[3].possibleResponses = [];
							for (var i = 0; i < getActions.actionCodes.length; i++) {
								$scope.questions[3].possibleResponses.push({
									"responseDesc" : getActions.actionCodes[i].actionCodeDesc,
									"code" : getActions.actionCodes[i].actionCode,
									"nextQuestionID" : "D4"
								});
							}
						}
						
					});
					
				};
				if($scope.isTeleCalling){					
					getActionsCode('TELECALLING',true);					
				}else{
					getActionsCode('COLLECTIONS',true);
				}
				$scope.changeAuctionCode = function(desc){					
					if(desc === 'Telecalling'){
						getActionsCode('TELECALLING',false);
					}else{
						getActionsCode('COLLECTIONS',false);
					}
					
				};
				/* Method for Back and Next buttons disable */
				var checkStatus = function(isEdit) {
					$scope.swingButtons.backQuestion = true;
					$scope.swingButtons.nextQuestion = true;
					if ($scope.indexFlow.indexOf($scope.currentQuestion) === 0) {
						$scope.swingButtons.backQuestion = false;
					}
					if ($scope.indexFlow.indexOf($scope.currentQuestion) + 1 === $scope.indexFlow.length && !isEdit) {
						$scope.swingButtons.nextQuestion = false;
					} else if ($scope.indexFlow.length > $scope.indexFlow.indexOf($scope.currentQuestion) + 1) {
						$scope.swingButtons.nextQuestion = true;
					}
					if ($scope.currentQuestion.questionID === "D4") {
						$scope.swingButtons.nextQuestion = true;
					}
					if ($scope.currentQuestion.questionID && $scope.currentQuestion.questionID === "D1" && $scope.currentQuestion.possibleResponses[1].selected) {
						$scope.family.FamilyFields = true;
					} else {
						$scope.family.FamilyFields = false;
					}
				};
				/*Function for Action Code */
				var solveActionCode = function(thisAnswer,nextQuestion) {
					$scope.action.isPTP = false;
					$scope.action.isPU = false;
					if(thisAnswer === collectionConstants.CONTACT_RECORDING.PU){
						if (isPhone) {
							$scope.questions[3].questionDesc = collectionConstants.CONTACT_RECORDING.PICK_UP_DATE_TIME;
						} else {
							$scope.questions[4].questionDesc = collectionConstants.CONTACT_RECORDING.PICK_UP_DATE_TIME;
						}
						$scope.action.isPU = true;												
					} else if (thisAnswer !== collectionConstants.CONTACT_RECORDING.PTP) {
						if (isPhone) {
							$scope.questions[3].questionDesc = collectionConstants.CONTACT_RECORDING.RTP_DATE_TIME;
						} else {
							$scope.questions[4].questionDesc = collectionConstants.CONTACT_RECORDING.RTP_DATE_TIME;
						}
					} else {
						if (isPhone) {
							$scope.questions[3].questionDesc = collectionConstants.CONTACT_RECORDING.PTP_DATE_TIME;
						} else {
							$scope.questions[4].questionDesc = collectionConstants.CONTACT_RECORDING.PTP_DATE_TIME;
						}
						$scope.action.isPTP = true;
					}
				
					if(thisAnswer === collectionConstants.CONTACT_RECORDING.RTP){
						$scope.action.isRTP = true;
					} else {
						$scope.action.isRTP = false;
					}
					if (isPhone) {
						$scope.questions.length = 4;
						$scope.indexFlow.length = 3;
					} else {
						$scope.questions.length = 5;
						$scope.indexFlow.length = 4;
					}
					if (isPhone) {
						$scope.indexFlow = $scope.indexFlow.concat($scope.questions[3]);
					} else {
						$scope.indexFlow = $scope.indexFlow.concat($scope.questions[4]);
					}
					if (thisAnswer === collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE) {
						$scope.orangeCustomer.showOrange = true;
					} else {
						$scope.orangeCustomer.showOrange = false;
					}
					contactRecordingService.getQuestions(thisAnswer, $scope.customerInfo.productGroup).then(function(response) {
						if (response.length > 0) {
							$scope.questions = $scope.questions.concat(response);
							$scope.indexFlow = $scope.indexFlow.concat(response[0]);
						}
						$scope.currentQuestion = _.findWhere($scope.questions, {
							questionID : nextQuestion
						});
						$scope.currentQuestionNumber = $scope.currentQuestionNumber > 0 ? $scope.currentQuestionNumber + 1 : $scope.currentQuestionNumber;
						if (_.findWhere($scope.indexFlow, $scope.currentQuestion) === undefined) {
							$scope.indexFlow.push($scope.currentQuestion);
							$scope.currentQuestionNumber = $scope.currentQuestionNumber > 0 ? $scope.currentQuestionNumber + 1 : $scope.currentQuestionNumber;
						}
					});
					checkStatus();
				};
				/*Function for Else Action Code */
				var solveNonActionCode = function(thisQuestion,nextQuestion, thisAnswer){
					if (thisQuestion === collectionConstants.CONTACT_RECORDING.PTP_DATE_TIME) {
						if ($scope.postObj.nextPtpAmount !== '' && $scope.postObj.location !== '') {
							if (isPhone) {
								$scope.currentQuestion = $scope.indexFlow[6];
							} else {
								$scope.currentQuestion = $scope.indexFlow[7];
							}
							$scope.currentQuestionNumber++;
						} else {
							if ($scope.postObj.nextPtpAmount !== '') {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_PTP_AMOUNT);
								return;
							} else if ($scope.postObj.location !== '') {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_PTP_LOCATION);
								return;
							} else if (isNaN(Date.parse($scope.ptpDate.date))) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_DATE);
								return;
							} else if (isNaN(Date.parse($scope.ptpDate.time))) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_TIME);
								return;
							}
						}
					} else if (thisQuestion === collectionConstants.CONTACT_RECORDING.RTP_DATE_TIME) {
						if ($scope.postObj.location !== '') {
							if (isPhone) {
								$scope.currentQuestion = $scope.indexFlow[6];
							} else {
								$scope.currentQuestion = $scope.indexFlow[7];
							}
							$scope.currentQuestionNumber++;
						} else {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_LOCATION);
							return;
						}
						if (isNaN(Date.parse($scope.ptpDate.date))) {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_DATE);
							return;
						}
						if (isNaN(Date.parse($scope.ptpDate.time))) {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_TIME);
							return;
						}
					} else if (nextQuestion && nextQuestion !== '') {
						$scope.indexFlow.length = $scope.indexFlow.indexOf($scope.currentQuestion) + 1;
						$scope.currentQuestion = _.findWhere($scope.questions, {
							questionID : nextQuestion
						});
						/*if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT) {
							$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT;
						}*/
						if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX) {
							$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX;
						}
						if (_.findWhere($scope.indexFlow, $scope.currentQuestion) === undefined) {
							for (var m = 0; m < $scope.currentQuestion.possibleResponses.length; m++) {
								$scope.currentQuestion.possibleResponses[m].selected = false;
							}
							$scope.currentQuestion.selectedContent = '';
							$scope.indexFlow.push($scope.currentQuestion);
							$scope.currentQuestionNumber++;
							if ($scope.currentQuestion.questionID !== "D4" && ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === 'IMAGE_WITH_MULTIPLE_CHOICE' || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM)) {
								$scope.swingButtons.nextQuestion = true;
								$scope.submitFlow.submitDirect = true;
								return;
							}
						}
					} else if (nextQuestion === '') {
						$scope.indexFlow.length = $scope.indexFlow.indexOf($scope.currentQuestion) + 1;
						$scope.submitFlow.isSubmit = true;
						$scope.tabSet.isEdit = true;
						$scope.tabSet.noEdit = false;
					} else {
						return;
					}
					checkStatus();
				};
				/* Method to get code for action code name */
				var getActionCode = function(ans){
					var code = _.findWhere(getActions.actionCodes,{actionCodeDesc:ans}).actionCode;
					return code;
				};
				/* Method to fetch next question */
				$scope.getNextQuestion = function(thisQuestion, thisAnswer, nextQuestion, currentAnswerIndex) {


					/* set true to scope isCollected when action choosen as Collected */
					if (nextQuestion === 'D4') { 
						$scope.dateTimeFieldWithPastDate = (thisAnswer === 'Collected' || thisAnswer === 'Already Paid - Digital Payment'); 
					}

					/* set true to scope isPickUp when action choosen as Pick Up */
					//if (nextQuestion === 'D4') { $scope.customMaxDate = (thisAnswer === 'Pick Up') ? true : false; }

					if (nextQuestion === 'D4' && thisAnswer && thisAnswer.toUpperCase() === 'PICK UP'){
						$scope.startDate.maxDate = new Date(new Date().setDate(new Date().getDate() + 4));
					}else{
						$scope.startDate.maxDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000 * 91));
					}
					

					$timeout(function() {										
						$scope.submitFlow.isSubmit = false;
						/*if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT) {
							$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT;
						}*/
						if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX) {
							$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX;
						}
						if (currentAnswerIndex >= 0) {
							for (var i = 0; i < $scope.currentQuestion.possibleResponses.length; i++) {
								$scope.currentQuestion.possibleResponses[i].selected = false;
							}
							$scope.currentQuestion.possibleResponses[currentAnswerIndex].selected = true;
						}
						if ($scope.questions[2].questionID === 'D2') {
							$scope.questions.splice(2, 1);
						}
						if (thisQuestion === 'Mode of Visit') {
							$scope.indexFlow[0].selectedContent = thisAnswer;							
							/*var notAvailable = {
								"responseDesc" : "Not Available",
								"nextQuestionID" : "D2"
							};*/
							if(thisAnswer === 'Walk-in'){
								$scope.questions[1].questionDesc = "Met Whom";
							}else{
								$scope.questions[1].questionDesc = "Contacted Whom";
							}
							/*if ($scope.questions[1].possibleResponses.length === 3 && thisAnswer === 'Phone') {
								$scope.questions[1].possibleResponses.push(notAvailable);
							} else if($scope.questions[1].possibleResponses.length === 4 && thisAnswer === 'Walk-in'){
								$scope.questions[1].possibleResponses.length = 3;
							}*/
							if($scope.activity.isVishesh){
								$scope.questions[1].possibleResponses[2].isDisabled = true;
							}
							for (var n = 0; n < $scope.questions[1].possibleResponses.length; n++) {
								$scope.questions[1].possibleResponses[n].nextQuestionID = 'D3';
							}
							isPhone = true;
						}
						$scope.currentQuestion.selectedContent = thisAnswer;
						if (thisQuestion === 'Met Whom' && thisAnswer === 'Third Party') {
							$scope.editAddressPopup('true');
						}
						if ((thisQuestion === 'Met Whom' || thisQuestion === 'Contacted Whom') && thisAnswer === 'Family') {
							if (!$scope.family.FamilyFields) {
								$scope.indexFlow[2] = _.findWhere($scope.questions, {
									questionID : nextQuestion
								});
								for (var j = 0; j < $scope.indexFlow[2].possibleResponses.length; j++) {
									$scope.indexFlow[2].possibleResponses[j].selected = false;
								}
								$scope.indexFlow[2].selectedContent = '';
								$scope.indexFlow.length = 3;
							}
							if (thisAnswer === 'Family') {
								$scope.family.FamilyFields = true;
							}
							$scope.swingButtons.nextQuestion = true;
							return;
						} else {
							$scope.family.FamilyFields = false;
						}						
						if(thisQuestion === 'Action Code' && !$scope.activity.isVishesh) {
							thisAnswer = getActionCode(thisAnswer);
							solveActionCode(thisAnswer,nextQuestion);
						}else if(thisQuestion === 'Action Code' && $scope.activity.isVishesh){
							$scope.action.isPTP = (getActionCode(thisAnswer) === 'PTP');
							solveNonActionCode(thisQuestion,nextQuestion);
						}else{
							solveNonActionCode(thisQuestion,nextQuestion);
						}
						if(nextQuestion === 'D4'){
							checkAuctionCode();
						}
					}, 150);
				};
				/* Method to activate Submit */
				$scope.activateSubmit = function(thisValue, thisQuestion) {
					if (thisValue !== undefined) {
						$scope.submitFlow.isSubmit = true;
						$scope.tabSet.isEdit = true;
						$scope.tabSet.noEdit = false;
					} else {
						dialogService.showAlert('Alert', "Warning!", "Please enter valid " + thisQuestion + "!").result.then(function() {
						});
					}
				};
				$scope.auctionCode = false;
				var checkAuctionCode = function(){					
					var validAuctionCode = ['MOTORINSURANCEPICKUP','PTP','TOPUPPICKUP'];//only mandatory for this three auction code rest of auction code non-mandatory
					var auctionCode = _.findWhere(_.findWhere($scope.questions, {questionID: "D3"}).possibleResponses,{selected:true}).code;
					if(validAuctionCode.indexOf(auctionCode) > -1){
						$scope.auctionCode = true;
					}else{
						$scope.auctionCode = false;
					}
				};
				var validateTime = function(ptpDate){
					checkAuctionCode();					
					var flag,dayDiff,currentDate;
					currentDate = new Date();
					if(ptpDate.date){
						ptpDate.date.setHours(currentDate.getHours());
						ptpDate.date.setMinutes (currentDate.getMinutes());
						dayDiff = utility.dateDifference(ptpDate.time,ptpDate.date);
						return (dayDiff === 0 && ((ptpDate.date.getHours() > ptpDate.time.getHours()) || (ptpDate.date.getHours() == ptpDate.time.getHours() && ptpDate.time.getMinutes() <= ptpDate.date.getMinutes())));
					}					
				};
				
				/* Method for Back and Next Questions flow */
				$scope.swingQuestion = function(buttonName) {
					/*if($scope.currentQuestion.questionID === 'D4'){
						checkAuctionCode();
					}*/
					if($scope.isTeleCalling && $scope.currentQuestion.selectedContent === 'Telecalling'){
						$scope.getNextQuestion('Mode of Visit', 'Telecalling', 'D1', -1);						
					}
					var tempDate1,tempDate1Time,tempMonth1,ptpStartDateTime,thisExactDate1;
					if (buttonName === 'back') {
						if ($scope.currentQuestion.questionID !== "D4" && $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE) {
							if(!$scope.currentQuestion.possibleResponses[0].enteredValue){
								$scope.currentQuestion.possibleResponses[0].enteredValue = new Date($scope.contactDate.value);
							}							
							var tempDate = $scope.currentQuestion.possibleResponses[0].enteredValue;
							if(typeof tempDate === "object"){
								var tempMonth = tempDate.getMonth() + 1;
								var thisExactDate = tempDate.getDate() + ' / ' + tempMonth + ' / ' + tempDate.getFullYear();
								$scope.currentQuestion.selectedContent = thisExactDate;
							}							
							$scope.submitFlow.isSubmit = true;
						}
						if ($scope.currentQuestion.questionID !== "D4" && $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME) {
							tempDate1 = new Date($scope.dateTime.date);
							tempDate1Time = new Date($scope.dateTime.time);
							tempMonth1 = tempDate1.getMonth() + 1;
							ptpStartDateTime = new Date(tempDate1.getFullYear(), tempDate1.getMonth(), tempDate1.getDate(), tempDate1Time.getHours(), tempDate1Time.getMinutes(), tempDate1Time.getSeconds());
							$scope.postObj.nextPtpDateTime = ptpStartDateTime.toISOString();
							thisExactDate1 = tempDate1.getDate() + ' / ' + tempMonth1 + ' / ' + tempDate1.getFullYear() + ' - ' + tempDate1Time.toLocaleTimeString().replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3");								
							$scope.currentQuestion.selectedContent = thisExactDate1;
							$scope.currentQuestion.possibleResponses[0].enteredValue = thisExactDate1;								
						}
						var currentIndex = $scope.indexFlow.indexOf($scope.currentQuestion) > 0 ? $scope.indexFlow.indexOf($scope.currentQuestion) - 1 : $scope.indexFlow.indexOf($scope.currentQuestion);
						$scope.currentQuestion = $scope.indexFlow[currentIndex];
						$scope.currentQuestionNumber = $scope.currentQuestionNumber > 1 ? $scope.currentQuestionNumber - 1 : $scope.currentQuestionNumber;
						if ($scope.currentQuestion.questionID !== "D4" && ((($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX) && !$scope.currentQuestion.selectedContent) || ( isTextField() && $scope.currentQuestion.possibleResponses[0].enteredValue))) {
							$scope.swingButtons.nextQuestion = true;
							$scope.submitFlow.submitDirect = true;
							return;
						}
					} else if (buttonName === 'next') {
						$timeout(function() {	
							/*if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT) {
								$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT;
							}*/
							if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX) {
								$scope.currentQuestion.overAllResponseUiFormat = collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX;
							}
						},150);
						if ($scope.currentQuestion.questionID === "D4") {
							if ((!$scope.ptpDate.date || isNaN(Date.parse($scope.ptpDate.date)))) { // && $scope.auctionCode
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_DATE);
								return;
							}
							if ((!$scope.ptpDate.time || isNaN(Date.parse($scope.ptpDate.time)))) { // && $scope.auctionCode
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_TIME);
								return;
							}
							if(validateTime($scope.ptpDate)){ // && $scope.auctionCode
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "PTP time should be greater than current time.");
								return;
							}							
							if ($scope.action.isPTP && !$scope.postObj.nextPtpAmount) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_PTP_AMOUNT);
								return;
							}							
							if ($scope.action.isPU && !$scope.postObj.nextPtpAmount) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_PU_AMOUNT);
								return;
							}
							if ($scope.action.isPTP && $scope.postObj.location === '') {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_LOCATION);
								return;
							}
							$scope.setDateAndTime();
						}
						if ($scope.currentQuestion.questionID === 'D1' && $scope.currentQuestion.selectedContent === 'Family' && $scope.family.familyPersonName === '') {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.ENTER_FAMILY_NAME);
							return;
						} else {
							$scope.family.FamilyFields = false;
						}
						if ($scope.submitFlow.submitDirect && (isTextField() || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_RADIO_BUTTON || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM)) {
							if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE) {
								if(!$scope.currentQuestion.possibleResponses[0].enteredValue){
									$scope.currentQuestion.possibleResponses[0].enteredValue = new Date($scope.contactDate.value);
								}									
								var tempDate2 = $scope.currentQuestion.possibleResponses[0].enteredValue;
								if(typeof tempDate2 === "object"){
									var tempMonth2 = tempDate2.getMonth() + 1;
									var thisExactDate2 = tempDate2.getDate() + ' / ' + tempMonth2 + ' / ' + tempDate2.getFullYear();
									$scope.currentQuestion.selectedContent = thisExactDate2;
									$scope.currentQuestion.possibleResponses[0].enteredValue = thisExactDate2;
								}								
								/*$scope.swingButtons.nextQuestion = true;
								$scope.tabSet.isEdit = true;
								$scope.tabSet.noEdit = false;
								$scope.submitFlow.isSubmit = true;
								return;*/
							}else if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME) {
								tempDate1 = new Date($scope.dateTime.date);
								tempDate1Time = new Date($scope.dateTime.time);
								tempMonth1 = tempDate1.getMonth() + 1;
								ptpStartDateTime = new Date(tempDate1.getFullYear(), tempDate1.getMonth(), tempDate1.getDate(), tempDate1Time.getHours(), tempDate1Time.getMinutes(), tempDate1Time.getSeconds());
								$scope.postObj.nextPtpDateTime = ptpStartDateTime.toISOString();
								thisExactDate1 = tempDate1.getDate() + ' / ' + tempMonth1 + ' / ' + tempDate1.getFullYear() + ' - ' + tempDate1Time.toLocaleTimeString().replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3");								
								$scope.currentQuestion.selectedContent = thisExactDate1;
								$scope.currentQuestion.possibleResponses[0].enteredValue = thisExactDate1;								
							} else if (isTextField()) {
								if (!$scope.currentQuestion.possibleResponses[0].enteredValue) {
									if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER) {
										dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_NUMBER);
										return;
									}
									if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER_TEXT) {
										dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_DETAILS);
										return;
									}
									if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER) {
										dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_NUMBER);
										return;
									}
									dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_TEXT);
									return;
								} else if (!$scope.currentQuestion.possibleResponses) {									
									$scope.currentQuestion.selectedContent = $scope.currentQuestion.possibleResponses[0].enteredValue;
									$scope.swingButtons.nextQuestion = true;
									$scope.tabSet.isEdit = true;
									$scope.tabSet.noEdit = false;
									$scope.submitFlow.isSubmit = true;
									return;
								}
							} else if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) {
								if (_.findWhere($scope.currentQuestion.possibleResponses, {
									selected : true
								}) === undefined) {
									dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.SELECT_OPTION);
									return;
								}
							} else if (($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_RADIO_BUTTON || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) && $scope.currentQuestion.selectedContent && ($scope.indexFlow.length === $scope.indexFlow.indexOf($scope.currentQuestion) + 1)) {
								$scope.swingButtons.nextQuestion = true;
								$scope.tabSet.isEdit = true;
								$scope.tabSet.noEdit = false;
								$scope.submitFlow.isSubmit = true;
								return;
							}
						}
						

						if ($scope.currentQuestion.questionID !== "D4" && (isTextField() || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME  || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) && $scope.currentQuestion.possibleResponses && $scope.currentQuestion.possibleResponses[0].nextQuestionID) {
							if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) {
								$scope.currentQuestion.selectedContent = '';
								_.each(_.where($scope.currentQuestion.possibleResponses, {
									selected : true
								}), function(element) {
									if ($scope.currentQuestion.selectedContent) {
										$scope.currentQuestion.selectedContent = $scope.currentQuestion.selectedContent + ', ' + element.responseDesc;
									} else {
										$scope.currentQuestion.selectedContent = element.responseDesc;
									}
								});
							} else {
								$scope.currentQuestion.selectedContent = $scope.currentQuestion.possibleResponses[0].enteredValue;
							}
							if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER && !collectionConstants.REGULAR_EXPRESSION.MOBILE_NO.test($scope.currentQuestion.possibleResponses[0].enteredValue)) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_MOBILE_NO);
								return;
							}
							$scope.currentQuestion = _.findWhere($scope.questions, {
								questionID : $scope.currentQuestion.possibleResponses[0].nextQuestionID
							});
							$scope.currentQuestionNumber++;//question number should increment after clicking next button. 
							if (_.findWhere($scope.indexFlow, $scope.currentQuestion) === undefined) {
								for (var q = 0; q < $scope.currentQuestion.possibleResponses.length; q++) {
									$scope.currentQuestion.possibleResponses[q].selected = false;
								}
								$scope.currentQuestion.selectedContent = '';
								$scope.indexFlow.push($scope.currentQuestion);
								//$scope.currentQuestionNumber++;
								if ($scope.currentQuestion.overAllResponseUiFormat !== collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_RADIO_BUTTON && $scope.currentQuestion.overAllResponseUiFormat !== 'DROP_DOWN') {
									$scope.swingButtons.nextQuestion = true;
									$scope.submitFlow.submitDirect = true;
								} else {
									$scope.swingButtons.nextQuestion = false;
									$scope.submitFlow.submitDirect = false;
								}
								return;
							}
							checkStatus(true);//added true for enable next button : this problem already have now only resolved
							return;
						} else if ($scope.currentQuestion.questionID !== "D4" && (isTextField() || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) && $scope.currentQuestion.possibleResponses && $scope.currentQuestion.possibleResponses[0].nextQuestionID === '') {

							if( $scope.currentQuestion.questionDesc === "Third party Contact Number" ){
								if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER && !collectionConstants.REGULAR_EXPRESSION.MOBILE_NO.test($scope.currentQuestion.possibleResponses[0].enteredValue)) {
									dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_MOBILE_NO);
									return;
								}								
							}

							if ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM) {
								$scope.currentQuestion.selectedContent = '';
								_.each(_.where($scope.currentQuestion.possibleResponses, {
									selected : true
								}), function(element) {
									if ($scope.currentQuestion.selectedContent) {
										$scope.currentQuestion.selectedContent = $scope.currentQuestion.selectedContent + ', ' + element.responseDesc;
									} else {
										$scope.currentQuestion.selectedContent = element.responseDesc;
									}
								});
							} else {
								$scope.currentQuestion.selectedContent = $scope.currentQuestion.possibleResponses[0].enteredValue;
							}
							$scope.submitFlow.isSubmit = true;
							$scope.tabSet.isEdit = true;
							$scope.tabSet.noEdit = false;
							return;
						}
						var currentIndex1 = $scope.indexFlow.indexOf($scope.currentQuestion) >= 0 ? $scope.indexFlow.indexOf($scope.currentQuestion) + 1 : $scope.indexFlow.indexOf($scope.currentQuestion);
						if ($scope.indexFlow[currentIndex1]) {
							$scope.currentQuestion = $scope.indexFlow[currentIndex1];
							$scope.currentQuestionNumber = $scope.currentQuestionNumber > 0 ? $scope.currentQuestionNumber + 1 : $scope.currentQuestionNumber;
							checkStatus(true);//added true for enable next button : this problem already have now only resolved
							return;
						} else if ($scope.currentQuestion.questionID === "D4" && $scope.indexFlow.length === currentIndex1) {
							$scope.submitFlow.isSubmit = true;
							$scope.tabSet.isEdit = true;
							$scope.tabSet.noEdit = false;
							return;
						}
						if ($scope.currentQuestion.questionID !== "D4" && ((($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.MULTIPLE_CHOICE_WITH_CHECKBOX) && !$scope.currentQuestion.selectedContent) || (($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_NUMBER_TEXT || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.FREE_TEXT) && ($scope.currentQuestion.possibleResponses[0].enteredValue === undefined || $scope.currentQuestion.possibleResponses[0].enteredValue === '')))) {
							$scope.swingButtons.nextQuestion = true;
							$scope.submitFlow.submitDirect = true;
							return;
						}
						if ($scope.currentQuestion.questionID !== "D4" && (isTextField() || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_DATE_TIME || ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_RADIO_BUTTON && $scope.currentQuestion.selectedContent) || ($scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_CHECKBOX || $scope.currentQuestion.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.LIST_ITEM&& $scope.currentQuestion.selectedContent))) {
							$scope.swingButtons.nextQuestion = true;
							$scope.submitFlow.submitDirect = true;
							return;
						}
					}
					checkStatus();
				};
				$scope.listItemChange = function(thisObject) {
					for (var l = 0; l < $scope.currentQuestion.possibleResponses.length; l++) {
						$scope.currentQuestion.possibleResponses[l].selected = false;
					}
					for (var k = 0; k < thisObject.length; k++) {
						var thisIndex = $scope.currentQuestion.possibleResponses.indexOf(thisObject[k]);
						$scope.currentQuestion.possibleResponses[thisIndex].selected = true;
					}
				};
				/* Method for edit Questions */
				$scope.enableEdit = function(thisIndex) {
					$scope.currentQuestion = $scope.indexFlow[thisIndex];
					$scope.tabSet.isEdit = false;
					$scope.tabSet.noEdit = true;
					$scope.submitFlow.submitDirect = true;
					$scope.family.FamilyFields = ($scope.currentQuestion.questionID === 'D1' && $scope.currentQuestion.selectedContent === 'Family');
					$scope.currentQuestionNumber = thisIndex + 1;
					checkStatus(true);
				};
				var addressPopUpHandler = function(dataObject, thirdPartyFlag) {
					$modal.open({
						templateUrl : 'app/collections/contactRecording/partials/addressDetail.html',
						controller : 'addressEditController',
						size : 'lg',
						backdrop : 'static',
						windowClass : 'modal-custom',
						keyboard :false,
						resolve : {
							data : function() {
								return {
									dataObject : dataObject,
									thirdPartyFlag : thirdPartyFlag
								};
							}
						}
					});
				};
				/* Method for Address Update popup */
				$scope.editAddressPopup = function(thirdPartyFlag) {
					addressPopUpHandler($scope.customerInfo, thirdPartyFlag);
					//var thisBody;
					/*contactRecordingService.getAgreementSummary($scope.myCustomerSummary.agreementNo).then(function(data) {
						//thisBody = data;
						addressPopUpHandler(data, thirdPartyFlag);
					});*/
				};
				// Third Party cancel and revert to last step
				messageBus.onMsg('ADDRESS', function(event, data) {
					if (data && data === 'false') {
						$scope.swingQuestion('back');
						_.each($scope.currentQuestion.possibleResponses, function(element) {
							if (element.selected) {
								element.selected = false;
							}
						});
						$scope.indexFlow.splice(($scope.indexFlow.length - 1), 1);
						checkStatus();
					}
				}, $scope);
				var addressHistoryPopUpHandler = function(dataObject) {
					$modal.open({
						templateUrl : 'app/collections/contactRecording/partials/addressHistory.html',
						controller : 'addressHistoryController',
						size : 'lg',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return dataObject;
							}
						}
					});
				};
				/* Method for Address History Popup */
				$scope.addressHistoryPopup = function() {
					var thisBody = $scope.customerInfo.agreementNo;
					addressHistoryPopUpHandler(thisBody);
				};
				//set Date and Time for final Post
				$scope.setDateAndTime = function(){
					var tempDate1 = new Date($scope.ptpDate.date);
					var tempDate1Time = new Date($scope.ptpDate.time);
					var tempMonth1 = tempDate1.getMonth() + 1;
					var ptpStartDateTime = new Date(tempDate1.getFullYear(), tempDate1.getMonth(), tempDate1.getDate(), tempDate1Time.getHours(), tempDate1Time.getMinutes(), tempDate1Time.getSeconds());
					$scope.postObj.nextPtpDateTime = ptpStartDateTime.toISOString();
					var thisExactDate1 = tempDate1.getDate() + ' / ' + tempMonth1 + ' / ' + tempDate1.getFullYear() + ' - ' + tempDate1Time.toLocaleTimeString().replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3");
					if($scope.currentQuestion.questionDesc === collectionConstants.CONTACT_RECORDING.PTP_DATE_TIME || $scope.currentQuestion.questionDesc === collectionConstants.CONTACT_RECORDING.RTP_DATE_TIME || $scope.currentQuestion.questionDesc === collectionConstants.CONTACT_RECORDING.PICK_UP_DATE_TIME){
						$scope.currentQuestion.selectedContent = thisExactDate1;
					}
					
				};
				/* Method for Insight popup */
				var popUpHandler = function(response, actionCode) {
					$modal.open({
						templateUrl : 'app/collections/contactRecording/partials/insightDetails.html',
						controller : 'insightPopupController',
						size : 'md',
						backdrop : 'static',
						resolve : {
							data : function() {
								return {
									questionsData : $scope.selectedQuestions,
									actionCode : actionCode
								};
							}
						}
					});
				};
				var answeredAll = true;
				var postSubmit = function() {
					$scope.postObj.branchID = $scope.customerInfo.branchID;
					$scope.postObj.productGroup = $scope.customerInfo.productGroup;
					$scope.postObj.contactedPersonRelation = $scope.indexFlow[1].selectedContent;
					if ($scope.indexFlow[1].selectedContent === 'Family') {
						$scope.postObj.contactedPersonName = $scope.family.familyPersonName;
					}else if($scope.indexFlow[1].selectedContent === 'Third Party'){
						$scope.postObj.contactedPersonName = $scope.customerInfo.thirdPartyDetails && $scope.customerInfo.thirdPartyDetails[0] ?  $scope.customerInfo.thirdPartyDetails[0].name : '';
					}
					else if($scope.indexFlow[1].selectedContent === 'Not Available'){
						$scope.postObj.contactedPersonName = $scope.details.customerName+"_Not Available";
					}
					if ($scope.postObj.contactedPersonName === '') {
						$scope.postObj.contactedPersonName = $scope.details.customerName;
					}
					//$scope.postObj.placeOfMeeting = $scope.indexFlow[0].selectedContent;
					$scope.postObj.actionCode = getActionCode($scope.indexFlow[2].selectedContent);
					$scope.postObj.modeOfVisit = $scope.indexFlow[0].selectedContent;

							
					if ($scope.postObj.nextPtpAmount !== '') {
						$scope.postObj.nextPtpAmount = parseInt($scope.postObj.nextPtpAmount);
					} else {
						$scope.postObj.nextPtpAmount = 0;
					}
					if (isPhone) {						
						$scope.selectedQuestions = _.reject($scope.indexFlow, function(objArr){ return (objArr.questionID == 'D0' || objArr.questionID == 'D1' || objArr.questionID == 'D2' || objArr.questionID == 'D3' || objArr.questionID == 'D4'); });
					} else {
						$scope.selectedQuestions = _.reject($scope.indexFlow, function(objArr){ return (objArr.questionID == 'D0' || objArr.questionID == 'D1' || objArr.questionID == 'D2' || objArr.questionID == 'D3' || objArr.questionID == 'D4'); });
					}
					$scope.postObj.questionnaire = [];
					for (var i = 0; i < $scope.selectedQuestions.length; i++) {
						var item = $scope.selectedQuestions[i];
						if ((item.overAllResponseUiFormat === constants.SINGLE_RADIO || item.overAllResponseUiFormat === constants.MULTIPLE_RADIO || item.overAllResponseUiFormat === constants.DROP_DOWN) && _.findWhere(item.possibleResponses, {
							selected : true
						}) !== undefined) {
							var thisResponse = _.findWhere(item.possibleResponses, {
								selected : true
							});
							$scope.postObj.questionnaire.push({
								"question" : item.questionID,
								"response" : thisResponse.responseDesc
							});
						} else if ((item.overAllResponseUiFormat === constants.SINGLE_CHECK || item.overAllResponseUiFormat === constants.AUTO_COMPLETE || item.overAllResponseUiFormat === constants.MULTIPLE_CHECK || item.overAllResponseUiFormat === constants.LIST_ITEM) && _.findWhere(item.possibleResponses, {
							selected : true
						}) !== undefined) {
							$scope.postObj.questionnaire.push({
								"question" : item.questionID,
								"response" : item.selectedContent
							});
						} else if ((item.overAllResponseUiFormat === constants.SINGLE_RADIO || item.overAllResponseUiFormat === constants.MULTIPLE_RADIO) && _.findWhere(item.possibleResponses, {
							selected : true
						}) === undefined) {
							answeredAll = false;
						} else if ((item.overAllResponseUiFormat === constants.FREE_TEXT || item.overAllResponseUiFormat === constants.SINGLE_TEXT) && item.possibleResponses[0].enteredValue !== '') {
							$scope.postObj.questionnaire.push({
								"question" : item.questionID,
								"response" : item.possibleResponses[0].enteredValue
							});
						} else if (item.overAllResponseUiFormat === constants.SINGLE_NUMBER && item.possibleResponses[0].enteredValue !== '') {
							$scope.postObj.questionnaire.push({
								"question" : item.questionID,
								"response" : item.possibleResponses[0].enteredValue
							});
						} else if ((item.overAllResponseUiFormat === constants.SINGLE_DATE || item.overAllResponseUiFormat === constants.SINGLE_DATE_TIME) && item.possibleResponses[0].enteredValue !== '') {
							$scope.postObj.questionnaire.push({
								"question" : item.questionID,
								"response" : item.possibleResponses[0].enteredValue
							});
						} else if (item.overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_VALUE_MOBILE_NUMBER && item.possibleResponses[0].enteredValue !== '') {
							if($scope.isTeleCalling && item.questionDesc === "Contacted Mobile No"){
								$scope.postObj.contactedMobileNo = item.possibleResponses[0].enteredValue;
							}else{
								$scope.postObj.questionnaire.push({
									"question" : item.questionID,
									"response" : item.possibleResponses[0].enteredValue
								});
							}
						}
					}
					if ($scope.orangeCustomer.isOrange && $scope.postObj.actionCode === collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE) {
						$scope.postObj.suggestedRating = $scope.postObj.questionnaire[$scope.postObj.questionnaire.length - 1].response;
						$scope.postObj.currentRating = $scope.orangeCustomer.orangeDetails.rating;
						$scope.postObj.status = "initiated";
					} else {
						delete $scope.postObj.suggestedRating;
						delete $scope.postObj.currentRating;
						delete $scope.postObj.status;
					}
					if (answeredAll) {
						$scope.postObj.overlap = "false";
						contactRecordingService.postQuestions($scope.details.agreementNo, $scope.postObj).then(function(response) {
							if (!response.status) {
								popUpHandler(response, $scope.postObj.actionCode);
							} else if (response.status === 'failed' && response.message.errors[0].errorCode === 'MYACT-1005') {
								dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.APPINTMENT_ALREADY_EXISTS).result.then(function() {
									$scope.postObj.overlap = "true";
									contactRecordingService.postQuestions($scope.details.agreementNo, $scope.postObj).then(function(response) {
										if (!response.status) {
											popUpHandler(response, $scope.postObj.actionCode);
										} else if (response.status === 'failed') {
											var errormsg = '';
											if(response.message.errors[0].errorCode === 'CONREC-1007'){
												errormsg = response.message.errors[0].message + collectionConstants.ERROR_MSG.CANNOT_COMPLETE_RECORDING;
											}	
											else if(response.message.errors[0].errorCode === 'APPVL-0000'){
												errormsg = collectionConstants.ERROR_MSG.NO_APPROVER_FOUND;
											}else{
												errormsg = response.message.errors[0].message;
											}
											dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, errormsg).result.then(function() {
											}, function() {
												$globalScope.gotoPreviousPage();
												//lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_MY_CUSTOMER_PAGE);
											});
										}
									});
								}, function() {
									if (isPhone) {
										$scope.currentQuestion = $scope.indexFlow[3];
										$scope.currentQuestionNumber = 4;
									} else {
										$scope.currentQuestion = $scope.indexFlow[4];
										$scope.currentQuestionNumber = 5;
									}
									$scope.tabSet.isEdit = false;
									$scope.tabSet.noEdit = true;
									checkStatus();
								});
							} else if (response.status === 'failed') {
								var errormsg = '';
								if(response.message.errors[0].errorCode === 'CONREC-1007'){
									errormsg = response.message.errors[0].message + collectionConstants.ERROR_MSG.CANNOT_COMPLETE_RECORDING;
								}	
								else if(response.message.errors[0].errorCode === 'APPVL-0000'){
									errormsg = collectionConstants.ERROR_MSG.NO_APPROVER_FOUND;
								}else{
									errormsg = response.message.errors[0].message;
								}
								dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, errormsg).result.then(function() {
								}, function() {
									$globalScope.gotoPreviousPage();
									//lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_MY_CUSTOMER_PAGE);
								});
							}
						});
					}
				};
				/* method to construct post data on submit */
				$scope.postData = function() {
					if (thisGroupID) {
						dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.MARK_GROUP_AGREEMENTS, 'IsYesNo').result.then(function() {
							$scope.postObj.cifID = $scope.customerPartyDetails.cifID;
							postSubmit();
						}, function() {
							$scope.postObj.cifID = '';
							postSubmit();
						});
					} else {
						$scope.postObj.cifID = '';
						postSubmit();
					}
				};
				/* Method for Close recording */
				$scope.close = function() {
					dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.CLOSE_WITHOUT_RECORDING).result.then(function() {
						//lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_MY_CUSTOMER_PAGE);
						$globalScope.gotoPreviousPage();
					}, function() {
					});
				};
				// Code for Summary details and oter Informations
				/*contactRecordingService.getAgreementListDetails($scope.customerPartyDetails.cifID, $scope.myCustomerSummary.agreementNo).then(function() {
					$scope.details.agreementNo = $stateParams.agreementNo;
				});*/
				$scope.agreementChangeHandler = function(agreementNo) {
					var param = {
						agreementNo : agreementNo
					};
					$state.go('collections.contactRecording', param);
					$globalScope.removeAndResetLastState('agreementNo', agreementNo);
				};
				/* Method will trigger on click of the My Activity button. */
				$scope.appointmentHandler = function() {
					$rootScope.setCustomerDetails = {
						cifID : $scope.customerPartyDetails.cifID,
						customerName : $scope.details.customerName,
						agreementNo : $state.params.agreementNo
					};
					if ($scope.customerPartyDetails.cifID) {
						lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_MY_ACTIVITY_PAGE);
					}else{
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,collectionConstants.ERROR_MSG.CIF_ID_NOT_FOUND);
					}
				};
				/* Method will trigger on click of the case details button. */
				$scope.caseDetailHandler = function(data) {
					if (data && data === "PRINT") {
						$rootScope.print = 'printMiniStatement';
					}
					var params = {
						agreementNo : $stateParams.agreementNo
					// $rootScope.agreementNo
					};
					lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_CASE_DETAIL, params);
				};
				/*
				 * Method will trigger on click of the receipt button. Navigate
				 * to case eReceipt module.
				 */
				$scope.receiptingHandler = function() {
					$globalScope.isClickedViaMenu = false;
					$globalScope.goPreviousState = {
						name : $state.current.name,
						params : $state.params
					};
					lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_EPAYMENT, {
						agreementNo : $stateParams.agreementNo,
						receiptType : ($scope.activity.isVishesh && !$scope.activity.trip) ?'VISHESH':$scope.activity.trip ? 'TRIP':'OD'
					});
					$rootScope.agreementNo = $stateParams.agreementNo;// $rootScope.agreementNo;
				};
				/* Method for Back option */
				$scope.backHandler = function() {
					$globalScope.gotoPreviousPage();
					//$state.go(collectionConstants.CONTACT_RECORDING.LOAD_MY_CUSTOMER_PAGE);
				};
				/* Image upload controller */
				$scope.customerPhotoChangeHandler = function(customerPhoto, scope) {
					var urlParam = {
						customer : "customerphoto"
					};
					var obj = {
						agreementNo : $stateParams.agreementNo,
						partyType : "A",
						majorVersion : $scope.customerInfo.majorVersion,
						minorVersion : $scope.customerInfo.minorVersion,
						imagePathDetails : customerPhoto
					};
					contactRecordingService.uploadPhoto(urlParam, obj).then(function(data) {
						if (data.status === "success") {
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.SUCCESS_MSG.CUSTOMER_PHOTO_UPLOAD).result.then(function() {
							}, function() {
								angular.extend(customerPhoto.imagePathReferences,data.data[0].imagePathReferences);
								/*var imageRef = $scope.customerInfo.APPLICANT.customerPhoto.imagePathReferences;
								data.data[0].imagePathReferences[0].location = imageRef[imageRef.length - 1].location;
								$scope.customerInfo.APPLICANT.customerPhoto.imagePathReferences = data.data[0].imagePathReferences;
								scope.customerPhotoPanel.refreshFiles();*/
							});
						}
					});
				};
				$scope.caseFlaggingPopup = function() {
					$modal.open({
						templateUrl : 'app/collections/contactRecording/partials/caseFlagging.html',
						controller : 'caseFlaggingController',
						size : 'sm',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return {
									agreementDetails : getCustomerDetails
								};
							}
						}
					});
				};
				messageBus.onMsg('CASEFLAG', function(event, data) {
					if (data) {
						contactRecordingService.getCustomerInformation($stateParams.agreementNo).then(function(response){
							if(response){
								getCustomerDetails = response;
								$scope.customerInfo = utility.getCustomerInfo(response);
							}
			            });
					}
				}, $scope);
				
				messageBus.onMsg('ADDRESS_UPDATED', function(event, data) {
					if(data.addressType === 'CURRES'){
						$scope.details.currentAddress = utility.setAddress(data);
						$scope.details.currentAddress.push('Mobile : ' + data.mobileNo);
					}
					$scope.customerInfo.addressDetails.unshift(data);
				},$scope);
				
				messageBus.onMsg('THIRDPARTY', function(event, data) {
					$scope.customerInfo.thirdPartyDetails.unshift(data);
				},$scope);
				
				
			};
			contactRecording.controller('contactRecordingController', [ '$scope', '$globalScope', '$timeout', '$rootScope', 'contactRecordingService', '$state', '$modal', 'dialogService', 'lazyModuleLoader', 'messageBus', 'getCustomerDetails', '$stateParams', 'appFactory', contactRecordingController ]);
			return contactRecordingController;
		});