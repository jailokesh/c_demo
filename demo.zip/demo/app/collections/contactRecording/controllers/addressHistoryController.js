/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','contactRecording','constants','contactRecordingConstants'], function(r,contactRecording,constants,contactRecordingConstants) {
	'use strict';
	
	/**
	 * Pop up controller for My eReceiopt Swap .
	*/
     var addressHistoryController = function($scope,$modalInstance,$modal,contactRecordingService,data) {  
    	 $scope.agreementNo = data;
    	 $scope.contactInfoCurrentPage = 1;
    	 $scope.pageMaxSize = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
    	 $scope.totalCounts = 0;
    	 
    	 var getAddressDetails = function(thisOffset){
    		 contactRecordingService.getContactInfoDetail($scope.agreementNo,$scope.pageMaxSize,thisOffset).then(function(data){
 				if(data.data){
 					$scope.contactInfo = data.data[0] ? data.data[0].data : [];
 					$scope.totalCounts = data.meta.totalCount;
 				}
 			});
    	 };
    	 
    	 getAddressDetails('1');
    	 $scope.paginationHandler = function(pageNo) {
    		var thisOffset = (((pageNo-1)*$scope.pageMaxSize)+1);
    		getAddressDetails(thisOffset);
 		};
 		
 		 $scope.close = function(){	                		
  			$modalInstance.close();
  		};
    	 
     };
     contactRecording.controller('addressHistoryController',['$scope','$modalInstance','$modal','contactRecordingService','data',addressHistoryController]);
		return addressHistoryController;
	});