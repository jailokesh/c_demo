define([ 'require', 'contactRecording', 'constants', 'contactRecordingConstants', 'collectionConstants' ], function(r, contactRecording, constants, contactRecordingConstants, collectionConstants) {
	'use strict';
	var contactRecordingSearchController = function($scope, $rootScope, contactRecordingService, $state, lazyModuleLoader, dialogService, $globalScope) {
		$scope.placeHolderAndMaxLength = _.findWhere(contactRecordingConstants.PLACEHOLDER_TEXT, {
			type : 'agreementNo'
		});
		$scope.patternVal = contactRecordingConstants.REGULAR_EXPRESSION.ALPHANUMERIC;
		var paginationObj = {};
		$scope.validateKey = function(searchKey) {
			switch (searchKey) {
			case 'mobileNo':
			case 'thirdPartyMobileNo':
				$scope.patternVal = '^[0-9]+$';
				return;
			case 'agreementNo':
			case 'vishesh':
				$scope.patternVal = '^[A-Za-z0-9 ]+$';
				return;
			case 'trip':
				$scope.patternVal = '^[A-Za-z0-9 ]+$';
				return;
			case 'cifID':
				$scope.patternVal = '^[0-9]+$';
				return;
			case 'vehicleNo':
				$scope.patternVal = '^[A-Za-z0-9]+$';
				return;
			case 'customerName':
				$scope.patternVal = '^[A-Za-z ]+$';
				return;
			default:
				$scope.patternVal = '^[A-Za-z0-9]+$';
				break;
			}
		};
		var initController = function() {
			$scope.searchByParams = _.sortBy(contactRecordingConstants.SEARCH_BY, 'name');
			$scope.searchParams = {};
			$scope.searchParams.searchBy = $scope.searchByParams[0];
			$scope.data = {};
			$scope.data.currentPage = 1;
			$scope.offset = 1;
			$scope.offsetlast = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			$scope.searchDone = false;
			$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			$scope.maxSize = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			paginationObj = contactRecordingService.getPageValues();
			if ($globalScope.isClickedViaMenu || !paginationObj) {
				$scope.myCustomers = [];
			} else {
				$scope.searchDone = true;
				$scope.myCustomers = paginationObj.response.data;
				$scope.totalRecord = paginationObj.totalRecord;
				$scope.searchParams = paginationObj.searchParams;
				$scope.data.currentPage = paginationObj.currentPage;
				$scope.offsetlast = paginationObj.offsetlast;
				$scope.offset = (((paginationObj.searchParams.offset - 1) * 10) + 1);
			}
		};
		initController();
		/**
		 * set place holder content
		 */
		$scope.setPlaceHolderContent = function(searchBy) {
			$scope.searchDone = false;
			$scope.searchParams.searchKey = '';
			$scope.placeHolderAndMaxLength = _.findWhere(contactRecordingConstants.PLACEHOLDER_TEXT, {
				type : searchBy.value
			});
			$scope.validateKey(searchBy.value);
		};
		$scope.searchHandler = function(selectedCase) {
			contactRecordingService.agreementNo = selectedCase.agreementNo;
			var stateVal = $scope.isManualReceipt ? 'collections.manualPayment' : 'collections.ePayment';
			$scope.receiptType = ($scope.searchParams.searchBy.type === 'common') ? 'OD' : $scope.searchParams.searchBy.type.toUpperCase();
			$state.go(stateVal, {
				agreementNo : selectedCase.agreementNo || selectedCase.leadID,
				receiptType : $scope.receiptType
			});
		};
		var getSearchResults = function() {
			paginationObj = {};
			$scope.searchParams.offset = $scope.data.currentPage;
			$scope.searchParams.limit = constants.PAGINATION_CONFIG.MAX_SIZE_TEN;
			paginationObj.searchParams = $scope.searchParams;
			paginationObj.currentPage = $scope.data.currentPage;
			contactRecordingService.getMyCustomers($scope.searchParams).then(function(data) {
				var response = data;
				$scope.customers = paginationObj.response = response;
				$scope.myCustomers = $scope.customers.data || [];
				$scope.searchParams.productType = $scope.myCustomers[0] ? $scope.myCustomers[0].productGroup : '';
				$scope.searchParams.isHEAgreement = ($scope.searchParams.productType !== "VF"); 
				$scope.isSort = true;
				$scope.customerCounts = ($scope.customers && $scope.customers.meta) ? $scope.customers.meta.count : 0;
				$scope.totalRecord = paginationObj.totalRecord = ($scope.customers.meta && $scope.customers.meta.count) ? parseInt($scope.customers.meta.count) : 0;
				$scope.searchDone = true;
				$scope.offsetlast = (($scope.offset + 10) > $scope.totalRecord) ? $scope.totalRecord : $scope.offset + 9;
			});
			paginationObj.offsetlast = $scope.offsetlast;
			contactRecordingService.setPageValues(paginationObj);
		};
		$scope.doSearch = function(agreementNo) {
			$scope.searchParams.searchKey = agreementNo;
			if ($scope.searchParams.searchKey === '' || typeof ($scope.searchParams.searchKey) === 'undefined') {
				dialogService.showAlert('Message', "Message", "Please enter a valid search value");
				return;
			} else if ($scope.searchParams.searchBy.value === 'mobileNo' && agreementNo.length < 10) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please enter 10 digit mobile no !");
				return;
			} else if (agreementNo.length < collectionConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
			getSearchResults();
		};
		$scope.capitalizeHandler = function(val) {
			if ($scope.searchParams.searchBy.value === 'agreementNo' || $scope.searchParams.searchBy.value === 'vishesh' || $scope.searchParams.searchBy.value === 'trip'|| $scope.searchParams.searchBy.value === 'vehicleNo') {
				$scope.searchParams.searchKey = (val && val.length) ? val.toUpperCase() : '';
			}
		};
		$scope.resetHandler = function() {
			$scope.searchParams.searchKey = '';
			initController();
		};
		$scope.rowClickedHandler = function(customerObj) {
			if(customerObj.productGroup === 'PL'){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.CONTACT_REC_NA_PL);
				return;
			}
			lazyModuleLoader.loadState('collections.contactRecording', {
				agreementNo : customerObj.agreementNo
			});
			$rootScope.agreementNo = customerObj.agreementNo;
		};
		$scope.paginationHandler = function(pageNum) {
			$scope.data.currentPage = pageNum;
			$scope.offset = ((($scope.data.currentPage - 1) * 10) + 1);
			$scope.offsetlast = (($scope.offset + 10) > $scope.totalRecord) ? $scope.totalRecord : $scope.offset + 9;
			getSearchResults();
		};
		/**
		 * Method will trigger on click of the My Activity button. Navigate to
		 * My Activity module
		 */
		$scope.appointmentHandler = function() {
			$rootScope.setCustomerDetails = {
				cifID : $scope.customerInfo.cifID,
				customerName : $scope.customerInfo.name
			};
			if ($scope.customerInfo.cifID) {
				lazyModuleLoader.loadState('collections.myActivity');
			}
		};
		/**
		 * Method will trigger on click of the case details button. Navigate to
		 * case details module
		 */
		$scope.caseDetailHandler = function(data) {
			if (data && data === "PRINT") {
				$rootScope.print = 'printMiniStatement';
			}
			var params = {
				agreementNo : $rootScope.agreementNo
			};
			lazyModuleLoader.loadState('collections.caseDetail', params);
		};
		/**
		 * Method will trigger on click of the receipt button. Navigate to case
		 * eReceipt module.
		 */
		$scope.receiptingHandler = function() {
			$rootScope.agreementNo = $rootScope.agreementNo;
			// lazyModuleLoader.loadState('collections.receipt.eReceipt');
			lazyModuleLoader.loadState('collections.ePayment', {
				agreementNo : $rootScope.agreementNo,
				receiptType : 'OD'
			});
		};
		$scope.backHandler = function() {
			$state.go('collections.myCustomers');
		};
	};
	contactRecording.controller('contactRecordingSearchController', [ '$scope', '$rootScope', 'contactRecordingService', '$state', 'lazyModuleLoader', 'dialogService', '$globalScope', contactRecordingSearchController ]);
	return contactRecordingSearchController;
});