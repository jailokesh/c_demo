define(['require','contactRecording','collectionConstants'], function(r,contactRecording,collectionConstants) {
'use strict';
     var caseFlaggingController = function($scope,$modalInstance,$modal,$rootScope,lazyModuleLoader,contactRecordingService,messageBus,data) {
    	 
    	 $scope.flags = (collectionConstants.CASE_FLAGGING && collectionConstants.CASE_FLAGGING.length)?collectionConstants.CASE_FLAGGING:[];
    	 _.each($scope.flags,function(item){
    		 item.flagStatus = false;
    	 });
    	 if(data.agreementDetails && data.agreementDetails.flagStatus && data.agreementDetails.flagStatus.length){
    		 _.each(data.agreementDetails.flagStatus,function(item){
    			 var thisIndex = _.findIndex($scope.flags,{flagName:item});
    			 if(_.findWhere($scope.flags,{flagName:item}) !== undefined){
 					$scope.flags[thisIndex].flagStatus = true;
 				} else if(thisIndex > -1){
 					$scope.flags[thisIndex].flagStatus = false;
 				}
    		 });
    	 } else {
    		 _.each($scope.flags,function(item){
    			 item.flagStatus = false;
    		 });
    	 }
    	 $scope.updateFlagStatus = function(){
    		 var thisObj = {"flagStatus":"",
    				 		"minorVersion":data.agreementDetails.minorVersion,
    				 		"majorVersion":data.agreementDetails.majorVersion
    				 	};
    		 var thisFlag = [];
    		 _.each($scope.flags,function(item){
  				if(item.flagStatus){
  					thisFlag.push(item.flagName);
  				}
     		 });
    		 thisObj.flagStatus = thisFlag.join();
    		 contactRecordingService.updateCaseFlagging(data.agreementDetails.agreementNo,thisObj).then(function(response) {
    			 if(response){
    				 $modalInstance.dismiss();
    				 messageBus.emitMsg("CASEFLAG",true);
    			 }
    		 });
    	 };
         $scope.close = function(){
        	 $modalInstance.dismiss(); 
         };   
     };
	contactRecording.controller('caseFlaggingController',['$scope','$modalInstance','$modal','$rootScope','lazyModuleLoader','contactRecordingService','messageBus','data',caseFlaggingController]);
	return caseFlaggingController;
});