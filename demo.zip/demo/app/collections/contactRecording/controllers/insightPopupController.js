define(['require','contactRecording','collectionConstants'], function(r,contactRecording,collectionConstants) {
'use strict';
     var insightPopupController = function($scope,$modalInstance,$modal,$rootScope,$globalScope,data) {
    	 
    	 $scope.questions = data.questionsData;
    	 if(data.actionCode === collectionConstants.CONTACT_RECORDING.ORANGE_CUSTOMER_ACTION_CODE){
    		 $scope.actionCodeOrange = true; 
    	 } else {
    		 $scope.actionCodeOrange = false;
    	 }
    	 $scope.record = {isActions:false};

    	 for(var i=0;i<$scope.questions.length;i++){
    		 if($scope.questions[i].overAllResponseUiFormat === collectionConstants.CONTACT_RECORDING.SINGLE_CHOICE_WITH_RADIO_BUTTON){
    			 for(var j=0;j<$scope.questions[i].possibleResponses.length;j++){
    				 if($scope.questions[i].possibleResponses[j].selected){
    					 $scope.questions[i].possibleResponses.length = j+1;
    					 if($scope.questions[i].possibleResponses[j].insightDesc){
    						 $scope.record.isActions = true;
    					 } else{
    						 $scope.record.isActions = false;
    					 }
    				 }
    			 }
    		 }
    	 }
    	 
         $scope.close = function(){
        	 $rootScope.filterValue = 'All';
        	 $modalInstance.dismiss();
        	 $globalScope.gotoPreviousPage();
        	 //lazyModuleLoader.loadState(collectionConstants.CONTACT_RECORDING.LOAD_MY_CUSTOMER_PAGE);
        	  
         };   
     };
             
             
	contactRecording.controller('insightPopupController',['$scope','$modalInstance','$modal','$rootScope','$globalScope','data',insightPopupController]);
	return insightPopupController;
});