/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'contactRecording', 'utility', 'constants', 'collectionConstants' ], function(r, contactRecording, utility, constants, collectionConstants) {
	'use strict';
	/**
	 * Pop up controller for My eReceiopt Swap .
	 */
	var addressEditController = function($scope, $modalInstance, $modal, contactRecordingService, initialData, messageBus, dialogService, masterService, $globalScope) {
		var currentAddressCategory = _.findWhere($globalScope.imageCategories, {
			subCategory : "AddressDetails"
		});
		$scope.categoryDetails = currentAddressCategory ? currentAddressCategory : {};
		var isThirdParty = initialData.thirdPartyFlag;
		var data = angular.copy(initialData.dataObject);
		$scope.data = data;
		var thisCustomerID, thisApplicantCustomer, thisApplicantCurrentAddress, ContactRecordingModel,initialThirdPartyLength;
		var checkCityAndState = function(addressObj) { // city, state description will be empty if state / city ID is invalid.
			if (!addressObj.cityDesc) {
				addressObj.cityDesc = addressObj.city;
				addressObj.city = '';
			}
			if (!addressObj.stateDesc) {
				addressObj.stateDesc = addressObj.state;
				addressObj.state = '';
			}
			addressObj.addressLine2 = addressObj.addressLine2 ? addressObj.addressLine2 : '';
			addressObj.addressLine2 += addressObj.addressLine3 ? ', ' + addressObj.addressLine3 : '';

			return addressObj;
		};
		var getAddressFromType = function(_type){
			var _addressObj,intialAddressObj = {
				customerID : 0,
				mobileNo : "",
				addressType : "",
				addressLine1 : "",
				addressLine2 : "",
				addressLine3 : "",
				city : "",
				state : "",
				pincode : "",
				latitude : "",
				longitude : "",
				landLineNo : "",
				imageRef : {
					imagePathReferences : []
				}
			};
			_addressObj = _.findWhere(data.addressDetails, { addressType : _type});
			if(_addressObj){
				_addressObj.imageRef = !_addressObj.imageRef ? { imagePathReferences : [] } : _addressObj.imageRef;
			}else{
				_addressObj = intialAddressObj;
			}
			return checkCityAndState(_addressObj);
		};
		
		var initPopUp = function() {
			if (isThirdParty === 'true') {
				$scope.partyType = 'ThirdParty';
			} else {
				$scope.partyType = 'Applicant';
			}
			ContactRecordingModel = contactRecordingService.getContactPostModel();
			$scope.validators = ContactRecordingModel.validators;
			thisApplicantCustomer = _.findWhere(data.partyDetails, {
				partyType : 'A'
			});
			if (data.partyDetails.length) {
				thisCustomerID = _.findWhere(data.partyDetails, {
					partyType : 'A'
				}).customerID;
				$scope.customerName = '';
				if (thisApplicantCustomer) {
					var customerFullName = thisApplicantCustomer.firstName ? thisApplicantCustomer.firstName : '';
					customerFullName += thisApplicantCustomer.middleName ? (' ' + thisApplicantCustomer.middleName) : ' ';
					customerFullName += thisApplicantCustomer.lastName ? (' ' + thisApplicantCustomer.lastName) : ' ';
					$scope.customerName = customerFullName;
				}
			}
			$scope.addressDetailCurres = getAddressFromType(collectionConstants.CURRENT_ADDRESS);
			$scope.addressDetailPerres = getAddressFromType(collectionConstants.PERMANENT_ADDRESS);
			$scope.addressDetailOffice = getAddressFromType(collectionConstants.OFFICE);
			$scope.currentAddress = '';
			thisApplicantCurrentAddress = $scope.addressDetailCurres ? $scope.addressDetailCurres : $scope.addressDetailPerres ? $scope.addressDetailPerres : $scope.addressDetailOffice;
			$scope.addressTypeSelected = thisApplicantCurrentAddress.addressType ? thisApplicantCurrentAddress.addressType : collectionConstants.CURRENT_ADDRESS;
			$scope.currentAddress = utility.setAddress(thisApplicantCurrentAddress);
			
			$scope.thirdpartyDetail = {};
			initialThirdPartyLength = data.thirdPartyDetails.length;
			if (data.thirdPartyDetails.length > 0) {
				data.thirdPartyDetails[0].thirdPartyAddresses[0] = checkCityAndState(data.thirdPartyDetails[0].thirdPartyAddresses[0]);
				$scope.thirdpartyDetail = data.thirdPartyDetails[0];
			}
		};
		initPopUp();
		$scope.streetNameValidator = function(val) {
			if (collectionConstants.REGULAR_EXPRESSION.STREET_NAME.test(val)) {
				return utility.getSuccessResult();
			} else {
				return utility.getFailureResult("Invalid street name");
			}
		};
		$scope.doorNoValidator = function(val) {
			if (collectionConstants.REGULAR_EXPRESSION.DOOR_NO.test(val)) {
				return utility.getSuccessResult();
			} else {
				return utility.getFailureResult("Invalid door number");
			}
		};
		$scope.setType = function(partyType) {
			$scope.partyType = partyType;
		};
		$scope.setAddressType = function(type) {
			$scope.addressTypeSelected = type;
		};
		$scope.close = function() {
			if (isThirdParty === 'true' && initialThirdPartyLength === data.thirdPartyDetails.length && data.thirdPartyDetails.length > 0) {
				dialogService.confirm(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.THIRD_PARTY_UPDATE_EXISTING, 'IsYesNo').result.then(function() {
					isThirdParty = "false";
					$modalInstance.close();
					return;
				}, function() {
					isThirdParty = "false";
					$modalInstance.close();
					messageBus.emitMsg("ADDRESS", isThirdParty);
					return;
				});
				/*
				 * } else if(isThirdParty == 'true' && initialThirdPartyLength
				 * === data.thirdPartyDetails.length &&
				 * data.thirdPartyDetails.length == 0) {
				 * dialogService.showAlert('Alert', "Warning", "Third Party
				 * Address is mandatory for this Recording!"); return;
				 */
			} else if (isThirdParty === 'true' && initialThirdPartyLength > data.thirdPartyDetails.length) {
				isThirdParty = "false";
				$modalInstance.close();
				return;
			} else {
				if (isThirdParty === 'true') {
					dialogService.confirm(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.REPO_MSG.CONFIRM_CLOSE).result.then(function() {
						isThirdParty = "false";
						$modalInstance.close();
						messageBus.emitMsg("ADDRESS", isThirdParty);
						return;
					}, function() {
						return;
					});
				} else {
					$modalInstance.close();
				}

			}
		};
		/* get Current Object */
		var currentObject = function() {
			var thisCurrentAddressObj;
			if ($scope.addressTypeSelected === collectionConstants.CURRENT_ADDRESS) {
				thisCurrentAddressObj = $scope.addressDetailCurres;
			} else if ($scope.addressTypeSelected === collectionConstants.PERMANENT_ADDRESS) {
				thisCurrentAddressObj = $scope.addressDetailPerres;
			} else if ($scope.addressTypeSelected === collectionConstants.OFFICE) {
				thisCurrentAddressObj = $scope.addressDetailOffice;
			}
			return thisCurrentAddressObj;
		};

		/* get List pincode, state and city list */
		$scope.getPincodeList = function(pincode) {
			var _stateID, _cityID, thisAddressObjCheck;
			if ($scope.partyType === 'Applicant') {
				thisAddressObjCheck = currentObject();
			} else {
				thisAddressObjCheck = $scope.thirdpartyDetail.thirdPartyAddresses[0];
			}
			_stateID = thisAddressObjCheck.stateDesc ? thisAddressObjCheck.state : '';
			_cityID = thisAddressObjCheck.cityDesc ? thisAddressObjCheck.city : '';
			return contactRecordingService.getFilteredData('CityZip', {
				'zipCode' : pincode,
				'limit' : 10,
				stateID : _stateID,
				cityID : _cityID
			}).then(function(result) {
				return result;
			});
		};
		$scope.getCityList = function(cityName) {
			var _stateID,thisObj;
			if ($scope.partyType === 'Applicant') {
				thisObj = currentObject();
			} else {
				thisObj = $scope.thirdpartyDetail.thirdPartyAddresses[0];
			}
			_stateID = thisObj.stateDesc ? thisObj.state : '';
			return contactRecordingService.getFilteredData('City', {
				'cityName' : cityName,
				'limit' : 10,
				stateID : _stateID
			}).then(function(result) {
				return result;
			});
		};

		$scope.getStateList = function(stateName) {
			return contactRecordingService.getFilteredData('State', {
				'stateDesc' : stateName,
				'limit' : 10
			}).then(function(result) {
				return result;
			});
		};

		/* Method to get State and City */
		$scope.getStateAndCity = function() {
			return function(item) {
				if (item) {
					var thisObj;
					if ($scope.partyType === 'Applicant') {
						thisObj = currentObject();
					} else {
						thisObj = $scope.thirdpartyDetail.thirdPartyAddresses[0];
					}
					if (thisObj.state !== item.stateID || thisObj.city !== item.cityID) {
						masterService.getStateAndCity(item.zipCode).then(function(response) {
							if (response.status === "success" && response.data.City.length > 0) {
								thisObj.stateDesc = (response.data.State[0]) ? response.data.State[0].stateDesc : '';
								thisObj.state = (response.data.State[0]) ? response.data.State[0].stateID : '';
								thisObj.cityDesc = (response.data.City[0]) ? response.data.City[0].cityName : '';
								thisObj.city = (response.data.City[0]) ? response.data.City[0].cityID : '';
							} else {
								dialogService.showAlert(constants.ERROR_HEADER.info, collectionConstants.ERROR_MSG.NO_MAPPING_FOUND, collectionConstants.ERROR_MSG.PINCODE_NO_MAPPING);
								thisObj.state = thisObj.stateDesc = thisObj.city = thisObj.cityDesc = '';
							}
						});
					}
				}
			};
		};

		$scope.citySelected = function() {
			return function(item) {
				if (item) {
					var thisAddressObjCity;
					if ($scope.partyType === 'Applicant') {
						thisAddressObjCity = currentObject();
					} else {
						thisAddressObjCity = $scope.thirdpartyDetail.thirdPartyAddresses[0];
					}
					if (item.cityID !== thisAddressObjCity.city) {
						thisAddressObjCity.pincodeName = thisAddressObjCity.pincode = '';
					}
					thisAddressObjCity.city = item.cityID;
					thisAddressObjCity.state = item.stateID;
					thisAddressObjCity.cityDesc = item.cityName;
					if (thisAddressObjCity.state !== item.stateID) {
						return contactRecordingService.getFilteredData('State', {
							stateID : item.stateID
						}).then(function(data) {
							thisAddressObjCity.stateDesc = data[0].stateDesc;
						});
					}
				}
			};
		};

		$scope.stateSelected = function() {
			return function(item) {
				if (item) {
					var thisAddressObjState, clearObject, checkObj;
					if ($scope.partyType === 'Applicant') {
						thisAddressObjState = currentObject();
					} else {
						thisAddressObjState = $scope.thirdpartyDetail.thirdPartyAddresses[0];
					}
					//if (item.stateID !== thisAddressObjState.state && item.stateDesc !== thisAddressObjState.state) {
					thisAddressObjState.city = thisAddressObjState.cityDesc = '';
					thisAddressObjState.pincodeName = thisAddressObjState.pincode = '';
					thisAddressObjState.state = item.stateID;
					//}
					
				}
			};
		};

		var postApplicantAddress = function(obj) {
			contactRecordingService.postCustomerAddress(obj).then(function(data) {
				if (data) {
					var emitObj;
					if ($scope.addressTypeSelected === collectionConstants.CURRENT_ADDRESS) {
						emitObj = $scope.addressDetailCurres;
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.CURRES_ADDRESS_SUCCESS);
					} else if ($scope.addressTypeSelected === collectionConstants.PERMANENT_ADDRESS) {
						emitObj = $scope.addressDetailPerres;
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.PERRES_ADDRESS_SUCCESS);
					} else if ($scope.addressTypeSelected === collectionConstants.OFFICE) {
						emitObj = $scope.addressDetailOffice;
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.OFFICE_ADDRESS_SUCCESS);
					}
					emitObj.addressType = $scope.addressTypeSelected;
					emitObj.pincode = emitObj.pincodeName;
					delete emitObj.addressLine3;
					messageBus.emitMsg("ADDRESS_UPDATED", emitObj);
					$modalInstance.close();
				}
			});
		};

		var setStateCityID = function() {
			var currentObjectData;
			if ($scope.partyType === 'Applicant') {
				currentObjectData = currentObject();
			} else {
				currentObjectData = $scope.thirdpartyDetail.thirdPartyAddresses[0];
			}
			masterService.getStateAndCity(currentObjectData.pincode).then(function(data) {
				currentObjectData.city = (data.data.City[0]) ? data.data.City[0] : '';
				currentObjectData.state = (data.data.State[0]) ? data.data.State[0] : '';
				if ($scope.partyType === 'Applicant') {
					postAddress();
				} else {
					postThirdParty();
				}
			});
		};

		$scope.updateApplicant = function() {
			var thisAddressObj = currentObject();
			if (!thisAddressObj.city || !thisAddressObj.state) {
				return;
			}
			postAddress();
		};

		var postAddress = function() {
			var thisAddressObj = currentObject();
			var obj = {
				customerID : thisCustomerID,
				mobileNo : thisAddressObj.mobileNo,
				addressType : $scope.addressTypeSelected,
				addressLine1 : thisAddressObj.addressLine1,
				addressLine2 : thisAddressObj.addressLine2,
				city : thisAddressObj.city,
				state : thisAddressObj.state,
				pincode : thisAddressObj.pincodeName,
				latitude : thisAddressObj.latitude,
				longitude : thisAddressObj.longitude,
				landLineNo : thisAddressObj.landLineNo,
				imageRef : thisAddressObj.imageRef
			};
			if (!thisAddressObj.imageRef || !thisAddressObj.imageRef.imagePathReferences || !(thisAddressObj.imageRef.imagePathReferences && thisAddressObj.imageRef.imagePathReferences.length && thisAddressObj.imageRef.imagePathReferences[0].location)) {
				dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm, collectionConstants.ERROR_MSG.ADDRESS_UPDATE_WITHOUT_PROOF, 'IsYesNo').result.then(function() {
					// obj.isHostAddress = false;
					postApplicantAddress(obj);
				}, function() {
					return;
				});
			} else {
				// obj.isHostAddress = true;
				postApplicantAddress(obj);
			}
		};

		$scope.updateThirdParty = function() {
			if (!$scope.thirdpartyDetail.thirdPartyAddresses[0].city || !$scope.thirdpartyDetail.thirdPartyAddresses[0].state) {
				return;
			}
			postThirdParty();
		};

		var postThirdParty = function() {
			var obj = {
				agreementNos : [ $scope.data.agreementNo ],
				name : $scope.thirdpartyDetail.name,
				status : 'INITIATED',
				branchID : $scope.data.branchID,
				thirdPartyAddresses : [ {
					name : $scope.thirdpartyDetail.customerName,
					doorNo : $scope.thirdpartyDetail.thirdPartyAddresses[0].doorNo,
					streetAreaLandmark : $scope.thirdpartyDetail.thirdPartyAddresses[0].streetAreaLandmark,
					city : $scope.thirdpartyDetail.thirdPartyAddresses[0].city,
					cityDesc : $scope.thirdpartyDetail.thirdPartyAddresses[0].cityDesc,
					state : $scope.thirdpartyDetail.thirdPartyAddresses[0].state,
					stateDesc : $scope.thirdpartyDetail.thirdPartyAddresses[0].stateDesc,
					pincode : $scope.thirdpartyDetail.thirdPartyAddresses[0].pincodeName,
					latitude : $scope.thirdpartyDetail.thirdPartyAddresses[0].latitude,
					longitude : $scope.thirdpartyDetail.thirdPartyAddresses[0].longitude,
					landLineNo : $scope.thirdpartyDetail.thirdPartyAddresses[0].landLineNo,
					mobileNo : $scope.thirdpartyDetail.thirdPartyAddresses[0].mobileNo,
					addressProofPathRef : $scope.thirdpartyDetail.thirdPartyAddresses[0].addressProofPathRef
				} ]
			};
			contactRecordingService.postThirdPartyAddress(obj).then(function(data) {
				if (data.status === "success") {
					if (data.data && data.data.thirdPartyID) {
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.THIRDPARTY_ADDRESS_REQUEST);
					} else {
						initialThirdPartyLength = initialThirdPartyLength + 1;
						dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.THIRDPARTY_ADDRESS_SUCCESS);
					}
					$scope.thirdpartyDetail.thirdPartyAddresses[0].pincode = $scope.thirdpartyDetail.thirdPartyAddresses[0].pincodeName; 
					messageBus.emitMsg("THIRDPARTY", $scope.thirdpartyDetail);
					$modalInstance.close();
				}
			});
		};
		// $scope.setType($scope.partyType);
	};
	contactRecording.controller('addressEditController', [ '$scope', '$modalInstance', '$modal', 'contactRecordingService', 'data', 'messageBus', 'dialogService', 'masterService', '$globalScope', addressEditController ]);
	return addressEditController;
});