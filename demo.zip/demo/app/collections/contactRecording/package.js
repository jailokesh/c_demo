define([], function() {
'use strict';
   require.config({
      //    baseUrl:'/sales.chola.com/',
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'contactRecording': 'app/collections/contactRecording/contactRecording',
          'contactRecordingService': 'app/collections/contactRecording/services/contactRecordingService',
          'contactRecordingController': 'app/collections/contactRecording/controllers/contactRecordingController',
          'contactRecordingSearchController': 'app/collections/contactRecording/controllers/contactRecordingSearchController',
          'insightPopupController': 'app/collections/contactRecording/controllers/insightPopupController',
          'caseFlaggingController': 'app/collections/contactRecording/controllers/caseFlaggingController',
          'addressEditController': 'app/collections/contactRecording/controllers/addressEditController',
          'addressHistoryController': 'app/collections/contactRecording/controllers/addressHistoryController',
          'contactRecordingResolver':'app/collections/contactRecording/resolvers/contactRecordingResolver',
          'sharedPackage' : 'app/common/shared/package',
          'contactRecordingConstants' : 'app/collections/contactRecording/contactRecordingConstants'
      },
      shim: {
    	  'contactRecording': ['angular', 'angular-ui-router','contactRecordingResolver','contactRecordingConstants'],
          'contactRecordingController': ['contactRecording','contactRecordingService'],
          'contactRecordingSearchController': ['contactRecording','contactRecordingService'],
          'insightPopupController': ['contactRecordingService','contactRecording'],
          'caseFlaggingController': ['contactRecordingService','contactRecording'],
          'addressEditController': ['contactRecordingService','contactRecording'],
          'addressHistoryController': ['contactRecordingService','contactRecording'],
          'contactRecordingService':['contactRecording']
      }
   });
   return function(callback){
	   requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs([ 'contactRecordingController','contactRecordingSearchController', 'insightPopupController', 'addressEditController','addressHistoryController','caseFlaggingController'], callback);
			});
		});
   };
});