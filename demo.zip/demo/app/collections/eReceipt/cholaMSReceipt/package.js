define([], function() {
    'use strict';
    require.config({
        paths: {
            'collectionsApp':'app/collections/collections',
            'cholaMSReceipt': 'app/collections/eReceipt/cholaMSReceipt/cholaMSReceipt',
            'cholaMSReceiptService': 'app/collections/eReceipt/cholaMSReceipt/services/cholaMSReceiptService',
            'cholaMSReceiptController':'app/collections/eReceipt/cholaMSReceipt/controllers/cholaMSReceiptController'
        },
        shim: {
            'cholaMSReceipt': ['angular', 'angular-ui-router'],
            'cholaMSReceiptController' : ['cholaMSReceipt','cholaMSReceiptService'],
        }
    });
    return function(callback) {
        requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['cholaMSReceiptController'], callback);
            });
        });
    };
});