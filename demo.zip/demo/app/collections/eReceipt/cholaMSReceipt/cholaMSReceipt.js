define([ 'collectionsApp' ], function(collectionsApp) {
    'use strict';
    var baseViewUrl = 'app/collections/eReceipt/cholaMSReceipt/';
    var app = angular.module('cholaMSReceipt', [ 'ui.router', 'collections', 'angularFileUpload' ]);

    var cholaMSReceipt = function($stateProvider, $urlRouterProvider) {
        $stateProvider
            .state('collections.cholaMSReceipt', {
                name : 'cholaMSReceipt',
                url : '/cholaMSReceipt',
                views : {
                    'mainContent' : {
                        templateUrl : baseViewUrl + 'cholaMSReceipt.html',
                        controller : 'cholaMSReceiptController'
                    }
                },
                data : {
                    'headerText' : 'Chola MS Receipt',
                    'stateActivity' : ['COL_CHOLA_MS_RECEIPT']
                }
            })
    };
    app.config([ '$stateProvider', '$urlRouterProvider', cholaMSReceipt ]);
    return app;
});