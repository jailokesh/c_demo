define(['require','cholaMSReceipt','collectionServiceURLs','collectionConstants','utility','DatePickerConfig' ],function(require,cholaMSReceipt, collectionServiceURL,collectionConstants,utility,DatePickerConfig){
    'use strict';
    /**
     * Represents a image Upload Service.
     * Image Upload Service function
     * Dependency injection $q,restProxy,authService as parameters.
     */
    var cholaMSReceiptService =function($q,restProxy,dialogService){


        this.getCholaMSPrintList = function(data){
            var queryObj ={};
            queryObj.userID = data.userID
            queryObj.fromDate = data.fromDateConfig && data.fromDateConfig.value ?  displayDetailDate(data.fromDate ? data.fromDate : data.fromDateConfig.value) : '';
            queryObj.toDate = data.toDateConfig && data.toDateConfig.value ? displayDetailDate(data.toDate ? data.toDate : data.toDateConfig.value) : '';

            collectionServiceURL.receiptingServices.GET_CHOLAMS_PRINT_LIST.queryParams = queryObj;
            return restProxy.get(collectionServiceURL.receiptingServices.GET_CHOLAMS_PRINT_LIST).then(function (data) {
                if(data.status === "success"){
                    return data;
                }else{
                    return {data : [],meta : {totalCount:0}};
                }
            });
        };

        this.updateCholaMSPrintList = function (data,getPrintListData) {
            collectionServiceURL.receiptingServices.UPDATE_CHOLAMS_PRINT_LIST.queryParams = data;

            return restProxy.save('PUT', collectionServiceURL.receiptingServices.UPDATE_CHOLAMS_PRINT_LIST,{}).then(function(data) {
                if(data.status){
                    return data;
                }
            });
        };

        var displayDetailDate = function(inputDate){
            var _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug','Sep', 'Oct', 'Nov', 'Dec'];
            var _date = new Date(inputDate);
            return  _date.getDate() + '-'+ _months[_date.getMonth()] + '-'+ _date.getFullYear();
        };
    };

    cholaMSReceipt.service('cholaMSReceiptService',['$q','restProxy','dialogService',cholaMSReceiptService]);
    return cholaMSReceiptService;
});