define(['require', 'cholaMSReceipt', 'utility', 'collectionConstants', 'constants', 'DatePickerConfig'], function (r, cholaMSReceipt, utility, collectionConstants, constants, DatePickerConfig) {
    'use strict';
    var cholaMSReceiptController = function ($scope, $state, cholaMSReceiptService, $modal, lazyModuleLoader, $rootScope, dialogService, appFactory, $globalScope, addressLocationFactory) {
        $scope.data = {
            attrsValues: collectionConstants.GLOBAL_ATTRS_VALUES,
            selectedOption: '',
            searchValue: '',
            totalRecord: 0,
            maxRecordPerPage: constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
            maxSize: constants.PAGINATION_CONFIG.MAX_SIZE_TEN,
            offset: 1,
            offsetlast: 10,
            currentPage: 1,
            activeTab:'agreementsList',
            offsetlast2:10,
            totalRecord2:0,
            offset2:1,
            pageNo:1
        };


        /*Date configuration*/
        $scope.data.fromDateConfig = new DatePickerConfig({
            value:new Date(new Date().setDate(new Date().getDate() - 30)),
            maxDate:new Date(),
            onchange:function(val){
                $scope.data.fromDate = val;
                $scope.data.toDateConfig.minDate = val;
            },
            readonly: true
        });
        $scope.data.toDateConfig = new DatePickerConfig({
            value:new Date(),
            minDate:$scope.data.fromDate,
            maxDate:new Date(),
            readonly: true,
            onchange:function(val){
                $scope.data.toDate = val;
                $scope.data.fromDateConfig.maxDate = val;
            }
        });
         $scope.doSearch = function(data){
             if(data.activeTab == 'agreementsList'){
                 $scope.data.printList = _.where($scope.data.receiptDetails,{PrintCount:0})
                 if($scope.data.selectedOption == 'agreementNo'){
                     $scope.data.printList = _.where($scope.data.printList,{AgreementNum : $scope.data.searchValue});
                     $scope.data.masterPrintList = _.where($scope.data.printList,{AgreementNum : $scope.data.searchValue});
                 }
                 if($scope.data.selectedOption == 'receiptNo'){
                     $scope.data.printList = _.where($scope.data.printList,{ReceiptNum : parseInt($scope.data.searchValue)});
                     $scope.data.masterPrintList = _.where($scope.data.printList,{ReceiptNum : parseInt($scope.data.searchValue)});
                 }
                 if($scope.data.selectedOption == 'userId'){
                     $scope.data.printList = _.where($scope.data.printList,{UserId : $scope.data.searchValue.toUpperCase()});
                     $scope.data.masterPrintList = _.where($scope.data.printList,{UserId : $scope.data.searchValue.toUpperCase()});
                 }
             }else{
                 $scope.data.rePrintList = [];
                _.each($scope.data.receiptDetails,function(oneItem){
                    if(oneItem.PrintCount > 0){
                        $scope.data.rePrintList.push(oneItem)
                    }
                })
                 if($scope.data.selectedOption == 'agreementNo'){
                     $scope.data.rePrintList = _.where($scope.data.rePrintList,{AgreementNum : $scope.data.searchValue});
                     $scope.data.masteRePrintList = _.where($scope.data.rePrintList,{AgreementNum : $scope.data.searchValue});
                 }
                 if($scope.data.selectedOption == 'receiptNo'){
                     $scope.data.rePrintList = _.where($scope.data.rePrintList,{ReceiptNum : parseInt($scope.data.searchValue)});
                     $scope.data.masteRePrintList = _.where($scope.data.rePrintList,{ReceiptNum : parseInt($scope.data.searchValue)});
                 }
                 if($scope.data.selectedOption == 'userId'){
                     $scope.data.rePrintList = _.where($scope.data.rePrintList,{UserId : $scope.data.searchValue.toUpperCase()});
                     $scope.data.masteRePrintList = _.where($scope.data.rePrintList,{UserId : $scope.data.searchValue.toUpperCase()});
                 }
             }
             $scope.paginationHandler(1);
         };

        $scope.selectedPrintCheckBox = function(data,check){
            _.each($scope.data.printList,function(item){
                if(check  && (data.ReceiptNum == item.ReceiptNum)){
                    item.selected = true;
                }else{
                    item.selected = false;
                }
            });
            if(check){
                $scope.showPrintPopup(data,$scope);
            }
        };
        $scope.selectedReprintCheckBox = function(data,check){
            _.each($scope.data.rePrintList,function(item){
                if(check  && (data.ReceiptNum == item.ReceiptNum)){
                    item.selected = true;
                }else{
                    item.selected = false;
                }
            });
            if(check){
                $scope.showPrintPopup(data,$scope);
            }
        };
        $scope.paginationHandler = function(pageNo){
            if($scope.data.activeTab == 'agreementsList') {
                $scope.data.currentPage = pageNo;
                $scope.data.totalRecord = $scope.data.masterPrintList.length;
                $scope.data.totalRecordList = $scope.data.masterPrintList;
                var startLen = $scope.data.maxRecordPerPage * (pageNo - 1);
                var endLen = $scope.data.maxRecordPerPage + ($scope.data.maxRecordPerPage * (pageNo - 1));
                $scope.data.printList =  $scope.data.totalRecordList.slice(startLen, endLen);
                $scope.data.offset = ((pageNo - 1) * 10) + 1;
                $scope.data.offsetlast = ((pageNo * 10) > $scope.data.totalRecord) ? $scope.data.totalRecord : pageNo * 10;
            }else{
                $scope.data.pageNo = pageNo;
                $scope.data.totalRecord2 = $scope.data.masteRePrintList.length;
                $scope.data.totalRecordList2 = $scope.data.masteRePrintList;
                var startLen = $scope.data.maxRecordPerPage * (pageNo - 1);
                var endLen = $scope.data.maxRecordPerPage + ($scope.data.maxRecordPerPage * (pageNo - 1));
                $scope.data.rePrintList =  $scope.data.totalRecordList2.slice(startLen, endLen);
                $scope.data.offset2 = ((pageNo - 1) * 10) + 1;
                $scope.data.offsetlast2 = ((pageNo * 10) > $scope.data.totalRecord2) ? $scope.data.totalRecord2 : pageNo * 10;
            }
        };
        $scope.showPrintPopup = function(data,scope) {
            var paramObj = {
                templateUrl : 'app/collections/eReceipt/cholaMSReceipt/partials/cholaMSPrint.html',
                controller : [ '$scope', '$modalInstance', 'data', 'cholaMSReceiptService', function($scope, $modalInstance, data, cholaMSReceiptService) {
                    $scope.receiptDetails = data;
                       $scope.receiptDetails.currentDateTime = new Date();
                    $scope.close = function() {
                        data.selected = false;
                        $modalInstance.close();
                    };
                    $scope.printHandler = function() {
                        var updateObj = {
                            "receiptNo" : data.ReceiptNum,
                            "userID" : $rootScope.identity.userID
                        };
                        cholaMSReceiptService.updateCholaMSPrintList(updateObj).then(function(result){
                            if(result.data && result.data.SUCCESS_FAIL && result.data.SUCCESS_FAIL == 'SUCCESS'){
                                dialogService.showAlert('Success', "Success", "Print details have been updated successfully").result.then(function(){},function(){
                                    scope.getPrintList();
                                });
                            }else{
                                dialogService.showAlert('Error', "Error",result.data.MESSAGE);
                            }
                        });
                             data.selected = false;
                            $modalInstance.close();
                        }
                }],
                size : 'sm',
                backdrop : 'static',
                windowClass : 'modal-custom',
                resolve : {
                    data : function() {
                        return data;
                    }
                }
            };
            return $modal.open(paramObj);
        };

        $scope.getPrintList = function () {
            $scope.data.userID = $rootScope.identity.userID;
            cholaMSReceiptService.getCholaMSPrintList($scope.data).then(function (result) {
                $scope.data.receiptDetails = result.data;
                $scope.data.printList = [];
                $scope.data.masterPrintList = [];
                $scope.data.rePrintList = [];
                $scope.data.masteRePrintList = [];

                _.each($scope.data.receiptDetails,function(oneItem){
                    if(oneItem.PolicyPremium && oneItem.PolicyPremium != 'undefined'){
                        oneItem.amountInWords = utility.numberIntoWords(oneItem.PolicyPremium) +' Only';
                    }
                    if(oneItem.PrintCount == 0){
                        $scope.data.printList.push(oneItem);
                        $scope.data.masterPrintList.push(oneItem);
                    }else if(oneItem.PrintCount > 0){
                        $scope.data.rePrintList.push(oneItem);
                         $scope.data.masteRePrintList.push(oneItem)
                    }

                });

                $scope.paginationHandler(1);
            });
        };
        if($scope.data.activeTab =='agreementsList'){
            $scope.getPrintList();
        }

    };

    cholaMSReceipt.controller('cholaMSReceiptController', ['$scope', '$state', 'cholaMSReceiptService', '$modal', 'lazyModuleLoader', '$rootScope', 'dialogService', 'appFactory', '$globalScope', 'addressLocationFactory', cholaMSReceiptController]);
        return cholaMSReceiptController;
    });