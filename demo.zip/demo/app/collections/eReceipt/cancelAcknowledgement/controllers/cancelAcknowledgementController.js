define([ 'require', 'cancelAcknowledgement', 'collectionConstants', 'utility', 'DatePickerConfig', 'constants' ], function(require, cancelAcknowledgement, collectionConstants, utility, DatePickerConfig, constants) {

	var cancelAcknowledgementController = function($scope, $stateParams, $modal, cancelAcknowledgementService, lazyModuleLoader, $globalScope) {
		$scope.data = {};
		$scope.data.maxSize = constants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
		$scope.data.maxRecordPerPage = constants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
		$scope.data.totalRecord = 0;
		$scope.data.currentPage = 1;
		$scope.data.ackSearch = false;
		$scope.data.offset = 0;
		var today = new Date();
		today.setHours(0, 0, 0, 0);

		$scope.acknowledgeStartDate = new DatePickerConfig({
			value : today,
			maxDate : new Date(),
			onchange : function(val) {
				$scope.acknowledgeEndDate.minDate = new Date(val);
			}
		});
		$scope.acknowledgeEndDate = new DatePickerConfig({
			value : today,
			maxDate : new Date(),
			onchange : function(val) {
				$scope.acknowledgeStartDate.maxDate = new Date(val);
			}
		});

		/**
		 * Method to validate the receipt no
		 */
		$scope.ackNoValidator = function(val) {
			if (collectionConstants.REGULAR_EXPRESSION.ACK_NO.test(val)) {
				return utility.getSuccessResult();
			} else {
				return utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_ACK_NO);
			}
		};
		/**
		 * Method to get Receipt details
		 */
		if (!$globalScope.isClickedViaMenu) {
			var savedDetails = cancelAcknowledgementService.getAckDetails();
			$scope.acknowledgementNo = savedDetails.searchVal;
			$scope.acknowledgeStartDate.dateValue = $scope.acknowledgeStartDate.value = savedDetails.fromDate;
			$scope.acknowledgeEndDate.dateValue = $scope.acknowledgeEndDate.value = savedDetails.toDate;
			$scope.data.currentPage = savedDetails.pagination.currentPage;
			var selectedAck = _.findWhere(savedDetails.data, {
				pddAcknowledgementNo : $globalScope.deletedACKNo
			});
			if (selectedAck){
				selectedAck.status = 'CANCELLED';
			}
			$scope.receiptInfo = savedDetails.data;
			$scope.data.totalRecord = savedDetails.pagination.totalRecord;
			$scope.data.offset = savedDetails.pagination.offset;
			$scope.data.offsetlast = savedDetails.pagination.offsetlast;
		}
		var setImageForAck = function(pddObj){
			var imageRef = '',type;
			type = pddObj.pddAcknowledgementType === 'INSURANCE' ? 'insuranceDetail' : pddObj.pddAcknowledgementType === 'INVOICE' ? 'invoiceDetail' : pddObj.pddAcknowledgementType === 'RC' ? 'RCDetail' : '';
			if(type){
				imageRef = pddObj[type].imageRef;
			}else if(pddObj.pddAcknowledgementType === 'ACH' || pddObj.pddAcknowledgementType === 'ECS'){
				imageRef = pddObj.paymentInstructionType.imageRef;
			}
			return imageRef;
		};
		
		$scope.getAcknowledgementDetails = function() {
			if (!$scope.acknowledgementNo) {
				return;
			}
			$scope.acknowledgeStartDate.value = $scope.acknowledgeEndDate.value = "";
			$scope.data.offset = $scope.data.totalRecord = 1;
			$scope.data.ackSearch = true;
			cancelAcknowledgementService.getAcknowledgementDetails($scope.acknowledgementNo).then(function(data) {
				$scope.receiptInfo = [];
				if (data && data[0]) {
					$scope.receiptInfo = data;
					$scope.receiptInfo[0].imageRef = setImageForAck($scope.receiptInfo[0]);
					$scope.receiptInfo[0].pddAcknowledgementType = $scope.receiptInfo[0].pddAcknowledgementType.toUpperCase();
				}
				$scope.data.totalRecord = $scope.receiptInfo.length;
			});
		};
		$scope.cancelHandler = function(type, item) {
			cancelAcknowledgementService.setAckDetails({
				searchVal : $scope.acknowledgementNo,
				fromDate : $scope.acknowledgeStartDate.dateValue,
				toDate : $scope.acknowledgeEndDate.dateValue,
				data : $scope.receiptInfo,
				pagination : $scope.data
			});
			$globalScope.isClickedViaMenu = false;
			lazyModuleLoader.loadState('collections.cancelAck', {
				ackNo : item.pddAcknowledgementNo,
				type : type
			});
		};
		/* Method for Date Search */
		$scope.getReceiptDetails = function(thisOffset) {
			$scope.data.ackSearch = false;
			if (!thisOffset) {
				thisOffset = 1;
			}
			$scope.data.offset = (((thisOffset-1)*$scope.data.maxSize)+1);
			$scope.acknowledgementNo = "";
			cancelAcknowledgementService.getAcknowledgementSearch(utility.formDateString(new Date($scope.acknowledgeStartDate.dateValue), true), utility.formDateString(new Date($scope.acknowledgeEndDate.dateValue), true), thisOffset).then(function(data) {
				if (data && data.data) {
					_.each(data.data, function(item, i) {
						data.data[i].imageRef = setImageForAck(item);
					});
					$scope.receiptInfo = data.data;
					$scope.data.totalRecord = (data.meta && data.meta.totalCount) ? parseInt(data.meta.totalCount) : 0;
					$scope.data.offsetlast = (($scope.data.offset+$scope.data.maxSize)>$scope.data.totalRecord) ? $scope.data.totalRecord : $scope.data.offset+($scope.data.maxSize-1);
				}
			});
		};
		/* Method for Pagination */
		$scope.paginationHandler = function(pageNum) {
			$scope.data.currentPage = pageNum;
			$scope.getReceiptDetails(pageNum);
		};
		$scope.goToDashboard = function() {
			lazyModuleLoader.loadState('dashboard');
		};
	};
	cancelAcknowledgement.controller('cancelAcknowledgementController', [ '$scope', '$stateParams', '$modal', 'cancelAcknowledgementService', 'lazyModuleLoader', '$globalScope', cancelAcknowledgementController ]);
	return cancelAcknowledgementController;
});