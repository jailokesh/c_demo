/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','cancelAcknowledgement','constants','collectionConstants'], function(require,cancelAcknowledgement,constants,collectionConstants) {
	'use strict';
	
	/**
	 * Pop up controller function for Dashboard .
	 * Dependency injection $scope,$modalInstance,data as parameters.
	*/
     var acknowledgementPopUpController = function($scope,$modalInstance,data,dialogService,$globalScope,$timeout) {
    	 
    	 var init = function(){
	    	 $scope.data = data.popUpData;
	    	 $scope.data.printCount = 0;
	    	 $scope.data.receiptNo = $scope.data.pddAcknowledgementNo;
	    	 $scope.isAcknowledgement = true;
	  	 };
	  	 
	  	 var closeAndRedirect = function(){
        	 $modalInstance.dismiss();
        	 $globalScope.deletedACKNo = $scope.data.pddAcknowledgementNo;
        	 $globalScope.gotoPreviousPage();
         };
         
    	 init();
    	 /**
          * Method to close the modal pop up
          */
    	 $scope.close = function() {
    		 closeAndRedirect();
    		 $globalScope.isClickedViaMenu = false;
    		 /*if($scope.data.printCount  > 0){
    			 closeAndRedirect();
    		 }else{
    			 dialogService.confirm(constants.ERROR_HEADER.confirm, constants.ERROR_HEADER.confirm,collectionConstants.ERROR_MSG.PRINT_CONFIRMATION).result.then(function(){
    				 closeAndRedirect();
				 },function(){});
    		 }*/
         };
         
    	 /**
          * Method to close the modal pop up
          */
    	 $scope.printHandler = function() {
    		$timeout(function(){
    			 $scope.data.printCount++;
			},300);
         };
         
     };
     cancelAcknowledgement.controller('acknowledgementPopUpController',['$scope','$modalInstance',
                                                                        'data','dialogService','$globalScope','$timeout',acknowledgementPopUpController]);
	return acknowledgementPopUpController;
	});