define(['require','cancelAcknowledgement','receiptCancelModifyModel','collectionServiceURLs','constants'],function(require,cancelAcknowledgement,receiptCancelModifyModel,collectionServiceURLs,constants){

	var cancelAcknowledgementService=function($q,$rootScope,restProxy)
	{	
		/**
		 * Method to fetch the acknowledgement details for the given acknowledgement number
		 * @param {string} ackno - Acknowledgement Number
		 */
		this.getAcknowledgementDetails = function(acknowledgementNo){
			collectionServiceURLs.receiptingServices.SEARCH_ACKNOWLEDGEMENT.urlParams = {
					pddAcknowledgementNo : 	acknowledgementNo
			};
			return restProxy.get(collectionServiceURLs.receiptingServices.SEARCH_ACKNOWLEDGEMENT).then(function(data){
				return data.data;
			});
		};
		
		this.cancelAcknowledgement = function(ackObj){
			collectionServiceURLs.receiptingServices.CANCEL_ACKNOWLEDGEMENT.queryParams = {
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			};
			collectionServiceURLs.receiptingServices.CANCEL_ACKNOWLEDGEMENT.urlParams = {
					pddAcknowledgementNo : ackObj.ackNo
			};
			return restProxy.save('DELETE',collectionServiceURLs.receiptingServices.CANCEL_ACKNOWLEDGEMENT,{remarks:ackObj.remarks}).then(function(response){
				if(response.status === 'success'){
					return response.data[0];
				}
				else{
					return utility.getFailureResult();
				}
			});			
		};
		
		this.getAcknowledgementSearch = function(startDate,endDate,thisOffset){
			collectionServiceURLs.batchingServices.GET_PENDINGACKNOWLEDGEMENTS.queryParams = {
					stDate : startDate,
					endDate : endDate,
					limit : constants.PAGINATION_CONFIG.MAX_SIZE_FIVE,
					offset : thisOffset,
					view : "summary",
					userrole : $rootScope.identity.hierarchyName,
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			};
			return restProxy.get(collectionServiceURLs.batchingServices.GET_PENDINGACKNOWLEDGEMENTS).then(function(data){
				return data;
			});	
		};
		
		var ackDetails;
		this.setAckDetails = function(value){
			ackDetails = value;
		};
		this.getAckDetails = function(){
			return ackDetails;
		};
		
	};

	cancelAcknowledgement.service('cancelAcknowledgementService',['$q','$rootScope','restProxy',cancelAcknowledgementService]);
	return cancelAcknowledgementService;
});