define([ 'require', 'collectionsApp' ], function(r, collectionsApp) {
	'use strict';
	var baseViewUrl = 'app/collections/eReceipt/cancelAcknowledgement/';
	var app = angular.module('cancelAcknowledgement', [ 'ui.router', 'collections', 'angularFileUpload' ]);
	var cancelAcknowledgement = {
		name : 'collections.cancelAcknowledgement',
		url : '/cancelAcknowledgement',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'cancelAcknowledgement.html',
				controller : 'cancelAcknowledgementController'

			}
		},
		data : {
			'headerText' : 'Cancel Acknowledgement',
			'stateActivity' : [ 'COL_RECEIPT_CANCELLATION', 'COL_RECEIPT_CANCELLATION_MODIFICATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ]
		}
	};

	var cancelAcknowledgementConfiguration = function($stateProvider) {
		$stateProvider.state(cancelAcknowledgement);
	};
	app.config([ '$stateProvider', cancelAcknowledgementConfiguration ]);
	return app;
});
