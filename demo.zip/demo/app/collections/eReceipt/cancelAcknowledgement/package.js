define([], function() {
'use strict';
   require.config({
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'cancelAcknowledgement': 'app/collections/eReceipt/cancelAcknowledgement/cancelAcknowledgement',
          'cancelAcknowledgementController':'app/collections/eReceipt/cancelAcknowledgement/controllers/cancelAcknowledgementController',
          'acknowledgementPopUpController':'app/collections/eReceipt/cancelAcknowledgement/controllers/acknowledgementPopUpController',
          'cancelAcknowledgementService':'app/collections/eReceipt/cancelAcknowledgement/services/cancelAcknowledgementService'
          },
      shim: {
    	  'cancelAcknowledgement': ['angular', 'angular-ui-router'],    	   	  
    	  'cancelAcknowledgementController' : ['cancelAcknowledgement','cancelAcknowledgementService'],
    	  'acknowledgementPopUpController' : ['cancelAcknowledgement','cancelAcknowledgementService']
      }
   });
   return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs(['cancelAcknowledgementController','acknowledgementPopUpController' ], callback);
			});
		});
	};
});