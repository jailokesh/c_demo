define([ 'require', 'LmsReceiptCancellation', 'collectionServiceURLs', 'utility' ], function(r, LmsReceiptCancellation, collectionsServiceURL, utility) {
	'use strict';
	var receiptCancellationService = function($q, $rootScope, restProxy) {

		var thisObj = this;

		this.doSearch = function(reqObj) {
			var queryParams = {				
				view : 'lmsReceipt',
				isChallaned : false,
				offset : 1,
				limit : 500
			};
			queryParams[reqObj.typeValue] = reqObj.textValue;
			queryParams.modeOfPayment = reqObj.modeValue.toUpperCase();
			collectionsServiceURL.LmsReceiptServices.GET_RECEIPTDETAILS.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.LmsReceiptServices.GET_RECEIPTDETAILS).then(function(response) {
				return response.data;
			});
		};
		
		this.cancelReceipt = function(receiptDetails){
			collectionsServiceURL.LmsReceiptServices.CANCEL_RECEIPT.queryParams = {"userrole":$rootScope.identity.hierarchyName,"userbranch":JSON.parse(getCookie('selectedBranch')).branchID,view : 'lmsReceipt'};
			collectionsServiceURL.LmsReceiptServices.CANCEL_RECEIPT.urlParams = {"receiptNo":receiptDetails.receiptNo};
			var receiptDetail ={
				cancellationRemarks : receiptDetails.remarks,
				cancelledReceiptImageRef : receiptDetails.cancelledReceiptImageRef,
				productType : receiptDetails.productType,
				branchID : JSON.parse(getCookie('selectedBranch')).branchID
			};
			var deleteHeader = {
				'Content-Type' :'application/json',
				'Authorization': window.sessionStorage.token
			};
			receiptDetail.receiptFor = receiptDetails.receiptFor ? receiptDetails.receiptFor : ''; 
			receiptDetail.agreementNos = receiptDetails.agreementNos;
			return restProxy.save('DELETE',collectionsServiceURL.LmsReceiptServices.CANCEL_RECEIPT,receiptDetail,undefined,deleteHeader).then(function(response){
				return response.data[0];
			});			
		};
	};

	LmsReceiptCancellation.service('receiptCancellationService', [ '$q', '$rootScope', 'restProxy', receiptCancellationService ]);
	return receiptCancellationService;
});