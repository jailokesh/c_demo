define([ 'require', 'collectionsApp'], function(r, collectionsApp) {
	'use strict';
	var baseViewUrl = 'app/collections/eReceipt/LmsReceiptCancellation/';
	var app = angular.module('LmsReceiptCancellation', [ 'common', 'ui.router', 'collections' ]);

	var receiptCancellation = function($stateProvider) {
		$stateProvider.state('collections.LmsReceiptCancellation', {
			url : 'LmsReceiptCancellation',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'receiptCancellation.html',
					controller : 'receiptCancellationController'					
				}
			},
			data : {
				'headerText' : 'LMS - Receipt Cancellation',
				'stateActivity' : [ 'COLL_LMS_RECEIPT_CANCELLATION' ]
			}
		}).state('collections.lmsCancellationDetail', {
			url : 'lmsReceiptCancelDetail/:mode/:receiptNo',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'receiptCancellation.html',
					controller : 'receiptCancellationController'					
				}
			},
			data : {
				'headerText' : 'LMS - Receipt Cancellation',
				'stateActivity' : [ 'COLL_LMS_RECEIPT_CANCELLATION' ],
				'backState' : true
			}
		});
	};
	app.config([ '$stateProvider', receiptCancellation ]);
	return app;
});