define([], function() {
	'use strict';
	require.config({// baseUrl:'/sales.chola.com/',
		paths : {
			'collectionsApp' : 'app/collections/collections',
			'LmsReceiptCancellation' : 'app/collections/eReceipt/LmsReceiptCancellation/receiptCancellation',
			'receiptCancellationController' : 'app/collections/eReceipt/LmsReceiptCancellation/controllers/receiptCancellationController',
			'receiptCancellationService' : 'app/collections/eReceipt/LmsReceiptCancellation/services/receiptCancellationService',
			'sharedPackage' : 'app/common/shared/package'
		},
		shim : {
			'LmsReceiptCancellation/' : [ 'angular', 'angular-ui-router' ],
			'receiptCancellationController' : [ 'LmsReceiptCancellation', 'receiptCancellationService' ]
		}
	});
	return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs([ 'receiptCancellationController' ], callback);
			});
		});
	};
});