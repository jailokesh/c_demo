define([ 'require', 'LmsReceiptCancellation', 'constants', 'utility', 'collectionConstants' ], function(r, LmsReceiptCancellation, constants, utility, collectionConstants) {
	'use strict';
	var receiptCancellationController = function($scope, $globalScope, receiptCancellationService, $state, dialogService, environmentConfig, $stateParams) {
		$scope.doSearch = function() {
			if ($scope.currentSearch.textValue) {
				receiptCancellationService.doSearch($scope.currentSearch).then(function(data) {
					$scope.data.isSearchDone = true;
					if (data.length === 1) {
						$scope.data.receiptList = [];
						$scope.data.receiptDetails = data;
						checkApproval(data[0]);
					} else if (data.length > 1) {
						$scope.data.receiptList = data;
					} else {
						$scope.data.receiptDetails = [];
						$scope.data.receiptList = [];
					}
				});
			}
		};
		var init = function(flag) {
			$scope.data = {
				mode : [ 'Select' ].concat(environmentConfig.paymentMode),
				type : [ {
					key : 'Select',
					value : 'Select'
				} ],
				cancelReceipt : _.findWhere($globalScope.imageCategories, {
					subCategory : 'cancelled receipt'
				})
			};
			$scope.currentSearch = {
				modeValue : 'Select',
				typeValue : 'Select',
				textValue : ''
			};
			if(!$globalScope.isClickedViaMenu && flag){
				$scope.currentSearch.modeValue = $stateParams.mode;
				$scope.data.type = collectionConstants.LMS_RECEIPT_MODE_TYPES[$stateParams.mode];
				$scope.currentSearch.typeValue = 'receiptNo';
				$scope.currentSearch.textValue = $stateParams.receiptNo;
				$scope.doSearch();
			}
		};
		$scope.setSearchByType = function(value, form) {
			form.resetSubmited();
			if (value !== 'Select') {
				$scope.data.type = collectionConstants.LMS_RECEIPT_MODE_TYPES[value];
			}
			$scope.currentSearch.typeValue = 'Select';
			$scope.currentSearch.textValue = '';
			$scope.data.inputAttr = '';
			$scope.data.receiptDetails = [];
			$scope.data.isSearchDone = false;
		};
		$scope.setPlaceHolderContent = function(value, form) {
			form.resetSubmited();
			$scope.currentSearch.textValue = '';
			var setInputAttr = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, {
				type : value
			});
			if (setInputAttr) {
				$scope.data.inputAttr = setInputAttr;
			} else {
				$scope.data.inputAttr = '';
			}
			$scope.data.receiptDetails = [];
			$scope.data.isSearchDone = false;
		};
		$scope.setInScope = function(signed_doc) {
			$scope.signed_doc = signed_doc;
		};
		var resetClicked = function(){
			var _clicked = _.findWhere($scope.data.receiptList,{isClicked : true});
			if(_clicked){
				_clicked.isClicked = false;
			}
		};
		var checkApproval = function(obj) {
			var initiatedIndex = _.findLastIndex(obj.workflow, {
				workStatus : 'INITIATED',
				requestType : 'LMSCANCELLATIONRECEIPT'
			});

			var recommendedIndex = _.findLastIndex(obj.workflow, {
				workStatus : 'RECOMMENDED',
				requestType : 'LMSCANCELLATIONRECEIPT'
			});

			if ((initiatedIndex > -1 && initiatedIndex == obj.workflow.length-1) || (recommendedIndex > -1 && recommendedIndex == obj.workflow.length-1)) {
				dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.LMS_RECEIPTCANCELLATION_INITIATED).result.then(function() {
				}, function() {
					$scope.data.receiptDetails = [];
					resetClicked();
				});
				return;
			}
		};
		$scope.setReceiptObj = function(obj, form) {
			resetClicked();
			obj.isClicked = true;
			checkApproval(obj);
			if ($scope.data.receiptDetails[0] && $scope.data.receiptDetails[0].cancelledReceiptImageRef && $scope.data.receiptDetails[0].cancelledReceiptImageRef.imagePathReferences && $scope.data.receiptDetails[0].cancelledReceiptImageRef.imagePathReferences.length > 0) {
				$scope.data.receiptDetails[0].cancelledReceiptImageRef.imagePathReferences = [];
				$scope.data.receiptDetails[0].remarks = '';
				if ($scope.signed_doc && $scope.signed_doc.refreshFiles)
					$scope.signed_doc.refreshFiles();
			}
			$scope.data.receiptDetails = [ obj ];
			form.resetSubmited();
		};
		
		$scope.pasteHandler = function(event) {
			var item = event.clipboardData.items[0];
			item.getAsString(function(data) {
				$scope.currentSearch.textValue = data;
			});
		};
		$scope.submitLmsCancellation = function(list) {
			receiptCancellationService.cancelReceipt($scope.data.receiptDetails[0]).then(function(data) {
				if (data && list.length > 0) {					
					$scope.doSearch();
				}else if(data && list.length === 0){
					init(false);
				}
			});
		};
		$scope.textChangeHandler = function(value){
			if($scope.currentSearch.typeValue === 'receiptNo' || $scope.currentSearch.typeValue === 'agreementNo'){
				$scope.currentSearch.textValue = value.toUpperCase();
			}
		};
		init(true);
	};
	LmsReceiptCancellation.controller('receiptCancellationController', [ '$scope', '$globalScope', 'receiptCancellationService', '$state', 'dialogService', 'environmentConfig', '$stateParams', receiptCancellationController ]);
	return receiptCancellationController;
});