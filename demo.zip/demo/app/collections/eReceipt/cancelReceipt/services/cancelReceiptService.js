define(['require','cancelReceipt','constants','receiptCancelModifyModel','collectionServiceURLs','receiptModel','collectionConstants'],function(r,cancelReceipt,constants,receiptCancelModifyModel,collectionServiceURLs,receiptModel,collectionConstants){

	var cancelReceiptService=function($q,restProxy,$rootScope,$modal,dialogService,$globalScope)
	{	
		/**
		 * Method to fetch the receipt details for the given receipt number
		 * @param {string} receiptno - Receipt Number
		 */
		this.getReceiptDetails = function(receiptObj,keyVal,receiptNo,productType,standByTellerID){
			receiptObj.view = "summary";			
			receiptObj.collectionAgentID = standByTellerID || $rootScope.identity.userID;
			receiptObj.product = (!receiptNo || productType === 'DEALER') ? productType : '';								
			receiptObj.userrole = $rootScope.identity.hierarchyName;
			receiptObj.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			receiptObj[keyVal] = receiptNo;
			if($globalScope.isClickedDashboard){
				receiptObj.source = 'dashboard';
				delete receiptObj.isChallaned;  				
			}
			collectionServiceURLs.batchingServices.GET_RECEIPTDETAILS.queryParams = receiptObj;
			return restProxy.get(collectionServiceURLs.batchingServices.GET_RECEIPTDETAILS).then(function(data){
				if(data.data){
					data.totalCount = data.meta[0].totalCount;
				}
				return data;
			});
		};
		
		this.getManualReceiptBookDetails = function(invoiceNo){
			collectionServiceURLs.receiptingServices.GET_MANUAL_RECEIPT_BOOK_DETAILS.queryParams = {currentManualReceiptNo:invoiceNo,userbranch:JSON.parse(getCookie('selectedBranch')).branchID};
			return restProxy.get(collectionServiceURLs.receiptingServices.GET_MANUAL_RECEIPT_BOOK_DETAILS).then(function(data){
				if(data.data && data.data[0]){
					return data.data[0];
				}
				return data.data;
			});
		};
		
		this.deleteManualReceipt = function(receiptNo,postBody){
			collectionServiceURLs.receiptingServices.DELELTE_MANUAL_RECEIPT.queryParams = {userbranch:JSON.parse(getCookie('selectedBranch')).branchID};
			collectionServiceURLs.receiptingServices.DELELTE_MANUAL_RECEIPT.urlParams = {receiptNo:receiptNo};
			return restProxy.save('DELETE',collectionServiceURLs.receiptingServices.DELELTE_MANUAL_RECEIPT,postBody,undefined,{'Content-Type':'application/json'}).then(function(response){
				if(response.status === 'success'){
					dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message,collectionConstants.SUCCESS_MSG.DELETE_MAN_RECEIPT);
					return response;
				}
			});
		};
		this.getReceiptCancelModel = function(){
			return new receiptCancelModifyModel();
		};
		
		this.getReceiptModel = function(){
			return new receiptModel();
		};
		
		var objDetails;
		this.setReceiptObj = function(value){
			objDetails = value;
		};
		this.getReceiptObj = function(){
			return objDetails;
		};
	};
	cancelReceipt.service('cancelReceiptService',['$q','restProxy','$rootScope','$modal','dialogService','$globalScope',cancelReceiptService]);
	return cancelReceiptService;
});