/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','cancelReceipt','constants','collectionConstants','utility'], function(require,cancelReceipt,constants,collectionConstants,utility) {
	'use strict';
	
	/**
	 * Pop up controller function for Dashboard .
	 * Dependency injection $scope,$modalInstance,data as parameters.
	*/
     var receiptPopUpController = function($scope,$state,$modalInstance,data,dialogService,lazyModuleLoader,$globalScope,$rootScope) {
    	 
    	 var setChargeType = function(){
    		var _chargeType = '';
			if($scope.receiptDetails.receiptType === 'FCPARTPAY'){
				_chargeType = 'FC Partypay';
			}else if($scope.receiptDetails.receiptType === 'ADVANCE EMI'){
				_chargeType = 'Advance EMI';
			}else if($scope.receiptDetails.receiptType === 'PART PAYMENT'){
				_chargeType = 'Part Payment';
			}
			if(_chargeType){
				$scope.receiptDetails.chargeDetails[0].chargeType = _chargeType;
			}
    	 };
    	 var init = function(){
    		 if(data.receiptDetails){
    			 $scope.alphabets = angular.copy(collectionConstants.ALPHABETS);
				$scope.data = data.popUpData;
				$scope.receiptDetails = data.receiptDetails;
				$scope.isCancel = true;
				$scope.receiptDetails.paymentMode = {};
				$scope.receiptDetails.applications = [];
				$scope.receiptDetails.agreements = [];
				$scope.additionString = '';
				$scope.agreementTotal = [];
				$scope.receiptDetails.printCount = $scope.receiptDetails.isCancelled ?  Number($scope.receiptDetails.printCount) : Number($scope.receiptDetails.printCount) - 1;
				$scope.isReprint = (data.receiptDetails.printCount > 0);//data.isDuplicate;
				$scope.receiptDetails.partPayCharges = collectionConstants.OTHERS.PART_PAY_CHARGES;
				$scope.receiptDetails.amountInwords = utility.numberIntoWords($scope.receiptDetails.amountPaid) + " Only";
				if($scope.receiptDetails.receiptType !== 'IMD'){
					$scope.alphabets.splice($scope.receiptDetails.agreementNos.length,$scope.alphabets.length);
					_.each($scope.alphabets,function(item,index){
						$scope.additionString += (index===0) ? item : '+'+item;
						$scope.receiptDetails.agreements.push({agreementNo:data.receiptDetails.agreementNos[index],chargeDetails:[]});
					});
					_.each($scope.receiptDetails.agreementNos,function(item,index){
						$scope.agreementTotal.push(0);
						_.each($scope.receiptDetails.chargeDetails,function(data){
							if(item === data.referenceNo){
								$scope.agreementTotal[index] += parseInt(data.amount);
								$scope.receiptDetails.agreements[index].chargeDetails.push({chargeType:data.chargeType,amount:data.amount});
							}
						});
						if($scope.receiptDetails.receiptType === 'SALE'){
							var saleObj = _.findWhere($scope.receiptDetails.linkedSaleAgreements,{agreementNo : item});
							$scope.receiptDetails.agreements[index].saleAmount = saleObj ? saleObj.saleAmt : '';
							$scope.receiptDetails.agreements[index].emdAmount = saleObj ? saleObj.emdAmt : '';
						}/*else if ($scope.receiptDetails.receiptType === 'FORECLOSURE' && $scope.receiptDetails.productType === 'VF'){
							var _sum = 0;
							_.each($scope.receiptDetails.fcChargeDetails,function(_charge){
								if(_charge.chargeID !== '20002'){
									_sum += Number(_charge.amount);
								}
							});
							// Deducting waiver amount from total charge amount
							if(_sum && $scope.receiptDetails.foreClosureDetail && $scope.receiptDetails.foreClosureDetail.waiveOffAmount){
								_sum -= $scope.receiptDetails.foreClosureDetail.waiveOffAmount;
							}
							// Deducting Refund amount
							var _refund = _.findWhere($scope.receiptDetails.fcChargeDetails,{chargeID : "20002"});
							if(_refund){
								_sum -= _refund.amount;
							}
							var _diff = Number($scope.receiptDetails.amountPaid - _sum);
							if(_diff > 0){
								$scope.receiptDetails.fcChargeDetails.push({chargeType : 'Excess Collected', amount : _diff});
							}
							var afcObj = _.findWhere($scope.receiptDetails.fcChargeDetails,{chargeID : "7"});
							if(afcObj){
								afcObj.chargeType += " (inc. Current AFC)";
							}
						}*/
						$scope.receiptDetails.agreements[index].amountInwords = utility.numberIntoWords($scope.agreementTotal[index])+ " Only";
					});
					setChargeType();
				}
				
				if($scope.receiptDetails.receiptType === 'IMD'){
					$scope.receiptDetails.agreements = [];
					$scope.alphabets.splice($scope.receiptDetails.applicationNos.length,$scope.alphabets.length);
					_.each($scope.alphabets,function(item,index){
						$scope.additionString += (index===0) ? item : '+'+item;
						$scope.receiptDetails.agreements.push({agreementNo:data.receiptDetails.applicationNos[index],chargeDetails:[]});
					});		
					_.each($scope.receiptDetails.applicationNos,function(item,index){
						$scope.agreementTotal.push(0);
						_.each($scope.receiptDetails.chargeDetails,function(data){
							if(item === data.referenceNo){
								$scope.agreementTotal[index] += parseInt(data.amount);
								$scope.receiptDetails.agreements[index].chargeDetails.push({chargeType:data.chargeType,amount:data.amount});
								$scope.receiptDetails.agreements[index].amountInwords = utility.numberIntoWords($scope.agreementTotal[index])+ " Only";
							}
						});
					});
					$scope.receiptDetails.agreements = $scope.receiptDetails.applications;
				}
				var mode = ($scope.receiptDetails.modeOfPayment==='CHEQUE'||$scope.receiptDetails.modeOfPayment==='CHEQUE-NON-MICR')?'cheque':'demandDraft';
				$scope.receiptDetails.paymentMode[mode] = $scope.receiptDetails.instrumentDetail;
				$scope.receiptDetails.paymentMode[mode].type = $scope.receiptDetails.instrumentDetail.instrumentType;
				$scope.receiptDetails.paymentMode[mode].micrNo = $scope.receiptDetails.paymentMode[mode].bankDetails?$scope.receiptDetails.paymentMode[mode].bankDetails.micrCode:'';
				if(!data.isDuplicate){
					$scope.receiptDetails.isModified = true;
				}
    		 }else{
		    	 $scope.data = data.popUpData;
		    	 $scope.isAcknowledgement = false;
    		 }
    	 };
    	 init();
    	 var closeRedirect = function() {
 			$globalScope.isClickedViaMenu = false;
 			$modalInstance.dismiss();
 			$globalScope.gotoPreviousPage();
 		 };
    	 $scope.close = function() {
    		 if($rootScope.enablePrint){
    			 dialogService.confirm('Confirm', "Confirm!",collectionConstants.ERROR_MSG.PRINT_CONFIRMATION).result.then(function(){
    			 closeRedirect();
    			 },function(){});
    		 }else{
    			 closeRedirect();
    		 }
         };
         
    	 /**
          * Method to close the modal pop up
          */
    	 $scope.printHandler = function() {
    		 $modalInstance.dismiss();
         };
         
         
     };
     cancelReceipt.controller('receiptPopUpController',['$scope','$state','$modalInstance','data','dialogService','lazyModuleLoader','$globalScope','$rootScope',receiptPopUpController]);
	return receiptPopUpController;
	});