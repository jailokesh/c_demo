/**
 * Represents a E-Receipt Cancellation / Modification Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'cancelReceipt','utility','collectionConstants','constants','DatePickerConfig' ],function(r, cancelReceipt,utility, collectionConstants, constants,DatePickerConfig) {
	'use strict';		
	/**
	 * E-receipt cancellation/modification Controller function.
	 * Dependency injection $scope,eReceiptService as parameters. 
	 */		
	 var cancelReceiptController = function($scope,cancelReceiptService,lazyModuleLoader,$rootScope,dialogService,appFactory,$globalScope) {
	 	$scope.productTypes = angular.copy($rootScope.identity.productDetails);
    	$scope.data = {};
    	$scope.manualReceiptPost = {};
    	var init = function(){
    		$scope.data.modifyCancelReceipt = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.CANCEL);
    		$scope.data.rePrintReceipt = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.REPRINT);
    		$scope.data.isDealerAgrCheck = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.TA_RECEIPT);
    		if($scope.data.isDealerAgrCheck){
    		 	$scope.productTypes.push({value:'DEALER'});
    		}
    		$scope.productType = $rootScope.productType;
		 	$scope.receiptObj = {};
		 	$scope.totalRecord = 0;
		 	$scope.receiptNo = '';
			if($rootScope.identity.standByTeller){
				$scope.receiptObj.standByTellerID = "";
				$scope.receiptObj.userTypes = [{ text: $rootScope.identity.standByTeller.userID + "-TELLER", value: $rootScope.identity.standByTeller.userID }];
				$scope.receiptObj.standByTeller = $rootScope.identity.standByTeller.status;
			}						 
		 	$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			$scope.maxSize = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			$scope.paymentModeShort = constants.PAYMENTMODE_SHORT;
			$scope.offset = 1;
			$scope.offsetlast = 5;
			$scope.searchType = collectionConstants.CENCEL_RECEIPT_SEARCH_OPTIONS;
			$scope.currentSearch = {value:""};
			$scope.data.hideFilters = $globalScope.isClickedDashboard;
			if(!$rootScope.isClickedViaMenu){
	    		var cancelObj = cancelReceiptService.getReceiptObj();
	    		if(cancelObj && !$globalScope.isClickedDashboard){
		    		$scope.fromDateConfig.value = cancelObj.start;
		    		$scope.toDateConfig.value = cancelObj.end;
		    		var strArr = [],endArr=[];
		    		strArr = cancelObj.start.split('/');
		    		endArr = cancelObj.end.split('/');
		    		$scope.fromDate = new Date(strArr[1]+'-'+strArr[0]+'-'+strArr[2]);		    		
					$scope.toDate =  new Date(endArr[1]+'-'+endArr[0]+'-'+endArr[2]);					
					$scope.data.currentPage = $scope.offset =  cancelObj.offset;
					$scope.receiptNo = cancelObj.receipt;		
					if(!cancelObj.datebollen){
						$scope.currentSearch = angular.copy( _.findWhere($scope.searchType,{value:cancelObj.searchBy}));
					}
					$scope.data.hideFilters = cancelObj.disabled;
					$scope.receiptInfo = cancelObj.data;
					$scope.totalRecord = cancelObj.totalCount;
					$scope.offsetlast = cancelObj.offSetLast;
					$scope.data.selectedValue = cancelObj.selectedVal;
					$scope.data.isDealerReceipt = cancelObj.isDealerReceipt; 
					$scope.productType = cancelObj.productType;
					$scope.data.searchPattern = _.findWhere(collectionConstants.PLACEHOLDER_TEXT,{type:$scope.currentSearch.value});
					cancelReceiptService.setReceiptObj(null);

					$scope.getReceiptDetails(cancelObj.datebollen);
					 // else condition is from dashboard
	    		}else{
	    			$scope.data.selectedValue = 'cancel';
	    			$scope.fromDate = $scope.toDate = new Date();
	    			$scope.fromDateConfig.setDateVal($scope.fromDate);
		    		$scope.toDateConfig.setDateVal($scope.toDate);
		    		$scope.getReceiptDetails(true);
	    		}
				$rootScope.isClickedViaMenu = true;
	    	}else{
	    		//$scope.data.selectedValue = $scope.data.modifyCancelReceipt ? 'cancel' : 'reprint';
	    	}
	 	};			
		/**
		 * Method to validate the receipt no
		 */
	 	$scope.receiptNoValidator = function(val){
			if(collectionConstants.REGULAR_EXPRESSION.RECEIPT_OR_CHEQUE.test(val)){
				return utility.getSuccessResult();
			}else{
		    	 return utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_RECEIPT_NO);
			}
		};
		$scope.paginationHandler = function(pageNum) {
			$scope.offset = pageNum;
			var flag = ($scope.receiptNo) ? false : true;
			$scope.getReceiptDetails(flag);
		};
		/**
		 * Method to get Receipt details
		 */
		$scope.fromDateConfig = new DatePickerConfig({					
			value:'',
			maxDate:new Date(),
			onchange:function(val){
				$scope.fromDate = val;
				$scope.toDateConfig.minDate = $scope.fromDate;
			},
			readonly: true
		});
		$scope.toDateConfig = new DatePickerConfig({					
			value:'',
			minDate:$scope.fromDate,
			maxDate:new Date(),
			readonly: true,
			onchange:function(val){
				$scope.toDate = val;
				$scope.fromDateConfig.maxDate = val;
			}
		});
		$scope.getReceiptDetails = function(isDateWise){
			if(!$scope.data.selectedValue && $scope.currentSearch.value !== 'manual'){
				dialogService.showAlert('Alert', "Alert!",collectionConstants.ERROR_MSG.CHOOSE_CANCEL_REPRINT);
				return;
			}
			var reqObj = {};
			reqObj.isChallaned = ($scope.data.selectedValue === 'cancel') ? 'false' : '';
			reqObj.isCancelled = ($scope.data.selectedValue === 'reprint') ? true : '';
			reqObj.source = ($scope.data.selectedValue === 'reprint') ? 'reprint' : '';
			if(isDateWise){
				$scope.receiptNo='';
				reqObj.stDate = utility.formDateString($scope.fromDate,true);
				reqObj.endDate = utility.formDateString($scope.toDate,true);
				$scope.data.placeHolder = $scope.currentSearch.value = '';
				reqObj.limit = $scope.maxRecordPerPage;
				reqObj.offset = $scope.offset;
				if(!reqObj.stDate || !reqObj.endDate){
					return;
				}
			}else{
				if(!$scope.receiptNo){
					return;
				}
				if($scope.currentSearch.value === 'manual'){
					cancelReceiptService.getManualReceiptBookDetails($scope.receiptNo).then(function(data){
						if(!data || !data.receiptBookNo || !data.allocatedUserID){
							$scope.receiptInfo=[];
							$scope.data.isValidManualReceipt = false;
							var messageStr = (!data || !data.receiptBookNo) ? collectionConstants.ERROR_MSG.MANUAL_RECEIPT_VALIDATION : collectionConstants.ERROR_MSG.RECEIPT_BOOK_NOT_ASSIGNED; 
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error,messageStr);
						}else{
							$scope.manualReceiptPost.reason = $scope.manualReceiptPost.remarks = '';
							$scope.data.enteredManualNo = $scope.receiptNo;
							$scope.data.isValidManualReceipt = true;
							$scope.manualReceiptPost.collectionAgentID = data.allocatedUserID;
						}
					});
					return;
				}
				$scope.fromDateConfig.value = $scope.toDateConfig.value = '';
			}
			if($scope.currentSearch.value === 'ta' && $scope.receiptNo.indexOf(collectionConstants.OTHERS.TA_AGR_PREFIX) !== 0){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.TA_AGR_CHECK);
				return;
			}
			var keyVal = $scope.currentSearch.value === 'ta' ? 'agreementNo' : $scope.currentSearch.value; 
			if(keyVal === "agreementNo"){
				reqObj.limit=$scope.maxRecordPerPage;
				reqObj.offset=$scope.offset;
			}			
			cancelReceiptService.getReceiptDetails(reqObj,keyVal,$scope.receiptNo,$scope.productType,$scope.receiptObj.standByTellerID).then(function(data){						
				if(!data.data||!data.data.length){
					$scope.noRecordFound = true;
					$scope.receiptInfo=[];
				}else{
					$scope.data.isDealerReceipt = !isDateWise ? data.data[0].receiptType === 'TA' : $scope.productType === 'DEALER';
					$scope.noRecordFound = false;
					$scope.receiptInfo = data.data;
					$scope.data.currentPage = $scope.offset;
				}
				$scope.totalRecord = data.totalCount?data.totalCount:0;
				$scope.offsetlast = (($scope.offset*$scope.maxRecordPerPage)>$scope.totalRecord) ? $scope.totalRecord : ((($scope.data.currentPage-1)*$scope.maxRecordPerPage)+$scope.maxRecordPerPage);
			 });
		};
	 	init();								
		$scope.goToDashboard = function(){
			lazyModuleLoader.loadState('collections.dashboard');
		};
		$scope.resetAll = function(mode){
			if(mode === 'cancel' && !$scope.data.modifyCancelReceipt){
				dialogService.showAlert('Alert', "Alert!",collectionConstants.ERROR_MSG.CANCEL_RECEIPT_ACCESS).result.then(function(){},function(){
					$scope.data.selectedValue = 'reprint';
				});
				return;
			}else if(mode === 'reprint' && !$scope.data.rePrintReceipt){
				dialogService.showAlert('Alert', "Alert!",collectionConstants.ERROR_MSG.REPRINT_RECEIPT_ACCESS).result.then(function(){},function(){
					$scope.data.selectedValue = 'cancel';
				});
				return;
			}
			$scope.data.currentPage = $scope.offset =  1;
			if(mode){
				$scope.data.selectedValue = mode;
			}
			if($scope.productType !== 'DEALER'){
				$rootScope.productType = $scope.productType;
			}
			if(($scope.fromDateConfig.value && $scope.toDateConfig.value) || $scope.receiptNo){
				$scope.getReceiptDetails(($scope.receiptNo) ? false : true);
			}
		};
		$scope.searchChangeHandler = function(value){
			$scope.data.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
			$scope.data.searchPattern = _.findWhere(collectionConstants.PLACEHOLDER_TEXT,{type:value});
			$scope.receiptNo = '';
			if(value === 'manual'){
				dialogService.showAlert('Alert', "Alert!",collectionConstants.ERROR_MSG.ALERT_MANUAL_RECEIPT);
			}
		};
		$scope.cancelReceipts = function(item){
			var cancelObj = {
					start:$scope.fromDateConfig.value,
					end:$scope.toDateConfig.value,
					offset:$scope.offset,
					receipt:$scope.receiptNo,
					datebollen:$scope.receiptNo ? false :true,
					searchBy : $scope.currentSearch.value,
					data : $scope.receiptInfo,
					totalCount : $scope.totalRecord,
					offSetLast : $scope.offsetlast,
					selectedVal : $scope.data.selectedValue,
					productType : $scope.productType,
					isDealerReceipt : $scope.data.isDealerReceipt,
					disabled : $scope.data.hideFilters
			};
			$rootScope.isClickedViaMenu = false;
			cancelReceiptService.setReceiptObj(cancelObj);
			lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:item,type:$scope.data.selectedValue});
		};
		$scope.cancelManualReceipt = function(postBody,formObj){
			if($scope.receiptNo !== $scope.data.enteredManualNo){
				dialogService.showAlert('Alert', "Alert!","Please enter valid Manual Receipt No");
				return;
			}
			dialogService.confirm('Alert', "Alert!",collectionConstants.ERROR_MSG.CANCEL_RECEIPT).result.then(function(){
				cancelReceiptService.deleteManualReceipt($scope.receiptNo,postBody).then(function(data){
					if(data){
						formObj.resetSubmited(true);
						delete $scope.receiptInfo;
						$scope.manualReceiptPost = {};
						$scope.data.isValidManualReceipt = false;
					}
				});
			},function(){});
		};
		$scope.capitalizeHandler = function(val){
			$scope.receiptNo = (val && val.length) ? val.toUpperCase() : '';
		};
	 };
	cancelReceipt.controller('cancelReceiptController', [ '$scope','cancelReceiptService','lazyModuleLoader','$rootScope','dialogService','appFactory','$globalScope', cancelReceiptController ]);
	return cancelReceiptController;
});