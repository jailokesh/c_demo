define([ 'collectionsApp' ], function(collectionsApp) {
	'use strict';
	var baseViewUrl = 'app/collections/eReceipt/cancelReceipt/';
	var app = angular.module('cancelReceipt', [ 'ui.router', 'collections', 'angularFileUpload' ]);

	var cancelReceipt = {
		name : 'collections.cancelReceipt',
		url : '/cancelReceipt',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'cancelReceipt.html',
				controller : 'cancelReceiptController'
			}
		},
		data : {
			'headerText' : 'Receipt Cancel/Modify/Re-Print',
			'stateActivity' : [ 'COL_RECEIPT_CANCELLATION', 'COL_RECEIPT_CANCELLATION_MODIFICATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ]
		}

	};

	var cancelReceiptConfiguration = function($stateProvider) {
		$stateProvider.state(cancelReceipt);
	};
	app.config([ '$stateProvider', cancelReceiptConfiguration ]);
	return app;
});
