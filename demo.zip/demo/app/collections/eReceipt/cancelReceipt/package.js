define([], function() {
'use strict';
   require.config({
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'cancelReceipt': 'app/collections/eReceipt/cancelReceipt/cancelReceipt',
          'cancelReceiptController':'app/collections/eReceipt/cancelReceipt/controllers/cancelReceiptController',
          'receiptPopUpController':'app/collections/eReceipt/cancelReceipt/controllers/receiptPopUpController',
          'cancelReceiptService':'app/collections/eReceipt/cancelReceipt/services/cancelReceiptService'
          },
      shim: {
    	  'cancelReceipt': ['angular', 'angular-ui-router'],    	   	  
    	  'cancelReceiptController' : ['cancelReceipt','cancelReceiptService'],
    	  'receiptPopUpController' : ['cancelReceipt','cancelReceiptService']
      }
   });
   return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs(['cancelReceiptController','receiptPopUpController' ], callback);
			});
		});
	};
});