define([ 'require', 'emdRefund', 'collectionServiceURLs', 'constants', 'collectionConstants', 'emdRefundModel' ], function(r, emdRefund, collectionServiceURL, constants, collectionConstants, EMDRefundModel) {

	var emdRefundService = function($q, restProxy, $rootScope, dialogService) {

		var buyerDetails = {};
		/*
		 * this method is to get the buyer related data
		 */
		this.getBuyerName = function(buyerId) {
			collectionServiceURL.receiptingServices.BUYERNAME.urlParams = {
				vendorid : buyerId
			};
			return restProxy.get(collectionServiceURL.receiptingServices.BUYERNAME).then(function(data) {
				if (data.data && data.data[0]) {
					buyerDetails = {
						address : data.data[0].addressDetail,
						phoneNo : data.data[0].phoneNo,
						buyerID : buyerId,
						name : data.data[0].vendorName
					};
					return data.data[0];
				} else {
					$q.reject(data);
				}
			});
		};

		this.getEMDModel = function() {
			return new EMDRefundModel();
		};
		this.getBuyerDetails = function() {
			return buyerDetails;
		};
		/*
		 * this method is called to do the search based on input
		 */
		this.getCustomerData = function(searchQuery, buyerID) {
			buyerDetails.receiptNo = searchQuery;
			collectionServiceURL.receiptingServices.CREATE_RECEIPTS.urlParams = {
				receiptNo : searchQuery
			};
			url = collectionServiceURL.receiptingServices.CREATE_RECEIPTS;
			return restProxy.get(url).then(function(data) {
				var response;
				if (data.data && data.data[0]) {
					response = data.data[0];
				} else {
					return $q.reject();
				}
				if (buyerID !== response.payerID) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.BUYER_NOT_MATCH);
					return $q.reject();
				} else if (response.receiptType !== 'EMD') {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_RECEIPT_EMD);
					return $q.reject();
				}
				return response;
			});
		};

		/*
		 * this method is to post emd refund
		 */
		this.postEmdRefund = function(reqObj) {
			reqObj.receiptNo = buyerDetails.receiptNo;
			collectionServiceURL.EMDRefundServices.POST.urlParams = {
				receiptNo : buyerDetails.receiptNo
			};
			collectionServiceURL.EMDRefundServices.POST.queryParams = {
				userrole : $rootScope.identity.hierarchyName,
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			};
			return restProxy.save('POST', collectionServiceURL.EMDRefundServices.POST, reqObj).then(function(response) {
				if (response.data && response.data[0]) {
					return response.data;
				}
			});
		};
	};
	emdRefund.service('emdRefundService', [ '$q', 'restProxy', '$rootScope', 'dialogService', emdRefundService ]);
	return emdRefundService;
});