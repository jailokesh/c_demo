define([ 'require', 'emdRefund', 'collectionConstants', 'constants' ], function(r, emdRefund, collectionConstants, constants) {

	var emdRefundController = function($scope, $state, emdRefundService, dialogService,$globalScope) {
		$scope.emdRefundModel = {};
		$scope.getName = function(id) {
			if (id) {
				emdRefundService.getBuyerName(id).then(function(data) {
					$scope.emdRefundModel.buyerName = data ? data.vendorName : '';
				});
			}
		};

		$scope.doSearch = function(searchQuery, buyerID) {
			if (!$scope.emdRefundModel.buyerName || !searchQuery) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.notFound, collectionConstants.ERROR_MSG.INVALID_BUYER);
				return;
			}

			$state.go('collections.emdRefund.emdRefundDetails', {
				'receiptNo' : searchQuery,
				'buyerID' : buyerID
			});
		};
	};

	emdRefund.controller('emdRefundController', [ '$scope', '$state', 'emdRefundService', 'dialogService','$globalScope', emdRefundController ]);
	return emdRefundController;
});