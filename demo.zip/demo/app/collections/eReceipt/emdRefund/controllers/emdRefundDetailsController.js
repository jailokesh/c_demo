define([ 'require', 'emdRefund', 'collectionConstants', 'utility', 'constants' ], function(r, emdRefund, collectionConstants, utility, constants) {

	var emdRefundDetailsController = function($scope, $state, emdRefundService, dialogService, getRefundDeatils,masterService) {
		var vendorDetails = emdRefundService.getBuyerDetails();
		$scope.emdRefundModel =  emdRefundService.getEMDModel();
		$scope.buyerObj = {
			buyerDetails : getRefundDeatils,
			amount : getRefundDeatils.amountPaid
		};
		masterService.getStateAndCity(vendorDetails.address.pincode).then(function(data){
			var adddresDetails = data.data;
			if(adddresDetails){
				vendorDetails.address.city = adddresDetails.City[0].cityName;
				vendorDetails.address.state = adddresDetails.State[0].stateDesc;
			}	
			$scope.buyerObj.fullAddress = utility.setAddress(vendorDetails.address);			
		});
		$scope.emdRefundModel.phoneNo = vendorDetails.phoneNo;
		$scope.emdRefundModel.amountPaid = getRefundDeatils.amountPaid;
		$scope.emdRefundModel.vendorID = vendorDetails.buyerID;
		$scope.emdRefundModel.agreementNos = getRefundDeatils.agreementNos;
		$scope.goBack = function() {
			$state.go('collections.emdRefund');
		};
		$scope.refund = function() {
			emdRefundService.postEmdRefund($scope.emdRefundModel).then(function(data) {
				if (data) {
					dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.ERROR_MSG.EMD_REFUND_INITIATED).result.then(function() {
					}, function() {
						$scope.goBack();
					});
				}
			});
		};
	};

	emdRefund.controller('emdRefundDetailsController', [ '$scope', '$state', 'emdRefundService', 'dialogService', 'getRefundDeatils','masterService', emdRefundDetailsController ]);
	return emdRefundDetailsController;
});