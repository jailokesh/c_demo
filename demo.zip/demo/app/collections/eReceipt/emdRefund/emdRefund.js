define([ 'require', 'collectionsApp', 'emdRefundResolver' ], function(r, collectionsApp, emdRefundResolver) {
	'use strict';
	var baseViewUrl = 'app/collections/eReceipt/emdRefund/';
	var app = angular.module('emdRefund', [ 'ui.router', 'collections' ]);

	var emdRefund = {
		name : 'collections.emdRefund',
		url : '/emdRefund',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'emdRefund.html',
				controller : 'emdRefundController'
			}
		},
		data : {
			'headerText' : 'EMD Refund',
			'stateActivity' : [ 'COL_EMD_REFUND' ]
		}
	};

	var emdRefundDetails = {
		name : 'collections.emdRefund.emdRefundDetails',
		url : '/emdRefund/:receiptNo/:buyerID',
		views : {
			'mainContent' : {
				templateUrl : 'app/collections/eReceipt/emdRefund/partials/emdRefundDetails.html',
				controller : 'emdRefundDetailsController',
				resolve : emdRefundResolver
			}
		},
		data : {
			'headerText' : 'EMD Refund',
			'backState' : 'collections.emdRefund',
			'stateActivity' : [ 'COL_EMD_REFUND' ]
		}
	};

	var emdRefundConfiguration = function($stateProvider) {
		$stateProvider.state(emdRefund).state(emdRefundDetails);
	};
	app.config([ '$stateProvider', emdRefundConfiguration ]);
	return app;
});
