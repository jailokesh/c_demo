/**
 * Represents emdRefund Resolver.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 * 
 */
define([], function() {
	'use strict';
    return {
    	getRefundDeatils:['emdRefundService','$stateParams', function(emdRefundService,$stateParams) {
			return emdRefundService.getCustomerData($stateParams.receiptNo,$stateParams.buyerID).then(function(data){
				return data;
			});	
    	}]
    };

});