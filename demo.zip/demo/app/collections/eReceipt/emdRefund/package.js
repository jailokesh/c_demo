define([], function() {
'use strict';
   require.config({
      paths: {
    	  'collectionsApp':'app/collections/collections',
          'emdRefund': 'app/collections/eReceipt/emdRefund/emdRefund',
          'emdRefundController':'app/collections/eReceipt/emdRefund/controllers/emdRefundController',
          'emdRefundDetailsController':'app/collections/eReceipt/emdRefund/controllers/emdRefundDetailsController',
          'emdRefundService':'app/collections/eReceipt/emdRefund/services/emdRefundService',
          'emdRefundResolver':'app/collections/eReceipt/emdRefund/resolvers/emdRefundResolver'
          },
      shim: {
    	  'emdRefund': ['angular', 'angular-ui-router'],    	   	  
    	  'emdRefundController' : ['emdRefund','emdRefundService'],
    	  'emdRefundDetailsController' : ['emdRefund','emdRefundResolver','emdRefundService']     
      }
   });
   return function(callback) {
		requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				requirejs(['emdRefundController','emdRefundDetailsController'], callback);
			});
		});
	};
});