/**
* Represents Image Upload Service.
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','onlinePaymentSearch','collectionServiceURLs'],function(require,onlinePaymentSearch,collectionServiceURLs){
	'use strict';
	/**
	* Represents a image Upload Service.
	* Image Upload Service function
	* Dependency injection $q,restProxy,authService as parameters.
	*/
	var paymentService = function($q,restProxy,$rootScope,$modal){
		
		this.getOnlinePaymentReceipt = function(receiptObj,searchKey,searchValue){
			receiptObj.userrole = $rootScope.identity.hierarchyName;
			receiptObj.userbranch = JSON.parse(getCookie('selectedBranch')).branchID;
			receiptObj.view = "BROWSER";			
			collectionServiceURLs.receiptingServices.SEARCH_ONLINE_RECEIPTS.queryParams = receiptObj;
			return restProxy.get(collectionServiceURLs.receiptingServices.SEARCH_ONLINE_RECEIPTS).then(function(data){
				if(data){
					data.totalCount = (data.meta && data.meta.totalCount) ? data.meta.totalCount : 0;
				}
				return data;
			});
		};
		
	};
	onlinePaymentSearch.service('paymentService',['$q','restProxy','$rootScope','$modal',paymentService]);
	return paymentService;
});