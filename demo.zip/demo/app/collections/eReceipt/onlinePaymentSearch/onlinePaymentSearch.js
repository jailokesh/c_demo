define(['require','collectionsApp'],function(require,collectionsApp){
	'use strict';
	/**
	* Contains the image upload routing information.
	* Create and return the image upload module.
	*/
	var baseViewUrl = 'app/collections/eReceipt/onlinePaymentSearch/';
	var app = angular.module('onlinePaymentSearch',['ui.router','collections']);

	var onlinePaymentSearch = {
		name : 'collections.onlinePaymentSearch',
		url : '/onlinePaymentSearch',
		views : {
			'mainContent': {
				templateUrl: baseViewUrl + 'onlinePaymentSearch.html',
				controller: 'paymentController'
			}
		},
		data : {'headerText':'Online Payment Search',				
				stateActivity : ['COLL_ONLINE_PAYMENT_RECEIPT_SEARCH']
			}
	};
	/**
	* Contains the challan search configuration details.
	*/
	var onlinePaymentConfiguration = function($stateProvider, $urlRouterProvider){
		$stateProvider.state(onlinePaymentSearch);
	};
	app.config(['$stateProvider','$urlRouterProvider',onlinePaymentConfiguration]);
	return app;
});
