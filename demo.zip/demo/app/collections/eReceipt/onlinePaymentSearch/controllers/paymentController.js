/**
* Represents an Image Upload Controller .
* @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
* @author Chola.
*/
define(['require','onlinePaymentSearch','constants','utility','collectionConstants','DatePickerConfig'],function(r,onlinePaymentSearch,constants,utility,collectionConstants,DatePickerConfig){
	'use strict';
	/**
	* Dependency injection $scope,$modalInstance,challanSearchService,$modal as parameters.
	*/
	var paymentController = function($scope,$globalScope,$stateParams,$modal,authService,paymentService,masterService,messageBus,lazyModuleLoader,dialogService){
		$scope.data = {};
		$scope.data.noRecordFound = false;
		$scope.data.searchDone = false;
		$scope.offset = $scope.data.currentPage = 1;
		$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		$scope.maxSize = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
		$scope.searchType =  [ {
			type : "Agreement Number",
			value : "agreementNo",
			placeHolder : "Enter Agreement No"
		}, {
			type : "Receipt Number",
			value : "receiptNo",
			placeHolder : "Enter Receipt No"
		}, {
			type : "Transaction ID",
			value : "transactionIdentifier",
			placeHolder : "Enter Transaction ID"
		}];
		
		$scope.fromDate = $scope.toDate = new Date();
		$scope.fromDateConfig = new DatePickerConfig({					
			value:'',
			maxDate:new Date(),
			onchange:function(val){
				$scope.fromDate = val;
				$scope.toDateConfig.minDate = $scope.fromDate;
			},
			readonly: true
		});
		$scope.toDateConfig = new DatePickerConfig({					
			value:'',
			minDate:$scope.fromDate,
			maxDate:new Date(),
			readonly: true,
			onchange:function(val){
				$scope.toDate = val;
				$scope.fromDateConfig.maxDate = val;
			}
		});
		$scope.fromDateConfig.setDateVal($scope.fromDate);
		$scope.toDateConfig.setDateVal($scope.toDate);
		$scope.searchChangeHandler = function(value){
			$scope.data.placeHolder = value ? _.findWhere($scope.searchType,{value:value}).placeHolder : '';
			$scope.data.searchPattern = _.findWhere(collectionConstants.PLACEHOLDER_TEXT,{type:value});
			$scope.searchInput = '';
			$scope.data.searchDone = false;
		};
		
		
		$scope.getTransactionDetails = function(){
			var reqObj = {};
			reqObj.searchKey = $scope.currentSearch.value;
			reqObj.searchValue = $scope.searchInput;
			reqObj.limit = $scope.maxRecordPerPage;
			reqObj.offset = $scope.offset;
			paymentService.getOnlinePaymentReceipt(reqObj,$scope.currentSearch.value,$scope.searchInput).then(function(data){
				if(data && data.data && data.data.length){
					$scope.transactionData = data.data;
					$scope.data.currentPage = $scope.offset;
					$scope.data.noRecords = false;
				}else{
					$scope.transactionData = [];
					//$scope.data.currentPage = $scope.offset = '';
					$scope.data.noRecords = true;
				}
				$scope.data.totalCount = data.totalCount;
				$scope.data.searchDone = true;
				$scope.offsetlast = (($scope.offset*$scope.maxRecordPerPage)>$scope.data.totalCount) ? $scope.data.totalCount : ((($scope.data.currentPage-1)*$scope.maxRecordPerPage)+$scope.maxRecordPerPage);
			});
		};
		
		$scope.paginationHandler = function(pageNum) {
			$scope.offset = pageNum;
 			$scope.getTransactionDetails();
		};
		
	};
	onlinePaymentSearch.controller('paymentController',['$scope','$globalScope','$stateParams','$modal','authService','paymentService','masterService','messageBus','lazyModuleLoader','dialogService', paymentController]);
	return paymentController;
});