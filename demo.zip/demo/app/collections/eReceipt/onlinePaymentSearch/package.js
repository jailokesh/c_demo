define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'onlinePaymentSearch': 'app/collections/eReceipt/onlinePaymentSearch/onlinePaymentSearch',
			'paymentService': 'app/collections/eReceipt/onlinePaymentSearch/services/paymentService',
			'paymentController': 'app/collections/eReceipt/onlinePaymentSearch/controllers/paymentController'
		},
		shim: {
			'onlinePaymentSearch': ['angular', 'angular-ui-router'],
			'paymentController': ['paymentService']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['paymentController'],callback);
			});
		});
	};
});