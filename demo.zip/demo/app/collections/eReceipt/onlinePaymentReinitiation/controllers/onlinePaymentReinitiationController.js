/**
 * Represents an Image Upload Controller .
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'onlinePaymentReinitiation', 'collectionConstants', 'constants' ], function(r, onlinePaymentReinitiation, collectionConstants, constants) {
	'use strict';
	/**
	 * Dependency injection $scope,$modalInstance,challanSearchService,$modal as
	 * parameters.
	 */
	var onlinePaymentReinitiationController = function($scope, getReceiptDetails, onlinePaymentReinitiationService, dialogService) {
		$scope.data = {
			searchType : [ {
				type : "Agreement Number",
				value : "agreementNo",
				placeHolder : "Enter Agreement No"
			}, {
				type : "Transaction ID",
				value : "transactionIdentifier",
				placeHolder : "Enter Transaction ID"
			} ],
			maxRecordPerPage : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
			maxSize : constants.PAGINATION_CONFIG.MAX_SIZE_TEN,
			offset : 1,
			currentPage : 1,
			offsetlast : constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
			totalCount : getReceiptDetails.totalCount,
			result : getReceiptDetails.data,
			noRecordFound : false,
			lastOpendItem : {}
		};
		$scope.searchChangeHandler = function(value) {
			if (!$scope.data.searchBy) {
				$scope.getReceiptDetails();
			}
			$scope.data.placeHolder = value ? _.findWhere($scope.data.searchType, {
				value : value
			}).placeHolder : '';
			$scope.data.searchPattern = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, {
				type : value
			});
			$scope.data.searchInput = '';
		};
		$scope.getReceiptDetails = function() {
			var reqObj = {};
			reqObj[$scope.data.searchBy] = $scope.data.searchInput;
			reqObj.offset = $scope.data.offset;
			onlinePaymentReinitiationService.getReceiptData(reqObj).then(function(data) {
				if (data && data.data && data.data.length) {
					$scope.data.result = data.data;
					$scope.data.currentPage = $scope.data.offset;
					$scope.data.noRecords = false;
				} else {
					$scope.data.result = [];
					$scope.data.noRecords = true;
				}
				$scope.data.totalCount = data.totalCount;
				$scope.data.offsetlast = (($scope.data.offset * $scope.data.maxRecordPerPage) > $scope.data.totalCount) ? $scope.data.totalCount : ((($scope.data.currentPage - 1) * $scope.data.maxRecordPerPage) + $scope.data.maxRecordPerPage);
			});
		};
		$scope.UpdateReceiptDetails = function(receipt, status) {
			var msg;
			var reqObj = {
				hoRemarks : receipt.remarks,
				hoAction : status,
				majorVersion : receipt.majorVersion,
				minorVersion : receipt.minorVersion
			};

			if (status === 'HO_APPROVED') {
				msg = collectionConstants.SUCCESS_MSG.SUCCESS_REINIT;
			} else {
				msg = collectionConstants.SUCCESS_MSG.SUCCESS_REJECT;
			}

			onlinePaymentReinitiationService.updateReceiptDetails(reqObj, receipt.transactionIdentifier).then(function(data) {
				if (data.status === "success") {
					dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, msg).result.then(function() {
					}, function() {
						$scope.getReceiptDetails();
					});

				}
			});

		};

		$scope.paginationHandler = function(pageNum) {
			$scope.data.offset = pageNum;
			$scope.getReceiptDetails();
		};
		
		$scope.showAgreements = function(_agreements,_type){
			var obj = {
				agreements : _agreements,
				type : _type
			};
			onlinePaymentReinitiationService.openModal('app/collections/challan/challanSearch/partial/agreementList.html',obj);
		};
	};
	onlinePaymentReinitiation.controller('onlinePaymentReinitiationController', [ '$scope', 'getReceiptDetails', 'onlinePaymentReinitiationService', 'dialogService', onlinePaymentReinitiationController ]);
	return onlinePaymentReinitiationController;
});