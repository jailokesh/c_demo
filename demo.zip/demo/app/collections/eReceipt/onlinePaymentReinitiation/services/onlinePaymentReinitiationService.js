/**
 * Represents Image Upload Service.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'onlinePaymentReinitiation', 'collectionServiceURLs', 'constants' ], function(require, onlinePaymentReinitiation, collectionServiceURLs, constants) {
	'use strict';
	/**
	 * Represents a image Upload Service. Image Upload Service function
	 * Dependency injection $q,restProxy,authService as parameters.
	 */
	var onlinePaymentReinitiationService = function($q, restProxy, $rootScope,$modal) {

		this.getReceiptData = function(obj) {
			var receiptObj = obj ? obj : {};
			receiptObj.limit = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
			receiptObj.offset = receiptObj.offset ? (receiptObj.limit * (receiptObj.offset - 1) + 1) : 1;
			collectionServiceURLs.receiptingServices.GET_HO_NOTIFY_LIST.queryParams = receiptObj;
			return restProxy.get(collectionServiceURLs.receiptingServices.GET_HO_NOTIFY_LIST).then(function(data) {
				if (data.status === 'success') {
					data.totalCount = data.meta.totalCount ? data.meta.totalCount : 0;
				}
				return data;
			});
		};
		this.updateReceiptDetails = function(receiptDetails, txnID) {
			var urlParams = {
				receiptNo : txnID
			};
			var queryParams = {
				userrole : "ho",
				view : "hoAction"
			};
			collectionServiceURLs.receiptingServices.UPDATE_ONLINE_RECEIPTS.queryParams = queryParams;
			collectionServiceURLs.receiptingServices.UPDATE_ONLINE_RECEIPTS.urlParams = urlParams;
			return restProxy.save('PUT', collectionServiceURLs.receiptingServices.UPDATE_ONLINE_RECEIPTS, receiptDetails).then(function(response) {
				return response;
			});
		};
		
		this.openModal = function(_url, _modalData){
			var paramObj = {
				templateUrl: _url,
				controller: ['$scope', '$modalInstance', '$modal', 'data', function($scope, $modalInstance, $modal, data){
					$scope.data = data;
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				}],
				size : 'sm',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return  _modalData;
	                }
				}	
			};
			$modal.open(paramObj);
		};
	};
	onlinePaymentReinitiation.service('onlinePaymentReinitiationService', [ '$q', 'restProxy', '$rootScope','$modal', onlinePaymentReinitiationService ]);
	return onlinePaymentReinitiationService;
});