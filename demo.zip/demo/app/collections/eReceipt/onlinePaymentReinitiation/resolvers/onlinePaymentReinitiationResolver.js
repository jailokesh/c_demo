/**
 * Represents emdRefund Resolver.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 * 
 */
define([], function() {
	'use strict';
	return {
		getReceiptDetails : [ 'onlinePaymentReinitiationService', '$stateParams', function(onlinePaymentReinitiationService, $stateParams) {
			return onlinePaymentReinitiationService.getReceiptData().then(function(data) {
				return data;
			});
		} ]
	};

});