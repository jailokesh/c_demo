define([],function(){
	'use strict';
	require.config({
		paths: {
			'collectionsApp': 'app/collections/collections',
			'onlinePaymentReinitiation': 'app/collections/eReceipt/onlinePaymentReinitiation/onlinePaymentReinitiation',
			'onlinePaymentReinitiationResolver': 'app/collections/eReceipt/onlinePaymentReinitiation/resolvers/onlinePaymentReinitiationResolver',
			'onlinePaymentReinitiationService': 'app/collections/eReceipt/onlinePaymentReinitiation/services/onlinePaymentReinitiationService',
			'onlinePaymentReinitiationController': 'app/collections/eReceipt/onlinePaymentReinitiation/controllers/onlinePaymentReinitiationController'
		},
		shim: {
			'onlinePaymentReinitiation': ['angular', 'angular-ui-router'],
			'onlinePaymentReinitiationController': ['onlinePaymentReinitiationService','onlinePaymentReinitiationResolver']
		}
	});
	return function(callback){
		requirejs(['sharedPackage'],function(commonPackageLoader){
			commonPackageLoader(function(){
				requirejs(['onlinePaymentReinitiationController'],callback);
			});
		});
	};
});