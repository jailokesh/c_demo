define(['require','collectionsApp','onlinePaymentReinitiationResolver'],function(require,collectionsApp,onlinePaymentReinitiationResolver){
	'use strict';
	/**
	* Contains the image upload routing information.
	* Create and return the image upload module.
	*/
	var baseViewUrl = 'app/collections/eReceipt/onlinePaymentReinitiation/';
	var app = angular.module('onlinePaymentReinitiation',['ui.router','collections']);

	var onlinePaymentReinitiation = {
		name : 'collections.onlinePaymentReinitiation',
		url : 'onlinePaymentReinitiation',
		views : {
			'mainContent': {
				templateUrl: baseViewUrl + 'onlinePaymentReinitiation.html',
				controller: 'onlinePaymentReinitiationController',
				resolve : onlinePaymentReinitiationResolver
			}
		},
		data : {'headerText':'Online Payment Re-initiation',
				stateActivity : ['COL_HO_ONLINE_PAYMENT_REINITIATION']
			}
	};
	/**
	* Contains the challan search configuration details.
	*/
	var onlinePaymentReinitiationConfiguration = function($stateProvider, $urlRouterProvider){
		$stateProvider.state(onlinePaymentReinitiation);
	};
	app.config(['$stateProvider','$urlRouterProvider',onlinePaymentReinitiationConfiguration]);
	return app;
});
