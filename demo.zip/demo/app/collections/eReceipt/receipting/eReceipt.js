define([ 'require', 'collectionsApp', 'eReceiptResolver' ], function(r, collectionsApp, eReceiptResolver) {
	'use strict';

	/**
	 * Contains the receipting routing information. Create and return the
	 * receipt module.
	 */
	var baseViewUrl = 'app/collections/eReceipt/receipting/';
	var baseReceipt = {
		name : 'collections.receipt',
		abstract : true,
		views : {
			'mainContent' : {
				template : '<div ui-view="receiptTemplate"></div>',
				controller : 'eReceiptController'
			}
		},
		data : {
			'headerText' : ''
		}
	};

	var eReceipt = {
		name : 'collections.receipt.eReceipt',
		url : '/eReceipt',
		views : {
			'receiptTemplate' : {
				templateUrl : baseViewUrl + 'eReceipt.html',
				controller : 'onlineReceiptController'
			}
		},
		data : {
			'headerText' : 'Online Receipt',
			isManual : false,
			'stateActivity' : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS', 'COL_EMD_RECEIPTING', 'COL_SALE_RECEIPTING', 'COL_IMD_RECEIPTING', 'COL_TA_RECEIPTING', 'COL_FORECLOSURE_RECEIPTING', 'COL_MI_INS_RENEWAL' ]
		}
	};
 
	var manualReceipt = {
		name : 'collections.receipt.manualReceipt',
		url : '/manualReceipt',
		views : {
			'receiptTemplate' : {
				templateUrl : baseViewUrl + 'eReceipt.html',
				controller : 'manualReceiptController'
			}
		},
		data : {
			'headerText' : 'Manual Receipt',
			isManual : true,
			'stateActivity' : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS', 'COL_EMD_RECEIPTING', 'COL_SALE_RECEIPTING', 'COL_IMD_RECEIPTING', 'COL_TA_RECEIPTING', 'COL_FORECLOSURE_RECEIPTING', 'COL_MI_INS_RENEWAL' ]
		}
	};

	var ePaymentCommon = {
		name : 'collections.ePayment',
		url : '/eReceipt/:agreementNo/type/:receiptType',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/eReceiptCommon.html',
				controller : 'ePayController',
				resolve : angular.extend({}, eReceiptResolver.getBalanceDetailsInfo, eReceiptResolver.getChargesList)
			}
		},
		data : {
			'headerText' : 'Online Receipt',
			'backState' : 'collections.receipt.eReceipt',
			'stateActivity' : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS', 'COL_EMD_RECEIPTING', 'COL_SALE_RECEIPTING', 'COL_IMD_RECEIPTING', 'COL_TA_RECEIPTING', 'COL_FORECLOSURE_RECEIPTING', 'COL_MI_INS_RENEWAL' ]
		}
	};

	var receiptCancelModify = {
		name : 'collections.cancelReceipts',
		url : '/cancelReceipt/:receiptNo/type/:type',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/eReceiptCommon.html',
				controller : 'cancelModifyController',
				resolve : angular.extend({}, eReceiptResolver.getReceipts, eReceiptResolver.getBankList,eReceiptResolver.getChargesList)
			}
		},
		data : {
			'headerText' : 'Cancel/Modify Receipt',
			'backState' : 'collections.cancelReceipt',
			'stateActivity' : [ 'COL_RECEIPT_CANCELLATION', 'COL_RECEIPT_CANCELLATION_MODIFICATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ]
		}
	};

	var cancelAck = {
		name : 'collections.cancelAck',
		url : '/acknowledgement/:ackNo/type/:type',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/eReceiptCommon.html',
				controller : 'cancelAckController',
				resolve : angular.extend({}, eReceiptResolver.getCancelAck, eReceiptResolver.getBankList)
			}
		},
		data : {
			'headerText' : 'Cancel Acknowledgement',
			'backState' : 'collections.cancelAcknowledgement',
			'stateActivity' : [ 'COL_RECEIPT_CANCELLATION','COL_RECEIPT_CANCELLATION_MODIFICATION', 'COL_RECEIPT_CANCEL_MODIFY_REPRINT' ]
		}
	};

	var ePaymentCommonManual = {
		name : 'collections.manualPayment',
		url : '/manualReceipt/:agreementNo/type/:receiptType',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/eReceiptCommon.html',
				controller : 'ePayController',
				resolve : angular.extend({}, eReceiptResolver.getBalanceDetailsInfo, eReceiptResolver.getChargesList)
			}
		},
		data : {
			'headerText' : 'Manual Receipt',
			'backState' : 'collections.receipt.manualReceipt',
			'stateActivity' : [ 'COL_OD_RECEIPTING_CASH_CHEQUE_DD_RTGS', 'COL_EMD_RECEIPTING', 'COL_SALE_RECEIPTING', 'COL_IMD_RECEIPTING', 'COL_TA_RECEIPTING', 'COL_FORECLOSURE_RECEIPTING', 'COL_MI_INS_RENEWAL' ]
		}
	};
	
	var nonAgreement = {
		name : 'collections.nonAgreements',
		url : '/nonAgreement/:referenceNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/nonAgreement.html',
				controller : 'nonAgreementController'
			}
		},
		data : {
			'headerText' : 'Online Receipt',
			'backState' : 'collections.receipt.eReceipt',
		}
	};
	
	var onlinePayment = {
		name : 'collections.onlinePayment',
		url : '/eReceipt/onlinePayment',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/onlinePayment.html',
				controller : 'onlinePaymentController'
			}
		},
		data : {
			'headerText' : 'Online Payment'			
		}
	};

	var shortfallUpload = {
		name : 'collections.uploadShortfall',
		url : '/uploadShortfall',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/shortfallUpload.html',
				controller : 'shortfallUploadController'
			}
		},
		data : {
			'headerText' : 'Shortfall Details Upload'			
		}
	};

	var shortfallSOA = {
		name : 'collections.shortfallSOA',
		url : '/shortfallSOA',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl + 'partials/shortfallSOA.html',
				controller : 'shortfallSOAController'
			}
		},
		data : {
			'headerText' : 'Shortfall SOA'
			// 'backState' : 'collections.shortfallSOA'			
		}
	};

	var eReceiptConfiguration = function($stateProvider) {
		$stateProvider.state(baseReceipt).state(manualReceipt).state(eReceipt).state(ePaymentCommon).state(ePaymentCommonManual)
		.state(receiptCancelModify).state(cancelAck).state(nonAgreement).state(onlinePayment).state(shortfallUpload).state(shortfallSOA);
	};

	var app = angular.module('eReceipt', [ 'common', 'ui.router', 'collections', 'angularFileUpload', 'qrCode' ]);
	app.config([ '$stateProvider', '$urlRouterProvider', eReceiptConfiguration ]);
	return app;
});
