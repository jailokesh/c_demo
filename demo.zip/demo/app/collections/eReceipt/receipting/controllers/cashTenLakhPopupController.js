define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var cashTenLakhPopupController = function($scope, $modalInstance, $modal, $state, data, messageBus) {
		$scope.data = data.popUpData;
		$scope.close = function() {
			$modalInstance.dismiss();
		};
		$scope.approvalHandler = function() {
			$modalInstance.dismiss();
			messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.TEN_LAKHS);
		};
	};
	eReceipt.controller('cashTenLakhPopupController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus', cashTenLakhPopupController ]);
	return cashTenLakhPopupController;
});