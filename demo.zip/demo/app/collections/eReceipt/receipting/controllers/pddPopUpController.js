/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'collectionConstants' ], function(require, eReceipt, collectionConstants) {
	'use strict';

	/**
	 * Pop up controller function for Dashboard . Dependency injection
	 * $scope,$modalInstance,data as parameters.
	 */
	var pddPopUpController = function($scope, $modalInstance, data, eReceiptService, dialogService,$globalScope,$timeout,$rootScope) {
		$scope.data = data.popUpData;
		$scope.agreementDetails = $scope.data[$scope.data.pddAcknowledgementType + 'Detail'];
		$scope.searchObj = eReceiptService.getSearchParam();
		$scope.isReprint = false;
		$scope.printCount = 0;
		var isCloseFlag;
		var closeRedirect = function() {
			isCloseFlag = true;
			$modalInstance.dismiss();
			$globalScope.gotoPreviousPage();
		};

		/**
		 * Method to close the modal pop up
		 */
		$scope.close = function() {
			isCloseFlag = true;
			if ($scope.isReprint) { 
				closeRedirect();
			} else if ($rootScope.enablePrint){
				dialogService.confirm('Confirm', "Confirm!", collectionConstants.ERROR_MSG.PRINT_CONFIRMATION).result.then(function() {
					closeRedirect();
				}, function() {
				});
			}else{
				closeRedirect();
			}
		};
		/**
		 * Method to close the modal pop up
		 */
		$scope.printHandler = function() {
			isCloseFlag = true;
			$timeout(function(){
				$scope.isReprint = true;
				$scope.printCount++;
				$scope.data.modifiedDate = new Date();
			},300);
			
		};

		$modalInstance.result.then(function() {
		}, function() {
			if (!isCloseFlag) {
				$scope.close();
			}
		});

	};
	eReceipt.controller('pddPopUpController', [ '$scope', '$modalInstance', 'data', 'eReceiptService', 'dialogService','$globalScope','$timeout','$rootScope', pddPopUpController ]);
	return pddPopUpController;
});