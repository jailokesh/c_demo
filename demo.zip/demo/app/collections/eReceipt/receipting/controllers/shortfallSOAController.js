define(['require', 'eReceipt', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility'], function (r, eReceipt, constants, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var shortfallSOAController = function ($scope, $rootScope, $state, $modal, $upload, $stateParams, eReceiptService, dialogService, lazyModuleLoader, messageBus, environmentConfig, appFactory) {

		var DateTime = new Date();
		var isAgreementOrApp;
		$scope.agreementStatus = false;

		$scope.searchParams = {
			branchName: JSON.parse(getCookie('selectedBranch')).branchID,
			searchBy: '',
			searchKey: '',
			receiptNo: '',
			receiptDate: ''
		};

		var initialize = function () {
			var outPutArr = [];
			_.each(collectionConstants.SEARCH_BY, function (item) {
				if (!item.activityID) {
					outPutArr.push(item);
				} else if (appFactory.getActivityAccess(item.activityID)) {
					outPutArr.push(item);
				}
			});
			$scope.searchByParams = _.sortBy(outPutArr, 'name');
			$scope.searchParams.searchBy = $scope.searchByParams[0];
			$scope.noResult = true;

		};
		initialize();

		$scope.setPlaceHolderContent = function (searchBy, form) {
			form.resetSubmited();
			$scope.searchParams.searchKey = '';
			$scope.placeHolderAndMaxLength = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, {
				type: searchBy.value
			});
			$scope.searchDone = false;
			$scope.patternVal = eReceiptService.getPatternValue(searchBy);
		};

		$scope.capitalizeHandler = function (val) {
			isAgreementOrApp = ($scope.searchParams.searchBy.value === 'agreementNo' || $scope.searchParams.searchBy.value === 'dealerAgreementNo' || $scope.searchParams.searchBy.value === 'ClosedAgreement');
			if (isAgreementOrApp || $scope.searchParams.searchBy.value === 'vehicleNo' || $scope.searchParams.searchBy.value === 'policyNo' || $scope.searchParams.searchBy.value === 'panCardNo' || $scope.searchParams.searchBy.value === 'vishesh' || $scope.searchParams.searchBy.value === 'trip') {
				$scope.searchParams.searchKey = (val && val.length) ? val.toUpperCase() : '';
			}
		};

		var formatDate = function (date) {
			var dateParts = date.split("/");
			return [dateParts[0], dateParts[1], dateParts[2]].join('-');
		}

			/* popupModal for breakupDetails */ 
			$scope.openModal = function (option, otherDetails, actualAmount) {
					$modal.open({
						templateUrl: 'app/collections/approvals/initiateRequest/partials/shortfallWaiverPopup.html',
						controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {

							$scope.data = option;
							$scope.header = 'shortfallSOA';
							$scope.breakupDetails = otherDetails;

							actualAmount = (actualAmount == '' || actualAmount == 'undefined' || actualAmount == undefined) ? 0 : actualAmount;
							if(actualAmount){

							var currentBVLoss = parseInt(otherDetails.currentBVLoss) - parseInt(otherDetails.currentPaidAmount);
							var currentBalance = (parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected);

								$scope.breakupDetails.waiverAmount = actualAmount;
								
								if(parseInt(otherDetails.currentApprovedWaiverAmount) > 0){
									$scope.breakupDetails.agreedAmount = parseInt(currentBalance) - (parseInt(otherDetails.currentApprovedWaiverAmount) + parseInt(actualAmount));
								}else{
									$scope.breakupDetails.agreedAmount = parseInt(otherDetails.currentBVLoss) - (parseInt(otherDetails.currentPaidAmount) + parseInt(actualAmount));
								}
								$scope.breakupDetails.agreedAmount = (parseInt($scope.breakupDetails.agreedAmount) < 0) ? 0 : $scope.breakupDetails.agreedAmount;
							}

							$scope.close = function () {
								$modalInstance.dismiss();
							};
						}],
						size: 'md',
						backdrop: 'static',
						windowClass: 'modal-custom',
						resolve: {

						}
					});
				};

		$scope.showChildAgreements = function(details) {
			$modal.open({
				templateUrl : 'app/collections/eReceipt/receipting/partials/popup/viewChildAgreements.html',
				controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
					$scope.childAgreements = details.childAgreementNos ? details.childAgreementNos : [];
					$scope.close = function() {
						$modalInstance.close();
					};
					$scope.okHandler = function() {
						$scope.close();
					};
				} ],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};

		$scope.searchHandler = function(agreementNo){

			if (agreementNo) {
				
				var queryParams = {
					toDate: formatDate($scope.dateTimeField.value),
					agreementNo: $scope.searchParams.searchKey
				}
				eReceiptService.getShortfallSOA(queryParams).then(function (data) {

					if (data) {
						$scope.noResult = $scope.agreementStatus = false;
						$scope.soaDetails = true;
						$scope.breakupDetails.currentInterestAmount = data.currentInterestAmount;
						$scope.breakupDetails.checkDate = data.checkDate;
						$scope.breakupDetails.childAgreementNos = data.childAgreementNos;
						var percent;
						var waiverAmount = data.currentApprovedWaiverAmount;
						var actuvalBVLoss = parseInt(data.currentBVLoss);
						var netWorking = parseInt(actuvalBVLoss) - parseInt(waiverAmount);
						percent = ((parseInt(waiverAmount) / parseInt(actuvalBVLoss)) * 100);
						percent = percent.toFixed(2);
						var percentage = percent !== '0.00' && !parseInt(percent) ? '< 1%' : percent + '%';


					$scope.shortfallDetails = data;
					data.currentShortfallCollected = data.currentPaidAmount;

					var legalDetails = {};
					var netWorking;
					
					var currentBVLoss = parseInt(data.currentBVLoss) - parseInt(data.currentPaidAmount);
					var currentBalance = parseInt(currentBVLoss) - parseInt(data.currentShortfallCollected);
				
						netWorking = (currentBalance) - parseInt(data.currentApprovedWaiverAmount);
						legalDetails = {
						currentBVLoss : parseInt(data.currentBVLoss) - parseInt(data.currentApprovedWaiverAmount),
						currentAVLoss : parseInt(data.currentAVLoss) - parseInt(data.currentApprovedWaiverAmount),
						currentShortfallDue : (parseInt(data.currentAVLoss) + parseInt(data.currentInterestAmount)) - parseInt(data.currentApprovedWaiverAmount),
						noticeAmount : parseInt(data.shortfallNoticeAmount) - parseInt(data.currentApprovedWaiverAmount)						
						};

					var percent,bvWaiverAmount,avWaiverAmount,noticeWaiverAmt,shotfallDueWaiverAmt,waiverAmt ;
					if(data.currentSettlementAgreed){
                        bvWaiverAmount = parseInt(data.currentBVLoss) - parseInt(data.currentSettlementAgreed);
                        avWaiverAmount = parseInt(data.currentAVLoss) - parseInt(data.currentSettlementAgreed);
                        noticeWaiverAmt = parseInt(data.shortfallNoticeAmount) - parseInt(data.currentSettlementAgreed);
                        shotfallDueWaiverAmt = (parseInt(data.currentAVLoss) + parseInt(data.currentInterestAmount)) - (parseInt(data.currentSettlementAgreed));
						netWorking = parseInt(data.currentSettlementAgreed) - parseInt(data.currentShortfallCollected);
                    }else{
                        data.currentSettlementAgreed = (parseInt(data.currentAVLoss) + parseInt(data.currentInterestAmount));
						netWorking = parseInt(data.currentSettlementAgreed) - parseInt(data.currentShortfallCollected);
                    }

					var actuvalBVLoss = parseInt(data.currentBVLoss);
						percent = ((parseInt(waiverAmount)/parseInt(actuvalBVLoss))*100);
						percent = percent.toFixed(2);

					var interestAmount = 'Interest as on '+ formatDate($scope.dateTimeField.value);
					$scope.shortfallDetails = [{
						chargeType : 'BV Loss',
						actualLoss : parseInt(data.currentBVLoss),
						settlementAgreed : parseInt(data.currentSettlementAgreed),
						shortfallCollected : parseInt(data.currentShortfallCollected),
						balance : parseInt(legalDetails.currentBVLoss) - parseInt(data.currentShortfallCollected),
						breakupDetails: {
							'Installment': data.otherDetails.installment,
							'POS': data.otherDetails.POS,
							'Seizure Charges': data.otherDetails.seizureCharges,
							'Parking Charges': data.otherDetails.parkingCharges,
							'Legal Charges': data.otherDetails.legalCharges,
							'Open Payable Advice (-)': data.otherDetails.openPayAdvise,
							'Sale Price (-)': data.otherDetails.salePrice,
							'Total' : data.currentBVLoss
						},
						waiverCharge: true,
						waiverAmount : bvWaiverAmount <= 0 ? 0 :bvWaiverAmount ,
						percentage : percent !== '0.00' && !parseInt(percent) ? '< 1%' : percent+'%',
						netWorking : parseInt(netWorking)
					}, {
						chargeType : 'AV Loss',
						actualLoss : parseInt(data.currentAVLoss),
						settlementAgreed : parseInt(data.currentSettlementAgreed),
						shortfallCollected : parseInt(data.currentShortfallCollected),
						balance : parseInt(legalDetails.currentAVLoss) - parseInt(data.currentShortfallCollected),
						breakupDetails: {
							'Installment': data.otherDetails.installment,
							'POS': data.otherDetails.POS,
							'Seizure Charges': data.otherDetails.seizureCharges,
							'Parking Charges': data.otherDetails.parkingCharges,
							'Legal Charges': data.otherDetails.legalCharges,
							'Over Due Charges': data.otherDetails.overDueCharges,
							'Prepayment Penalty': data.otherDetails.prepaymentPenalty,
							'Interest On Termination': data.otherDetails.terminationInt,
							'Other Receivable Advice(FVC, RPDC Charges etc.)': data.otherDetails.otherReceivableAdvise,
							'Open Payable Advice (-)': data.otherDetails.openPayAdvise,
							'Sale Price (-)': data.otherDetails.salePrice,
							'Total' : data.currentAVLoss
						},
						waiverAmount : avWaiverAmount <= 0 ? 0 :avWaiverAmount,
						netWorking : parseInt(netWorking)
					}, {
						chargeType : 'Shortfall Notice',
						actualLoss : parseInt(data.shortfallNoticeAmount),
						settlementAgreed : parseInt(data.currentSettlementAgreed),
						shortfallCollected : parseInt(data.currentShortfallCollected),
						balance : parseInt(legalDetails.noticeAmount) - parseInt(data.currentShortfallCollected),
						waiverAmount : noticeWaiverAmt <= 0 ? 0 :noticeWaiverAmt,
						netWorking : parseInt(netWorking)
					}, {
						chargeType : 'Shortfall Due',
						actualLoss : parseInt(data.currentAVLoss) + parseInt(data.currentInterestAmount),
						//actualLoss : (parseInt(data.currentShortfallDue) <= 0) ? 0 : data.currentShortfallDue,
						settlementAgreed : parseInt(data.currentSettlementAgreed),
						shortfallCollected : parseInt(data.currentShortfallCollected),
						balance : parseInt(legalDetails.currentShortfallDue) - parseInt(data.currentShortfallCollected),
						breakupDetails: {
							'AV Loss': parseInt(data.currentAVLoss),
							'Total' : parseInt(data.currentAVLoss) + parseInt(data.currentInterestAmount)
						},
						waiverAmount : shotfallDueWaiverAmt <= 0 ? 0 :shotfallDueWaiverAmt ,
						netWorking : parseInt(netWorking)
					}];
					
						$scope.shortfallDetails[3].breakupDetails[interestAmount] = data.currentInterestAmount;


/*					
						var shortfallDetails = [{
							'chargeType': 'BV LOSS',
							'actualAmount': actuvalBVLoss,
							'waiverAmount': waiverAmount,
							'percentage': percentage,
							'netWorking': netWorking,
						}, {
							'chargeType': 'AV LOSS',
							'actualAmount': parseInt(data.currentAVLoss),
							'waiverAmount': 0,
							'percentage': 0,
							'netWorking': parseInt(data.currentAVLoss),
						}, {
							'chargeType': 'SHORTFALL DUE',
							'actualAmount': parseInt(data.currentShortfallDue),
							'waiverAmount': 0,
							'percentage': 0,
							'netWorking': parseInt(data.currentShortfallDue),
						}];
*/
						$scope.shortfallBreakup = data;
						//$scope.shortfallDetails = shortfallDetails;


					}
				});
			}
		};
        $scope.downloadSOA = function(){
			if ($scope.agreementDetails && $scope.agreementDetails.isProfit) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.IS_PROFIT_SOA_CHECK + " " + $scope.searchParams.searchKey);
				return;
			}
            var queryParams = {
				toDate: formatDate($scope.dateTimeField.value),
                agreementNo: $scope.searchParams.searchKey
            }

            eReceiptService.downloadShortfallSOA(queryParams).then(function (data) {
                console.log(data,"DTATTTTTT")

            });
        }
		$scope.doSearch = function (agreementNo, formObj) {
			$scope.soaDetails = false;
			$scope.agreementStatus = false;
			eReceiptService.getAgreementDetails(agreementNo).then(function (data) {
				if (data && data.isShortfall) {
					if(data && data.isParent){
						$scope.noResult = false;
						$scope.agreementStatus = true;
						$scope.agreementDetails = data;
						$scope.breakupDetails = data.shortfallDetails;
						var saleDate = new Date(data.shortfallDetails.otherDetails.saleDate);
						var terminationDate = new Date(data.shortfallDetails.otherDetails.terminationDate);
						$scope.dateTimeField = new DatePickerConfig({
							value: new Date(),
							minDate: new Date().setFullYear(saleDate.getFullYear(), saleDate.getMonth(), saleDate.getDate()),
							maxDate: new Date,
							readonly: true,
							DateTime: new Date().setFullYear(saleDate.getFullYear(), saleDate.getMonth(), saleDate.getDate())
						});
						return;
					}else{
						$scope.noResult = true;
						if(data.parentAgreementNo){
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Child/Topup agreements are not allowed for shortfall soa, please try again with parent agreement "+data.parentAgreementNo);
						}else{
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Child/Topup agreements are not allowed for shortfall soa, please try again with parent agreement.")
						}
					}
				}else{
					$scope.noResult = true;
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Shortfall is not marked for this agreement!");
				}
			});
		}
		$scope.goBack = function(){
			$scope.noResult = true;$scope.agreementStatus = $scope.soaDetails =false;
		};
	};
	eReceipt.controller('shortfallSOAController', ['$scope', '$rootScope', '$state', '$modal', '$upload', '$stateParams', 'eReceiptService', 'dialogService', 'lazyModuleLoader', 'messageBus', 'environmentConfig', 'appFactory', shortfallSOAController]);
	return shortfallSOAController;
});
