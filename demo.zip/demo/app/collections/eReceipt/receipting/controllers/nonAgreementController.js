define([ 'require', 'eReceipt', 'collectionConstants', 'constants' ], function(r, eReceipt, collectionConstants, constants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var nonAgreementController = function($scope,$stateParams,eReceiptService,$rootScope,messageBus,$state, dialogService){
		$scope.data = {};
		$scope.value = {};
		$scope.enableSubmitButton = function(){
			$scope.paymentMode.validators.validateFields($scope.paymentMode.modeOfPayment);
			return (!$scope.paymentMode.enableSubmitButton || !$scope.receiptPostModel.Receipt.amountPaid);
		};
		
		var init = function(){
			$scope.data.referenceNo = $stateParams.referenceNo;
			$scope.receiptPostModel = eReceiptService.getReceiptModel();
			$scope.paymentMode = eReceiptService.getPaymentModeModel();
			$scope.data.currentDate = new Date();
			$scope.data.searchParams = eReceiptService.getSearchParam();
			$scope.data.productTypes = collectionConstants.PRODUCT_TYPES;
			$scope.receiptPostModel.Receipt.receiptType = "NonAgreement";
			$scope.receiptPostModel.Receipt.receiptFor = "NonAgreement";
			$scope.isManualReceipt = eReceiptService.getManualReceiptFlag();
			$scope.payerType = 'Applicant';
			if($scope.isManualReceipt){
				$state.$current.data.headerText = "Manual Receipt";
				$scope.data.manualReceiptInfo = eReceiptService.getManualReceiptDetails();
				$scope.receiptPostModel.Receipt.productType = $scope.data.manualReceiptInfo.productType; 
				var _manReceiptDate = new Date($scope.data.searchParams.receiptDate),_minDate;
				$scope.paymentMode.demandDraft.instrumentDate.maxDate = $scope.paymentMode.cheque.instrumentDate.maxDate = _manReceiptDate;
				_minDate = new Date(new Date().setDate(_manReceiptDate.getDate()-collectionConstants.OTHERS.MAX_CHEQUE_EXPIRY_DAY));
				$scope.paymentMode.demandDraft.instrumentDate.minDate = $scope.paymentMode.cheque.instrumentDate.minDate = _minDate;				
				eReceiptService.getManualPendingRef($scope.data.manualReceiptInfo).then(function(data){
					$scope.data.manualReferences = data;
				});
			}else{
				$state.$current.data.headerText = "Online Receipt";
			}
		};
		init();
		
		$scope.value.manualReceiptReferenceCase = '';
		$scope.referenceChangeHandler = function(value) {
			$scope.value.manualRefDetails = _.findWhere($scope.data.manualReferences, {
				referenceNo : value
			});
		};
		var createReceipt = function(receiptForm){
			if($scope.isManualReceipt){
				$scope.receiptPostModel.Receipt.receiptNo = $scope.data.searchParams.receiptNo;
				$scope.receiptPostModel.Receipt.collectionAgentID = $scope.data.manualReceiptInfo.allocatedUserID;
				$scope.receiptPostModel.Receipt.receiptEnteredTime = new Date($scope.data.searchParams.receiptDate);
				$scope.receiptPostModel.Receipt.manualReceiptReferenceCase = $scope.value.manualReceiptReferenceCase;
			}else{
				$scope.receiptPostModel.Receipt.collectionAgentID = $rootScope.identity.userID;
				$scope.receiptPostModel.Receipt.receiptEnteredTime = $scope.receiptPostModel.Receipt.receiptDateTime = $scope.data.currentDate;
			}
			$scope.receiptPostModel.Receipt.chargeDetails[0].chargeID = collectionConstants.CHARGE_IDS.EXCESS;
			$scope.receiptPostModel.Receipt.chargeDetails[0].amount = $scope.receiptPostModel.Receipt.amountPaid;
			$scope.receiptPostModel.Receipt.modeOfPayment = $scope.paymentMode.modeOfPayment;
			$scope.receiptPostModel.Receipt.payerType = "CUSTOMER";
			$scope.receiptPostModel.Receipt.chargeDetails[0].referenceNo = $scope.receiptPostModel.Receipt.payerID = $scope.data.referenceNo;
			$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase = $scope.data.referenceNo;
			$scope.receiptPostModel.Receipt.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
			$scope.receiptPostModel.Receipt.isPanChanged = false;
			$scope.receiptPostModel.Receipt.panNo = $scope.paymentMode.cash.pan;
			$scope.receiptPostModel = eReceiptService.setPaymentModeInfo($scope.paymentMode,$scope.receiptPostModel);
			var params = {
				formObj : receiptForm,
				isTenlakhs : false
			};
			eReceiptService.createReceipt($scope.receiptPostModel,params);
		};
		
		var panMandatoryFunction;
		$scope.submitReceipt = function(receiptForm){
			createReceipt(receiptForm);
		};
		
		var cashValidation = function(value){
			if(value === 'CASH' && Number($scope.receiptPostModel.Receipt.amountPaid) > collectionConstants.CASH_AMT_RESTRICT_OTHER_CHAGRES){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.CASH_AMT_RESTRICT_OTHER_CHAGRES);
				$scope.receiptPostModel.Receipt.amountPaid = '';
			}
		};

		$scope.getActualAmount = function() {
			cashValidation($scope.paymentMode.modeOfPayment);
		};

		$scope.modeHandler = function(value){
			cashValidation(value);		
		};
	};
	
	eReceipt.controller('nonAgreementController', [ '$scope','$stateParams','eReceiptService','$rootScope','messageBus','$state', 'dialogService', nonAgreementController ]);
	return nonAgreementController;
});