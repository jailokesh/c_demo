define([ 'require', 'eReceipt', 'utility', 'collectionConstants' ], function(r, eReceipt, utility, collectionConstants) {
'use strict';
	var miniSOAController = function($scope, shortfallRecoveryInfo, eReceiptService, $stateParams, $modal, $state, dialogService) {
		$scope.miniSOAInfo = shortfallRecoveryInfo;
		$scope.searchParam = eReceiptService.getSearchParam();
		$scope.receiptDate = new Date();
		$scope.partyType = 'applicant';
		var chargeDetails = {};
		chargeDetails.chargeType = 'EXCESSAMT';
		chargeDetails.chargeID = collectionConstants.CHARGE_IDS.EXCESS;

		/*
		 * validators required for the page
		 */
		$scope.validators = {
			mobileNo : function(val) {
				var isValid = constants.REGULAR_EXPRESSION.MOBILE_NO.test(val);
				return isValid ? utility.getSuccessResult() : utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_MOBILE_NO);
			},
			panNo : function(val) {
				var isValid = constants.REGULAR_EXPRESSION.PAN_NO.test(val);
				return isValid ? utility.getSuccessResult() : utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_PAN_NO);

			},
			name : function(val) {
				var isValid = constants.REGULAR_EXPRESSION.NAME.test(val);
				return isValid ? utility.getSuccessResult() : utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_NAME);
			}

		};

		/*
		 * post model is constructed here
		 */
		var minisoaPostModel = {};
		minisoaPostModel = eReceiptService.getReceiptModel($scope.miniSOAInfo);
		$scope.thirdParty = false;
		$scope.applicant = eReceiptService.getApplicanInfo($scope.miniSOAInfo.partyDetails);
		$scope.paymentMode = eReceiptService.getPaymentModeModel($scope.applicant);
		$scope.contactNo = $scope.applicant.mobileNos[0];
		var thirdPartyContactNo = ($scope.miniSOAInfo.thirdPartyDetails[0]) ? $scope.miniSOAInfo.thirdPartyDetails[0].mobileNos[0] : '';
		var thirdPartyName = ($scope.miniSOAInfo.thirdPartyDetails[0]) ? $scope.miniSOAInfo.thirdPartyDetails[0].name : '';
		$scope.thirdPartyName = thirdPartyName;

		$scope.loadCustomerDetails = function() {
			$scope.contactNo = $scope.applicant.mobileNos[0];
			$scope.thirdParty = false;
			$scope.partyType = 'applicant';
		};

		/*
		 * this method loads third party details on clicking third party
		 */

		$scope.loadThirdPartyDetails = function() {
			$scope.contactNo = thirdPartyContactNo;
			$scope.thirdPartyName = thirdPartyName;
			$scope.thirdParty = true;
			$scope.partyType = 'thirdParty';

		};

		$scope.cancel = function() {
			$state.go('collections.receipt.eReceipt');
		};
		minisoaPostModel.Receipt.productType = $scope.searchParam.productType || 'HE';
		minisoaPostModel.Receipt.receiptType = $scope.searchParam.receiptType;

		$scope.submitMiniSOA = function() {
			minisoaPostModel.Receipt.agreementNos = [];
			if (Number($scope.shortfallAmount) > 50000 && !$scope.paymentMode.cash.pan && $scope.paymentMode.modeOfPayment === 'CASH') {
				dialogService.showAlert('Wrong', "Wrong!", "Pan is be mandatory if amount exceeds 50000");
				return;
			}
			minisoaPostModel.Receipt.modeOfPayment = $scope.paymentMode.modeOfPayment;
			if (!$scope.thirdParty) {
				minisoaPostModel.AddressDetail.mobileNo = $scope.contactNo;
				minisoaPostModel.AddressDetail.panNo = $scope.panNo;
			} else {
				minisoaPostModel.ThirdParty.mobileNos[0] = $scope.contactNo;
				minisoaPostModel.ThirdParty.panNo = $scope.panNo;
				minisoaPostModel.ThirdParty.name = $scope.thirdPartyName;
			}
			minisoaPostModel.Receipt.agreementNos.push($scope.miniSOAInfo.agreementNo);
			minisoaPostModel.Receipt.amountPaid = $scope.shortfallAmount;
			minisoaPostModel.Receipt.payerType = $scope.partyType;
			minisoaPostModel.Receipt.payerID = $scope.applicant.customerID;
			minisoaPostModel.Receipt.chargeDetails = [];
			minisoaPostModel = eReceiptService.setPaymentModeInfo($scope.paymentMode, minisoaPostModel);
			chargeDetails.amount = $scope.shortfallAmount;
			chargeDetails.referenceNo = $scope.miniSOAInfo.agreementNo;
			minisoaPostModel.Receipt.chargeDetails.push(chargeDetails);

			eReceiptService.postMiniSOA(minisoaPostModel);
		};
	};
	eReceipt.controller('miniSOAController', [ '$scope', 'shortfallRecoveryInfo', 'eReceiptService', '$stateParams', '$modal', '$state', 'dialogService', miniSOAController ]);
	return miniSOAController;
});
