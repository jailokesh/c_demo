define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var repaySchedulePopupController = function($scope, $modalInstance, $modal, $state, data, messageBus, eReceiptService) {

		$scope.customerInfo = data;
		$scope.pageMaxSize = collectionConstants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
		$scope.tenRecordsPerPage = collectionConstants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;

		/**
		 * Method to retrieve the Repayment schedule info for the Agreement No.
		 */
		$scope.getRepaymentDetails = function() {
			$scope.repayScheduleInfo = [];
			var offSet = ((($scope.repaymentCurrentPage-1)*$scope.pageMaxSize)+1);
			eReceiptService.getRepaymentScheduleDetail($scope.customerInfo.agreementNo, $scope.pageMaxSize, offSet).then(function(data) {
				if (data.data) {
					$scope.repayScheduleInfo = data.data[0].items;
					$scope.repayTotalRecordCount = parseInt(data.meta.totalCount);
					$scope.noRecordFound = ($scope.repayTotalRecordCount === 0);
				} else {
					$scope.noRecordFound = true;
				}
			});
		};

		/*
		 * initially to load the first page
		 */
		$scope.getRepaymentDetails();

		/**
		 * Method to call the service once the pagination buttons has been clicked.
		 * @param {pageNo} Current page no.
		 * @param {pageNo} Current page name.
		 */
		$scope.paginationHandler = function(pageNo, pageName) {
			$scope[pageName + 'CurrentPage'] = pageNo;
			var currentMethod = "get" + pageName[0].toUpperCase() + pageName.slice(1) + "Details";
			$scope[currentMethod]();
		};
		$scope.close = function() {
			$modalInstance.dismiss();
		};
	};
	eReceipt.controller('repaySchedulePopupController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus', 'eReceiptService', repaySchedulePopupController ]);
	return repaySchedulePopupController;
});