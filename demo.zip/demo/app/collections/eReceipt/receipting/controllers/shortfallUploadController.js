define([ 'require', 'eReceipt', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility' ], function(r, eReceipt, constants, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var shortfallUploadController = function($scope, $rootScope, $state, $modal, $upload, $stateParams, eReceiptService, dialogService, lazyModuleLoader, messageBus, environmentConfig) {
	
			 $scope.productTypes = angular.copy($rootScope.identity.productDetails);
			 $scope.selectedProductType = $scope.productTypes[0].value;	
			 var initialize = function(){
					$scope.showSummaryPage = false;
					$scope.showUploadPage = true;
					$scope.uploadShow = false;
				};
				initialize();
			    /*Method to check the uploaded file type*/
			 	var file;
		        $scope.onFileSelect = function($files) {
		            //$files: an array of files selected, each file has name, size, and type.
		            if ($files && $files.length > 0) { //todo:Check file extension here
		                var extTemp = $files[0].name.split('.');
		                var ext = extTemp[extTemp.length - 1];
		                if (ext.indexOf('cs') === 0) {
		                    file = $files[0];
		                    $scope.uploadedFileName = file.name;
		                    $scope.formNotValid = false;
		                    $scope.uploadShow = true;
		                } else {
		                	dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.UPLOAD_CSV_CHECK);
		                    $scope.uploadedFileName = '';
		                    $scope.uploadShow = false;
		                    angular.element(document.querySelector('#userUpload')).val(null); 
		                }
		            }
		        };
				$scope.$on('$destroy', function () {
					eReceiptService.destroyBlobRefs();
				});
				$scope.downloadSampleBaseURL = function(){
					eReceiptService.shortfallDownloadSampleFile('Shortfall_Details');
				};

		        /* Method to upload file */
		        $scope.upload = function(sfCheck) {
		            if (file === undefined) {
		                $scope.formNotValid = true;
		            } else {
		            	var checkSf = sfCheck ? sfCheck :false;
		            	var urlString =  '/'+environmentConfig.baseURL+'/shortfallCasesUploadCsv'+ '?sfCheck='+checkSf;

		            	$upload.upload({
		                    url:urlString, //upload.php script, node.js route, or servlet url
		                    method: 'PUT',
		                    headers: {
		                        'Content-Type': undefined,
		                        'userId': $rootScope.identity.userID,
		                        'Accept': undefined,
		                        "Authorization" : window.sessionStorage.token,
		                        "client_Transaction_Id" : utility.getGuid()
		                    },
		                    //withCredentials: true,
		                    data: {
		                        collectionType: {
		                            'type': "user"
		                        }
		                    },
		                    file: file,
		                    fileFormDataName: 'CSVDATA'
		                }).progress(function() {
		                }).success(function(data, status, headers, config) {
		                    if (status === 200) {
		                       dialogService.confirm('Warning', 'Alert', 'Totally ' + data.totalRecords + ' Records processed, Are you sure you want to proceed?')
		                            .result.then(function(response) {
										console.log('data', data);
		                            	$scope.showSummaryPage=true;
                                        $scope.showUploadPage=false;
                                        $scope.uploadStatus=data;		                            	
		                            	
                                        	var searchObj = {
                                				offset:1,
                                				limit:constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
                                				product:'All'
                                			};
											/*
                                			hoStockService.getHOStockList(searchObj).then(function(data){
                                				hoStockList = data;
                                				setTotalRecord();
                                			});
											*/
									});
		                    } else {
		                    	if(data.message){
		                        	dialogService.showAlert('Warning', 'Error', data.message);
		                        } else if(data.errors[0].name == "NOTICEMANAGEMENT-1071"){
		                        	// var msg = data.errors[0].message + ". Do you want to upload again ? \n"+ data.errors[0].data[0];
		                        	// dialogService.confirm('Warning', 'Alert', msg,true)
		                        	var edsmessages = [], a;
									for (a = data.errors.length - 1; a >= 0; a--) {
										edsmessages.push(data.errors[a].message + " Do you want to upload again ?");
										if (data.errors[a].data && data.errors[a].data) {
											edsmessages = _.union(edsmessages,data.errors[a].data);
										}
									}
									dialogService.confirm('Warning', 'Alert', edsmessages.join('<br/>'), false,true)
					                            .result.then(function(response) {
					                            	console.log("ok"+file);
					                            	$scope.upload(true);
					                            },function(){
													$scope.uploadShow = false;
					                            });
					                        }else {
					                        	dialogService.showAlert('Warning', 'Error', data.errors[0].message);
												$scope.uploadShow = false;
					                        }
					                    }
					                    $scope.uploadedFileName = '';
										document.getElementById('userUpload').value = '';
					                });
		            }
		        };
		        $scope.errorDownload = function() {
		        	if($scope.uploadStatus.summaryID){
		        		eReceiptService.downloadFile($scope.uploadStatus.summaryID,$scope.uploadStatus.fileName);
		        	}
		        };
		          var rowData = [{
		        	  bookNo:'',
		        	  productType:'',
		        	  startingReceiptNo:'',
		        	  endingReceiptNo:'',
		        	  remarks:''
		          }];
		          $scope.addRows = rowData;
				  $scope.modifyRows = function(pos, count) {
						if (!count) {
							var addObj = angular.copy($scope.addRows[pos]);
							$scope.addRows.push(addObj);
							$scope.addRows[pos+1].bookNo = '';
							$scope.addRows[pos+1].productType = '';
							$scope.addRows[pos+1].startingReceiptNo = '';
							$scope.addRows[pos+1].endingReceiptNo = '';
							$scope.addRows[pos+1].remarks = '';
						} else {
							$scope.addRows.splice(pos, count);
						}
					};
				$scope.getBook = function(index,bookNo) {
					if(bookNo == ''){
						$scope.addRows[index].productType = '';
						$scope.addRows[index].startingReceiptNo = '';
						$scope.addRows[index].endingReceiptNo = '';
	      				$scope.addRows[index].remarks = '';
					}
	      		};
	      		
	      		$scope.clearAll = function() {
	      			$scope.addRows = [{
			        	  bookNo:'',
			        	  productType:'',
			        	  startingReceiptNo:'',
			        	  endingReceiptNo:'',
			        	  remarks:''
			          }];
	      		};
	      		$scope.showUpload = function() {
	      			$scope.uploadedFileName = '';
	    			initialize();
	      		};


	};
	eReceipt.controller('shortfallUploadController', [ '$scope', '$rootScope', '$state', '$modal', '$upload', '$stateParams', 'eReceiptService', 'dialogService', 'lazyModuleLoader', 'messageBus', 'environmentConfig', shortfallUploadController ]);
	return shortfallUploadController;
});

/*
define([ 'require', 'initiateRequest', 'constants', 'DatePickerConfig' ], function(r, initiateRequest, constants, DatePickerConfig) {
	var appSimulationPopupController = function($scope, data, $modalInstance) {
		$scope.data = {
			tillDate : new DatePickerConfig({
				value : '',
				readonly : true,
				minDate : new Date(),
				minErrorMsg : "Interest till Date cannot be less than current date"
			})
		};
		$scope.simulateHandler = function() {
			$modalInstance.close($scope.data.tillDate);
		};

		$scope.close = function() {
			$modalInstance.dismiss();
		};

	};
	initiateRequest.controller('appSimulationPopupController', [ '$scope', 'data', '$modalInstance', appSimulationPopupController ]);
	return appSimulationPopupController;
});
*/