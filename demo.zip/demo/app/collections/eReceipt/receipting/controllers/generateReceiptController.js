/**
 * Represents Generate Receipt Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola. 
 */
define([ 'require', 'eReceipt','collectionConstants','utility'],function(r, eReceipt,collectionConstants,utility) {
'use strict';
	/**
	 * Pop up controller for pdcRemaining .
	 */
	var generateReceiptController = function($scope, $globalScope, $modalInstance,$state,data,eReceiptService,authService,dialogService,$timeout,$rootScope) {
		$scope.alphabets = angular.copy(collectionConstants.ALPHABETS);
		$scope.data = data.popUpData;
		$scope.receiptDetails = data.receiptDetails;
		if($scope.receiptDetails.receiptType === "miniStatement"){
			$scope.miniStatement = (authService) ? authService.getMiniStatement() : {};
		}		
		$scope.receiptDetails.branchID = JSON.parse(getCookie('selectedBranch')).branchDesc;
		$scope.receiptDetails.payerType = $scope.receiptDetails.payerType?$scope.receiptDetails.payerType.toUpperCase():$scope.receiptDetails[0].payerType.toUpperCase();
		$scope.receiptDetails.amountInwords = utility.numberIntoWords($scope.receiptDetails.amountPaid) + " Only";
		$scope.receiptDetails.printCount = !data.isDuplicate ? 0 : $scope.receiptDetails.printCount-1;
		$scope.receiptDetails.partPayCharges = collectionConstants.OTHERS.PART_PAY_CHARGES;
		if(!data.isRPDC){
			$scope.receiptDetails.agreements = [];
			$scope.additionString = '';
			$scope.agreementTotal = [];
			if($scope.receiptDetails.agreementNos.length > 1){
				$scope.alphabets.splice($scope.receiptDetails.agreementNos.length,$scope.alphabets.length);
				_.each($scope.alphabets,function(item,index){
					$scope.additionString += (index===0) ? item : '+'+item;
					$scope.receiptDetails.agreements.push({agreementNo:data.receiptDetails.agreementNos[index],chargeDetails:[]});
				});
			}else{
				$scope.receiptDetails.agreements.push({agreementNo:data.receiptDetails.agreementNos[0],chargeDetails:[]});
			}
			_.each($scope.receiptDetails.agreementNos,function(item,index){
				$scope.agreementTotal.push(0);
				_.each($scope.receiptDetails.chargeDetails,function(data){
					if(item === data.referenceNo){
						$scope.agreementTotal[index] += parseInt(data.amount);
						$scope.receiptDetails.agreements[index].chargeDetails.push({chargeType:data.chargeType,amount:data.amount});
					}
				});
				if($scope.receiptDetails.receiptType === 'SALE'){
					var saleObj = _.findWhere($scope.receiptDetails.linkedSaleAgreements,{agreementNo : item});
					$scope.receiptDetails.agreements[index].saleAmount = saleObj ? saleObj.saleAmt : '';
					$scope.receiptDetails.agreements[index].emdAmount = saleObj ? saleObj.emdAmt : '';
				}/*else if ($scope.receiptDetails.receiptType === 'FORECLOSURE' && $scope.receiptDetails.productType === 'VF'){
					var _sum = 0;
					_.each($scope.receiptDetails.fcChargeDetails,function(_charge){
						if(_charge.chargeID !== '20002'){
							_sum += Number(_charge.amount);
						}
					});
					//Deducting waiver amount from total charge amount
					if(_sum && $scope.receiptDetails.foreClosureDetail && $scope.receiptDetails.foreClosureDetail.waiveOffAmount){
						_sum -= $scope.receiptDetails.foreClosureDetail.waiveOffAmount;
					}
					// Deducting Refund amount
					var _refund = _.findWhere($scope.receiptDetails.fcChargeDetails,{chargeID : "20002"});
					if(_refund){
						_sum -= _refund.amount;
					}
					var _diff = Number($scope.receiptDetails.amountPaid - _sum);
					if(_diff > 0){
						$scope.receiptDetails.fcChargeDetails.push({chargeType : 'Excess Collected', amount : _diff});
					}
					var afcObj = _.findWhere($scope.receiptDetails.fcChargeDetails,{chargeID : "7"});
					if(afcObj){
						afcObj.chargeType += " (inc. Current AFC)";
					}
				}*/
				$scope.receiptDetails.agreements[index].amountInwords = utility.numberIntoWords($scope.agreementTotal[index])+ " Only";
			});
		}else{
			$scope.receiptDetails[0].amountInWords = utility.numberIntoWords($scope.receiptDetails[0].chargeDetails[0].amount)+ " Only";
		}
		$scope.isReprint = !data.isDuplicate ? false : ($scope.receiptDetails.printCount > 0);
		$scope.printHandler = function(isReprint) {
			isCloseFlag = true;
			if(isReprint){
				eReceiptService.rePrintReceipt($scope.receiptDetails.receiptNo,{'minorVersion':$scope.receiptDetails.minorVersion,'majorVersion':$scope.receiptDetails.majorVersion}).then(function(data){
					if(data.printCount){
						$scope.receiptDetails.printCount++;
						$scope.receiptDetails.minorVersion = data.minorVersion;
						$scope.receiptDetails.majorVersion = data.majorVersion;
						$scope.receiptDetails.currentDateTime = data.currentDateTime; 
					}
				});
			}else{
				$timeout(function(){
					$scope.receiptDetails.printCount++;
					$scope.isReprint = true;
				},300);
			}
		};
		var closeRedirect = function(){
			$globalScope.isClickedViaMenu = false;
			$modalInstance.dismiss();
			$globalScope.gotoPreviousPage();
		};
		var isCloseFlag;
		$scope.close = function(){
			isCloseFlag = true;
			if($scope.isReprint) {			//should be uncommented before SIT
				closeRedirect();
			} else if($rootScope.enablePrint){
				dialogService.confirm('Confirm', "Confirm!",collectionConstants.ERROR_MSG.PRINT_CONFIRMATION).result.then(function(){
					closeRedirect();
				},function(){
					//closeRedirect();
				});
			}else{
				closeRedirect();
			}
		};
		
		$modalInstance.result.then(function(){},function(){
	       	 if(!isCloseFlag){
	       		 $scope.close();
	       	 }
	    });
	};
	eReceipt.controller('generateReceiptController',[ '$scope', '$globalScope', '$modalInstance', '$state', 'data','eReceiptService','authService','dialogService','$timeout','$rootScope',generateReceiptController ]);
	return generateReceiptController;
});