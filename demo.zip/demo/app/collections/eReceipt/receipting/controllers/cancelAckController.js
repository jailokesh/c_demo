/**
 * Represents a EMD Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'DatePickerConfig', 'collectionConstants', 'utility', 'constants' ], function(require, eReceipt, DatePickerConfig, collectionConstants, utility, constants) {
	'use strict';

	/**
	 * EMD Collection Controller function. getEMDReceipting is method in a EMD
	 * resolver to get the emd info before the page load. Dependency injection
	 * $stateparam ,$scope, $state, eReceiptService as a parameter.
	 */

	var cancelAckController = function($scope, $state, eReceiptService, dialogService, getAckDetails, getBankList) {
		$scope.documentTypes = [ {
			'id' : 'INSURANCE',
			'text' : 'Insurance'
		}, {
			'id' : 'INVOICE',
			'text' : 'Invoice'
		}, {
			'id' : 'RC',
			'text' : 'RC'
		} ];
		$scope.receiptType = $state.params.type.split('-')[0];
		$scope.isCancelModify = true;
		$scope.eReceiptModel = getAckDetails;
		$scope.pddData = eReceiptService.setPDDDCouments($scope.eReceiptModel);
		$scope.productType = $scope.eReceiptModel.productGroup;
		$scope.isCancelAck = true;
		$scope.value = $scope.remarks = $scope.selectedAgreement = {};
		$scope.agreementStatus = constants.AGREEMENT_STATUS;
		$scope.status = constants.STATUS;
		$scope.value.accountTypes = collectionConstants.ACCOUNT_TYPES;
		var setPDDValues = function() {
			$scope.pddSubmitModel = eReceiptService.getAckInfo($scope.receiptType);
			$scope.value.collectorID = $scope.pddSubmitModel.pddAcknowledgement.collectionAgentID;
			$scope.receiptDate = $scope.pddSubmitModel.pddAcknowledgement.receivedDate;
			if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'RC') {
				$scope.registrationDate = new DatePickerConfig({
					value : $scope.pddSubmitModel.pddAcknowledgement.RCDetail.registrationDate,
					maxDate : new Date(),
					onchange : function(val) {
						$scope.pddSubmitModel.pddAcknowledgement.RCDetail.registrationDate = val;
					},
					readonly : true
				});
				$scope.RCReceivedDate = new DatePickerConfig({
					readonly : true,
					value : $scope.pddSubmitModel.pddAcknowledgement.receivedDate
				});
			} else if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'INSURANCE') {
				$scope.insuranceEndDate = new DatePickerConfig({
					value : $scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.expiryDate,
					minDate : $scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate,
					onchange : function(val) {
						$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.expiryDate = $scope.insuranceEndDate.setDateVal(val);
					},
					readonly : true
				});

				$scope.insuranceStartDate = new DatePickerConfig({
					value : $scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate,
					maxDate : new Date(),
					onchange : function(val) {
						$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate = $scope.insuranceStartDate.setDateVal(val);
						$scope.insuranceEndDate.minDate = val;
					},
					readonly : true
				});
				$scope.insReceivedDate = new DatePickerConfig({
					readonly : true,
					value : $scope.pddSubmitModel.pddAcknowledgement.receivedDate
				});
				eReceiptService.getInsuranceProviders().then(function(data) {
					$scope.insuranceProviders = data;
				});
			} else {
				$scope.invoiceDate = new DatePickerConfig({
					value : $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceDate,
					onchange : function(val) {
						$scope.pddSubmitModel.invoiceDetail.invoiceDate = val;
					},
					readonly : true
				});
				$scope.invReceivedDate = new DatePickerConfig({
					readonly : true,
					value : $scope.pddSubmitModel.pddAcknowledgement.receivedDate
				});
			}
		};
		var setRPDCValues = function() {
			//$scope.bankList = [$scope.rpdcSubmitModel.pddAcknowledgement.bankDetails];//getBankList;
			$scope.repayModes = collectionConstants.RPDC_REPAY_MODES;
			$scope.repayMode = $scope.repayModes[0];
			$scope.rpdcSubmitModel = eReceiptService.getAckInfo($scope.receiptType);
			$scope.receiptDate = $scope.rpdcSubmitModel.pddAcknowledgement.receivedDate;
			$scope.eReceiptModel.relatedAgreementNos = [];
			$scope.value.collectorID = $scope.rpdcSubmitModel.pddAcknowledgement.collectionAgentID;
			if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'RPDC') {
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankBranchID;
				$scope.value.totalEMIOD = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].chequeValue;
			} else {
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.push({});
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID = $scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.bankBranchID;
				$scope.value.totalEMIOD = $scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.amount;
			}
			if ($scope.rpdcSubmitModel.pddAcknowledgement.bankDetails) {
				$scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.name = $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.bankName;
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.bankID;
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].ifsCode = $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.ifsCode;
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].micrCode = $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.micrCode;
				$scope.branchList = [ {
					name : $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails.branchName,
					bBranchID : $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID
				} ];
			}
			$scope.value.emiDue = $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible + $scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited;
			$scope.bankList = [$scope.rpdcSubmitModel.pddAcknowledgement.bankDetails];
			$scope.value.bank = $scope.rpdcSubmitModel.pddAcknowledgement.bankDetails;
			$scope.pendingEMI = Number($scope.eReceiptModel.noOfInstallmentsOD);
			$scope.rePayBankDetails = {};
			_.each($scope.eReceiptModel.rightSideColumn.repaymentBankDetails,function(item){
				if(item.PDCDetails && item.PDCDetails[0]){
					$scope.rePayBankDetails.bankAccNo = item.PDCDetails[0].bankAccountNo;
					$scope.rePayBankDetails.bankID = item.PDCDetails[0].pdcBankID;
					var bankObj = _.findWhere(getBankList,{bankID:item.PDCDetails[0].pdcBankID});
					$scope.rePayBankDetails.bankName = (bankObj) ? bankObj.name : '';
				}
			});
			_.each($scope.rpdcSubmitModel.pddAcknowledgement.agreementNos, function(item) {
				var obj = {};
				obj.agreementNo = item;
				obj.isSelected = true;
				obj.balanceAllocationModel = [];
				obj.shortAgreementNo = '..' + item.substr(item.length - 5, item.length);
				$scope.eReceiptModel.relatedAgreementNos.push(obj);
			});
		};
		var initController = function() {
			$scope.remarks.value = '';
			$scope.receiptPostModel = eReceiptService.getReceiptModel();
			$scope.selectedAgreement.agreementNo = $scope.eReceiptModel.agreementNo;
			$scope.applicantDetail = eReceiptService.getApplicanInfo($scope.eReceiptModel.partyDetails);
			if ($scope.productType !== 'VF') {
				$scope.value.propertyDetailsAddress = utility.setAddress($scope.eReceiptModel.propertyDetail);
			}
			$scope.applicantDetail.name = $scope.applicantDetail.firstName + ' ';
			$scope.applicantDetail.name += (!$scope.applicantDetail.lastName) ? '' : $scope.applicantDetail.lastName;
			$scope.applicantDetail.mobileNos = $scope.numbers = utility.getApplicantMobileNos($scope.eReceiptModel.addressDetails);
			
			$scope.applicantAddress = {};
			if($scope.eReceiptModel.addressDetails && $scope.eReceiptModel.addressDetails.length > 0){
				var _address = _.findWhere($scope.eReceiptModel.addressDetails,{addressType:collectionConstants.CURRENT_ADDRESS});
				if(!_address){
					_address = _.findWhere($scope.eReceiptModel.addressDetails,{addressType:collectionConstants.PERMANENT_ADDRESS});
				}
				if(!_address){
					_address = _.findWhere($scope.eReceiptModel.addressDetails,{addressType:collectionConstants.OFFICE});
				}
				$scope.applicantAddress = _address || {};
			}
			$scope.customerFullAddress = utility.setAddress($scope.applicantAddress);
			$scope.receiptPostModel.AddressDetail.mobileNo = $scope.value.mobileNo = $scope.applicantAddress.mobileNo;
			$scope.partyType = 'Applicant';
			if ($scope.receiptType === 'PDD') {
				setPDDValues();
			} else {
				setRPDCValues();
			}
		};
		initController();
		$scope.cancelAck = function() {
			if ($scope.remarks.value === '') {
				dialogService.showAlert('Message', 'Message', collectionConstants.ERROR_MSG.VALIDATE_REMARKS);
				return;
			}
			var receiptObj;
			if ($scope.receiptType === 'PDD') {
				receiptObj = {
					pddAcknowledgementNo : $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementNo,
					remarks : $scope.remarks.value
				};
			} else {
				receiptObj = {
					pddAcknowledgementNo : $scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementNo,
					remarks : $scope.remarks.value
				};
			}
			var isOfflineRPDC = ($state.params.type === 'RPDC-OFFLINE');
			eReceiptService.cancelAcknowledgement(receiptObj, $scope.receiptForm,isOfflineRPDC);
		};

		$scope.validateRemarks = function(val) {
			if (val.trim === '') {
				return utility.getFailureResult(collectionConstants.ERROR_MSG.VALIDATE_REMARKS);
			} else {
				return utility.getSuccessResult();
			}
		};
	};

	eReceipt.controller('cancelAckController', [ '$scope', '$state', 'eReceiptService', 'dialogService', 'getAckDetails', 'getBankList', cancelAckController ]);
	return cancelAckController;
});