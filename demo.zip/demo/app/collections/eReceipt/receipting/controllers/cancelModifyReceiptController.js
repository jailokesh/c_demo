/**
 * Represents a EMD Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'constants', 'collectionConstants', 'utility', 'DatePickerConfig' ], function(require, eReceipt, constants, collectionConstants, utility, DatePickerConfig) {
	'use strict';

	/**
	 * EMD Collection Controller function. getEMDReceipting is method in a EMD
	 * resolver to get the emd info before the page load. Dependency injection
	 * $stateparam ,$scope, $state, eReceiptService as a parameter.
	 */

	var cancelModifyController = function($scope, $state, eReceiptService, dialogService, getAgreementDetails, getBankList, getchargesListResolver, masterService, appFactory, $globalScope, messageBus,$timeout,$modal) {
		$scope.isCancelModify = true;
		$scope.agreementStatus = constants.AGREEMENT_STATUS;
		$scope.status = constants.STATUS;
		var receiptDetails = eReceiptService.getReceiptInfo();
		var paymentStr, totalODVal = 0, receiptOption;
		var payerType = collectionConstants.PAYER_TYPE;		
		$scope.receiptNo = receiptDetails.receiptNo;
		$scope.thirdPartyDetails = {};
		$scope.applicantAddress = {};
		$scope.receiptDate = receiptDetails.receiptDateTime;
		$scope.value = $scope.remarks = {};
		$scope.swapChargesAgreements = receiptDetails.agreementNos;
		$scope.activity = {};
		$scope.activity.modify = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.MODIFY);
		$scope.activity.canel = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.CANCEL);
		$scope.activity.reprint = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.REPRINT);
		$scope.remarks.type = $state.params.type;
		$scope.value.cancelReceipt = _.findWhere($globalScope.imageCategories, {
			subCategory : 'cancelled receipt'
		});

		var setIMDBalanceAllocation = function(loan, charges) {
			var outputArr = [], chargeObj, temp, obj;
			loan.totalOD = 0;
			if (receiptDetails.productType === 'VF') {
				_.each(charges, function(item) {
					chargeObj = _.findWhere(collectionConstants.IMD_CHARGES, {
						chargeID : item.chargeID
					}) || {};
					temp = _.findWhere(outputArr, {
						title : chargeObj.group
					});
					loan.totalOD += Number(item.amount);
					if (!temp) {
						obj = {
							charges : [],
							title : chargeObj.group
						};
						obj.charges.push({
							chargeAmount : item.amount,
							chargeType : chargeObj.name,
							shortName : chargeObj.shortName,
							chargeID : chargeObj.chargeID,
							enabled : false
						});
						outputArr.push(obj);
					} else {
						temp.charges.push({
							chargeAmount : item.amount,
							chargeType : chargeObj.name,
							shortName : chargeObj.shortName,
							chargeID : chargeObj.chargeID,
							enabled : false
						});
					}
				});
			} else {
				obj = {
					charges : [],
					title : 'Charges'
				};
				_.each(charges, function(item) {
					obj.charges.push({
						chargeAmount : item.amount,
						chargeType : item.chargeType,
						chargeID : item.chargeID
					});
				});
				outputArr.push(obj);
			}
			return outputArr;
		};
		/* popupModal for breakupDetails */ 
            $scope.openModal = function(option, otherDetails,waiverSplitUp,chargeDetails){
                $modal.open({
                    templateUrl : 'app/collections/eReceipt/receipting/partials/popup/shortfallBreakupPopup.html',
                    controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
		
                        $scope.data = option;
						$scope.breakupDetails = otherDetails;				
						$scope.partPaymentDetails = waiverSplitUp;
						$scope.chargeDetails = chargeDetails;

                        $scope.close = function() {
                            $modalInstance.dismiss();
                        };
                    } ],
                    size : 'md',
                    backdrop : 'static',
                    windowClass : 'modal-custom',
                    resolve : {

                    }
                });
            }
		var setBalanceAllocationTable = function() {
			getAgreementDetails.relatedAgreementNos = [];
			var agreementList = [];
			var defaultCharges = [];
			_.each(collectionConstants.CHARGE_IDS, function(keys) {
				defaultCharges.push(keys);
			});
			if (receiptDetails.receiptType === 'IMD' && receiptDetails.productType !== 'VF') { // changing type to array for HEHL receipt details.
				getAgreementDetails.loanDetails = [ getAgreementDetails.loanDetail ];
			}
			
			if(receiptDetails.receiptType === 'IMD' || receiptDetails.receiptType === 'INS-LEAD'){
				agreementList = receiptDetails.applicationNos;
			}else if(receiptDetails.receiptType !== 'NonAgreement'){
				agreementList = receiptDetails.agreementNos;
			}
			_.each(agreementList, function(item, ind) {
				var obj = (receiptDetails.receiptType === 'IMD' || receiptDetails.receiptType === 'INS-LEAD') ? getAgreementDetails.loanDetails[ind] : {};
				obj.agreementNo = item;
				obj.isSelected = (item === agreementList[0]);
				var chargesArr = agreementList.length > 1 ? _.where(receiptDetails.chargeDetails, {
					referenceNo : item
				}) : receiptDetails.chargeDetails;
				var tempArr = [], otherOD = 0, taCharge;
				if($scope.value.isVishesh){
					getAgreementDetails.otherODCharges = obj.otherODCharges;
                    var chargeDetails  = [];
                    _.each(collectionConstants[getAgreementDetails.productCode+"_CHARGE_DETAILS"],function(oneItem){
                        chargeDetails.push({
                            chargeType : oneItem.chargeType,
                            amount : getAgreementDetails[oneItem.chargeAmount],
                            isLink : oneItem.isLink,
                            actual : oneItem.actual  ? receiptDetails.amountPaid :'',
                            chargeID : oneItem.chargeID ? oneItem.chargeID : ''
                        })
                    });
                    if(receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN'){
                    	_.each(getAgreementDetails.expenseDetails, function(expItem) {
							var chargeAmnt = Number(expItem.chargeAmount) - Number(expItem.paidAmount);
							if(chargeAmnt > 0){
								chargeDetails.push({
									chargeType: expItem.receiptChargeType,
									amount: chargeAmnt
								})
							}
	                    });
                    }
                    obj.balanceAllocationModel = chargeDetails;
				}else if (receiptDetails.receiptType === 'IMD') {
					tempArr = chargesArr;
					obj.balanceAllocationModel = setIMDBalanceAllocation(obj, tempArr);
				}else if (receiptDetails.receiptType === 'SHORTFALL' && getAgreementDetails.shortfallDetails) {
								var chargeObj = _.findWhere(getchargesListResolver, {
									leapDescription : collectionConstants.LEAP_DESC_CHARGES.SHORT_FALL
								});
								 defaultCharges = [/* {
									chargeType : 'BV Loss',
									chargeID : chargeObj.chargeID,
									amount : getAgreementDetails.shortfallDetails.currentBVLoss,
									breakupDetails: {
										'Installment': getAgreementDetails.shortfallDetails.otherDetails.installment,
										'POS': getAgreementDetails.shortfallDetails.otherDetails.POS,
										'Seizure': getAgreementDetails.shortfallDetails.otherDetails.seizureCharges,
										'Parking Charges': getAgreementDetails.shortfallDetails.otherDetails.parkingCharges,
										'Legal Charges': getAgreementDetails.shortfallDetails.otherDetails.legalCharges,
										'Open Payable Advise (-)': getAgreementDetails.shortfallDetails.otherDetails.openPayAdvise,
										'Sale Price (-)': getAgreementDetails.shortfallDetails.otherDetails.salePrice,
										'Total' : getAgreementDetails.shortfallDetails.currentBVLoss
									}
								 }, */{
									chargeType : 'Settlement Agreed',
									amount : getAgreementDetails.shortfallDetails.currentSettlementAgreed,
									breakupDetails: {
										'bvLoss': getAgreementDetails.shortfallDetails.currentBVLoss,
										'waiverAmount': getAgreementDetails.shortfallDetails.currentApprovedWaiverAmount,
										'settlementAgreed': getAgreementDetails.shortfallDetails.currentSettlementAgreed
									}
								 }, {
									chargeType : 'Shortfall Collected',
									amount : getAgreementDetails.shortfallDetails.currentShortfallCollected
								 }, {
									chargeType : 'Balance',
									chargeID : chargeObj.chargeID,
									amount : getAgreementDetails.shortfallDetails.currentBalance
								 } ];
								 obj.balanceAllocationModel = defaultCharges;
				} else {
					_.each(chargesArr, function(charge, chargeInd) {
						var overDueValues = _.findWhere(getAgreementDetails.expenseDetails, {chargeID:charge.chargeID});						
						if(overDueValues){
							var diff = overDueValues.chargeAmount - overDueValues.paidAmount;
							charge.chargeAmount = diff < 0 ? 0 : diff;
						}
						if (defaultCharges.indexOf(charge.chargeID) === -1) {
							// otherOD += parseInt(charge.amount);
							var _obj = _.findWhere(getchargesListResolver,{chargeID : charge.chargeID}) || {};
							charge.chargeType = _obj.leapDescription;
							tempArr.push(charge);
						} else {
							if (receiptDetails.receiptType === 'TA') {
								taCharge = _.findWhere(collectionConstants.OTHERS.TA_CHARGES, {
									chargeID : charge.chargeID
								});
								charge.chargeType = (taCharge) ? taCharge.chargeType : '';
							} else if (receiptDetails.receiptType === 'PART PAYMENT') {
								charge.chargeType = collectionConstants.OTHERS.PART_PAY_CHARGES[chargeInd];
							} else if (receiptDetails.receiptType === 'INS') {
								$scope.value.isMSFlag = receiptDetails.insuranceDetail && receiptDetails.insuranceDetail.totalPremium ? true : false;
								charge.chargeAmount = charge.premiumAmt = 0;//(getAgreementDetails.insuranceDetail && getAgreementDetails.insuranceDetail.length) ? getAgreementDetails.insuranceDetail[0].premiumAmount : 0;
							}else if (receiptDetails.receiptType === 'SHORTFALL') {
								var _amt = Number(getAgreementDetails.totalShortfallAmount) - Number(getAgreementDetails.totShortFallReceiptAmt);
								charge.chargeAmount = _amt < 0 ? 0 : _amt;
							} else if (receiptDetails.receiptType === 'EMD') {
								charge.chargeType = 'EMD Amount';
							}
							charge.percentage = 100;
							tempArr.push(charge);
						}
					});
					if (otherOD > 0) {
						tempArr.push({
							amount : otherOD,
							chargeType : 'Other OD',
							actual : otherOD
						});
					}
					obj.balanceAllocationModel = tempArr;
				}
				obj.isAllocated = true;
				obj.shortloanID = obj.shortAgreementNo = '..' + item.substr(item.length - 5, item.length);
				obj.chargeAmount = obj.totalActualAmount = _.reduce(_.pluck(obj.balanceAllocationModel, 'amount'), function(memo, num) {
					return memo + num;
				}, 0);
				totalODVal += obj.chargeAmount;
				obj.totalBalanceAmount = 0;
				obj.balanceAmount = 0;
				obj.allocatedAmount = obj.totalActualAmount;
				obj.assetDetail = getAgreementDetails.assetDetail || {};
				_.each(obj.balanceAllocationModel, function(item) {
					// item.actual = item.chargeAmount = item.amount;
					item.actual = item.amount;
				});
				if($scope.value.editManualReceipt){
					obj.otherODCharges = [];
					_.each(getAgreementDetails.expenseDetails, function(expObj){
						var _charge, _diff;
						var _obj = _.findWhere(getchargesListResolver,{chargeID : expObj.chargeID}) || {};
						if(collectionConstants.LEAP_DESC_CHARGES.PRIMARY_CHARGE_IDS.indexOf(expObj.chargeID) === -1){
							_diff = expObj.chargeAmount - expObj.paidAmount;
							if(_diff > 0){
								_charge = {};
								_charge.chargeType = _obj.leapDescription;
								_charge.chargeObj = _obj;
								_charge.chargeID = expObj.chargeID;
								_charge.chargeAmount = _diff;
								_charge.selected = true;
								_charge.actual = 0;
								_charge.isDefault = true;
								_charge.percentage = 100;
								_charge.receiptChargeType = expObj.receiptChargeType; // for vishesh
								obj.otherODCharges.push(_charge);
							}
						}
					});
                    if($scope.value.isVishesh){
                        getAgreementDetails.otherODCharges = obj.otherODCharges;
                        var chargeDetails  = [];
                        _.each(collectionConstants[getAgreementDetails.productCode+"_CHARGE_DETAILS"],function(oneItem){
                            chargeDetails.push({
                                chargeType : oneItem.chargeType,
                                chargeAmount : getAgreementDetails[oneItem.chargeAmount],
                                isLink : oneItem.isLink,
                                actual : oneItem.actual  ? receiptDetails.amountPaid :'',
                                chargeID : oneItem.chargeID ? oneItem.chargeID : ''
                            })
                        });
                        if(receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN'){
                        	_.each(getAgreementDetails.expenseDetails, function(expItem) {
								var chargeAmnt = Number(expItem.chargeAmount) - Number(expItem.paidAmount);
								if(chargeAmnt > 0){
									chargeDetails.push({
										chargeType: expItem.receiptChargeType,
										chargeAmount: chargeAmnt
									})
								}
		                    });
                        }
                        obj.balanceAllocationModel = chargeDetails;
                    }
				}
				getAgreementDetails.relatedAgreementNos.push(obj);
			});
		};

		var getAddress = function(addressObj) {
			eReceiptService.getAddressFromPincode(addressObj, true).then(function(response) {
				$scope.vendorFullAddress = $scope.customerFullAddress = $scope.thirdPartyFullAddress = utility.setAddress(response);
			});
		};
		$scope.checkInstrumentDetails = function(){
			if($scope.value.editManualReceipt){
				var payStr = $scope.paymentMode.modeOfPayment === 'CHEQUE' ? 'cheque' : $scope.paymentMode.modeOfPayment === 'DD' || 'DRAFT' ? 'demandDraft' : '';
				$scope.value.isReceiptImgRequired = (payStr && (receiptDetails.amountPaid !== $scope.receiptPostModel.Receipt.amountPaid || 
												receiptDetails.agreementNos[0] !==  $scope.eReceiptModel.agreementNo ||
												receiptDetails.instrumentDetail.instrumentType !== $scope.paymentMode[payStr].type || 
												receiptDetails.instrumentDetail.instrumentNo !== $scope.paymentMode[payStr].instrumentNo ||
												receiptDetails.instrumentDetail.bankBranchID !== $scope.paymentMode[payStr].bankBranchID ||
												receiptDetails.instrumentDetail.bankID !== $scope.paymentMode[payStr].bankID ||
												receiptDetails.instrumentDetail.micrNo !== $scope.paymentMode[payStr].micrNo ||
												(receiptDetails.instrumentDetail.bankBranchDetails && receiptDetails.instrumentDetail.bankBranchDetails.ifsCode !== $scope.paymentMode[payStr].ifsc)||
												utility.dateDifference(new Date(receiptDetails.instrumentDetail.instrumentDate),new Date($scope.paymentMode[payStr].instrumentDate.dateValue)) !== 0) || 
												receiptDetails.payerType !== payerType[$scope.partyType]);
				};
		};
		
		var setMinMaxDate = function(){
			if($scope.value.editManualReceipt){
				var _manReceiptDate = new Date(receiptDetails.receiptEnteredTime),_minDate,_minDate = new Date(receiptDetails.receiptEnteredTime);
				$scope.paymentMode.demandDraft.instrumentDate.maxDate = $scope.paymentMode.cheque.instrumentDate.maxDate = _manReceiptDate;
				_minDate = _minDate.setDate(_minDate.getDate()-collectionConstants.OTHERS.MAX_CHEQUE_EXPIRY_DAY);
				$scope.paymentMode.demandDraft.instrumentDate.minDate = $scope.paymentMode.cheque.instrumentDate.minDate = _minDate;
				$scope.paymentMode.cheque.instrumentDate.onchange = function(value){$scope.checkInstrumentDetails();}; 
				$scope.paymentMode.demandDraft.instrumentDate.onchange = function(value){$scope.checkInstrumentDetails();}; 
				
			}
		};
		var setPaymentValues = function() {
			if (receiptDetails.modeOfPayment === 'CASH') {
				$scope.paymentMode.cash.pan = receiptDetails.panNo;
			}else if (receiptDetails.modeOfPayment === 'DD') {
				paymentStr = 'demandDraft';
			} else if (receiptDetails.modeOfPayment === 'CHEQUE' || receiptDetails.modeOfPayment === 'CHEQUE-NON-MICR') {
				paymentStr = 'cheque';
			} else if (receiptDetails.modeOfPayment === 'RTGS') {
				$scope.paymentMode.rtgs.instrumentDate.setDateVal(new Date(receiptDetails.valueDate));
				$scope.paymentMode.rtgs.instrumentDate.dateValue = new Date(receiptDetails.valueDate);
				$scope.paymentMode.rtgs.utrNo = receiptDetails.utrNo;
				$scope.paymentMode.rtgs.rtgsBankID = receiptDetails.rtgsBankID;
				$scope.paymentMode.rtgs.branch = receiptDetails.instrumentDetail.bankBranchDetails;
				$scope.paymentMode.rtgs.bankID = receiptDetails.instrumentDetail.bankID;
				$scope.paymentMode.rtgs.bankBranchID = receiptDetails.instrumentDetail.bankBranchID;
				$scope.paymentMode.rtgs.micrNo = (receiptDetails.instrumentDetail) ? receiptDetails.instrumentDetail.micrNo : '';
				$scope.paymentMode.rtgs.imageRef = receiptDetails.instrumentDetail.imageRef;
				$scope.paymentMode.rtgs.cityID = receiptDetails.instrumentDetail.cityID;
				$scope.paymentMode.rtgs.remarks = receiptDetails.posRemarks;
			}else if(receiptDetails.modeOfPayment === 'POS'){
				$scope.paymentMode.pos.txnID = receiptDetails.posTxnID;
				$scope.paymentMode.pos.remarks = receiptDetails.posRemarks;
				$scope.paymentMode.pos.instrumentDate.setDateVal(new Date(receiptDetails.valueDate));
				$scope.paymentMode.pos.instrumentDate.dateValue = new Date(receiptDetails.valueDate);
				$scope.paymentMode.pos.imageRef = receiptDetails.instrumentDetail.imageRef;
				$scope.paymentMode.pos.bankID = receiptDetails.rtgsBankID;
			}
			if (paymentStr) {
				$scope.paymentMode[paymentStr].type = (!receiptDetails.instrumentDetail.instrumentType || receiptDetails.instrumentDetail.instrumentType.toLowerCase().indexOf('local') > -1) ? 'LOCAL' : 'OUTSTATION';
				$scope.paymentMode[paymentStr].bank = {
					bankID : receiptDetails.instrumentDetail.bankDetails.bankID,
					name : receiptDetails.instrumentDetail.bankDetails.name + " - " + receiptDetails.instrumentDetail.bankDetails.bankID
				};
				$scope.paymentMode[paymentStr].bankID = receiptDetails.instrumentDetail.bankID;
				$scope.paymentMode[paymentStr].branch = receiptDetails.instrumentDetail.bankBranchDetails;
				$scope.paymentMode[paymentStr].bankBranchID = receiptDetails.instrumentDetail.bankBranchID;
				$scope.paymentMode[paymentStr].instrumentNo = receiptDetails.instrumentDetail.instrumentNo;
				$scope.paymentMode[paymentStr].instrumentDate.setDateVal(new Date(receiptDetails.instrumentDetail.instrumentDate));
				$scope.paymentMode[paymentStr].instrumentDate.dateValue = new Date(receiptDetails.instrumentDetail.instrumentDate);				
				$scope.paymentMode[paymentStr].imageRef = receiptDetails.instrumentDetail.imageRef;
				$scope.paymentMode[paymentStr].micrNo = (receiptDetails.instrumentDetail.bankBranchDetails) ? receiptDetails.instrumentDetail.bankBranchDetails.micrCode : '';
				$scope.paymentMode[paymentStr].cityID = receiptDetails.instrumentDetail.cityID;
			}
			setMinMaxDate();
		};		
		var setEMDSaleValues = function() {
			$scope.buyerDetails = {};
			if (getAgreementDetails.vendorDetails.addressDetail && getAgreementDetails.vendorDetails.addressDetail.pincode) {
				$scope.buyerDetails.address = getAgreementDetails.vendorDetails.addressDetail;
				getAddress($scope.buyerDetails.address);
			}
			if (!$scope.eReceiptModel.receiptDetails || !$scope.eReceiptModel.receiptDetails.amountPaid) {
				$scope.eReceiptModel.receiptDetails = {
					amountPaid : 0
				};
			}
			$scope.value.linkedSaleAgreements = [];
			if($scope.receiptType === 'SALE'){
				$scope.value.balAmount = 0;
				if(receiptDetails.agreementNos.length > 1){
					$scope.eReceiptModel.approvedSaleAmount = 0;
					_.each(receiptDetails.chargeDetails, function(item){
						var _agrObj = receiptDetails.agreementDetails[item.referenceNo];
						var _emdAmt = 0, unAdjAmt;
						_emdAmt = _agrObj[0].receiptDetails ? _agrObj[0].receiptDetails.amountPaid : 0;
						if(item.referenceNo !== $scope.eReceiptModel.agreementNo){
							unAdjAmt = Math.round(Number(_agrObj[0].totalEMIODAmount + _agrObj[0].futurePrincipalAmount) - Number(item.amount));
							unAdjAmt = unAdjAmt < 0 ? 0 : Math.round(unAdjAmt);
							$scope.value.linkedSaleAgreements.unshift({
								agreementNo : item.referenceNo,
								emdAmt:_emdAmt,
								saleAmt: item.amount + _emdAmt,
								balAmt: item.amount,
								unAdjAmt: unAdjAmt,
								assetDetail: _agrObj[0].assetDetail ? _agrObj[0].assetDetail:{},
								disable : true
							});
						}else{
							unAdjAmt = Math.round(Number($scope.eReceiptModel.totalEMIODAmount + $scope.eReceiptModel.futurePrincipalAmount) - Number(item.amount));
							$scope.eReceiptModel.unadjustedAmount = unAdjAmt < 0 ? 0 : Math.round(unAdjAmt);
							$scope.eReceiptModel.approvedSaleAmount +=   parseInt(item.amount) + _emdAmt;
							$scope.value.balAmount = parseInt(item.amount);
							$scope.value.linkedSaleAgreements.push({isPrimary:true,emdAmt:_emdAmt,saleAmt:Number(item.amount+_emdAmt),agreementNo : item.referenceNo});
						}
					});
				}else{
					var _emdAmt = $scope.eReceiptModel.receiptDetails && $scope.eReceiptModel.receiptDetails.amountPaid ? $scope.eReceiptModel.receiptDetails.amountPaid : 0;
					$scope.eReceiptModel.approvedSaleAmount =  Number(_emdAmt) + Number($scope.receiptPostModel.Receipt.amountPaid);
				}
			}
			if(receiptDetails.buyerDetails){
				$scope.buyer = receiptDetails.buyerDetails;
				if($scope.buyer.address){
					$scope.buyer.address.pincodeDesc = $scope.buyer.address.pincode; 
					$scope.buyer.address.cityDesc = $scope.buyer.address.city;
					$scope.buyer.address.stateDesc = $scope.buyer.address.state;
				}
				$scope.buyer.panNo = receiptDetails.panNo;
				$scope.buyerStageType = ($scope.buyer.buyerType.toLowerCase() === 'individual' || $scope.buyer.buyerType.toLowerCase() === 'proprietor') ? collectionConstants.REPO_BUYER_INDIVIDUAL : collectionConstants.REPO_BUYER_CORPORATE;  
				$scope.buyer.kycDocument.imageRef.imagePathReferences = $scope.buyer.kycDocument.imageRef.imagePathReferences.splice($scope.buyer.kycDocument.imageRef.imagePathReferences.length-1);
			}else{
				eReceiptService.getBuyerName(receiptDetails.payerID).then(function(data) {
					$scope.buyer = {};
					$scope.buyer.buyerName = data.vendorName ? data.vendorName :"";
				});
			}
			$scope.buyerDetails.buyerID = receiptDetails.payerID;
			$scope.buyerDetails.buyerName = receiptDetails.payerName;
			$scope.receiptPostModel.AddressDetail.mobileNo = (getAgreementDetails.vendorDetails && getAgreementDetails.vendorDetails.phoneNo && getAgreementDetails.vendorDetails.phoneNo[0] )? getAgreementDetails.vendorDetails.phoneNo[0] : '';
		};
		var getIMDTotalOD = function(item) {
			var totalOD = 0;
			_.each(item.balanceAllocationModel, function(model) {
				totalOD += Number(_.reduce(model.charges, function(memo, num) {
					return memo + num.chargeAmount;
				}, 0));
			});
			return totalOD;
		};
		var setIMDValues = function() {
			$scope.productType = receiptDetails.productType;
			$scope.paymentMode.agreementNo = getAgreementDetails.leadID || getAgreementDetails.applicationID;
			if (receiptDetails.receiptType === 'IMD') {
				$scope.eReceiptModel.loanDetails = getAgreementDetails.relatedAgreementNos;
			}
			$scope.receiptPostModel.AddressDetail.mobileNo = receiptDetails.mobileNo;
			$scope.applicantAddress = _.findWhere($scope.applicantDetail.addressDetails, {
				isMailingAddress : true
			});
			if ($scope.applicantAddress) {
				$scope.applicantAddress.pincode = $scope.applicantAddress.pincodeDesc;
				getAddress($scope.applicantAddress);
			}
			$scope.selectedAgreement = getAgreementDetails.relatedAgreementNos[0];
			$scope.selectedAgreement.totalOD = getIMDTotalOD($scope.selectedAgreement);
			if ($scope.productType !== 'VF' && $scope.selectedAgreement.propertyDetails[0]) {
				$scope.selectedAgreement.propertyDetails[0].addressDetail.pincode = $scope.selectedAgreement.propertyDetails[0].addressDetail.pincodeDesc;
				$scope.value.propertyDetailsAddress = utility.setAddress($scope.selectedAgreement.propertyDetails[0].addressDetail);
			}
		};		
		var _type;
		var checkApprovalInitiated = function(){
			var i, _works, _approvals = ['RECEIPTCANCELLATION', 'RECEIPTMODIFICATION', 'LMSRECEIPTCANCELLATION'];
			for(i=0; i<=_approvals.length-1; i++){
				_works =  _.where(receiptDetails.workflow, {requestType : _approvals[i]});
				if(_works.length && _works[_works.length-1].workStatus !== 'APPROVED' && _works[_works.length-1].workStatus !== 'REJECTED'){
					$scope.paymentMode.hideFields = $scope.remarks.isCancelled = true;
					dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG[_approvals[i]+'_INITIATED']).result.then(function() {
					}, function() {
						if ($scope.remarks.isOffline || $state.params.type === 'cancel') {
							$globalScope.gotoPreviousPage();
						}
					});
					break;
				}
			}
		};
		  
		var initController = function() {
			$scope.remarks.value = '';
			$scope.remarks.isCancelled = receiptDetails.isCancelled;
			$scope.value.exclude = collectionConstants.CHARGES_EXCLUDE;
			$scope.remarks.isReprint = $state.params.type === "reprint";
			$scope.value.mobileNo = receiptDetails.mobileNo;
			$scope.value.collectorID = receiptDetails.collectionAgentID;
			$scope.value.isVishesh = (receiptDetails.receiptFor && (receiptDetails.receiptFor.toUpperCase() === 'VISHESHAGREEMENT' || receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN'));
			$scope.value.isPL = (receiptDetails.productType === 'PL');
			$scope.value.isTrip = (receiptDetails.receiptFor && receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN');
			if(receiptDetails.modeOfPayment === "POS" || receiptDetails.modeOfPayment === "RTGS" ){
				var _workflow = _.where(receiptDetails.workflow,{requestType : receiptDetails.modeOfPayment});
				var _rc = _.where(receiptDetails.workflow,{requestType : 'RECEIPTCANCELLATION'});
				if(_workflow.length){
					$scope.remarks.isApproved = _workflow[_workflow.length-1].workStatus === 'APPROVED';
					$scope.remarks.rejectedIndex = _workflow[_workflow.length-1].workStatus === 'REJECTED';
					$scope.remarks.isApprovalsPending = _workflow[_workflow.length-1].workStatus !== 'APPROVED';
				}
				if(_rc.length){
					$scope.remarks.reInitiateCancel = _rc[_rc.length-1].workStatus === 'REJECTED';
					$scope.remarks.cancelApproved = _rc[_rc.length-1].workStatus === 'APPROVED';
				}
			}
			$scope.remarks.isChallaned = ((receiptDetails.status && receiptDetails.status.toUpperCase() === 'CHALLANED') || $state.params.type === "reprint") || $scope.remarks.isApprovalsPending === false || $scope.remarks.cancelApproved;
			$scope.remarks.isOffline = $state.params.type === "offline";
			$scope.remarks.isDuplicateNo = (receiptDetails.validationMessage === "DUPLICATE_RECEIPT");
			$scope.receiptDate = receiptDetails.createdDate;
			$scope.receiptPostModel = (receiptDetails.receiptType === 'IMD' || receiptDetails.receiptType === 'INS-LEAD') ? eReceiptService.getIMDReceiptModel(getAgreementDetails.partyDetails) : eReceiptService.getReceiptModel(getAgreementDetails);
			$scope.receiptPostModel.Receipt.amountPaid = receiptDetails.amountPaid;
			$scope.partyType = (!receiptDetails.payerType || receiptDetails.payerType.toUpperCase() === 'APPLICANT' || receiptDetails.payerType.toUpperCase() === 'CUSTOMER') ? 'Applicant' : 'ThirdParty';
			$scope.isManualReceipt = (receiptDetails.receiptSource === 'BROWSER_MANUAL');
			var isModifiedApproved = _.findWhere(receiptDetails.workflow,{requestType:'RECEIPTMODIFICATION',workStatus : 'APPROVED'});
			$scope.value.isReceiptImgRequired = isModifiedApproved ? true : false;
			$scope.value.editManualReceipt = ($scope.isManualReceipt && receiptDetails.status === "PENDING" && !receiptDetails.isCancelled && !isModifiedApproved && $state.params.type === "cancel" && receiptDetails.receiptType === 'OD');
			$scope.value.showAgrTxt = ($scope.value.editManualReceipt && (receiptDetails.receiptType === 'OD' || receiptDetails.receiptType === 'INS' || receiptDetails.receiptType === 'NonAgreement'));
			
			setBalanceAllocationTable();
			$scope.customerFullAddress = [];
			$scope.thirdPartyFullAddress = [];
			$scope.value.disableCashMode = ((receiptDetails.receiptFor && receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN') || getAgreementDetails.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY || (getAgreementDetails.allowCashReceipt && getAgreementDetails.allowCashReceipt.toUpperCase() === 'N'));
			$scope.applicantDetail = eReceiptService.getApplicanInfo(getAgreementDetails.partyDetails, receiptDetails.receiptType);
			$scope.paymentMode = eReceiptService.getPaymentModeModel($scope.applicantDetail);
			if (receiptDetails.modeOfPayment.toLowerCase().indexOf('cheque') > -1) {
				$scope.paymentMode.modeOfPayment = 'CHEQUE';
			} else if (receiptDetails.modeOfPayment === 'DD' ) {
				$scope.paymentMode.modeOfPayment = 'DRAFT';
			}else{
				$scope.paymentMode.modeOfPayment = receiptDetails.modeOfPayment;
			}
			//If payer name and payer ID is same, it will be considered as LMS closed agreement or leap closed agreement
			$scope.paymentMode.receiptType = $scope.receiptType = (receiptDetails.receiptFor === 'ClosedAgreement' && receiptDetails.payerName.toUpperCase() === receiptDetails.payerID.toUpperCase()) ? 'closed' : receiptDetails.receiptType;
			$scope.productType = $scope.paymentMode.productType = receiptDetails.productType;
			$scope.paymentMode.disableFields = ($scope.remarks.isDuplicateNo || $scope.remarks.isChallaned && !$scope.remarks.isOffline);
			$scope.paymentMode.agreementNo = receiptDetails.receiptFor === 'NonAgreement' ? receiptDetails.payerID : getAgreementDetails.agreementNo;
			$scope.paymentMode.branchID = getAgreementDetails.branchID;
			$scope.paymentMode.isNonAgreement = (receiptDetails.receiptFor === 'NonAgreement');
			$scope.value.cancelledReceiptImageRef = receiptDetails.cancelledReceiptImageRef;
			$scope.value.partPaymentImageRef = receiptDetails.partPaymentLetter;
			if($scope.value.editManualReceipt && receiptDetails.agreementNos[0] && (receiptDetails.receiptType === 'OD' || receiptDetails.receiptType === 'INS')){
				$scope.value.isReceiptTypeChange = true;
				$scope.receiptTypes = [{id : 'OD',value:'OD'},{id : 'INS',value:'INS'}];
				$scope.value.receiptType = receiptDetails.receiptType;
			}
			eReceiptService.setChargeDetails(receiptDetails);
			eReceiptService.setManualReceiptFlag($scope.isManualReceipt);
			setPaymentValues();
			$scope.numbers = [];
			$scope.modeType = false;
			if (receiptDetails.receiptType !== 'TA') {
				$scope.applicantDetail.name = $scope.applicantDetail.firstName ? $scope.applicantDetail.firstName + ' ' : '';
				$scope.applicantDetail.name += $scope.applicantDetail.middleName ? $scope.applicantDetail.middleName + ' ' : '';
				$scope.applicantDetail.name += $scope.applicantDetail.lastName ? $scope.applicantDetail.lastName : '';
				$scope.applicantDetail.mobileNos = $scope.numbers = utility.getApplicantMobileNos(getAgreementDetails.addressDetails);
			} else {
				$scope.receiptPostModel.AddressDetail = {};
			}			
			$scope.value.enteredRemarks = receiptDetails.remarks;
			$scope.applicantAddress = {};
			if (getAgreementDetails.addressDetails && getAgreementDetails.addressDetails.length > 0) {
				var _address = _.findWhere(getAgreementDetails.addressDetails, {
					addressType : collectionConstants.CURRENT_ADDRESS
				});
				if (!_address) {
					_address = _.findWhere(getAgreementDetails.addressDetails, {
						addressType : collectionConstants.PERMANENT_ADDRESS
					});
				}
				if (!_address) {
					_address = _.findWhere(getAgreementDetails.addressDetails, {
						addressType : collectionConstants.OFFICE
					});
				}
				$scope.applicantAddress = _address || {};
			}
			
			checkApprovalInitiated();
			$scope.eReceiptModel = getAgreementDetails;
			if(getAgreementDetails.getPendingShortfallWaiver && getAgreementDetails.getPendingShortfallWaiver.length){
				$scope.eReceiptModel.waiverSplitUp = getAgreementDetails.getPendingShortfallWaiver[0].payDetails ? getAgreementDetails.getPendingShortfallWaiver[0].payDetails[0].paySplitUp : [];
				$scope.eReceiptModel.chargeDetails = getAgreementDetails.getPendingShortfallWaiver[0].chargeDetails ? getAgreementDetails.getPendingShortfallWaiver[0].chargeDetails : [];
			}
			if ($scope.receiptType === 'IMD' || $scope.receiptType === 'INS-LEAD') {
				setIMDValues();
			}else if($scope.receiptType.toUpperCase() === 'NONAGREEMENT') {
				$scope.applicantDetail.name = $scope.receiptPostModel.Receipt.payerName = receiptDetails.payerName;
				$scope.receiptPostModel.Receipt.payerID = receiptDetails.payerID;
				$scope.receiptPostModel.AddressDetail.mobileNo = receiptDetails.mobileNo;
				$scope.selectedAgreement = {
					balanceAllocationModel : [{
						chargeID : receiptDetails.chargeDetails[0].chargeID,
						chargeType : receiptDetails.chargeDetails[0].chargeType,
						actual : receiptDetails.chargeDetails[0].amount
					}]
				};
			}else{
				$scope.selectedAgreement = _.findWhere($scope.eReceiptModel.relatedAgreementNos, {
					agreementNo : receiptDetails.agreementNos[0]
				});
				$scope.selectedAgreement = eReceiptService.setAgrMaturity($scope.selectedAgreement, $scope.eReceiptModel);
			}
			
			if($scope.isManualReceipt){
				$scope.value.manRefNo = receiptDetails.manualReceiptReferenceCase;
				$scope.searchParams = {
					receiptNo : receiptDetails.receiptNo,
					receiptDate : receiptDetails.receiptEnteredTime
				};
				$scope.manualReceiptInfo = {
					allocatedUserID : receiptDetails.collectionAgentID,
					productType : receiptDetails.productType
				};				
				if($scope.value.editManualReceipt){
					$scope.receiptPostModel.Receipt.remarks = receiptDetails.remarks;
					$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement,($scope.receiptType === 'INS'));
				}
				
				if(receiptDetails.receiptImageRef && receiptDetails.receiptImageRef.imagePathReferences){
					$scope.receiptPostModel.Receipt.receiptImageRef = receiptDetails.receiptImageRef;
					$scope.value.showReceiptImg = true;
				}else{
					$scope.receiptPostModel.Receipt.receiptImageRef = {
							imagePathReferences : []
					};
				}
				$scope.value.userDetails = receiptDetails.userDetails ? receiptDetails.userDetails[0] :{};
				eReceiptService.setManualReceiptDet($scope.manualReceiptInfo);
			}
			if(!$scope.value.editManualReceipt){
				$scope.totalOD = $scope.selectedAgreement.totalActualAmount;
			}
			if ($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') {
				setEMDSaleValues();
			} else if ($scope.receiptType === 'IMD' || $scope.receiptType === 'INS-LEAD') {
				return;
			} else if ($scope.receiptType.toUpperCase() === 'NONAGREEMENT') {
				return;
			} else {
				if($scope.receiptType === 'closed'){
					$scope.eReceiptModel.agreementNo = $scope.eReceiptModel.agreementNos[0];
					$scope.eReceiptModel.customerName = $scope.eReceiptModel.payerName;
					$scope.receiptPostModel.Receipt.receiptType = receiptDetails.receiptType;
				}
				if ($scope.partyType === 'Applicant') {
					getAddress($scope.applicantAddress);
					$scope.receiptPostModel.AddressDetail.mobileNo = receiptDetails.mobileNo;
				} else {
					if (getAgreementDetails.thirdPartyDetails && getAgreementDetails.thirdPartyDetails.length > 0) {
						$scope.thirdPartyDetails = (getAgreementDetails.thirdPartyDetails[0].thirdPartyAddresses[0]) ? getAgreementDetails.thirdPartyDetails[0].thirdPartyAddresses[0] : {};
						//$scope.thirdPartyDetails.panNo = (getAgreementDetails.thirdPartyDetails[0]) ? getAgreementDetails.thirdPartyDetails[0].panNo : '';
						getAddress($scope.thirdPartyDetails);
					}
					$scope.receiptPostModel.ThirdParty.mobileNos = [];
					$scope.receiptPostModel.ThirdParty.mobileNos[0] = receiptDetails.mobileNo;
					$scope.receiptPostModel.ThirdParty.name = receiptDetails.payerName;
				}
			}
			$scope.pddData = eReceiptService.setPDDDCouments($scope.eReceiptModel);
			$scope.eReceiptModel.totalOD = totalODVal;
			$scope.selectedAgreement.isDetailsFound = $scope.selectedAgreement.isDisabled = true;
			if ($scope.receiptType === 'FORECLOSURE') {
				if ($scope.productType === 'VF' || $scope.productType === 'PL') {
					$scope.simulatedData = receiptDetails.foreClosureDetail;
					$scope.dueData = receiptDetails.foreClosureDetail.dues;
					$scope.refundData = receiptDetails.foreClosureDetail.reFunds;
					$scope.interestTillDate = new DatePickerConfig({
						value : $scope.simulatedData.closureDate
					});
					$scope.closureDate = new DatePickerConfig({
						value : $scope.simulatedData.interestTillDate
					});
				} else {
					$scope.eReceiptModel.fcDetail = $scope.eReceiptModel.foreClosureRequestDetail[$scope.eReceiptModel.foreClosureRequestDetail.length - 1];
				}
			}
			if ($scope.productType !== 'VF') {
				$scope.value.propertyDetailsAddress = utility.setAddress($scope.eReceiptModel.propertyDetail);
			}
		};
		initController();
		/**
		 * *************** Added function for manual receipt
		 * **********************************
		 */
		var updateBalanceFunction;
		$scope.showOtherOD = function(){
			if($scope.value.isVishesh){
				var obj = {
					expenseDetails : $scope.eReceiptModel.otherODCharges,
					isVishesh : true
				};
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/waiverDetails.html','detailsPopupController','sm',obj);
				return;
			}
			if(updateBalanceFunction){
				updateBalanceFunction();
			}
			updateBalanceFunction = messageBus.onMsg('UPDATE_BALANCE_TABLE',function(data,value){
				$scope.selectedAgreement.otherODCharges = value;
				$scope.selectedAgreement.showOtherODs = true;
				$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
				var otherOD = _.findWhere($scope.selectedAgreement.otherODCharges, {
					chargeID : collectionConstants.CHARGE_IDS.EXCESS
				});
				$scope.value.isOtherChargeAdded = _.findWhere($scope.selectedAgreement.otherODCharges,{chargeID : collectionConstants.CHARGE_IDS.EXCESS}) ? true : false;
				if ($scope.value.isOtherChargeAdded) {
					$scope.value.isOtherChargeEntered = (otherOD.actual > 0);
				}
			},$scope);
			// Exclude the charges detail which are available in UI
			var ODChargesList =_.reject(getchargesListResolver, function(item1){
				 return _.findWhere($scope.eReceiptModel.ODDetails,{chargeID:item1.chargeID});
			});
			eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/otherOD.html', 'otherODPopupController', 'md', {
				chargeList : ODChargesList,
				otherCharges : $scope.selectedAgreement.otherODCharges
			});
		
		};
		$scope.removeOtherCharge = function(charges,index){
			if(charges.isDefault){
				return;
			}
			$scope.selectedAgreement.totalActualAmount -= charges.actual;
			$scope.selectedAgreement.totalBalanceAmount += charges.actual;
			charges.actual = 0;
			$scope.selectedAgreement.otherODCharges.splice(index,1);
			$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
			if(charges.chargeID === collectionConstants.CHARGE_IDS.EXCESS){
				$scope.value.isOtherChargeAdded = $scope.value.isOtherChargeEntered = false;
				$scope.receiptForm.resetSubmited();
			}
		};
		
		/** check charge details **/
		$scope.checkChargeDetails = function(){
			var chargeDetails = [];
			var getChargeDetails = eReceiptService.getChargeDetails();
			_.each($scope.selectedAgreement.balanceAllocationModel,function(item){
				var data = {
						chargeID: item.chargeID,
						chargeType: item.chargeType,
						amount: item.actual,
						referenceNo: $scope.selectedAgreement.agreementNo
				};
				chargeDetails.push(data);
			});			
			$scope.value.isReceiptImgRequired =  !(_.isEqual(chargeDetails, getChargeDetails));			
		};
		/**
		 * method used to calculate the total actual amount. Trigger on focus
		 * out of the actual text box in the balance allocation table
		 */
		$scope.calculateActuals = function(item) {
			if(item.actual){
				if(!$scope.receiptPostModel.Receipt.amountPaid){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,collectionConstants.ERROR_MSG.AMOUNT_CHECK);
					item.actual = 0;
					return;
				}
				if ($scope.receiptType !== 'closed' && $scope.paymentMode.modeOfPayment === 'CASH' && item.actual > item.chargeAmount && collectionConstants.CHARGES_EXCLUDE.indexOf(item.chargeID) < 0) {
					if((item.chargeID === '240' && Number(item.actual) > Number((item.chargeAmount*0.2) + item.chargeAmount) || item.chargeID !== '240')){
						eReceiptService.showValidationMessage(item.chargeType);
						item.actual = 0;
					}
				}else if (item.actual > item.chargeAmount && $scope.receiptType !== 'EMD' && $scope.receiptType !== 'closed') {
					if($scope.paymentMode.modeOfPayment === 'CASH' && ((item.chargeID === '7' && item.actual > $scope.eReceiptModel.targetAFC) || (item.chargeID === collectionConstants.CHARGE_IDS.SHORT_FALL && $scope.receiptType === 'OD'))){
						eReceiptService.showValidationMessage(item.chargeType);
						item.actual = 0;
					}else if($scope.paymentMode.modeOfPayment === 'CASH' && item.chargeID === collectionConstants.CHARGE_IDS.EMI && item.actual > $scope.eReceiptModel.targetEMI){
						var msg = $scope.eReceiptModel.targetEMI == 0 ? "You cannot collect EMI greater than overdue amount" : 'You can collect EMI for an amount Rs.'+utility.currencyFormatter($scope.eReceiptModel.targetEMI)+' in cash';
						dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', msg);
						item.actual = 0;					
					}
					else{						
						var exclusiveCharge = _.findWhere(collectionConstants.CHARGES_MAX_LIMIT,{'chargeID':item.chargeID});
						if($scope.paymentMode.modeOfPayment === 'CASH' && exclusiveCharge && item.actual > exclusiveCharge.maxLimit){	 			
							dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', "You cannot collect more than Rs." +utility.currencyFormatter(exclusiveCharge.maxLimit)+" against " +item.chargeType + " for the month. Please collect through Cheque/DD/POS/RTGS");							
							item.actual = 0;
						}else{
							dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', 'Actual ' + item.chargeType + ' amount is greater than overdue amount');
						}
					}
				}else if(item.actual > item.chargeAmount){
					dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch',item.chargeType + ' actual amount is greater than overdue amount');
				}
			}else{
				item.actual = 0;
			}
			if(item.chargeID === collectionConstants.CHARGE_IDS.EXCESS){
				$scope.value.isOtherChargeEntered = (item.actual > 0);
			}
			eReceiptService.calculateActuals($scope.selectedAgreement);
			$scope.checkChargeDetails();
		};
		/**
		 * Reset the balance allocation table.
		 */
		$scope.doReset = function(){
			eReceiptService.resetAllocationTable($scope.selectedAgreement);
		};
		/**
		 * Balance allocation logic is here. BRD: Allocation logic-whatever
		 * amount collected should be allocated first to EMIOD, and then the
		 * balance goes to AFC, FVC, and CBC and other charge codes.
		 * 
		 * @param {Number}
		 *            is the parameter. allocation will happen based on the
		 *            priority.
		 */
		var balanceAutoAllocation = function(){
			eReceiptService.autoAllocation($scope.selectedAgreement,$scope.receiptType);
		};
		/**
		 * Trigger on change of the amount collected text box. Balance
		 * allocation will happen on change of the text box.
		 */
		$scope.getActualAmount = function(amtCol) {
			amtCol = Number(amtCol);
			if (isNaN(amtCol) ){
				balanceAutoAllocation();
				return;
			}else if($scope.receiptType === 'NonAgreement'){
				$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = amtCol;
			}else if($scope.value.isVishesh){
				//$scope.selectedAgreement.totalActualAmount = $scope.selectedAgreement.allocatedAmount = $scope.totalOD = amtCol;
				///$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.selectedAgreement.balanceAllocationModel[0].actual = amtCol;
				$scope.selectedAgreement.totalBalanceAmount = 0;
				$scope.selectedAgreement.isAllocated = true;
				//$scope.receiptPostModel.Receipt.chargeDetails[0].amount  = amtCol;
				$scope.value.isReceiptImgRequired = (amtCol !== receiptDetails.amountPaid);
				return;
			}
			$scope.value.isReceiptImgRequired = (amtCol !== receiptDetails.amountPaid);
			$scope.selectedAgreement.totalBalanceAmount = amtCol;
			$scope.selectedAgreement.allocatedAmount = amtCol;
			balanceAutoAllocation();
		};
		
		var checkImageValidation = function(){
			var str = ($scope.partyType.toUpperCase() === 'APPLICANT' || $scope.partyType.toUpperCase() === 'CUSTOMER') ? 'Applicant' : 'ThirdParty';
			$scope.value.isReceiptImgRequired = (receiptDetails.payerType !== payerType[str]
												 || $scope.paymentMode.modeOfPayment !== receiptDetails.modeOfPayment
												 || $scope.receiptPostModel.Receipt.amountPaid !== receiptDetails.amountPaid); 
		}; 
		/**
		 * Method will call on change of payer type
		 */
		$scope.payerTypeHandler = function(value){
			$scope.partyType = value;
			checkImageValidation();
			//var str = $scope.partyType = (value.toUpperCase() === 'APPLICANT' || value.toUpperCase() === 'CUSTOMER') ? 'Applicant' : 'ThirdParty';
			//$scope.value.isReceiptImgRequired = (receiptDetails.payerType !== payerType[str]); 
		};		
		var modeChangedHandler = function(value){
			$scope.paymentMode.modeOfPayment = value;
			checkImageValidation();
			$scope.value.modeType = (value !== "CASH" && receiptDetails.modeOfPayment === "CASH" );

			$timeout(function(){
				$scope.receiptForm.$dirty = true;
			});			
		};
		$scope.modeHandler = function(value){
			$scope.selectedAgreement.targetEMI = $scope.eReceiptModel.targetEMI;
			$scope.selectedAgreement.targetAFC = $scope.eReceiptModel.targetAFC;
			if(value === 'CASH' && $scope.receiptType !== 'closed' && receiptDetails.modeOfPayment !== 'CASH'){
				var _retObj = eReceiptService.cashValidation($scope.selectedAgreement, true), _msg;
				if(_retObj.messages.length>0 || _retObj.exceedMsg.length>0){
					if(_retObj.messages.length>0 && _retObj.messages.indexOf("EMI") === -1){
						_msg = "You cannot collect charges greater than overdue amount";
					}else if(_retObj.messages.length>0 && _retObj.messages.indexOf("EMI") > -1){
						_msg = $scope.selectedAgreement.targetEMI==0 ? "You cannot collect EMI greater than overdue amount":"You can collect EMI for an amount Rs." +utility.currencyFormatter($scope.selectedAgreement.targetEMI) + " in cash";
					}else if(_retObj.exceedMsg.length>0){
						_msg = "You cannot collect more than Rs." +utility.currencyFormatter(_retObj.exceedMsg[0].limit)+" against " +_retObj.exceedMsg[0].chargeType + " for the month. Please collect through Cheque/DD/POS/RTGS";
					}
				}
				if(_retObj.messages.length>0 || _retObj.exceedMsg.length>0){
					dialogService.confirm('Alert', "Alert", _msg +". Are you sure want to change the mode of payment? Click yes to reset the balance allocation table", true).result.then(function(){
						_.each(_.union($scope.selectedAgreement.balanceAllocationModel, $scope.selectedAgreement.otherODCharges), function(item){
							item.actual = 0;
						});
						modeChangedHandler(value);
						eReceiptService.calculateActuals($scope.selectedAgreement);
					}, function(){
						$scope.paymentMode.modeOfPayment = receiptDetails.modeOfPayment;
					})
					return;	
				}
			}
			modeChangedHandler(value);
		};	
		$scope.enableButton = function(_form){
			if($scope.value.editManualReceipt && !$scope.paymentMode.isNonAgreement && !$scope.value.isVishesh){				
				return (!_form.$dirty || !$scope.receiptPostModel.Receipt.amountPaid || !($scope.selectedAgreement.totalBalanceAmount===0 && $scope.selectedAgreement.isAllocated));
			}else{
				return !_form.$dirty;
			}
		};
		
		$scope.foucsHandler = function(item){
			if(parseInt(item.actual) === 0){
				item.actual = '';
			}
		};
		
		$scope.receiptChangeHandler = function(value){
			dialogService.confirm('Alert', "Alert!",collectionConstants.ERROR_MSG.RECEIPT_CHANGE_CONFIRM).result.then(function(){
				$scope.receiptType = value;
				$scope.value.isReceiptImgRequired = (value !== receiptDetails.receiptType);
				$scope.eReceiptModel = eReceiptService.setAgreementChargeDetails($scope.eReceiptModel,$scope.receiptType,$scope.productType);
				if(value === 'OD'){
					$scope.selectedAgreement = _.findWhere($scope.eReceiptModel.relatedAgreementNos,{'agreementNo': $scope.selectedAgreement.agreementNo});
				}
				$scope.selectedAgreement.balanceAllocationModel = $scope.eReceiptModel.ODDetails;
				$scope.selectedAgreement.assetDetail = $scope.eReceiptModel.assetDetail;	
				$scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.allocatedAmount = $scope.receiptPostModel.Receipt.amountPaid;
				$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement, (value === 'INS'));
				$scope.receiptForm.$dirty = true;
				},function(){
					$scope.value.receiptType = $scope.receiptType;
			});
		};
		
		/** ************************************************* */
		$scope.getAgreement = function(agreementDetails) {
			$scope.selectedAgreement.isSelected = false;
			$scope.selectedAgreement = agreementDetails;
			agreementDetails.isSelected = true;
			
			if($scope.value.editManualReceipt){
				var totalActualForAllocatedAgreement = 0;
				_.each($scope.eReceiptModel.relatedAgreementNos,function(item){
					item.allocatedAmount = item.totalActualAmount = _.reduce(_.pluck(item.balanceAllocationModel,'actual'), function(memo, num){
						return Number(memo) + Number(num); 
					}, 0);
					totalActualForAllocatedAgreement += parseInt(item.totalActualAmount);
				});
				$scope.selectedAgreement.totalBalanceAmount = ($scope.receiptPostModel.Receipt.amountPaid-totalActualForAllocatedAgreement);
				$scope.selectedAgreement.allocatedAmount += $scope.selectedAgreement.totalBalanceAmount;
				if($scope.selectedAgreement.isDetailsFound) {
					return;
				}
				eReceiptService.getAgreementDetails(agreementDetails.agreementNo,$scope.receiptType).then(function(data){
					$scope.selectedAgreement.isDetailsFound = true;
					$scope.selectedAgreement.otherODCharges = [];
					$scope.selectedAgreement = eReceiptService.setAgrMaturity($scope.selectedAgreement, data);
					var chargeAmount = 0,_charge;
					_.each(data.expenseDetails,function(expense){
						_charge = _.findWhere($scope.selectedAgreement.balanceAllocationModel,{chargeID : expense.chargeID});
						if(_charge){
							chargeAmount = Math.round(Number(expense.chargeAmount) - Number(expense.paidAmount));
							_charge.chargeAmount = (chargeAmount < 0 ) ? 0 : chargeAmount;
						}
					});
				});
			}
		};

		$scope.showLastThreeChequeDetails = function(showPartial) {
			var popUpDataObj = {};
			popUpDataObj.chequeDetails = $scope.eReceiptModel.lastThreeChequeInformation;
			popUpDataObj.isDisbursal = ($scope.eReceiptModel.disbursalStatus && $scope.eReceiptModel.disbursalStatus.toUpperCase() === collectionConstants.OTHERS.FULLY_DISBURSED);
			popUpDataObj.isAutoPopUp = showPartial;
			eReceiptService.foreClosureCheck(popUpDataObj);
		};

		var checkTotal = function(){
			var _total = 0,_balanceArr = [];
				_.each($scope.eReceiptModel.relatedAgreementNos,function(agreement){
					_balanceArr = _.pluck(agreement.balanceAllocationModel, 'actual');
					_total += _.reduce(_balanceArr, function(amt, num){
						return Number(amt) + Number(num); 
					}, 0);
				});
				if(_total > $scope.receiptPostModel.Receipt.amountPaid){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Amount allocated for linked agreement(s) should not be greater than amount collected.");
					return false;
				}
				return true;
		};
		var printReceipts = function(paramObj,isReprint){
			if($scope.value.editManualReceipt && !isReprint){
				paramObj.receiptobj.panNo = $scope.paymentMode.cash.pan;
				paramObj.receiptobj.receiptType = $scope.receiptType;
				paramObj.receiptobj.payerType = payerType[$scope.partyType];				
				paramObj.receiptobj.payerName = ($scope.partyType === 'Applicant') ? $scope.applicantDetail.name : $scope.receiptPostModel.ThirdParty.name;
				paramObj.receiptobj.mobileNo = ($scope.partyType === 'Applicant') ? $scope.receiptPostModel.AddressDetail.mobileNo.toString() : $scope.receiptPostModel.ThirdParty.mobileNos[0].toString();
				if($scope.paymentMode.modeOfPayment === "CASH" && receiptDetails.modeOfPayment !== "CASH"){
					delete $scope.receiptPostModel.Receipt.instrumentDetail;
				}
				if($scope.value.isVishesh){
					$scope.receiptPostModel.Receipt.chargeDetails = [];
					var _chargeID = $scope.eReceiptModel.productCode === 'TRIP' ? '1000000128' : '1000000128';
					$scope.receiptPostModel.Receipt.chargeDetails.push({
						chargeID : _chargeID,
						amount : $scope.receiptPostModel.Receipt.amountPaid,
						'referenceNo' : $scope.eReceiptModel.agreementNo
					});
				}
				if($scope.paymentMode.isNonAgreement){
					paramObj.receiptobj.payerID = $scope.paymentMode.agreementNo;
				}else if(receiptDetails.agreementNos[0] !== $scope.selectedAgreement.agreementNo){
					paramObj.receiptobj.payerID = $scope.applicantDetail.customerID;
				}else{
					paramObj.receiptobj.payerID =  receiptDetails.payerID;
				}
				$scope.receiptPostModel.Receipt.isPanChanged = $scope.receiptType === 'closed' ? false : $scope.paymentMode.cash.isPanChanged; // Pan  updation is not for Closed Agreement
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase =  $scope.applicantDetail.cifID ? $scope.applicantDetail.cifID.toString() : paramObj.receiptobj.payerID;
				paramObj.receiptobj.manualReceiptReferenceCase = $scope.value.manRefNo;
				eReceiptService.updateReceipt(receiptDetails, paramObj,$scope.selectedAgreement);
			}else{
				if($scope.paymentMode.modeOfPayment === "RTGS"){
					receiptDetails.chola_accountNum = $scope.paymentMode.rtgs.accountNo;
				}
				eReceiptService.modifyReceipt(receiptDetails, paramObj);
			}
		};
		var panMandatoryFunction;
		$scope.rePrint = function(isReprint) {
			if ($scope.paymentMode.modeOfPayment === 'CHEQUE' && !$scope.paymentMode.cheque.instrumentDate.value || $scope.paymentMode.modeOfPayment === 'DD' && !$scope.paymentMode.demandDraft.instrumentDate.value) {
				return;
			}
			if(!isReprint && $scope.value.isValidAgreement === false){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_AGR);
				return;
			}
			if (receiptDetails.receiptType !== 'IMD' && receiptDetails.receiptType !== 'INS-LEAD' && receiptDetails.receiptType.toUpperCase() !== 'NONAGREEMENT') {
				receiptDetails.assetDetails = [];
				if (receiptDetails.agreementNos.length > 1) {
					_.each(receiptDetails.agreementNos, function(agreementNo) {
						var receiptObj = receiptDetails.agreementDetails[agreementNo][0];
						receiptDetails.assetDetails.push(receiptObj.assetDetail);
					});
				} else {
					$scope.eReceiptModel.assetDetail = ($scope.receiptType === 'closed') ? {} : $scope.eReceiptModel.assetDetail;
					receiptDetails.assetDetails.push($scope.eReceiptModel.assetDetail);
				}
			} else {
				$scope.receiptPostModel.agreementNos = [];
				$scope.receiptPostModel.applicationNos = receiptDetails.applicationNos;
			}
			$scope.receiptPostModel = eReceiptService.setPaymentModeInfo($scope.paymentMode, $scope.receiptPostModel);
			if(!$scope.receiptPostModel.Receipt.productType){
				$scope.receiptPostModel.Receipt.productType = receiptDetails.productType;
			}
			if (paymentStr) {
				$scope.remarks.isChequeNoChanged = (receiptDetails.instrumentDetail.instrumentNo !== $scope.paymentMode[paymentStr].instrumentNo);
			}
			var noOfAgreements = receiptDetails.receiptType === 'IMD' ? receiptDetails.applicationNos.length : receiptDetails.agreementNos.length;
			var paramObj = {
				receiptobj : $scope.receiptPostModel.Receipt,
				printFlag : isReprint,
				name : $scope.applicantDetail.name,
				formObj : $scope.receiptForm,
				remarkObj : $scope.remarks,
				leadDisplayID : $scope.productType === 'VF' ? $scope.eReceiptModel.leadDisplayID : $scope.eReceiptModel.applicationDisplayID,
				msDetail : $scope.receiptType === "INS" ? _.findWhere(getAgreementDetails.insuranceDetail, {insuranceStatus : 'true'}) : {},
				isVishesh : $scope.value.isVishesh
			};
			if ($scope.receiptType === "SALE") {
				paramObj.emdAmount = $scope.eReceiptModel.receiptDetails.amountPaid;
				paramObj.saleAmount = $scope.eReceiptModel.approvedSaleAmount;
				paramObj.linkedSaleAgreements = $scope.value.linkedSaleAgreements;
			}
			if ($scope.paymentMode.modeOfPayment === "POS" || $scope.paymentMode.modeOfPayment === "RTGS") {
				paramObj.showPrintPopup = !$scope.remarks.isApprovalsPending || $scope.remarks.cancelApproved;
				paramObj.reInitiate = $scope.remarks.rejectedIndex;
			}else{
				paramObj.showPrintPopup = true;
			}
			if (noOfAgreements > 1 && !$scope.remarks.isCancelled) {
				if(checkTotal()){
					if (typeof receiptOption === "function") {
						receiptOption();
					}
					receiptOption = messageBus.onMsg('PRINT_RECEIPT', function(eve, data) {
						paramObj.printOption = data;
						printReceipts(paramObj,isReprint);
					}, $scope);

					eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/receiptOptionPopup.html', 'optionController', 'md', {
						popUpData : noOfAgreements
					});
				}
			} else {
				printReceipts(paramObj,isReprint);
			}
		};

		$scope.getVehicle = function(loan) {
			$scope.selectedAgreement.isSelected = false;
			$scope.selectedAgreement = loan;
			loan.isSelected = true;
			$scope.selectedAgreement.totalOD = getIMDTotalOD($scope.selectedAgreement);
		};
		
		var displayAlertMessage = function(_messg){
			dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, _messg).result.then(function(){
			},function(){
				$scope.paymentMode.agreementNo = receiptDetails.agreementNos[0];
			});
			return;
		};

		$scope.cancelReceipt = function() {
			var payStr = $scope.paymentMode.modeOfPayment === 'CHEQUE' ? 'cheque' : $scope.paymentMode.modeOfPayment === 'DD' ? 'demandDraft' : '';
			var imagePathReference;
			if (payStr) {
				imagePathReference = $scope.paymentMode[payStr].imageRef.imagePathReferences;
				receiptDetails.instrumentDetail = {};
				receiptDetails.instrumentDetail.imageRef = $scope.paymentMode[payStr].imageRef;
			}
			if (payStr && (!imagePathReference || !imagePathReference.length || imagePathReference[imagePathReference.length - 1].isDelete)) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.INSTRUMENT_IMG_VALIDATION);
				return;
			} else if (!$scope.value.cancelledReceiptImageRef || !$scope.value.cancelledReceiptImageRef.imagePathReferences || !$scope.value.cancelledReceiptImageRef.imagePathReferences.length) {
				dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.UPLOAD_IMG_CANCEL_RECEIPT);
				return;
			} else if (!$scope.receiptPostModel.Receipt.cancellationRemarks) {
				dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.REMARKS_TO_CANCEL);
				return;
			}
			receiptDetails.assetDetails = [];
			var leadDisplayID = $scope.productType === 'VF' ? $scope.eReceiptModel.leadDisplayID : $scope.eReceiptModel.applicationDisplayID;
			receiptDetails.assetDetails.push($scope.eReceiptModel.assetDetail);
			receiptDetails.cancelledReceiptImageRef = $scope.value.cancelledReceiptImageRef;
			receiptDetails.cancellationRemarks = $scope.receiptPostModel.Receipt.cancellationRemarks;
			receiptDetails.agreementNo = $scope.eReceiptModel.agreementNo;
			dialogService.confirm('Alert', "Alert", collectionConstants.ERROR_MSG.CANCEL_RECEIPT).result.then(function() {
				eReceiptService.cancelReceipt(receiptDetails, leadDisplayID).then(function(response) {
					if (response) {
						$scope.receiptForm.resetSubmited(true);
						$scope.remarks.isCancelled = true;
					}

				});
			}, function() {
			});
		};
		
		$scope.checkAgreementHandler = function(agreementNo){
			if(agreementNo && $scope.eReceiptModel.agreementNo !== agreementNo){
				if($scope.paymentMode.isNonAgreement){
					$scope.selectedAgreement.agreementNo = $scope.paymentMode.agreementNo;
					$scope.value.isValidAgreement = $scope.value.isReceiptImgRequired = true;
					return;
				}
				$scope.value.isValidAgreement = false;
				eReceiptService.getAgreementDetails(agreementNo,$scope.receiptType,null,null,receiptDetails.productType).then(function(data){
					if(eReceiptService.isAgreementActive(data,false,true)){
						$scope.value.isValidAgreement = true;
						if(data.agreementStatus && data.agreementStatus.toUpperCase() === 'C'){
							return displayAlertMessage("The entered agreement has been closed already, cannot proceed OD receipting");
						}else if($scope.value.isVishesh && !$scope.value.isTrip && data.productCode.toUpperCase() !== 'VISHESH'){
							return displayAlertMessage("You have entered a Loan Agreement Number. Please enter correct Vishesh ID");
						}else if($scope.value.isTrip && data.productCode.toUpperCase() !== 'TRIP'){
							return displayAlertMessage("You have entered a Loan Agreement Number. Please enter correct Trip loan Agreement No");
						}else if(!$scope.value.isVishesh && (data.productCode.toUpperCase() === 'VISHESH' || data.productCode.toUpperCase() === 'TRIP')){
							return displayAlertMessage("You cannot enter Vishesh / Trip loan agreement No. Please enter correct Loan Agreement Number");
						}else if(receiptDetails.receiptType === 'INS' && data.productGroup.toUpperCase() === "PL"){
							return displayAlertMessage("Receipt Type INS not applicable for PL agreements.");
						}												
						$scope.value.isPL = (data.productGroup.toUpperCase() == 'PL');
						$scope.value.disableCashMode = ($scope.value.isTrip || (data.allowCashReceipt && data.allowCashReceipt.toUpperCase() === 'N') || data.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY);
						if($scope.value.disableCashMode && $scope.paymentMode.modeOfPayment === "CASH"){
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.alert,"Cash mode is not allowed for this agreement. Please choose other payment mode");
							$scope.paymentMode.modeOfPayment = '';
						}
						$scope.value.isReceiptImgRequired = true;
						$scope.value.isVishesh = ($scope.value.isVishesh ||  data.productCode.toUpperCase() === 'VISHESH' || data.productCode.toUpperCase() === 'TRIP');
						$scope.eReceiptModel = eReceiptService.setAgreementChargeDetails(data,$scope.receiptType,$scope.productType);
						if($scope.value.isVishesh){
							$scope.selectedAgreement = $scope.eReceiptModel.relatedAgreementNos[0] || {};
							$scope.selectedAgreement.agreementNo = $scope.eReceiptModel.agreementNo;
							$scope.selectedAgreement.assetDetail = $scope.eReceiptModel.assetDetail;
                            var chargeDetails  = [];
                            _.each(collectionConstants[data.productCode.toUpperCase() +'_CHARGE_DETAILS'],function(oneItem){
                                chargeDetails.push({
                                    chargeType : oneItem.chargeType,
                                    chargeAmount : $scope.eReceiptModel[oneItem.chargeAmount],
                                    isLink : oneItem.isLink,
                                    actual : oneItem.actual  ? receiptDetails.amountPaid :'',
                                    chargeID : oneItem.chargeID ? oneItem.chargeID : ''
                                })
                            });

                            if(receiptDetails.receiptFor.toUpperCase() === 'TRIPLOAN'){
	                        	_.each(data.expenseDetails, function(expItem) {
									var chargeAmnt = Number(expItem.chargeAmount) - Number(expItem.paidAmount);
									if(chargeAmnt > 0){
										chargeDetails.push({
											chargeType: expItem.receiptChargeType,
											chargeAmount: chargeAmnt
										})
									}
			                    });
                        	}
                            $scope.selectedAgreement.balanceAllocationModel = chargeDetails;
						}else{
							$scope.selectedAgreement = _.findWhere($scope.eReceiptModel.relatedAgreementNos,{'agreementNo': data.agreementNo});
							$scope.selectedAgreement.balanceAllocationModel = $scope.eReceiptModel.ODDetails;
							$scope.selectedAgreement.otherODCharges = $scope.eReceiptModel.otherODCharges;
							$scope.selectedAgreement = eReceiptService.setAgrMaturity($scope.selectedAgreement,data);
						}
						$scope.receiptPostModel.Receipt.agreementNos[0] = data.agreementNo;
						$scope.receiptPostModel.Receipt.productType = data.productGroup;
						$scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.allocatedAmount = $scope.receiptPostModel.Receipt.amountPaid;
						$scope.applicantDetail = eReceiptService.getApplicanInfo(data.partyDetails, receiptDetails.receiptType);
						$scope.pddData = eReceiptService.setPDDDCouments($scope.eReceiptModel);
						if(!$scope.paymentMode.cash.pan){
							$scope.paymentMode.cash.pan = ($scope.applicantDetail) ? $scope.applicantDetail.panNo: '';
						}
						if (receiptDetails.receiptType !== 'TA') {
							$scope.applicantDetail.name = $scope.applicantDetail.firstName ? $scope.applicantDetail.firstName + ' ' : '';
							$scope.applicantDetail.name += $scope.applicantDetail.middleName ? $scope.applicantDetail.middleName + ' ' : '';
							$scope.applicantDetail.name += $scope.applicantDetail.lastName ? $scope.applicantDetail.lastName : '';
							$scope.applicantDetail.mobileNos = $scope.numbers = utility.getApplicantMobileNos(getAgreementDetails.addressDetails);
						}
						$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
					}
				});
			}else{
				$scope.value.isValidAgreement = true;
			}
		};
		
		var getForeClosureChargeType = function(expense) {
			var chargeObj;
			_.each(expense, function(charge) {
				if (charge.chargeID === collectionConstants.CHARGE_IDS.EXCESS) {
					charge.chargeType = "POS";
				} else if (charge.chargeID === collectionConstants.CHARGE_IDS.FOUR_PERCENT_POS) {
					charge.chargeType = collectionConstants.OTHERS.FC_POS_PERCENTAGE * 100 + "% POS";
				} else {
					chargeObj = _.findWhere(getchargesListResolver, {
						chargeID : charge.chargeID
					});
					charge.chargeType = chargeObj ? chargeObj.leapDescription : "";
				}
			});
			return expense;
		};

		$scope.showWaiverDetails = function(waiveAmount, productType) {
			var _obj = {};
			if (productType === 'VF' || productType === 'PL') {
				_obj.expenseDetails = getForeClosureChargeType($scope.simulatedData.chargeDetails);
			} else if (productType === 'HE' || productType === 'HL') {
				_obj.expenseDetails = getForeClosureChargeType($scope.eReceiptModel.fcDetail.waiverCharges);
			} else {
				_obj.expenseDetails = _.union($scope.eReceiptModel.ODDetails, $scope.eReceiptModel.otherODCharges);
			}
			if (waiveAmount) {
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/waiverDetails.html', 'detailsPopupController', 'sm', _obj);
			}
		};

		$scope.showSplitUp = function(isMSFlag){
			if(isMSFlag){
				eReceiptService.showMSSplitUp(receiptDetails.insuranceDetail);
			}
		};
	};

	eReceipt.controller('cancelModifyController', [ '$scope', '$state', 'eReceiptService', 'dialogService', 'getAgreementDetails', 'getBankList','getchargesListResolver', 'masterService', 'appFactory', '$globalScope', 'messageBus','$timeout','$modal', cancelModifyController ]);
	return cancelModifyController;
});