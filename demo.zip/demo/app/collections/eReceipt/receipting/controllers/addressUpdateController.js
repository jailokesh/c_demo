/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','eReceipt','collectionConstants','utility'], function(r,eReceipt,collectionConstants,utility) {
'use strict';
	/**
	 * Pop up controller for My eReceiopt Swap .
	*/
     var addressUpdateController = function($scope,$modalInstance,eReceiptService,data,messageBus,masterService,dialogService) { 
    	 $scope.partyType = 'Applicant';
    	 $scope.mobileValidation = data.mobileNoValidation;
    	 $scope.mobileNo = {};
    	 $scope.data = angular.copy(data);
  		 $scope.partyType = data.customerType;
    	 $scope.close = function(){                		
 			$modalInstance.close();
 		};
 		
 		var setAddressFields = function(_addressObj){
 			_addressObj.pincodeDesc = _addressObj.pincode;
			_addressObj.addressLine2 = _addressObj.addressLine2 ? _addressObj.addressLine2 : '';
			_addressObj.addressLine2 += _addressObj.addressLine3 ? ', '+ _addressObj.addressLine3 : '';
			if(!_addressObj.cityDesc){
				_addressObj.cityDesc = _addressObj.city;
				_addressObj.city = '';
			}
			if(!_addressObj.stateDesc){
				_addressObj.stateDesc = _addressObj.state;
				_addressObj.state = '';
			}
			return _addressObj;
 		};
 		
 		var setApplicantObj = function(_type,formObj){
 			var _obj;
 			if(formObj){
 				formObj.resetFormValidation(true);
 			}
 			if($scope.partyType === 'Applicant'){
	 			$scope.data.type = _type;
	 			_obj = angular.copy(_.findWhere(data.addressDetails,{addressType:_type})) || {};
	 			$scope.data.addressObj.AddressDetail = setAddressFields(_obj);
	 			$scope.data.addressObj.AddressDetail.addressType = _type;
 			}else{
 				_obj = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0] || {};
 				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0] = setAddressFields(_obj);
 				if($scope.data.addressObj.ThirdParty.thirdPartyAddresses && $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0] && $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].mobileNo){
 					$scope.data.addressObj.ThirdParty.mobileNos[0] = $scope.data.addressObj.ThirdParty.mobileNos[0] ? $scope.data.addressObj.ThirdParty.mobileNos[0] : $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].mobileNo;
 				}
 			}
 		};
 		$scope.addressChangeHandler = function(_type,formObj){
 			if(_type !== $scope.data.type){
	 			if(formObj.$dirty){
	 				dialogService.confirm('Warning', "Warning", collectionConstants.ERROR_MSG.CHANGES_LOST_MSG).result.then(
	 					function(){
	 						formObj.$setPristine();
	 						setApplicantObj(_type,formObj);
	 					},function(){
	 						$scope.data.addressObj.AddressDetail.addressType = $scope.data.type;
	 					}
	 				);
	 			}else{
	 				setApplicantObj(_type,formObj);
	 			}
 			}
 		};
 		$scope.getCityList=function(cityName) {
 			var _stateID;
 			if($scope.partyType === 'Applicant'){
 				_stateID = $scope.data.addressObj.AddressDetail.stateDesc ? $scope.data.addressObj.AddressDetail.state : '';
 			}else{
 				_stateID = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].stateDesc ? $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].state : '';
 			}
            return eReceiptService.getFilteredData('City', {'cityName':cityName,'limit':10,stateID:_stateID}).then(function(result) {
                return result;
            });
        };
        $scope.getStateList=function(stateName) {
            return eReceiptService.getFilteredData('State', {'stateDesc':stateName,'limit':10}).then(function(result) {
                return result;
            });
        };	
        $scope.getPincodeList=function(pincode) {
        	var _stateID,_cityID;
 			if($scope.partyType === 'Applicant'){
 				_stateID = $scope.data.addressObj.AddressDetail.stateDesc ? $scope.data.addressObj.AddressDetail.state : '';
 				_cityID = $scope.data.addressObj.AddressDetail.cityDesc ? $scope.data.addressObj.AddressDetail.city : '';
 			}else{
 				_stateID = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].stateDesc ? $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].state : '';
 				_cityID = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].cityDesc ? $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].city : '';
 			}
        	return eReceiptService.getFilteredData('CityZip', {'zipCode':pincode,'limit':10,stateID:_stateID,cityID:_cityID}).then(function(result) {
                return result;
            });
        };	
        $scope.citySelected = function(){
        	return function (item){
        		if(item){
        			var clearObj,tempStateObj,tempZipObj;
        			if($scope.partyType === 'Applicant'){
        				$scope.data.cityObject = item;
        				$scope.data.addressObj.AddressDetail.state = item.stateID;
        				$scope.data.addressObj.AddressDetail.city = item.cityID;
        				$scope.data.addressObj.AddressDetail.cityDesc = item.cityName;
        				clearObj = $scope.data.addressObj.AddressDetail;
        				tempStateObj = $scope.data.stateObject;
        				tempZipObj = $scope.data.zipObject;
        			}else{
        				$scope.data.cityObjectThirdParty = item;
        				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].state = item.stateID;
        				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].city = item.cityID;
        				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].cityDesc = item.cityName;
        				clearObj = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0];
        				tempStateObj = $scope.data.stateObjectThirdParty;
        				tempZipObj = $scope.data.zipObjectThirdParty;
        			}
        			if(!tempZipObj || !tempZipObj.cityID || tempZipObj.cityID !== item.cityID){
        				clearObj.pincodeDesc = clearObj.pincode = '';
        			}
        			if(!tempStateObj || !tempStateObj.stateID || !clearObj.stateDesc || tempStateObj.stateID !== item.stateID){
			        	return eReceiptService.getFilteredData('State', {stateID:item.stateID}).then(function(data) {
			        		tempStateObj = data[0];
			        		$scope.data.addressObj.AddressDetail.stateDesc = clearObj.stateDesc = data[0].stateDesc;
			        		clearObj.state = data[0].stateID;
			            });
        			}	
        		}
        	};
        };
        $scope.stateSelected = function(){
        	return function (item){
        		if(item){
        			var clearObject,checkObj;
        			if($scope.partyType === 'Applicant'){
        				$scope.data.stateObject = item;
        				$scope.data.addressObj.AddressDetail.state = item.stateID;
        				$scope.data.addressObj.AddressDetail.stateDesc = item.stateDesc;
        				clearObject = $scope.data.addressObj.AddressDetail;
        				checkObj = $scope.data.cityObject;
        			}else{
        				$scope.data.stateObjectThirdParty = item;
        				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].state = item.stateID;
        				$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].stateDesc = item.stateDesc;
        				clearObject = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0];
        				checkObj = $scope.data.cityObjectThirdParty;
        			}
        			if(!checkObj || !checkObj.cityID || item.stateID !== checkObj.stateID){
        				clearObject.city = clearObject.cityDesc = '';
        				clearObject.pincodeDesc = clearObject.pincode = '';
        			}
        		}
        	};
        };
 		$scope.setType = function(partyType){
 			$scope.partyType = partyType;
 			if(partyType === "Applicant"){
 				$scope.customerName = $scope.data.applicant.name;
 			}else if(partyType === "ThirdParty"){
 				$scope.customerName = $scope.data.addressObj.ThirdParty.name;
 				/*if(data.addressObj.ThirdParty.thirdPartyAddresses && data.addressObj.ThirdParty.thirdPartyAddresses[0]){
 					$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0] = data.thirdparty;
 				}
 				$scope.data.addressObj.ThirdParty.mobileNos[0] = data.thirdparty.mobileNo; */				
 			}
 			setApplicantObj($scope.data.addressObj.AddressDetail.addressType,$scope.address);
 		};
 		$scope.customerName = data.partyDetails.firstName+' '+data.partyDetails.lastName; 	
 		if(!$scope.data.addressObj.AddressDetail || !$scope.data.addressObj.AddressDetail.addressType){
 			$scope.data.addressObj.AddressDetail = !$scope.data.addressObj.AddressDetail ? {} : $scope.data.addressObj.AddressDetail;
 			$scope.data.type = $scope.data.addressObj.AddressDetail.addressType = 'CURRES';
 		}
 		//Method to get State and City 
        $scope.getStateAndCity = function() {
        	return function(item){
	    		if(item){
	    			var clearObject;
        			if($scope.partyType === 'Applicant'){
        				$scope.data.zipObject = item;
        				clearObject = $scope.data.addressObj.AddressDetail;
        			}else{
        				$scope.data.zipObjectThirdParty = item;
        				clearObject = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0];
        			}
	    			if(!$scope.data.cityObject || !$scope.data.cityObject.cityID || item.cityID !== $scope.data.cityObject.cityID ||
	    				!$scope.data.stateObject || !$scope.data.stateObject.stateID || item.stateID !== $scope.data.stateObject.stateID){
		    			masterService.getStateAndCity(item.zipCode).then(function(response) {
		    				if(response.status === "success" && response.data.City.length > 0) {
		    					if($scope.partyType === 'Applicant'){
			    					$scope.data.cityObject = response.data.City[0];
			    					$scope.data.stateObject = response.data.State[0];
		    					}else{
		    						$scope.data.cityObjectThirdParty = response.data.City[0];
			    					$scope.data.stateObjectThirdParty = response.data.State[0];
		    					}
		    					clearObject.stateDesc = (response.data.State[0]) ? response.data.State[0].stateDesc : '';
		    					clearObject.state = (response.data.State[0]) ? response.data.State[0].stateID : '';
		    					clearObject.cityDesc = (response.data.City[0]) ? response.data.City[0].cityName : '';
		    					clearObject.city = (response.data.City[0]) ? response.data.City[0].cityID : '';
		    					
		    				}else{
		    					dialogService.showAlert('info', "No Mapping found", collectionConstants.ERROR_MSG.PINCODE_NO_MAPPING);
		    					clearObject.stateDesc = clearObject.stateID = '';
		    	    			clearObject.cityDesc = clearObject.cityID = '';
		    				}
		    			});
	    			}
	    		}
        	};
        };
 		$scope.updateApplicant = function(thisObj){
 			if(!thisObj.city || !thisObj.state){ return; }
 			eReceiptService.postCustomerAddress($scope.data.partyDetails.customerID,$scope.data.addressObj.AddressDetail.mobileNo,$scope.data.addressObj).then(function(data){
 				if(data){
					$modalInstance.close();
					thisObj.pincode = thisObj.pincodeDesc;
					messageBus.emitMsg("ADDRESS",{address:thisObj,mobileNo:$scope.data.addressObj.AddressDetail.mobileNo});
 					dialogService.showAlert(collectionConstants.REPO_MSG.SUCCESS,collectionConstants.REPO_MSG.SUCCESS,collectionConstants.SUCCESS_MSG[thisObj.addressType+'_ADDRESS_SUCCESS']);
 				}
 			});
 		};
 		$scope.updateThirdParty = function(thisObj){
 			if(!thisObj.city || !thisObj.state){
 				return;
 			}
 			$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].addressType =  "Temporary";
 			$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].pincode = $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].pincodeDesc;
 			delete $scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].stateID;
 			$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].effectiveDate = new Date().toISOString();
 			$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0].mobileNo = $scope.data.addressObj.ThirdParty.mobileNos[0];
 			var obj = {
 					agreementNos : $scope.data.selectedAgreement,
					name :$scope.data.addressObj.ThirdParty.name,
					panNo : $scope.data.addressObj.ThirdParty.panNo,
					branchID : data.branchID,
					status : 'INITIATED',
					thirdPartyAddresses : [$scope.data.addressObj.ThirdParty.thirdPartyAddresses[0]],
					productGroup : $scope.data.productType
 			};
 			eReceiptService.postThirdPartyAddress(obj).then(function(data){
 				if(data && data.thirdPartyID){
 					var messg = $scope.data.productType === 'PL' ? collectionConstants.SUCCESS_MSG.THIRDPARTY_ADDRESS_SUCCESS : collectionConstants.SUCCESS_MSG.THIRDPARTY_ADDRESS_REQUEST;
 					dialogService.showAlert(collectionConstants.REPO_MSG.SUCCESS,collectionConstants.REPO_MSG.SUCCESS,messg);
					messageBus.emitMsg("THIRDPARTY",{address:obj.thirdPartyAddresses[0],name:data.name});
 				}
 				$modalInstance.close();
 			});
 		};
 		$scope.streetNameValidator = function(val) {
             if (collectionConstants.REGULAR_EXPRESSION.STREET_NAME.test(val)) {
                 return utility.getSuccessResult();
             } else {
                 return utility.getFailureResult("Invalid street name");
             }
         };
         $scope.doorNoValidator = function(val) {
             if (collectionConstants.REGULAR_EXPRESSION.DOOR_NO.test(val)) {
                 return utility.getSuccessResult();
             } else {
                 return utility.getFailureResult("Invalid door number");
             }
         };
 		$scope.setType($scope.partyType);
     };
    eReceipt.controller('addressUpdateController',['$scope','$modalInstance','eReceiptService','data','messageBus','masterService','dialogService',addressUpdateController]);
		return addressUpdateController;
	});