/**
 * Represents a EPayment Mode Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */

define([ 'require', 'eReceipt','collectionConstants'], function(require, eReceipt,collectionConstants) {
'use strict';

	var ePaymentModeController = function($stateParams, $scope,$modal,masterService,dialogService,eReceiptService,$globalScope) {	
		/**
		 * Get Bank Id, IFSC Code, Bank Name from MICR Number
		 */
		var selectedBranch,collectionSource;
		collectionSource = $scope.$parent.receiptType === 'TA' ? 'DealerPdcBankBranch' : 'BankBranch';
		$scope.imageCategory = {};
		$scope.imageCategory.chequeCategory = _.findWhere($globalScope.imageCategories,{subCategory:'cheque'});
		//$scope.imageCategory.supportDoc = _.findWhere($globalScope.imageCategories,{subCategory:'supporting documents'}); // for RTGS mail
		$scope.getAccountNo = function(bankID,banks){
			if(bankID){
				var obj = _.findWhere(banks,{bankID:bankID});
				$scope.paymentMode[$scope.paymentMode.modeOfPayment.toLowerCase()].accountNo = obj ? obj.bankACNo : '';
			}
		};
		var getRTGSBanks = function(bankID){
			var bankStr = $scope.$parent.receiptType === 'TA' ? 'DealerBank' : 'Bank';
			var _type = $scope.paymentMode.modeOfPayment.toLowerCase() === 'rtgs' ? 'B' : '';
			masterService.getBankName('',_type,bankStr).then(function(banks){
				if($scope.paymentMode.modeOfPayment.toLowerCase() === 'rtgs'){
					$scope.rtgsBankNames = banks;
					$scope.getAccountNo(bankID,$scope.rtgsBankNames);
				}else{
					$scope.posBanks = _.where(banks,{posFlag : true});
					if($scope.posBanks && $scope.posBanks.length === 1){ // If it is one bank, then it should be auto populated.
						$scope.paymentMode.pos.bankID = bankID = $scope.posBanks[0].bankID;
					}
					$scope.getAccountNo(bankID,$scope.posBanks);
				}
			});
		};
		var getPDCBankName = function(bankID,cityID,mode){
			var bankRef = $scope.$parent.receiptType === 'TA' ? "DealerPdcBank" : "PdcBank";
			masterService.getMasters(bankRef,{bankID:bankID,cityID:cityID}).then(function(banks){
				$scope.bankNames = banks;
				$scope.paymentMode[mode].bank = banks[0];
			});
		};		
		$scope.toggleHandler = function(mode){
			$scope.receiptForm.resetSubmited(true);
			$scope.paymentMode.isTAReceipt = ($scope.$parent.receiptType === 'TA');		
			if(mode === 'CASH' && !eReceiptService.validateCashLimit($scope.$parent.selectedAgreement,$scope.$parent.receiptPostModel.Receipt, $scope.$parent.productType)){
				$scope.$parent.resetAllocatedLinedAgreements();
				return;
			}
				
			if(mode === 'CHEQUE' || mode === 'DRAFT' || mode === 'RTGS'){
				if(eReceiptService.bankNames.length === 0){
					masterService.getPDCBank().then(function(data){
						eReceiptService.bankNames = $scope.bankNames = data;
					});
				}else{
					$scope.bankNames = !$scope.bankNames || !$scope.bankNames.length ? eReceiptService.bankNames : $scope.bankNames;
				}
			}
			if(mode === 'RTGS' || mode === 'POS'){
				var _bankID = mode === 'RTGS' ? $scope.paymentMode[mode.toLowerCase()].rtgsBankID : $scope.paymentMode[mode.toLowerCase()].bankID;
				getRTGSBanks(_bankID);
			}
			selectedBranch = {};
		};
		$scope.getBankBranches = function(bankObj,mode,value){
			$scope.branchNames = [];
			$scope.paymentMode[mode].ifsc = '';
			$scope.paymentMode[mode].micrNo = '';
			var strMode = mode.toLowerCase();
			if($scope.receiptForm['input_'+strMode+'_micr']){
				$scope.receiptForm['input_'+strMode+'_micr'].resetValidation();
				$scope.receiptForm['input_'+strMode+'_ifsc'].resetValidation();
			}
			if(bankObj && bankObj.bankID){
				$scope.paymentMode[mode].bankID = bankObj.bankID;
				return masterService.getBankBranches(bankObj.bankID,collectionSource).then(function(data){
					$scope.branchNames = mode === 'rtgs' ? _.where(data,{rtgsEnabled:'Y'}) : data;
				});
			}
		};
		var isRTGSEnabled = function(mode,branch,msg){
			if(mode === 'rtgs' && branch && (!branch.ifsCode || branch.rtgsEnabled !== 'Y')){
				dialogService.showAlert('alert', "Alert",collectionConstants.ERROR_MSG.RTGS_INVALID_MSG + msg).result.then(function(){},function(){
					$scope.paymentMode.rtgs.branch = "";
					$scope.paymentMode.rtgs.ifsc = "";
					$scope.paymentMode.rtgs.micrNo = "";
				});
				return false;
			}
			return true;
		};
		$scope.getIFSCFromBranch = function(selectedBranch,mode){
			if(selectedBranch){
				//selectedBranch = _.findWhere($scope.branchNames,{bBranchID:bBranchId});
				if(!isRTGSEnabled(mode,selectedBranch,"Branch")){
        	  		return;
        	  	}
				$scope.paymentMode[mode].ifsc = selectedBranch.ifsCode;
				$scope.paymentMode[mode].micrNo = selectedBranch.micrCode;
				$scope.paymentMode[mode].cityID = selectedBranch.cityID;
				$scope.paymentMode[mode].bankBranchID = selectedBranch.bBranchID;
			}
		};
		var resetFields = function(mode){
			$scope.paymentMode[mode].isValidMICR = false;
			$scope.branchNames = [];
			$scope.bankNames = eReceiptService.bankNames;
			$scope.paymentMode[mode].bank = '';
			$scope.paymentMode[mode].ifsc = $scope.paymentMode[mode].bankID = '';
		};
		$scope.getBankIdFromMICR = function(micrNo,mode){
			if(micrNo && (selectedBranch && selectedBranch.micrCode === micrNo)){
				return;
			}else if(!micrNo){
				resetFields(mode);
				return;
			}
			if($scope.paymentMode.validators.micrNo(micrNo).status === 'success'){
				masterService.getBankIdFromMICR(micrNo,collectionSource).then(function(data){
					if(!data || !data[0]){
						$scope.paymentMode[mode].bank = "";
						$scope.paymentMode[mode].bankID = $scope.paymentMode[mode].bankBranchID = $scope.paymentMode[mode].ifsc = "";
						dialogService.showAlert('alert', "Alert","Unable to find bank branch details. "+ micrNo + " is not a valid MICR code." );
	        	  		return;
	        	  	}else if(!isRTGSEnabled(mode,data[0],"MICR No")){
	        	  		return;
	        	  	}
					$scope.paymentMode[mode].isValidMICR = true;
					$scope.branchNames = data;
					selectedBranch  =  data[0];
	        	  	$scope.paymentMode[mode].bankID = selectedBranch.bankID;
	        	  	$scope.paymentMode[mode].branch = selectedBranch;
	        	  	$scope.paymentMode[mode].bankBranchID = selectedBranch.bBranchID;
	        	  	$scope.paymentMode[mode].ifsc = selectedBranch.ifsCode;
	        	  	$scope.paymentMode[mode].cityID = selectedBranch.cityID;
	        	  	getPDCBankName(selectedBranch.bankID,selectedBranch.cityID,mode);
	            });
			}else{
				resetFields(mode);
			}
		};
		
		$scope.showSignPopup = function() {
			eReceiptService.getPDDDetail($stateParams.agreementNo).then(function(response){	
				if (response){
					eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/verifySignPopup.html','verifySignPopupController','md',{
						popUpData : response
					});
				}
			});
		};
		
		/**
		 * Get BankID, Bank Name from IFSC Code
		 */
		$scope.getBankIdFromIFSC = function(ifscNo,mode){
			if(!ifscNo || (selectedBranch && selectedBranch.ifsCode === ifscNo)){
				return;
			}
			if($scope.paymentMode.validators.ifscCode(ifscNo).status === 'success'){
				masterService.getBankIdFromIFSC(ifscNo,collectionSource).then(function(data){
					if(!data[0] || data[0].length === 0){
						$scope.paymentMode[mode].bankID = $scope.paymentMode[mode].bankBranchID = $scope.paymentMode[mode].micrNo = "";
	        	  		$scope.paymentMode[mode].isValidMICR = false;
	        	  		dialogService.showAlert('alert', "Alert","Unable to find bank branch details. "+ ifscNo + " is not a valid IFSC code." );
	        	  		return;
	        	  	}else if(!isRTGSEnabled(mode,data[0],"IFSC Code")){
	        	  		return;
	        	  	}
					selectedBranch  =  data[0];
					$scope.branchNames = data;
					$scope.paymentMode[mode].branch = selectedBranch;
					$scope.paymentMode[mode].bankBranchID = selectedBranch.bBranchID;
        	  		$scope.paymentMode[mode].bankID = selectedBranch.bankID;
        	  		$scope.paymentMode[mode].micrNo = selectedBranch.micrCode;
        	  		$scope.paymentMode[mode].isValidMICR = true;
        	  		$scope.paymentMode[mode].cityID = selectedBranch.cityID;
        	  		getPDCBankName(selectedBranch.bankID,selectedBranch.cityID,mode);
				});
			}else{
				$scope.paymentMode[mode].isValidMICR = false;
				$scope.branchNames = [];
				$scope.paymentMode[mode].bank = $scope.paymentMode[mode].micrNo = $scope.paymentMode[mode].bankID = '';
			}
		};
		
		$scope.validatePanHandler = function(panNo){
			var checkPanNo;
			if($scope.$parent.partyType === 'Applicant' && $scope.$parent.applicantDetail){
				checkPanNo =  $scope.$parent.applicantDetail.panNo;
			}else if($scope.$parent.partyType === 'ThirdParty' && $scope.$parent.thirdPartyDetails){
				checkPanNo =  $scope.$parent.thirdPartyDetails.panNo;
			}
			if(checkPanNo && checkPanNo === panNo && !$scope.paymentMode.cash.isPanChanged){
				$scope.paymentMode.cash.isValidPan = true;
				$scope.paymentMode.cash.isPanChanged = false;
				return;
			}
			var actionResult = $scope.paymentMode.validators.panNo(panNo);
			if(actionResult.status === 'success'){
				$scope.paymentMode.cash.isValidPan = true;
				if($scope.$parent.partyType === 'Applicant'){
					$scope.$parent.applicantDetail.panNo = panNo;
				}else{
					$scope.$parent.thirdPartyDetails.panNo = panNo;
				}
			    $scope.paymentMode.cash.isPanChanged = true;
			}
		};
		
		var init = function(){
			var bankID,bankBranchID,mode;
			if($scope.$parent.isCancelModify && !$scope.$parent.isCancelAck){
				if($scope.paymentMode.modeOfPayment === 'CASH'){
					return;
				}else if($scope.paymentMode.modeOfPayment === 'RTGS'|| $scope.paymentMode.modeOfPayment === 'POS'){
					getRTGSBanks($scope.paymentMode.rtgs.rtgsBankID || $scope.paymentMode.pos.bankID);
				}
				if($scope.paymentMode.modeOfPayment === 'CHEQUE' || $scope.paymentMode.modeOfPayment === 'CHEQUE-NON-MICR'){
					mode = 'cheque';
				}else if($scope.paymentMode.modeOfPayment=== 'DRAFT' || $scope.paymentMode.modeOfPayment=== 'DD'){
					mode = 'demandDraft';
				}else if($scope.paymentMode.modeOfPayment=== 'RTGS' || $scope.paymentMode.modeOfPayment === 'POS'){
					mode = $scope.paymentMode.modeOfPayment.toLowerCase();
				}
				if(mode === 'cheque' || mode === 'demandDraft' || mode === 'rtgs'){
					bankID = $scope.paymentMode[mode].bankID;
					bankBranchID = $scope.paymentMode[mode].bankBranchID;
					$scope.branchNames = [$scope.paymentMode[mode].branch];
					$scope.paymentMode[mode].ifsc = ($scope.paymentMode[mode].branch) ? $scope.paymentMode[mode].branch.ifsCode : '';
					$scope.paymentMode.isTAReceipt = ($scope.$parent.receiptType === 'TA');
					$scope.bankNames = eReceiptService.bankNames;
					if(mode !== 'rtgs'){
						$scope.paymentMode[mode].bank = _.findWhere($scope.bankNames,{bankID : $scope.paymentMode[mode].bank.bankID,name : $scope.paymentMode[mode].bank.name});
					}else{
						$scope.paymentMode[mode].bank = _.findWhere($scope.bankNames,{bankID : $scope.paymentMode[mode].bankID});
					}
				}
			}else if($scope.$parent.receiptType === 'IMD' && $scope.$parent.productType){
				if($scope.paymentMode.modeOfPayment === 'CHEQUE'){
					mode = 'cheque';
				}else if($scope.paymentMode.modeOfPayment=== 'DRAFT' || $scope.paymentMode.modeOfPayment=== 'DD'){
					mode = 'demandDraft';
				}else if($scope.paymentMode.modeOfPayment === 'RTGS' || $scope.paymentMode.modeOfPayment === 'POS'){
					mode = $scope.paymentMode.modeOfPayment.toLowerCase();
					getRTGSBanks($scope.paymentMode.rtgs.rtgsBankID || $scope.paymentMode.pos.bankID);
				}
				if(mode && $scope.paymentMode[mode].bankBranchID){
					return masterService.getMasters('BankBranch', {'bBranchID' : $scope.paymentMode[mode].bankBranchID}).then(function(branches){
						$scope.branchNames = branches;
						if(branches.length){
							selectedBranch = branches[0];
							$scope.paymentMode[mode].bankID = selectedBranch.bankID;
							$scope.paymentMode[mode].ifsc = selectedBranch.ifsCode;
							$scope.paymentMode[mode].micrNo = selectedBranch.micrCode;
							$scope.paymentMode[mode].branch = selectedBranch;
							getPDCBankName(selectedBranch.bankID,selectedBranch.cityID,mode);
						}
					});
				}else{
					if(eReceiptService.bankNames.length === 0){
						masterService.getPDCBank().then(function(data){
							eReceiptService.bankNames = $scope.bankNames = data;
						});
					}else{
						$scope.bankNames = eReceiptService.bankNames;
					}
				}
			}
		};
		
		$scope.showSignature = function(parentObj){
			eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/verifySignPopup.html','verifySignPopupController','sm',{popUpData : parentObj.partyDetails});
		};
		$scope.pasteHandler = function(event){
			if(event.clipboardData){
				var item = event.clipboardData.items[0];
				item.getAsString(function(data){
					$scope.paymentMode.rtgs.micrNo  = data;
				});
			}
		};
		init();
	};
	eReceipt.controller('ePaymentModeController', [ '$stateParams', '$scope','$modal','masterService','dialogService','eReceiptService','$globalScope',ePaymentModeController ]);
	return ePaymentModeController;
});