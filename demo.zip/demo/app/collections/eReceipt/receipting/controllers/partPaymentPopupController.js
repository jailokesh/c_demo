define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';
	/**
	 * Pop up controller for details .
	 */
	var partPaymentPopupController = function($scope, $modalInstance, messageBus, eReceiptService, data, dialogService, $globalScope, $state) {
		$scope.accountType = "";
		$scope.uploadedContent = "";
		$scope.paymentType = "";
		$scope.paymentMode = data.paymentMode;
		$scope.postModel = data.postModel;
		$scope.postModel.partPaymentLetter = '';
		$scope.data = {};
		$scope.categoryDetails = _.findWhere($globalScope.imageCategories, {subCategory : 'Part Payment Letter'}) || {};
		$scope.data.partpayAmount = Math.round(eReceiptService.data.principalOS);
		$scope.data.maxPartpayAmount = Math.round($scope.data.partpayAmount * collectionConstants.OTHERS.PART_PAY_PERCENTAGE);
		$scope.setAccountType = function(accountType) {
			if (accountType) {
				messageBus.emitMsg('PART_ADVANCE_ACCOUNT_TYPE', accountType);
				$modalInstance.dismiss();
				if ($scope.paymentMode.receiptType === "PART PAYMENT") {
					eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/uploadScannedCopyPopup.html', 'partPaymentPopupController', 'md', {
						postModel : $scope.postModel,
						paymentMode : $scope.paymentMode
					});
				}
			}
		};

		$scope.setReductionType = function(reductionType,amount) {
			if (reductionType) {
				eReceiptService.data.reductionType = reductionType;
				messageBus.emitMsg('PART_PAY_SUCCESS', amount);
				$modalInstance.dismiss();
			}
		};

		$scope.close = function() {
			dialogService.confirm('Alert', "Alert", collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function() {
				$modalInstance.dismiss();
				messageBus.emitMsg('CLOSE_PART_PAY');
			}, function() {
			});
		};

		$scope.redirect = function() {
			$modalInstance.dismiss();
		};
		
		$scope.generateLetter = function(reductionType,amount){
			if(reductionType && amount){
				$scope.data.flag = false;
				var reqObj = {
					/*loanType : "Part Payment",
					paymentMode : reductionType*/
					amountPaid : amount
	 			};
				eReceiptService.getLetterPreview($state.params.agreementNo,reqObj);
			}else{
				$scope.data.flag = true;
			}
		};
	};
	eReceipt.controller('partPaymentPopupController', [ '$scope', '$modalInstance', 'messageBus', 'eReceiptService', 'data', 'dialogService', '$globalScope', '$state', partPaymentPopupController ]);
	return partPaymentPopupController;
});