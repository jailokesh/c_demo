/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','eReceipt','messageBus','collectionConstants'], function(r,eReceipt,messageBus,collectionConstants) {
'use strict';
	
	/**
	 * Pop up controller for My eReceiopt Swap .
	*/
     var swapPopupController = function($scope,$modalInstance,$modal,$state,messageBus,$stateParams,data) {
    	$scope.type = data.rpdcData;
    	var isCloseFlag;
    	$scope.close = function() {
    		isCloseFlag = true;
            if($scope.type === 'info'){
            	messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.SWAP_OPTION,{option:'cancel'});
            }else{
            	messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.SWAP_OPTION,{option:'later'});
            }
            $modalInstance.dismiss();
        };
        $scope.clickHandler = function(){
        	isCloseFlag = true;
        	if($scope.type === 'info'){
        		messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.SWAP_OPTION,{option:'agreed'});
        	}else if($scope.type === 'submit'){
        		messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.SWAP_OPTION,{option:'receipt'});
        	}
 			$modalInstance.dismiss();
 		};
 		
 		$modalInstance.result.then(function(){},function(){
	       	if(!isCloseFlag){
	       		 $scope.close();
	       	}
        });
     };
    eReceipt.controller('swapPopupController',['$scope','$modalInstance','$modal','$state','messageBus','$stateParams','data',swapPopupController]);
	return swapPopupController;
});