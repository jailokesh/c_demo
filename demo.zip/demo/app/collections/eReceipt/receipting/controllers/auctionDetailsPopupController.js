/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
    'use strict';
    
        /**
         * Pop up controller for My eReceiopt Swap .
         */
        var auctionDetailsPopupController = function($scope, $modalInstance, $modal, $state, data, messageBus) {
            if( data.popUpData.auctions.length == 0){
                $scope.auctions = {
                    quotes : []
                }
            } else{
                $scope.auctions = data.popUpData.auctions;
            }
            $scope.approvedSaleAmount = data.popUpData.approvedSaleAmount;
            $scope.buyerID = data.popUpData.buyerID;
            $scope.currentStage = data.popUpData.currentStage;
            $scope.close = function() {
                $modalInstance.dismiss();
            };
    
        };
        eReceipt.controller('auctionDetailsPopupController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus', auctionDetailsPopupController ]);
        return auctionDetailsPopupController;
    });