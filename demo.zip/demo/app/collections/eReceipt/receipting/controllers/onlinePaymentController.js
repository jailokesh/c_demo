define([ 'require', 'eReceipt', 'collectionConstants', 'utility' ], function(r, eReceipt, collectionConstants, utility) {
	'use strict';

	/**
	 * Pop up controller for details .
	 */
	var onlinePaymentController = function($scope, $state, eReceiptService, environmentConfig, $globalScope,$timeout,$rootScope,dialogService) {
		var template;
		$scope.value = {};
		$scope.value.isOnline = false;
		$scope.alphabets = angular.copy(collectionConstants.ALPHABETS);
		var failureResponse = function(failure_response) {
			$timeout(function() {
				$scope.value.isSuccess = false;
				$scope.value.failureDeatils = failure_response ? failure_response : "";
			}, 100);	
		};
		$scope.returnToReceipt = function() {
			// set the back state after came back from tech process page
			$globalScope.stateStack[0] = {
				name : $state.get('collections.receipt.eReceipt'),
				params : ""
			};
			eReceiptService.returnToReceipt($scope.value.failureDeatils.transactionIdentifier).then(function(response) {
				$state.go('collections.ePayment', {
					agreementNo : response.agreementNos[0],
					receiptType : response.receiptType
				});
			});
		};

		$scope.cancelHandler = function() {
			$state.go('collections.receipt.eReceipt');
		};

		var receiptPrintDetails = function(response) {
			$scope.value.requestPage = 'app/collections/eReceipt/receipting/partials/receipt/' + template;
			$scope.receiptDetails = response;
			$scope.receiptDetails.branchID = JSON.parse(getCookie('selectedBranch')).branchDesc;
			$scope.receiptDetails.payerType = $scope.receiptDetails.payerType ? $scope.receiptDetails.payerType.toUpperCase() : $scope.receiptDetails[0].payerType.toUpperCase();
			$scope.receiptDetails.amountInwords = utility.numberIntoWords($scope.receiptDetails.amountPaid) + " Only";
			$scope.receiptDetails.partPayCharges = collectionConstants.OTHERS.PART_PAY_CHARGES;
			$scope.receiptDetails.agreements = [];
			$scope.additionString = '';
			$scope.agreementTotal = [];
			$scope.receiptDetails.assetDetails = [];
			if ($scope.receiptDetails.agreementNos.length > 1) {
				$scope.alphabets.splice($scope.receiptDetails.agreementNos.length, $scope.alphabets.length);
				_.each($scope.alphabets, function(item, index) {
					$scope.additionString += (index === 0) ? item : '+' + item;
					$scope.receiptDetails.agreements.push({
						agreementNo : $scope.receiptDetails.agreementNos[index],
						chargeDetails : []
					});
				});
			} else {
				$scope.receiptDetails.agreements.push({
					agreementNo : $scope.receiptDetails.agreementNos[0],
					chargeDetails : []
				});
			}
			_.each($scope.receiptDetails.agreementNos, function(item, index) {
				$scope.agreementTotal.push(0);
				var _assetDetails = $scope.receiptDetails.assetDetail ? $scope.receiptDetails.assetDetail[item] : '';
				if (_assetDetails) {
					$scope.receiptDetails.assetDetails.push(_assetDetails.assetDetail);
				}
				_.each($scope.receiptDetails.chargeDetails, function(data) {
					if (item === data.referenceNo) {
						$scope.agreementTotal[index] += parseInt(data.amount);
						$scope.receiptDetails.agreements[index].chargeDetails.push({
							chargeType : data.chargeType,
							amount : data.amount
						});
					}
				});
				if ($scope.receiptDetails.receiptType === 'SALE') {
					var _agrObj, _emdAmt, chargeObj, saleAmt;
					_agrObj = $scope.receiptDetails.agreementDetails[item];
					_emdAmt = _agrObj[0].receiptDetails ? _agrObj[0].receiptDetails.amountPaid : 0;
					chargeObj = _.findWhere($scope.receiptDetails.chargeDetails, {
						referenceNo : item
					});
					saleAmt = chargeObj.amount;
					// single agreement sale and emd amount will refer from
					// receipt details,for multiple agreement it will refer from
					// agreements array.
					$scope.receiptDetails.saleAmount = $scope.receiptDetails.agreements[index].saleAmount = saleAmt;
					$scope.receiptDetails.emdAmount = $scope.receiptDetails.agreements[index].emdAmount = _emdAmt;
				}

				$scope.receiptDetails.agreements[index].amountInwords = utility.numberIntoWords($scope.agreementTotal[index]) + " Only";
			});
		};
		function cancelResponse(responseObj){
			eReceiptService.createOnlineReceipt(responseObj).then(function(response) {
				failureResponse(response);
			});
		}
		function handleResponse(techResponse) {
			var responseObj = {
					statusCode : techResponse.paymentMethod.paymentTransaction.statusCode,
					statusMessage : techResponse.paymentMethod.paymentTransaction.statusMessage,
					techProcess : techResponse
			},_rctType;
			if (typeof techResponse !== 'undefined' && typeof techResponse.paymentMethod !== 'undefined' && typeof techResponse.paymentMethod.paymentTransaction !== 'undefined' && typeof techResponse.paymentMethod.paymentTransaction.statusCode !== 'undefined' && techResponse.paymentMethod.paymentTransaction.statusCode === '0300') {				
				eReceiptService.createOnlineReceipt(responseObj).then(function(response) {
					if (response) {
						$scope.value.isSuccess = true;
						if (response.agreementNos.length > 1) {
							eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/receiptOptionPopup.html', 'optionController', 'md', {
								popUpData : response.agreementNos.length
							}).result.then(function(data) {
								_rctType = response.receiptType === 'INS' && response.applicationNos[0] ? 'INS-LEAD' : response.receiptType;
								template = eReceiptService.getReceiptTemplate(_rctType, data);
								receiptPrintDetails(response);
							});
						} else {
							_rctType = response.receiptType === 'INS' && response.applicationNos.length ? 'INS-LEAD' : response.receiptType;
							template = eReceiptService.getReceiptTemplate(_rctType);
							if (response.productType === 'VF' && (_rctType === 'IMD' || _rctType === 'INS-LEAD')) {
								response.agreementNos = response.applicationNos;
								if(_rctType === 'IMD'){
									eReceiptService.updateLeadForOnline(response).then(function(data) {
										receiptPrintDetails(response);
									});
									return;
								}
							}
							receiptPrintDetails(response);
						}
					} else {
						failureResponse(response);
					}
				});
			} else {
				cancelResponse(responseObj);
			}
		}
		
		function initController() {
			var responseStr = window.location.hash || window.location.search;			
			if (responseStr.indexOf('txthdntpslmrctcd=') > -1 && responseStr.indexOf('txthdnMsg=') > -1) {
				new Card({
					'tarCall' : true,
					'features' : collectionConstants.ONLINE_PAYMENT_FEATURES,
					'consumerData' : {
						'deviceId' : 'Web',
						'authKey' : environmentConfig.authKey,
						'returnUrl' : window.location.origin + window.location.pathname + "#/eReceipt/onlinePayment",
						'responseHandler' : handleResponse,
						'paymentMode' : 'all'
					}
				}).init();
			}
		}
		initController();
		
		$scope.printHandler = function(isReprint) {
			if(isReprint){
				eReceiptService.rePrintReceipt($scope.receiptDetails.receiptNo,{'minorVersion':$scope.receiptDetails.minorVersion,'majorVersion':$scope.receiptDetails.majorVersion}).then(function(data){
					if(data.printCount){
						$scope.receiptDetails.printCount++;
						$scope.receiptDetails.minorVersion = data.minorVersion;
						$scope.receiptDetails.majorVersion = data.majorVersion;
						$scope.receiptDetails.currentDateTime = data.currentDateTime; 
					}
				});
			}else{
				$timeout(function(){
					$scope.isReprint = true;
				},300);
			}
		};

		$scope.close = function() {
			if ($scope.isReprint) {
				$scope.cancelHandler();
			} else if ($rootScope.enablePrint) {
				dialogService.confirm('Confirm', "Confirm!", collectionConstants.ERROR_MSG.PRINT_CONFIRMATION).result.then(function() {
					$scope.cancelHandler();
				}, function() {
				});
			} else {
				$scope.cancelHandler();
			}
		};
	};
	eReceipt.controller('onlinePaymentController', [ '$scope', '$state', 'eReceiptService', 'environmentConfig', '$globalScope', '$timeout','$rootScope','dialogService', onlinePaymentController ]);
	return onlinePaymentController;
});