/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';

	/**
	 * Pop up controller for My eReceiopt Swap .
	 */
	var foreClosurePopupController = function($scope, $modalInstance, $modal, $state, data, messageBus) {
		$scope.chequeDetails = data.popUpData.chequeDetails;
		$scope.isPartialDisbursement = data.popUpData.isDisbursal;
		$scope.isValidityExpired = data.popUpData.isValidityExpired;
		$scope.isForeclosed = data.popUpData.isForeclosed;
		$scope.isAutoPopUp = data.popUpData.isAutoPopUp;
		$scope.isPending = false;
		_.each($scope.chequeDetails, function(item) { // Checking only if status in PENDING
			if (item.instrumentDetail.status && item.instrumentDetail.status.toUpperCase() === "PENDING") {
				$scope.isPending = true;
			}
		});
		var isCloseFlag;
		$scope.close = function() {
			isCloseFlag = true;
			var flag = ($scope.isPending || !$scope.isPartialDisbursement || $scope.isValidityExpired || $scope.isForeclosed);
			if (($scope.isAutoPopUp) && flag) {
				messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.CANNOT_FORECLOSE);
			}
			$modalInstance.dismiss();
		};

		$modalInstance.result.then(function() {
		}, function() {
			if (!isCloseFlag){
				$scope.close();
			}
		});
	};
	eReceipt.controller('foreClosurePopupController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus', foreClosurePopupController ]);
	return foreClosurePopupController;
});