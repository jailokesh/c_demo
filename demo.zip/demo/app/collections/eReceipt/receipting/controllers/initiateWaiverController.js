define([ 'require', 'eReceipt', 'constants', 'collectionConstants' ], function(r, eReceipt, constants, collectionConstants) {
	'use strict';

	var initiateWaiverController = function($scope, $modalInstance, $modal, eReceiptService, lazyModuleLoader, dialogService, data, $globalScope) {
		$scope.caseDetailInfo = angular.copy(data.caseDetailInfo);
		var total = {
			receiptChargeType : 'TOTAL',
			actualAmount : 0,
			waiverAmount : 0,
			percentage : 0,
			netWorking : 0
		};
		if (($scope.caseDetailInfo.productType === 'HE' || $scope.caseDetailInfo.productType === 'HL') && $scope.caseDetailInfo.receiptType === 'FORECLOSURE') {
			$scope.caseDetailInfo.expenseDetails.push({
				chargeAmount : Math.round($scope.caseDetailInfo.principalOS),
				paidAmount : 0,
				chargeID : collectionConstants.CHARGE_IDS.EXCESS,
				receiptChargeType : 'POS'
			});
			$scope.caseDetailInfo.expenseDetails.push({
				chargeAmount : Math.round($scope.caseDetailInfo.principalOS * collectionConstants.OTHERS.FC_POS_PERCENTAGE),
				paidAmount : 0,
				chargeID : collectionConstants.CHARGE_IDS.FOUR_PERCENT_POS,
				receiptChargeType : collectionConstants.OTHERS.FC_POS_PERCENTAGE*100 + '% POS'
			});
		}
		
		var i, charge, differenceAmt;
		for (i = $scope.caseDetailInfo.expenseDetails.length - 1; i >= 0; i--) {
			charge = $scope.caseDetailInfo.expenseDetails[i];
			charge.waiverAmount = charge.waiverAmount ? charge.waiverAmount : 0;
			differenceAmt = Math.round(Number(charge.chargeAmount) - Number(charge.paidAmount)); 
			charge.netWorking = charge.actualAmount = differenceAmt > 0 ? differenceAmt : 0;
			charge.waiverAmount = charge.percentage = 0;
			if(charge.receiptChargeType && charge.receiptChargeType.toUpperCase() !== "EXCESS REFUNDS"){
				total.actualAmount += charge.actualAmount;
				total.netWorking += charge.netWorking;
			}else{
				total.actualAmount -= charge.actualAmount;
				total.netWorking -= charge.netWorking;
			}
			if (charge.actualAmount <= 0) {
				$scope.caseDetailInfo.expenseDetails.splice(i, 1);
			}
		}
		$scope.caseDetailInfo.expenseDetails.push(total);
		
		$scope.requestBody = {};
		$scope.close = function(waiverForm) {
			if (waiverForm.$dirty && $scope.caseDetailInfo.expenseDetails.length > 1) {
				dialogService.confirm('Confirm', "Confirm!", collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function() {
					$modalInstance.dismiss();
				}, function() {
				});
			} else {
				$modalInstance.dismiss();
			}
		};

		var roundOffValue = function(dividend, divisor) {
			if (!parseInt(dividend)) {
				return '0';
			}
			var roundedVal = ((parseInt(dividend) / parseInt(divisor)) * 100);
			roundedVal = roundedVal.toFixed(2);
			return {displayVal : (roundedVal !== '0.00' && !parseInt(roundedVal) ? '< 1%' : roundedVal + '%'),actualVal : roundedVal};
		};

		$scope.computePercent = function(charge) {
			if (!charge.waiverAmount) {
				charge.waiverAmount = 0;
			}
			if (parseInt(charge.waiverAmount) > charge.actualAmount) {
				dialogService.showAlert('Error', "Error!", "Waiver Amount cannot be greater than the due amount!");
				charge.waiverAmount = charge.actualAmount;
			}
			var _obj = roundOffValue(charge.waiverAmount, charge.actualAmount);
			charge.percentage = charge.waiverAmount ? _obj.displayVal : 0;
			charge.actualPercentage = _obj.actualVal;
			charge.netWorking = charge.waiverAmount ? charge.actualAmount - charge.waiverAmount : charge.actualAmount;
			var total = $scope.caseDetailInfo.expenseDetails[$scope.caseDetailInfo.expenseDetails.length - 1];
			total.waiverAmount = 0;
			for (var index = 0; index < $scope.caseDetailInfo.expenseDetails.length - 1; index++) {
				total.waiverAmount += $scope.caseDetailInfo.expenseDetails[index].waiverAmount ? parseInt($scope.caseDetailInfo.expenseDetails[index].waiverAmount) : 0;
			}
			_obj = roundOffValue(total.waiverAmount, total.actualAmount);
			total.percentage = total.waiverAmount ? _obj.displayVal : 0;
			total.netWorking = total.waiverAmount ? (total.actualAmount - total.waiverAmount) : total.netWorking;
		};

		$scope.initiateWaiver = function() {
			$scope.caseDetailInfo.showError = ($scope.caseDetailInfo.receiptType !== 'FORECLOSURE' && !$scope.requestBody.collectionType);
			if(!$scope.caseDetailInfo.showError){
				$scope.requestBody.agreementNos = [ $scope.caseDetailInfo.agreementNo ];
				$scope.requestBody.receiptNo = $scope.caseDetailInfo.receiptNo;
				$scope.requestBody.waiverType = $scope.caseDetailInfo.receiptType === 'FORECLOSURE' ? collectionConstants.APPROVALS_INIT_PAGE.foreclosureWaiver.requestType : collectionConstants.APPROVALS_INIT_PAGE.normalWaiver.requestType;
				$scope.requestBody.status = constants.REQUEST_STATUS.INITIATED.toUpperCase();
				$scope.requestBody.chargeDetails = [];
				$scope.requestBody.branchID = $scope.caseDetailInfo.branchID;
				if(data.details){
					$scope.requestBody.foreClosureLADetails = {
						linkedAgreements : data.details.agreementWithOD,
						agreementNo : $scope.caseDetailInfo.agreementNo,
						justification : data.details.reason,
						branchID : $scope.caseDetailInfo.branchID,
						requestType: "WAIVER",
						productGroup: $scope.caseDetailInfo.productType
					};
				}
				_.each($scope.caseDetailInfo.expenseDetails, function(charge) {
					if (charge.receiptChargeType !== 'TOTAL' && (($scope.caseDetailInfo.receiptType === 'FORECLOSURE' &&  $scope.caseDetailInfo.productType === 'VF') ||  parseInt(charge.waiverAmount))) {
						var chargeObj = _.findWhere($scope.requestBody.chargeDetails,{chargeID : charge.chargeID}); //checking if charge is already present in the array.
						if(chargeObj){
							chargeObj.actualAmount += parseInt(charge.actualAmount);
							chargeObj.waiverAmount += parseInt(charge.waiverAmount);
							var roundedVal = ((parseInt(chargeObj.waiverAmount) / parseInt(chargeObj.actualAmount)) * 100);
							chargeObj.waiverPercentage = Number(roundedVal.toFixed(2));
						}else{
							chargeObj = {};
							chargeObj.chargeID = charge.chargeID;
							chargeObj.actualAmount = parseInt(charge.actualAmount);
							chargeObj.waiverAmount = parseInt(charge.waiverAmount);
							chargeObj.waiverPercentage = Number(charge.actualPercentage)  || 0;
							$scope.requestBody.chargeDetails.push(chargeObj);
						}
					}
				});
				var _totalWaiver = _.reduce($scope.requestBody.chargeDetails, function(memo, item){
					return Number(memo) + Number(item.waiverAmount); 
				}, 0);
				
				if (!$scope.requestBody.chargeDetails.length || !_totalWaiver) {
					dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, "Cannot initiate request for zero waiver amount!");
					return;
				}
				eReceiptService.initiateRequest($scope.requestBody).then(function(response) {
					if (response && response.DataInserted) {
						dialogService.showAlert('Success', constants.ERROR_HEADER.success, collectionConstants.ERROR_MSG.WAIVER_INITIATED).result.then(function() {
						}, function() {
							if($scope.caseDetailInfo.receiptType === 'FORECLOSURE'){
								$globalScope.gotoPreviousPage();
							}
						});
					}
					$modalInstance.dismiss();
				});
			}
		};

		$scope.resetAll = function() {
			$scope.requestBody.customerBackground = $scope.requestBody.justification = $scope.requestBody.remarks = '';
			$scope.caseDetailInfo.showError = false;
			$scope.requestBody.collectionType = '';
			_.each($scope.caseDetailInfo.expenseDetails, function(charge) {
				charge.waiverAmount = 0;
				charge.percentage = 0;
				charge.netWorking = charge.actualAmount;
			});
		};

		$scope.foucsHandler = function(item) {
			if (parseInt(item.waiverAmount) === 0) {
				item.waiverAmount = '';
			}
		};

	};

	eReceipt.controller('initiateWaiverController', [ '$scope', '$modalInstance', '$modal', 'eReceiptService', 'lazyModuleLoader', 'dialogService', 'data', '$globalScope', initiateWaiverController ]);
	return initiateWaiverController;
});