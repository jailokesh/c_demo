/**
 * Represents ePayController Controller. All type of receipt payments logic
 * handles. *
 */
define([ 'require', 'constants', 'eReceipt', 'collectionConstants', 'utility', 'DatePickerConfig' ], function(require, constants, eReceipt, collectionConstants, utility, DatePickerConfig) {
	'use strict';
	var ePayController = function($stateParams, $rootScope, $scope, $state, eReceiptService, getBalanceDetailsInfo, $modal, masterService, dialogService, messageBus, getchargesListResolver, $globalScope, appFactory, $timeout,lazyModuleLoader,addressLocationFactory) {
		$scope.receiptDate = new Date();
		$scope.numbers = [];
		$scope.eReceiptModel = angular.copy(getBalanceDetailsInfo);
		$scope.chargesArr = [];
		var payerType = collectionConstants.PAYER_TYPE;
		$scope.partyType = 'Applicant';
		$scope.agreementStatus = constants.AGREEMENT_STATUS;
		$scope.isManualReceipt = eReceiptService.getManualReceiptFlag();
		$scope.value = {
			exclude : collectionConstants.CHARGES_EXCLUDE
		};
		$scope.value.receiptType = $scope.receiptType = $stateParams.receiptType;
		$scope.status = constants.STATUS;
		$scope.searchParams = eReceiptService.getSearchParam();
		$scope.imageCategory = {};
		$scope.remarks = $scope.editBuyer = {};
		if($scope.eReceiptModel.getPendingShortfallWaiver && $scope.eReceiptModel.getPendingShortfallWaiver.length){
			$scope.eReceiptModel.waiverSplitUp = $scope.eReceiptModel.getPendingShortfallWaiver[0].payDetails ? $scope.eReceiptModel.getPendingShortfallWaiver[0].payDetails[0].paySplitUp : [];
			$scope.eReceiptModel.chargeDetails = $scope.eReceiptModel.getPendingShortfallWaiver[0].chargeDetails ? $scope.eReceiptModel.getPendingShortfallWaiver[0].chargeDetails: [];
		}
		$scope.eReceiptModel.agreementNo = (getBalanceDetailsInfo.agreementNo) ? getBalanceDetailsInfo.agreementNo : $stateParams.agreementNo;
		var isRepoStage = $scope.value.isEditBuyer = false;
		$scope.checkBuyer = true;
		$scope.attrsValues =  collectionConstants.GLOBAL_ATTRS_VALUES;
		if ($scope.isManualReceipt) {
			var _product;
			if ($stateParams.receiptType === 'IMD' || $stateParams.receiptType === 'INS-LEAD') {
				if (!$scope.eReceiptModel.product) {
					_product = 'VF';
				} else if ($scope.eReceiptModel.product === 'SME') {
					_product = 'HE';
				} else {
					_product = $scope.eReceiptModel.product;
				}
			} else {
				_product = $scope.eReceiptModel.productGroup;
			}
			$scope.manualReceiptInfo = eReceiptService.getManualReceiptDetails();
			eReceiptService.getManualPendingRef($scope.manualReceiptInfo).then(function(data) {
				$scope.value.manualReferences = data;
			});
			$scope.value.manualReceiptReferenceCase = '';

			$scope.referenceChangeHandler = function(value) {
				$scope.value.manualRefDetails = _.findWhere($scope.value.manualReferences, {
					referenceNo : value
				});
			};
		} else {
			$scope.applicantAddress = {};
			if ($scope.eReceiptModel.addressDetails && $scope.eReceiptModel.addressDetails.length > 0) {
				var _address = _.findWhere($scope.eReceiptModel.addressDetails, {
					addressType : "CURRES"
				}) || {};
				if (!_address) {
					_address = _.findWhere($scope.eReceiptModel.addressDetails, {
						isMailingAddress : true
					});
				}
				$scope.applicantAddress = _address || {};
			}
			if ($scope.receiptType === 'OD' && $scope.applicantAddress && $scope.applicantAddress.latitude && $scope.applicantAddress.longitude) {
				eReceiptService.itzCashAddress($scope.applicantAddress.latitude, $scope.applicantAddress.longitude).then(function(data) {
					if (data && data.data && data.data.length) {
						var address = data.data[0].addressDetail;
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "<h4 class='blue page-top-title big-15'>The Nearest ITZ Cash Location – " + address.doorNo + ", " + address.street + ", " + address.city + "-" + address.pincode + " (" + data.data[0].vendorName + ") available.</h4> <span class='text-center'>At Chola we are delighted to serve better please inform the customer about this payment option .</span>", true);
					}
				});
			}
		}
		$scope.value.waiver = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.WAIVER);
		$scope.thirdPartyDetails = {};
		$scope.buyer = {};
		var popUpDataObj, initiateRequestObj = {}, partPayCallBack, totalPartAmount;
		$scope.changeHandlar = function() {
			$timeout(function() {
				var chargeArr = _.pluck($scope.eReceiptModel.filterArr, 'chargeAmount');
				$scope.eReceiptModel.totalOD = _.reduce(chargeArr, function(memo, num) {
					return memo + num;
				}, 0);
			}, 300);
		};
		/**
		 * Set balance allocation table for receipt type is part payment /
		 * advance EMI Method will call after selecting the option in the popup
		 * OWN/DIFFERENT
		 */
		var setPartPaymentBalanceTable = function(data) {
			totalPartAmount = 0;
			var serviceTax = 0, partPayCharge = 0, chargePercentage = 0, oneForthAmount = 0;
			if ($scope.partyType === 'ThirdParty') {
				oneForthAmount = $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount;
				chargePercentage = (data === 'DIFFERENT') ? collectionConstants.OTHERS.PART_PAY_DIFF_PERCENTAGE : collectionConstants.OTHERS.PART_PAY_OWN_PERCENTAGE;
				partPayCharge = Math.round(oneForthAmount * chargePercentage);
				serviceTax = Math.round(partPayCharge * collectionConstants.OTHERS.PART_PAY_SERVICE_TAX_PERCENTAGE);
			}
			if ($scope.receiptType === 'PART PAYMENT') {
				totalPartAmount = Number($scope.selectedAgreement.balanceAllocationModel[0].chargeAmount) + partPayCharge + serviceTax;
				$scope.selectedAgreement.balanceAllocationModel[1].chargeAmount = partPayCharge;
				$scope.selectedAgreement.balanceAllocationModel[2].chargeAmount = serviceTax;
				$scope.receiptPostModel.Receipt.amountPaid = totalPartAmount;
				_.each($scope.selectedAgreement.balanceAllocationModel, function(item) {
					item.actual = item.chargeAmount;
				});
				$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalActualAmount = totalPartAmount;
				$scope.selectedAgreement.isAllocated = true;
			}
			$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
		};
		/**
		 * Set receipts values in dropdown based on product type
		 */
		var setReceiptTypes = function(receiptArray) {
			var outPutArr = [];
			_.each(receiptArray, function(item) {
				if (appFactory.getActivityAccess(item.activityID)) {
					outPutArr.push(item);
				}
			});
			return outPutArr;
		};
		var setDefaultReceiptType = function(header, msg) {
			dialogService.showAlert(constants.ERROR_HEADER.error, header, msg).result.then(function() {
			}, function() {
				$scope.receiptType = $scope.value.receiptType = 'OD';
				initController();
			});
		};

		/**
		 * Fore closure validations method will call on change the receipt type
		 * as Fore closure
		 */
		var foreClosureValidation = function() {
			if ($scope.eReceiptModel.agreementStatus === 'C') {
				setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.AGREEMENT_CLOSED);
				return;
			}
			$scope.value.disableCashMode = true;
			if ($scope.productType === 'HE' || $scope.productType === 'HL') {
				$scope.eReceiptModel.fcDetail = $scope.eReceiptModel.foreClosureRequestDetail[$scope.eReceiptModel.foreClosureRequestDetail.length - 1];
				if (!$scope.eReceiptModel.fcDetail || !_.findWhere($scope.eReceiptModel.fcDetail.workflow, {
					workStatus : 'APPROVED'
				})) {
					setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.FC_REQUEST_PENDING);
					return;
				}
				if (new Date().getTime() > new Date($scope.eReceiptModel.fcDetail.issuedLetterValidityDate).getTime()) {
					setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.FC_LETTER_EXPIRED);
					return;
				}
			} else {
				$scope.simulatedData = {};
			}
			if ($scope.eReceiptModel.waiverRequestStatus === 'WAIVER-INITIATED' || $scope.eReceiptModel.waiverRequestStatus === 'WAIVER-RECOMMENDED' || $scope.eReceiptModel.waiverRequestStatus === 'WAIVER-ESCALATED') {
				setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.FC_WAIVER_PEDNING);
				return;
			} else if ($scope.eReceiptModel.waiverRequestStatus === 'FORECLOSURE-INITIATED' || $scope.eReceiptModel.waiverRequestStatus === 'FORECLOSURE-RECOMMENDED' || $scope.eReceiptModel.waiverRequestStatus === 'FORECLOSURE-ESCALATED') {
				setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.LA_APPROVAL_PEDNING);
				return;
			} else if($scope.eReceiptModel.yetToExpireForclosureWaiver){
				displayWaiverAlert('yetToExpireForclosureWaiver');
			}

			$scope.showLastThreeChequeDetails(true);
			var emiODAmt = _.findWhere($scope.eReceiptModel.expenseDetails, {
				chargeID : collectionConstants.CHARGE_IDS.EMI
			});
			var diffAmt = (emiODAmt) ? Number(emiODAmt.chargeAmount - emiODAmt.paidAmount) : 0;
			$scope.eReceiptModel.grossValue = Number($scope.eReceiptModel.futurePrincipalAmount + diffAmt);
		};
		/**
		 * Part payment receipt validations method will call on change the
		 * receipt type as Part payment
		 */
		var partPaymentValidation = function() {
			popUpDataObj = {};
			if (!eReceiptService.overDueCheck($scope.eReceiptModel.expenseDetails)) {
				setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.AGREEMENT_HAS_OD);
				return;
			}/*
				 * else if(!$scope.eReceiptModel.futureEMICount){
				 * setDefaultReceiptType(constants.ERROR_HEADER.message, "This
				 * agreement does not have future EMI. Cannot proceed.");
				 * return; }
				 */
			if ($scope.receiptType === 'PART PAYMENT') {
				eReceiptService.data.principalOS = $scope.eReceiptModel.futurePrincipalAmount;
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/partPaymentPopup.html', 'partPaymentPopupController', 'sm', {
					receiptType : $scope.receiptType,
					postModel : $scope.receiptPostModel.Receipt,
					paymentMode : $scope.paymentMode
				});
				messageBus.onMsg('CLOSE_PART_PAY', function() {
					$scope.value.receiptType = $scope.receiptType = 'OD';
					$scope.partyType = 'Applicant'; // Changing the payer type to default.
					initController();
				});
				if (partPayCallBack) {
					partPayCallBack();
				}
				messageBus.onMsg('PART_PAY_SUCCESS', function(event, data) {
					$scope.receiptPostModel.Receipt.amountPaid = $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = data;
					$scope.selectedAgreement.isDisabled = true;
					setPartPaymentBalanceTable($scope.value.accountType);
				});
				partPayCallBack = messageBus.onMsg('PART_ADVANCE_ACCOUNT_TYPE', function(event, data) {
					$scope.value.accountType = data;
					$scope.partyType = $scope.value.accountType === 'DIFFERENT' ? 'ThirdParty' : $scope.partyType;
					setPartPaymentBalanceTable($scope.value.accountType);
				}, $scope);
			}
		};
		/**
		 * Sale/emd receipts validations method will call on change the receipt
		 * type as sale / emd
		 */
		var _unadjustedAmt = 0,msDetail;
		var saleEMDValidation = function() {
			if ($scope.eReceiptModel.approvedSaleAmount && $scope.receiptType === 'SALE') {
				$scope.value.disableSaleField = true;
				if (!$scope.eReceiptModel.receiptDetails || !$scope.eReceiptModel.receiptDetails.amountPaid) {
					$scope.eReceiptModel.receiptDetails = {
						amountPaid : 0
					};
				}
				$scope.receiptPostModel.Receipt.amountPaid = parseInt($scope.eReceiptModel.approvedSaleAmount) - parseInt($scope.eReceiptModel.receiptDetails.amountPaid);
				$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.selectedAgreement.balanceAllocationModel[0].actual =  $scope.receiptPostModel.Receipt.amountPaid;
				$scope.selectedAgreement.isAllocated = true;
			} else {
				//$scope.value.disableSaleField = false;
				$scope.receiptPostModel.Receipt.amountPaid = '';
				if (!$scope.eReceiptModel.receiptDetails || !$scope.eReceiptModel.receiptDetails.amountPaid) {
					$scope.eReceiptModel.receiptDetails = {
						amountPaid : 0
					};
				}
			}
			var unAdjAmt = Number($scope.eReceiptModel.totalEMIODAmount + $scope.eReceiptModel.futurePrincipalAmount) - Number($scope.eReceiptModel.approvedSaleAmount);
			_unadjustedAmt = unAdjAmt < 0 ? 0 : Math.round(unAdjAmt);
			$scope.eReceiptModel.unadjustedAmount = angular.copy(_unadjustedAmt);
		};

		var getLoanCharges = function(selectedLoan, flag) {
			if (!selectedLoan.balanceAllocationModel || !selectedLoan.balanceAllocationModel.length) {
				eReceiptService.getLoanCharges($scope.eReceiptModel.leadID, selectedLoan).then(function(data) {
					selectedLoan.balanceAllocationModel = data.charges;
					selectedLoan.otherCharges = data.otherCharges;
					selectedLoan.totalOD = data.totalCharges;
					selectedLoan.marginalAmount = data.marginalAmount;
					eReceiptService.imdAutoAllocation(selectedLoan, flag);
				});

			} else {
				$scope.selectedAgreement.isAllocated = ($scope.receiptPostModel.Receipt.amountPaid > 0 && $scope.selectedAgreement.totalBalanceAmount >= 0);
			}
		};

		$scope.checkIMDReceiptValues = function(receipt, amountCollected){
			if(!receipt.actual){
				receipt.actual = 0;
			}
			if(!amountCollected && receipt.actual){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please enter the amount collected to proceed further");
				receipt.actual = 0;
				return;
			} else if(receipt.chargeAmount < receipt.actual){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Actual amount cannot be greater than the charge Amount.");
				receipt.actual = 0;
				return;
			}
			if($scope.productType !== 'VF'){
				$scope.selectedAgreement.totalActualAmount = 	_.reduce($scope.selectedAgreement.balanceAllocationModel[0].charges, function(memo, num) { return memo + Number(num.actual)}, 0);
				$scope.selectedAgreement.totalBalanceAmount = Number(Number(amountCollected) - $scope.selectedAgreement.totalActualAmount);
				$scope.selectedAgreement.isAllocated = $scope.selectedAgreement.totalBalanceAmount === 0;
			}
		};
		/**
		 * IMD receipts validations method will call on change the receipt type
		 * as IMD
		 */
		var imdValidation = function() {
			$scope.paymentMode.agreementNo = $scope.eReceiptModel.leadID || $scope.eReceiptModel.applicationID;
			$scope.productType = $scope.eReceiptModel.product ? $scope.eReceiptModel.product : 'VF';
			if ($scope.productType === 'SME') {
				$scope.productType = 'HE';
			}
			if ($scope.receiptType === 'IMD') {
				$scope.receiptTypes = [ {
					id : 'IMD',
					value : 'IMD'
				} ];
			} else {
				$scope.receiptTypes = [ {
					id : 'INS-LEAD',
					value : 'INS-LEAD'
				} ];
			}
			$scope.receiptPostModel = eReceiptService.getIMDReceiptModel($scope.eReceiptModel.partyDetails);
			$scope.selectedAgreement = ($scope.eReceiptModel.loanDetails) ? $scope.eReceiptModel.loanDetails[0] : {};
			$scope.eReceiptModel.relatedAgreementNos = $scope.eReceiptModel.loanDetails;
			$scope.selectedAgreement.isSelected = true;
			$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalActualAmount = $scope.selectedAgreement.balanceAmount = 0;
			$scope.selectedAgreement.otherODCharges = [];
			$scope.paymentMode.productType = $scope.productType;
			if ($scope.receiptType === 'IMD') {
				if ($scope.productType === 'VF') {
					getLoanCharges($scope.selectedAgreement);
					$scope.numbers = ($scope.applicantDetail.mobileNos) ? $scope.applicantDetail.mobileNos : [];
				} else {
					$scope.value.disableCashMode = true;
					$scope.selectedAgreement = eReceiptService.getIMDHEHLCharges($scope.selectedAgreement);
					if ($scope.selectedAgreement.propertyDetails && $scope.selectedAgreement.propertyDetails[0]) {
						$scope.selectedAgreement.propertyDetails[0].addressDetail.pincode = $scope.selectedAgreement.propertyDetails[0].addressDetail.pincodeDesc;
						$scope.value.propertyDetailsAddress = utility.setAddress($scope.selectedAgreement.propertyDetails[0].addressDetail);
					}
					if ($scope.selectedAgreement.balanceAllocationModel[0] && $scope.selectedAgreement.balanceAllocationModel[0].charges) {
						var chargeObj = $scope.selectedAgreement.balanceAllocationModel[0].charges[0], payStr;
						chargeObj.modeOfPayment = chargeObj.modeOfPayment ? chargeObj.modeOfPayment.toUpperCase() : '';
						$scope.paymentMode.modeOfPayment = chargeObj.modeOfPayment === 'DD' ? 'DRAFT' : chargeObj.modeOfPayment;
						payStr = chargeObj.modeOfPayment === 'DD' ? 'demandDraft' : chargeObj.modeOfPayment === 'CHEQUE' ? 'cheque' : 'rtgs';
						if (payStr !== 'cash' && payStr !== 'rtgs') {
							$scope.paymentMode[payStr].instrumentNo = chargeObj.chequeOrDDNo;
							$scope.paymentMode[payStr].instrumentDate.setDateVal(new Date(chargeObj.chequeOrDDDate));
							$scope.paymentMode[payStr].instrumentDate.dateValue = new Date(chargeObj.chequeOrDDDate);
							$scope.paymentMode[payStr].bankBranchID = chargeObj.bBranchID;
							$scope.paymentMode[payStr].type = 'LOCAL';
						} else if (payStr === 'rtgs') {
							$scope.paymentMode.rtgs.bankBranchID = chargeObj.bBranchID;
							$scope.paymentMode.rtgs.utrNo = chargeObj.transactionReference;
							$scope.paymentMode.rtgs.instrumentDate.setDateVal(new Date(chargeObj.chequeOrDDDate));
							$scope.paymentMode.rtgs.instrumentDate.dateValue = new Date(chargeObj.chequeOrDDDate);
						}
						$scope.receiptPostModel.Receipt.amountPaid = $scope.selectedAgreement.totalOD;
						$scope.selectedAgreement.isDisabled = $scope.selectedAgreement.isAllocated = true;
						$scope.selectedAgreement.totalBalanceAmount = 0;
					}

					_.each($scope.eReceiptModel.partyDetails, function(partyObj) {
						if (partyObj.photoImageRef) {
							partyObj.signature = _.findWhere(partyObj.photoImageRef, {
								imageCategoryID : "252"
							});
						}
					});
					$scope.numbers = ($scope.applicantDetail.mobileNo) ? $scope.applicantDetail.mobileNo : [];
				}
			} else {
				var premiumAmt = ($scope.selectedAgreement.vehicleDetail && $scope.selectedAgreement.vehicleDetail.insuranceDetail) ? $scope.selectedAgreement.vehicleDetail.insuranceDetail.totalClaimAmount : 0;
				$scope.selectedAgreement.balanceAllocationModel = [ {
					chargeID : collectionConstants.CHARGE_IDS.PRE_AMOUNT,
					chargeType : 'Premium Amount',
					chargeAmount : premiumAmt,
					actual : 0
				} ];
			}
			if ($scope.applicantDetail && $scope.applicantDetail.addressDetails && $scope.applicantDetail.addressDetails.length) {
				var imdApplicant = _.findWhere($scope.applicantDetail.addressDetails, {
					isMailingAddress : true
				});
				if (imdApplicant) {
					imdApplicant.pincode = imdApplicant.pincodeDesc;
					eReceiptService.getAddressFromPincode(imdApplicant, true).then(function(data) {
						$scope.customerFullAddress = utility.setAddress(imdApplicant);
					});
				}
			}
			$scope.thirdPartyDetails = _.where($scope.eReceiptModel.partyDetails, {
				partyType : "coApplicant"
			});
			$scope.thirdPartyDetails.mobileNos = [];
			_.each($scope.eReceiptModel.partyDetails, function(thirdPartyObj) {
				if (thirdPartyObj.partyType === "coApplicant" && thirdPartyObj.mobileNos && thirdPartyObj.mobileNos[0] && $scope.thirdPartyDetails.mobileNos.indexOf(thirdPartyObj.mobileNos[0]) === -1) {
					$scope.thirdPartyDetails.mobileNos.push(thirdPartyObj.mobileNos[0]);
				}
			});
			$scope.thirdPartyDetails.panNo = ($scope.thirdPartyDetails[0]) ? $scope.thirdPartyDetails[0].panNo : '';
			$scope.thirdPartyFullAddress = ($scope.thirdPartyDetails[0] && $scope.thirdPartyDetails[0].addressDetails) ? utility.setAddress($scope.thirdPartyDetails[0].addressDetails[0]) : {};
		};
		var applicantNos = [], tpNos = [];
		var setTPAddressMobileNos = function(responseObj, flag) {
			if (flag) {
				var _tpAddress = (responseObj.thirdPartyDetails[0]) ? responseObj.thirdPartyDetails[0] : {};
				$scope.thirdPartyDetails = _tpAddress.thirdPartyAddresses[0] ? _tpAddress.thirdPartyAddresses[0] : {};
				$scope.thirdPartyDetails.mobileNo = $scope.thirdPartyDetails.mobileNo || '';
				$scope.thirdPartyDetails.mobileNos = [];
				_.each(responseObj.thirdPartyDetails, function(thirdPartyObj) {
					if (thirdPartyObj.thirdPartyAddresses && thirdPartyObj.thirdPartyAddresses[0] && thirdPartyObj.thirdPartyAddresses[0].mobileNo && $scope.thirdPartyDetails.mobileNos.indexOf(thirdPartyObj.thirdPartyAddresses[0].mobileNo) === -1) {
						$scope.thirdPartyDetails.mobileNos.push(thirdPartyObj.thirdPartyAddresses[0].mobileNo);
					}
				});
				$scope.thirdPartyDetails.panNo = (responseObj.thirdPartyDetails[0]) ? responseObj.thirdPartyDetails[0].panNo : '';
				$scope.thirdPartyFullAddress = [];
				eReceiptService.getAddressFromPincode($scope.thirdPartyDetails, true).then(function(thirdPartyAddress) {
					$scope.thirdPartyDetails = thirdPartyAddress;
					$scope.value.thirdPartyZip = thirdPartyAddress.applicantZip;
					$scope.thirdPartyFullAddress = utility.setAddress($scope.thirdPartyDetails);
				});
			} else {
				$scope.thirdPartyDetails.mobileNos = tpNos.length ? tpNos : $scope.thirdPartyDetails.mobileNos;
			}
			if (responseObj.thirdPartyDetails[0] && !_.where($scope.eReceiptModel.relatedAgreementNos, {
				isAllocated : true
			}).length) {
				$scope.thirdPartyDetails.name = $scope.receiptPostModel.ThirdParty.name = responseObj.thirdPartyDetails[0].name;
			}
		};

		var setApplicantAddressMobileNos = function(responseObj, flag) {
			if (flag) {
				$scope.pddData = eReceiptService.setPDDDCouments($scope.eReceiptModel);
				if ($scope.eReceiptModel.addressDetails && $scope.eReceiptModel.addressDetails.length > 0) {
					// var _address =
					// _.findWhere($scope.eReceiptModel.addressDetails,{isMailingAddress:true});
					var addressList = angular.copy($scope.eReceiptModel.addressDetails), _address;
					_address = _.findWhere(addressList, {
						addressType : collectionConstants.CURRENT_ADDRESS
					});
					if (!_address) {
						_address = _.findWhere(addressList, {
							addressType : collectionConstants.PERMANENT_ADDRESS
						});
					}
					if (!_address) {
						_address = _.findWhere(addressList, {
							addressType : collectionConstants.OFFICE
						}) || {};
					}
					$scope.receiptPostModel.AddressDetail = $scope.applicantAddress = _address;
				}
				$scope.applicantDetail.mobileNos = $scope.numbers = utility.getApplicantMobileNos(angular.copy($scope.eReceiptModel.addressDetails));
				
				$scope.customerFullAddress = [];
				eReceiptService.getAddressFromPincode($scope.applicantAddress, true).then(function(addressObj) {
					$scope.applicantAddress = addressObj;
					$scope.value.applicantZip = addressObj.pincode;
					$scope.customerFullAddress = utility.setAddress($scope.applicantAddress);
				});
				$scope.receiptPostModel.AddressDetail.mobileNo = ''; // clearing the mobile no field by default

			} else {
				$scope.applicantDetail.mobileNos = $scope.numbers = applicantNos.length ? applicantNos : $scope.numbers;
			}
		};

		/**
		 * Important method, set all the details for the agreement, method will
		 * call on change of receipt in drop down.
		 */
		var setAgreementDetails = function(responseObj, flag) {
			if (!_.where($scope.eReceiptModel.relatedAgreementNos, {
				isAllocated : true
			}).length) {
				$scope.receiptPostModel.ThirdParty.mobileNos = [];
				$scope.thirdPartyDetails = {
					mobileNos : []
				};
				if (responseObj.thirdPartyDetails && responseObj.thirdPartyDetails.length > 0) {
					setTPAddressMobileNos(responseObj, flag);
				} else {
					$scope.thirdPartyFullAddress = '';
					$scope.receiptPostModel.ThirdParty.name = '';
					$scope.receiptPostModel.ThirdParty.mobileNos = [];
					$scope.receiptPostModel.ThirdParty.thirdPartyAddresses = [];
				}
			}
			if ($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') {
				if (responseObj.vendorDetails) {
					$scope.numbers = responseObj.vendorDetails.phoneNo;
					$scope.paymentMode.cash.pan = responseObj.vendorDetails.panNo;
					eReceiptService.getAddressFromPincode(responseObj.vendorDetails.addressDetail, true).then(function(vendorAddress) {
						responseObj.vendorDetails.addressDetail = vendorAddress;
						$scope.vendorFullAddress = utility.setAddress(vendorAddress);
					});
				} else {
					$scope.numbers = [];
				}
			} else {
				setApplicantAddressMobileNos(responseObj, flag);
				if ($scope.receiptType === 'miniStatement') {
					$scope.receiptPostModel.Receipt.amountPaid = $rootScope.miniSOACharge;
					$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.selectedAgreement.balanceAllocationModel[0].actual = $rootScope.miniSOACharge;
					$scope.selectedAgreement.isAllocated = true;
					$scope.receiptPostModel.AddressDetail.mobileNo = '';
				}
			}
			$scope.eReceiptModel.assetDetail = responseObj.assetDetail;
			$scope.eReceiptModel.pddAcknowledgementDetails = responseObj.pddAcknowledgementDetails;
			$scope.eReceiptModel.rightSideColumn = responseObj.rightSideColumn;
			if ($scope.eReceiptModel.generalPayerType && $scope.eReceiptModel.generalPayerType.toLowerCase() === 'third party' && !$scope.value.isGeneralPayerUsed) {
				$scope.partyType = 'ThirdParty';
				$scope.paymentMode.cash.pan = $scope.thirdPartyDetails.panNo;
				$scope.value.isGeneralPayerUsed = true;
			}
			$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
		};

		var createReceiptModel = function(flag) {
			$scope.eReceiptModel = eReceiptService.setAgreementChargeDetails($scope.eReceiptModel, $scope.receiptType, $scope.productType);
			$scope.paymentMode.branchID = $scope.eReceiptModel.branchID;
			$scope.paymentMode.productType = $scope.productType;
			if(flag) {
				$scope.receiptPostModel = eReceiptService.getReceiptModel($scope.eReceiptModel);
			}
			setApplicantAddressMobileNos($scope.eReceiptModel, flag);
		};
		var displayWaiverAlert = function(key){
			var waiverType = "Normal";
			var waiverType = "";
			if($scope.eReceiptModel[key] && $scope.eReceiptModel[key][0] && $scope.eReceiptModel[key][0].waiverStatus === "UNUSED"){
				var initDate =  _.findWhere($scope.eReceiptModel[key][0].workflow, {workStatus : "INITIATED" }).workDoneDate;
				if(key === "yetToExpireWaiver"){
					waiverType = "Normal";
				}else if(key === "yetToExpireShortfallWaiver"){
					waiverType = "ShortfallWaiver";
				}else{
					waiverType = "Foreclosure";
				}
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, waiverType + " Waiver initiated on " + utility.showDetailDate(initDate)+" is going to expire on " + utility.showDetailDate($scope.eReceiptModel[key][0].expDate));
			}
		};
		var validateAndSetReceiptTypes = function(){
			//var isShortFallCase = ($scope.eReceiptModel.agreementStatus !== 'A' && $scope.eReceiptModel.productGroup === 'VF' && $scope.eReceiptModel.npaStageID && $scope.eReceiptModel.npaStageID.toUpperCase() === 'SALE');
			var isShortFallCase = $scope.eReceiptModel.isShortfall;
			if (isShortFallCase) {
				$scope.receiptTypes = _.where(collectionConstants.VF_RECEIPT_TYPES, {
					value : "SHORTFALL"
				});
				$scope.value.isForeclosed = true;
			} else if (!eReceiptService.isAgreementActive($scope.eReceiptModel, true)) {
				$scope.receiptTypes = _.where(collectionConstants.VF_RECEIPT_TYPES, {
					value : "OD"
				});
				$scope.value.isForeclosed = true;
			} else {
				$scope.value.isForeclosed = false;
				if ($scope.productType === 'VF') {
					$scope.receiptTypes = $scope.isManualReceipt ? setReceiptTypes(collectionConstants.VF_MANUAL_RECEIPT_TYPES) : setReceiptTypes(collectionConstants.VF_RECEIPT_TYPES);
				} else if ($scope.productType === 'PL') {
					$scope.receiptTypes = setReceiptTypes(collectionConstants.PL_RECEIPT_TYPES);
				} else {
					$scope.receiptTypes = $scope.isManualReceipt ? setReceiptTypes(collectionConstants.HEHL_MANUAL_RECEIPT_TYPES) : setReceiptTypes(collectionConstants.HE_HL_RECEIPT_TYPES);
				}
			}
		};
		var repoStagePopup = function(){
			dialogService.showCustomDialog('app/collections/eReceipt/receipting/partials/popup/repoStage.html', 'repoStageController', {
						data: function() {
							return {
								repoStageList : collectionConstants.REPO_STAGE_TYPE,
								switchRepo : false
							};
						}
					},function(result){
						if (result.status === "success") {
							var stage = _.findWhere(collectionConstants.REPO_STAGE_TYPE,{id:result.data}).value;
							dialogService.confirm(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, "You have selected "+ stage + " option, Kindly confirm to proceed").result.then(function() {
								//start
								if(result && (result.data == 'AS' || result.data == 'TPS' || result.data == 'RF')){
									//if(!$scope.eReceiptModel.currentStage || ($scope.eReceiptModel.currentStage && $scope.eReceiptModel.currentStage !== 'SALE_APPROVED'  && $scope.eReceiptModel.currentStage !== 'ASSET_SALE')) {
									if(!$scope.eReceiptModel.approvedSaleAmount || !$scope.eReceiptModel.buyerID) {
										dialogService.showAlert('Alert', 'Alert', 'Sale/Quotes has not been approved. Cannot proceed receipting with '+stage+' repo stage.').result.then(function () {
										},function(){
											$globalScope.gotoPreviousPage();
										});
										return;
									} else {
										$scope.value.currentReceiptType = result.data;
									}
								}else if(result && result.data == 'TS'){
									if($scope.eReceiptModel.approvedSaleAmount){
										dialogService.showAlert('Alert', 'Alert', 'Quote received from GB. Please enter SALE/EMD receipt through Third Party GB Sale repo stage').result.then(function () {
										},function(){
											repoStagePopup();
										});
										return;
									}else if(!$scope.eReceiptModel.isSellable){
										dialogService.showAlert('Alert', 'Alert', 'Mandate repo docs pending for upload. Please upload in leap under repo queue to proceed SALE/EMD receipt').result.then(function () {
										},function(){
											$globalScope.gotoPreviousPage();
										});
										return;
									}else {
										$scope.value.currentReceiptType = result.data;
									}
								}else{
									$scope.value.currentReceiptType = '';
								}
								//end
								isRepoStage = true;
								$scope.receiptPostModel.Receipt.repoStage = stage;
							if(result.data ==='RA' || result.data ==='SLM'){
								$scope.receiptTypes = [{id : 'OD',value:'OD'},{id : 'FORECLOSURE',value:'FORECLOSURE'}];
								$scope.value.receiptType = $scope.receiptType = $scope.receiptTypes[0].value;
							}else{
								$scope.selectedAgreement.balanceAllocationModel = [{chargeAmount :0,chargeID : collectionConstants.CHARGE_IDS.EXCESS,actual : 0}];
								$scope.receiptTypes = [{id : 'EMD',value:'EMD'},{id : 'SALE',value:'SALE'}];
								$scope.value.receiptType = $scope.receiptType = $scope.receiptTypes[0].value;
								$scope.receiptPostModel.AddressDetail.mobileNo = ''; 
								initSaleEMDObjects();
								$scope.changeBuyerType("Individual");
							}
							}, function() {
								repoStagePopup();
							});
						}
					},'sm', 'modal-custom', true);
		}
		/**
		 * Initialize the controller initializing applicant payment mode etc.
		 */
		var initController = function(flag) {
			$scope.value.accountType = '';
			$scope.popupInfo = {};
			$scope.value.disableSubmitButton = false;
			$scope.eReceiptModel.relatedAgreementNos = getBalanceDetailsInfo.relatedAgreementNos;
			$scope.eReceiptModel.approvedSaleAmount = getBalanceDetailsInfo.approvedSaleAmount;
			if (flag) {
				try{
					$scope.applicantDetail = eReceiptService.getApplicanInfo($scope.eReceiptModel.partyDetails, $scope.receiptType);
					$scope.applicantDetail.name = (!$scope.applicantDetail.firstName	) ? '-' : $scope.applicantDetail.firstName + ' ';
					$scope.applicantDetail.name += (!$scope.applicantDetail.middleName) ? '' : $scope.applicantDetail.middleName + ' ';
					$scope.applicantDetail.name += (!$scope.applicantDetail.lastName) ? '' : $scope.applicantDetail.lastName;
				}catch(err){
					$scope.applicantDetail = {
						name  : ''
					};
				}
			}
			if(!$scope.paymentMode || !$scope.paymentMode.modeOfPayment){
				$scope.paymentMode = eReceiptService.getPaymentModeModel($scope.applicantDetail, $scope.receiptType);
			}
			if ($scope.isManualReceipt) {
				var _manReceiptDate = new Date($scope.searchParams.receiptDate), _minDate, _tempDate;
				$scope.paymentMode.demandDraft.instrumentDate.maxDate = $scope.paymentMode.cheque.instrumentDate.maxDate = _manReceiptDate;
				_minDate = new Date(new Date().setDate(_manReceiptDate.getDate() - collectionConstants.OTHERS.MAX_CHEQUE_EXPIRY_DAY));
				$scope.paymentMode.demandDraft.instrumentDate.minDate = $scope.paymentMode.cheque.instrumentDate.minDate = _minDate;
			}
			if ($scope.eReceiptModel && $scope.eReceiptModel.isProfit) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "You are proceeding receipt for Profit case " + $scope.eReceiptModel.agreementNo);
			}
			$scope.paymentMode.receiptType = $scope.receiptType;
			if ($scope.receiptType === 'VISHESH' || $scope.receiptType === 'TRIP') {
				createReceiptModel(flag);
				$scope.value.isVishesh = true;
				$scope.receiptTypes = _.where(collectionConstants.VF_RECEIPT_TYPES, {
					value : "OD"
				});
                if($scope.receiptType === 'TRIP')
                    $scope.value.disableCashMode = true;
                else if($scope.receiptType === 'VISHESH'){
                    $scope.value.disableCashMode = $scope.eReceiptModel.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY || ($scope.eReceiptModel.allowCashReceipt && $scope.eReceiptModel.allowCashReceipt.toUpperCase() === 'N')
                }
				$scope.receiptType = $scope.value.receiptType = 'OD';
				$scope.selectedAgreement = $scope.eReceiptModel.relatedAgreementNos[0] || {};
				$scope.selectedAgreement.agreementNo = $scope.eReceiptModel.agreementNo;
				$scope.selectedAgreement.assetDetail = $scope.eReceiptModel.assetDetail;
                var chargeDetails = [];
                if($scope.eReceiptModel.productCode === 'VISHESH') {
                    _.each(collectionConstants.VISHESH_CHARGE_DETAILS, function(oneItem) {
                        chargeDetails.push({
                            chargeType: oneItem.chargeType,
                            chargeAmount: $scope.eReceiptModel[oneItem.chargeAmount],
                            isLink: oneItem.isLink
                        })
                    });
                }
                if($scope.eReceiptModel.productCode === 'TRIP') {
                    _.each(collectionConstants.TRIP_CHARGE_DETAILS, function(oneItem) {
                        chargeDetails.push({
                            chargeType: oneItem.chargeType,
                            chargeAmount: $scope.eReceiptModel[oneItem.chargeAmount]
                        })
                    });
                    _.each($scope.eReceiptModel.expenseDetails, function(expItem) {
						var chargeAmnt = Number(expItem.chargeAmount) - Number(expItem.paidAmount);
						if(chargeAmnt > 0){
							chargeDetails.push({
								chargeType: expItem.receiptChargeType,
								chargeAmount: chargeAmnt
							})
						}
                    });					
                }
                $scope.selectedAgreement.balanceAllocationModel = chargeDetails;
				$scope.selectedAgreement.totalOtherOD = _.reduce($scope.eReceiptModel.expenseDetails, function(memo, charge) {
					var _diff = (charge.chargeAmount - charge.paidAmount) < 0 ? 0 : (charge.chargeAmount - charge.paidAmount);
					charge.chargeAmount = _diff;
					return memo + _diff;
				}, 0);
			} else if ($scope.receiptType !== 'IMD' && $scope.receiptType !== 'INS-LEAD') {
				$scope.paymentMode.agreementNo = $scope.eReceiptModel.agreementNo;
				$scope.productType = $scope.eReceiptModel.productGroup;
				$scope.eReceiptModel.npaStageID = $scope.eReceiptModel.npaStageID ? $scope.eReceiptModel.npaStageID.toUpperCase() : '';
				if(!$scope.receiptTypes || !$scope.receiptTypes.length){
					validateAndSetReceiptTypes();
				}
				if ($scope.receiptType === 'OD' && !_.findWhere($scope.receiptTypes, {
					value : $scope.receiptType
				})) {
					$scope.value.receiptType = $scope.receiptType = $scope.receiptTypes[0].value;
				}
				createReceiptModel(flag);
				if ($scope.productType !== 'VF') {
					$scope.value.propertyDetailsAddress = utility.setAddress($scope.eReceiptModel.propertyDetail);
				}
				$scope.selectedAgreement = _.findWhere($scope.eReceiptModel.relatedAgreementNos, {
					'agreementNo' : $scope.eReceiptModel.agreementNo
				});
				if (!$scope.selectedAgreement) {
					$scope.selectedAgreement = {};
					$scope.selectedAgreement.agreementNo = $scope.eReceiptModel.agreementNo;
					$scope.selectedAgreement.assetDetail = {};
				}
				initiateRequestObj = {
					principalOS : $scope.eReceiptModel.futurePrincipalAmount,
					expenseDetails : $scope.eReceiptModel.expenseDetails,
					agreementNo : $scope.eReceiptModel.agreementNo
				};
				$scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.totalActualAmount = $scope.selectedAgreement.totalOtherOD = $scope.selectedAgreement.allocatedAmount = 0;
				$scope.selectedAgreement.isAllocated = false;
				$scope.value.disableCashMode = (($scope.eReceiptModel.allowCashReceipt && $scope.eReceiptModel.allowCashReceipt.toUpperCase() === 'N') || $scope.receiptType === 'SALE' || $scope.eReceiptModel.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY);
				if ($scope.receiptType !== 'TA') {                                                  
					$scope.selectedAgreement.principalOS = $scope.eReceiptModel.futurePrincipalAmount;
					eReceiptService.setAgreementOrder($scope.eReceiptModel.relatedAgreementNos, $scope.selectedAgreement);
					var ODInfo = {
						balanceOS : Math.round($scope.eReceiptModel.balanceOS),
						billedEMI : 0,
						pendingEMI : 0,
						futureEMI : 0
					}, _bic, _pec;
					_bic = $scope.eReceiptModel.billedInstallmentCount ? Number($scope.eReceiptModel.billedInstallmentCount) : 0;
					_pec = $scope.eReceiptModel.paidEMICount ? Number($scope.eReceiptModel.paidEMICount) : 0;
					ODInfo.billedEMI = _bic;
					$scope.value.pendingEMI = ODInfo.pendingEMI = _bic - _pec;// Number($scope.eReceiptModel.noOfInstallmentsOD);
					ODInfo.futureEMI = Number($scope.eReceiptModel.futureEMICount);
					$scope.selectedAgreement.ODInfo = ODInfo;
					$scope.value.totalEMIOD = $scope.selectedAgreement.emiOD = $scope.eReceiptModel.emiAmount;
					$scope.selectedAgreement.emiDueDate = $scope.eReceiptModel.nextEMIDueDate;
					$scope.selectedAgreement.otherODCharges = $scope.eReceiptModel.otherODCharges;
				} else {
					$scope.paymentMode.cash.pan = $scope.eReceiptModel.dealer[0].panNo;
					$scope.value.disableCashMode = true;
				}
				$scope.selectedAgreement.assetDetail = $scope.eReceiptModel.assetDetail;
				$scope.selectedAgreement.balanceAllocationModel = $scope.eReceiptModel.ODDetails; //sale&emd
				if(!isRepoStage && (!$scope.value.isForeclosed &&  ($scope.eReceiptModel.npaStageID === 'REPO' && $scope.eReceiptModel.agreementStatus.toLowerCase() === 'a' && !$scope.isManualReceipt) || ($scope.eReceiptModel.flagStatus && $scope.eReceiptModel.flagStatus.length>0 && $scope.eReceiptModel.flagStatus.indexOf("RESALE") > -1 &&  (!$scope.eReceiptModel.isShortfall && $scope.eReceiptModel.allowSaleReceipt)))) {
					repoStagePopup();	
				}else if ($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') {
					$scope.eReceiptModel.relatedAgreementNos = [ $scope.selectedAgreement ];
					saleEMDValidation();
				} /*else if ($scope.receiptType === 'EMD') {
					if(Number($scope.receiptPostModel.Receipt.amountPaid)>0){
						$scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.allocatedAmount = Number($scope.receiptPostModel.Receipt.amountPaid);	
					}
					$scope.eReceiptModel.relatedAgreementNos = [ $scope.selectedAgreement ];
				}*/ else if ($scope.receiptType === 'PART PAYMENT' || $scope.receiptType === 'ADVANCE EMI') {
					partPaymentValidation();
				} else if ($scope.receiptType === 'FORECLOSURE') {
					foreClosureValidation();
				} else if ($scope.receiptType === 'SHORTFALL') {
					//if (new Date().getTime() > new Date($scope.eReceiptModel.fcDetail.issuedLetterValidityDate).getTime()) {
					if ($scope.receiptType.expiredShortfallWaiver) {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.SF_LETTER_EXPIRED).result.then(function() {
						}, function() {
							//lazyModuleLoader.loadState('collections.receipt.eReceipt');
						});						
						return;
					}
					if($scope.eReceiptModel.yetToExpireShortfallWaiver){
						displayWaiverAlert('yetToExpireShortfallWaiver');
					}							
				}else if($scope.receiptType === 'INS'){
					if($scope.productType === 'VF'){
						msDetail =  angular.copy(_.findWhere($scope.eReceiptModel.insuranceDetail, {insuranceStatus : "true"}));
						if(!msDetail){
							setDefaultReceiptType(constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.CHOLA_MS_DATA_NOT_FOUND);
							return;
						}else if(msDetail && msDetail.maxRenewalDate){ // if max renewal date is less than current date, cannot renewal the policy.
							var days = utility.dateDifference(new Date(), new Date(msDetail.maxRenewalDate));
							if(days < 0){
								setDefaultReceiptType(constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.CHOLA_MS_POLICY_EXPIRED);
								return;
							}
						}
						dialogService.showCustomDialog('app/collections/eReceipt/receipting/partials/popup/policyNoPrompt.html', 'verifySignPopupController', {
							data: function() {
								return {
									insuranceDetail : msDetail,
									isMSFlag : true,
									assetDetail : $scope.selectedAgreement.assetDetail
								};
							}
						},function(result){
							if (result.status === "success") {
								$scope.value.cholaMSDetails = result.data;
								$scope.totalOD = $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = Math.round(result.data.totalPremium);
								$scope.receiptPostModel.Receipt.amountPaid = Math.round(result.data.totalPremium);
								$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = Math.round(result.data.totalPremium);
								balanceAutoAllocation($scope.receiptPostModel.Receipt.amountPaid);
								$scope.value.isMSFlag = result.data.isMSFlag;
							}else{
								$scope.receiptType = $scope.value.receiptType = 'OD';
								initController();
							}
						},'md', 'modal-custom', true);
					}
				}
				
				setAgreementDetails($scope.eReceiptModel, flag);
				$scope.popupInfo = {
					agreementNo : $scope.eReceiptModel.agreementNo,
					mobileNos : $scope.applicantDetail.mobileNos,
					branchName : JSON.parse(getCookie('selectedBranch')).branchDesc,
					branchID : $scope.eReceiptModel.branchID
				};
				
			} else {
				imdValidation();
			}
			if(flag &&  $scope.receiptType === 'OD'){
				displayWaiverAlert('yetToExpireWaiver');
				/*var initDate =  _.findWhere($scope.eReceiptModel.expiredWaiver[0].workflow, {workStatus : "INITIATED" }).workDoneDate;
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "The waiver initiated on " + utility.formDateString(new Date(initDate))+" got expired");
				return;*/
			}
			
			$scope.popupInfo.firstName = $scope.applicantDetail.name;
		};

		/**
		 * Method to display last three cheque details in popup.
		 * 
		 * @param {Boolean}
		 *            true for foreclosure receipt and false for1 other receipt.
		 */
		$scope.showLastThreeChequeDetails = function(showPartial) {
			popUpDataObj = {};
			popUpDataObj.chequeDetails = $scope.eReceiptModel.lastThreeChequeInformation;
			popUpDataObj.isDisbursal = ($scope.eReceiptModel.disbursalStatus && $scope.eReceiptModel.disbursalStatus.toUpperCase() === collectionConstants.OTHERS.FULLY_DISBURSED);
			popUpDataObj.isAutoPopUp = showPartial;
			popUpDataObj.isAnyChequeStatusPending = $scope.eReceiptModel.isAnyChequeStatusPending;
			eReceiptService.foreClosureCheck(popUpDataObj);
		};
		$scope.auctionDetailsPopup = function() {
			var auctionDetailsObj = {};
			auctionDetailsObj.approvedSaleAmount =  $scope.eReceiptModel.approvedSaleAmount ? $scope.eReceiptModel.approvedSaleAmount : 0;
			auctionDetailsObj.buyerID =  $scope.eReceiptModel.buyerID ? $scope.eReceiptModel.buyerID : '';
			auctionDetailsObj.currentStage =  $scope.eReceiptModel.currentStage ? $scope.eReceiptModel.currentStage : '';
			if($scope.eReceiptModel.auctions){
				auctionDetailsObj.auctions = $scope.eReceiptModel.auctions;
				auctionDetailsObj.auctions.quotes = _.sortBy($scope.eReceiptModel.auctions.quotes, 'bidRank');
			}else{
				auctionDetailsObj.auctions = [];
			}
			eReceiptService.auctionDetailsPopup(auctionDetailsObj);
		};
		if ($scope.eReceiptModel) {
			initController(true);
		}

		var resetAllocatedAgreements = function(_amt) {
			/*
			 * Loop to remove the additional non-linked agreements if amount is
			 * zero Reset the allocated agreement actual amount to zero
			 */
			for (var i = $scope.eReceiptModel.relatedAgreementNos.length - 1; i >= 0; i--) {
				if ($scope.eReceiptModel.relatedAgreementNos[i].isMoreAgreement && _amt) {
					$scope.eReceiptModel.relatedAgreementNos.splice(i, 1);
				} else if ($scope.eReceiptModel.relatedAgreementNos[i].isAllocated && $scope.eReceiptModel.relatedAgreementNos[i].agreementNo !== $scope.selectedAgreement.agreementNo) {
					$scope.eReceiptModel.relatedAgreementNos[i].isAllocated = false;
					$scope.eReceiptModel.relatedAgreementNos[i].totalActualAmount = $scope.eReceiptModel.relatedAgreementNos[i].totalBalanceAmount = $scope.eReceiptModel.relatedAgreementNos[i].allocatedAmount = 0;
					var balanceModel = _.union($scope.eReceiptModel.relatedAgreementNos[i].balanceAllocationModel, $scope.eReceiptModel.relatedAgreementNos[i].otherODCharges);
					for(var j=0;j<balanceModel.length;j++){
						balanceModel[j].actual = 0;
					}
				}
			}
		};

		/**
		 * Balance allocation logic is here. BRD: Allocation logic-whatever
		 * amount collected should be allocated first to EMIOD, and then the
		 * balance goes to AFC, FVC, and CBC and other charge codes.
		 * 
		 * @param {Number}
		 *            is the parameter. allocation will happen based on the
		 *            priority.
		 */
		var balanceAutoAllocation = function(_amt) {
			resetAllocatedAgreements(_amt);
			eReceiptService.autoAllocation($scope.selectedAgreement, $scope.receiptType);
			$scope.value.isPrimaryAllocated = $scope.selectedAgreement.isAllocated;
			$scope.value.primaryAgreementNo = $scope.selectedAgreement.agreementNo;
		};
		
		$scope.resetAllocatedLinedAgreements = function(){
			resetAllocatedAgreements($scope.receiptPostModel.Receipt.amountPaid);
			$scope.selectedAgreement.isDisabled = false; 
		};
		
		/**
		 * Trigger on change of the amount collected text box. Balance
		 * allocation will happen on change of the text box.
		 */
		$scope.getActualAmount = function(amtCol) {
			amtCol = Number(amtCol);
			if(amtCol && $scope.paymentMode.modeOfPayment === 'CASH' && !eReceiptService.validateCashLimit($scope.selectedAgreement,$scope.receiptPostModel.Receipt,$scope.productType)){
				resetAllocatedAgreements(amtCol);
				return;
			}
			if ($scope.value.isVishesh) {
				$scope.selectedAgreement.isAllocated = amtCol ? true : false;
				$scope.selectedAgreement.totalBalanceAmount = 0;
				return;
			}
			if ($scope.receiptType === 'SHORTFALL') {
				$scope.selectedAgreement.totalBalanceAmount = amtCol;
				$scope.selectedAgreement.allocatedAmount = amtCol;
				_.each($scope.selectedAgreement.balanceAllocationModel, function(value) {
					if (value.chargeType == 'Settlement Agreed' && amtCol > value.chargeAmount) {
						dialogService.showAlert(constants.ERROR_HEADER.alert, 'Alert', 'Actual amount is greater than the Settlement Agreed amount' );
					}
				});
				_.each($scope.selectedAgreement.balanceAllocationModel, function(value) {
					if (value.chargeType == 'Balance') {
						value.actual = amtCol;
						$scope.selectedAgreement.totalBalanceAmount = 0;
						$scope.paymentMode.enableSubmitButton = true;
					}
				});	
				eReceiptService.calculateActuals($scope.selectedAgreement);
				if ($scope.value.primaryAgreementNo === $scope.selectedAgreement.agreementNo) {
					$scope.value.isPrimaryAllocated = $scope.selectedAgreement.isAllocated;
				}							
				return;
			}	
			if ($scope.receiptType === 'IMD') {
				if(amtCol > $scope.selectedAgreement.totalOD){
					dialogService.showAlert(constants.ERROR_HEADER.alert, 'Alert', 'Amount collected cannot be greater than the Total OD amount' );	
					$scope.receiptPostModel.Receipt.amountPaid = '';
				}else{
					$scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.allocatedAmount = amtCol;
					if($scope.productType === 'VF'){
						$scope.eReceiptModel.firstSelectedLoan = $scope.selectedAgreement.loanID;					
						eReceiptService.imdAutoAllocation($scope.selectedAgreement, true);
					}else{
						var totalActualvalue = 	_.reduce($scope.selectedAgreement.balanceAllocationModel[0].charges, function(memo, num) { return memo + Number(num.actual)}, 0);
						$scope.selectedAgreement.totalBalanceAmount = Number(Number(amtCol) - totalActualvalue);
						$scope.selectedAgreement.isAllocated = $scope.selectedAgreement.totalBalanceAmount === 0;
					}
				}
				return;
			}
			if (!amtCol) {
				balanceAutoAllocation(amtCol);
				$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = 0;
				$scope.value.disablePayment = false;
				$scope.value.additonalAgrNo = '';
				return;
			}
			var receiptFlag;
			switch ($scope.receiptType) {
			case 'SALE':
			case 'miniStatement':
			case 'ADVANCE EMI':
				receiptFlag = true;
				break;
			default:
				receiptFlag = false;
			}
			if ($scope.receiptType === 'EMD') {
				$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.selectedAgreement.balanceAllocationModel[0].actual = amtCol;
			}
			if (receiptFlag || $scope.receiptType === 'FORECLOSURE' || $scope.value.isVishesh) {
				$scope.selectedAgreement.totalActualAmount = $scope.selectedAgreement.allocatedAmount = $scope.totalOD = amtCol;
				$scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.selectedAgreement.balanceAllocationModel[0].actual = amtCol;
				$scope.selectedAgreement.totalBalanceAmount = 0;
				$scope.selectedAgreement.isAllocated = true;
			} else {
				$scope.selectedAgreement.totalBalanceAmount = amtCol;
				$scope.selectedAgreement.allocatedAmount = amtCol;
				balanceAutoAllocation(amtCol);
			}
		};

		$scope.imdActualBlurHandler = function(value) {
			$scope.selectedAgreement.totalBalanceAmount = Number($scope.receiptPostModel.Receipt.amountPaid) - Number($scope.selectedAgreement.otherCharges + parseInt(value.chargeAmount));
			$scope.selectedAgreement.isAllocated = ($scope.selectedAgreement.allocatedAmount >= $scope.selectedAgreement.otherCharges);
		};

		/**
		 * get vendor details using buyer id. method will execute on focus out
		 * of buyer name field in EMD / Sale receipt
		 */
		var getVendorAgreementSummary = function() {
			eReceiptService.getAgreementDetails($scope.eReceiptModel.agreementNo, $scope.receiptType, true, $scope.buyer.buyerId).then(function(data) {
				if (data) {
					if ($scope.receiptType === 'SALE') {
						if(checkEMDReceiptPending(data.receiptDetails)){
							setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.EMD_APPROVAL_PENDING);
							return;
						}else{
							$scope.eReceiptModel = data;
							saleEMDValidation();	
						}
					}else{
						$scope.eReceiptModel = data;
						$scope.eReceiptModel.relatedAgreementNos = [ $scope.selectedAgreement ];
					}
					//$scope.receiptPostModel.AddressDetail.mobileNo = "";
					$scope.eReceiptModel = data;
					initController(false);
				}
			});
		};
		var checkEMDReceiptPending = function(_receiptDetails) {
			return (_receiptDetails && _receiptDetails.workStatus && (_receiptDetails.workStatus !== 'APPROVED' && _receiptDetails.workStatus !== 'REJECTED'));
		};
		var checkSaleAmt = function() {
			var linkedTotal = 0;
			_.each($scope.value.linkedSaleAgreements, function(value) {
				linkedTotal += Number(value.balAmt);
			});
			$scope.value.totalBalAmount = Number($scope.value.totalAmount) - (linkedTotal + $scope.receiptPostModel.Receipt.amountPaid || 0);
			if(!$scope.value.totalBalAmount){
				$scope.value.additonalAgrNo = '';
			}
		};
		
		$scope.changeBuyerType = function (buyersType) {
			$scope.buyer.buyerType = buyersType;
			$scope.buyerStageType = ($scope.buyer.buyerType.toLowerCase() === 'individual' || $scope.buyer.buyerType.toLowerCase() === 'proprietor') ? collectionConstants.REPO_BUYER_INDIVIDUAL : collectionConstants.REPO_BUYER_CORPORATE;  
			if($scope.buyer && $scope.buyer.kycDocument){
				$scope.buyer.kycDocument = {
					docType : "",
					docValue :"",
					imageRef : {}
				}
			}
			if ($scope.kyc_doc && $scope.kyc_doc.setFiles && $scope.buyer.kycDocument && $scope.buyer.kycDocument.imageRef){
				$scope.kyc_doc.setFiles($scope.buyer.kycDocument.imageRef);
			}
		};

		/**
		 * Initializing sale and EMD variables
		 */

		 $scope.saleBlurHandler = function(_amount) {
			if (_amount) {
				$scope.receiptPostModel.Receipt.amountPaid = (_amount - ($scope.eReceiptModel.receiptDetails && $scope.eReceiptModel.receiptDetails.amountPaid ? $scope.eReceiptModel.receiptDetails.amountPaid :0));
			} else {
				_amount = $scope.receiptPostModel.Receipt.amountPaid = '';
			}
			checkSaleAmt();
			$scope.eReceiptModel.unadjustedAmount = (_unadjustedAmt - _amount) < 0 ? 0 : (_unadjustedAmt - _amount);
			$scope.selectedAgreement.balanceAllocationModel[0].actual = $scope.receiptPostModel.Receipt.amountPaid;
			$scope.selectedAgreement.isAllocated = ($scope.receiptPostModel.Receipt.amountPaid > 0);
		};

		$scope.saleEmdSwitch = function(_amount) {
			var balanceAmt = parseInt($scope.eReceiptModel.approvedSaleAmount);
			if($scope.eReceiptModel.receiptDetails && $scope.eReceiptModel.receiptDetails.amountPaid){
				balanceAmt = balanceAmt-parseInt($scope.eReceiptModel.receiptDetails.amountPaid);
			}
			if (_amount && parseFloat(_amount)) {
				if(parseFloat(_amount) >= balanceAmt){
					dialogService.confirm(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.SALE_EMD_SWITCH).result.then(function() {
						$scope.value.receiptType = 'SALE';
						$scope.receiptChangeHandler($scope.value.receiptType,true);
					}, function() {
						$scope.receiptPostModel.Receipt.amountPaid = '';
					});
				} else{
					$scope.getActualAmount(_amount);
				}
			} else {
				return;
			}
		};

		var initSaleEMDObjects = function() {
			$scope.numbers = [];
			$scope.partyType = 'Applicant';
			$scope.paymentMode.modeOfPayment = '';
			$scope.selectedAgreement.isDisabled = $scope.value.disableSaleField = false;
			$scope.value.totalBalAmount = 0;
			$scope.value.disableCashMode = (($scope.eReceiptModel.allowCashReceipt && $scope.eReceiptModel.allowCashReceipt.toUpperCase() === 'N') || $scope.receiptType === 'SALE' || $scope.eReceiptModel.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY);
			if ($scope.eReceiptModel.vendorDetails && $scope.eReceiptModel.vendorDetails.vendorID) {
				$scope.receiptPostModel.AddressDetail.mobileNo = ($scope.eReceiptModel.vendorDetails.phoneNo && $scope.eReceiptModel.vendorDetails.phoneNo.length > 0) ? $scope.eReceiptModel.vendorDetails.phoneNo[$scope.eReceiptModel.vendorDetails.phoneNo.length-1] :'';
				$scope.value.buyerDetails = $scope.eReceiptModel.vendorDetails;
				if ($scope.receiptType === 'SALE' && checkEMDReceiptPending($scope.eReceiptModel.receiptDetails)) {
					setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.EMD_APPROVAL_PENDING);
					return;
				}
				checkBuyerDetails($scope.eReceiptModel.vendorDetails);
				$scope.numbers = $scope.eReceiptModel.vendorDetails.phoneNo;
				$scope.paymentMode.cash.pan = $scope.eReceiptModel.vendorDetails.panNo;
				eReceiptService.getAddressFromPincode($scope.eReceiptModel.vendorDetails.addressDetail, true).then(function(vendorAddress) {
					$scope.eReceiptModel.vendorDetails.addressDetail = vendorAddress;
					//$scope.vendorFullAddress = utility.setAddress(vendorAddress);
				});
				saleEMDValidation();
			} 
			if ($scope.receiptType === 'EMD') {
				$scope.receiptPostModel.Receipt.amountPaid = '';
				$scope.eReceiptModel.relatedAgreementNos = [ $scope.selectedAgreement ];
				$scope.selectedAgreement.balanceAllocationModel = [ {
					chargeAmount : 0,
					chargeType : 'EMD Amount',
					chargeID : collectionConstants.CHARGE_IDS.EXCESS,
					actual : 0
				}];
				$scope.selectedAgreement.isMoreAgreement = false;
				$scope.value.disableSaleField = ($scope.eReceiptModel.buyerID) ? true : false;
				$scope.selectedAgreement.totalActualAmount = 0;
			}
			if (!$scope.buyer.buyerName) {
				$scope.vendorFullAddress = [];
			} 

			
			$scope.checkTotalAmtBal = function() {
				checkSaleAmt();
			};
		};

		/**
		 * Initializing foreclosure variables
		 */
		var cannotForeclose;
		var initForeclosureObjects = function() {
			var setForeclosureData = function(data) {
				$scope.simulatedData.netReceivable = Math.round(data.netReceivable);
				$scope.simulatedData.amountCollected = Math.round(data.amountCollected);
				//$scope.value.disableCashMode = ($scope.simulatedData.amountCollected > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY); 
				$scope.receiptPostModel.Receipt.amountPaid = $scope.simulatedData.amountCollected;
				$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount = $scope.receiptPostModel.Receipt.amountPaid;
				$scope.dueData = data && data.dues;
				//$scope.dueData.prePaymentPenalty = (Number($scope.dueData.prePaymentPenalty) - Number($scope.dueData.prePaymentPenaltyTax));
				$scope.dueData.totalDues = Math.round(parseInt(data.dues.totalDues));
				$scope.refundData = data && data.refunds;
				$scope.simulatedData.simulateDate = $scope.interestTillDate.dateValue;
				balanceAutoAllocation($scope.receiptPostModel.Receipt.amountPaid);
			};
			$scope.simulateForeclosure = function() {
				if ($scope.interestTillDate.dateValue) {
					eReceiptService.simulateForeclosure($scope.eReceiptModel.agreementNo, $scope.interestTillDate.value).then(function(data) {
						initiateRequestObj.simulation = $scope.simulatedData = data;
						initiateRequestObj.agreementList = data.getForeClosureLA.linkedAgreements;
						initiateRequestObj.interestTillDate = new Date($scope.interestTillDate.dateValue);
						var showLAPopup = ($scope.eReceiptModel.waiverRequestStatus !== 'FORECLOSURE-APPROVED' && $scope.eReceiptModel.waiverRequestStatus !== 'WAIVER-APPROVED' || (data.getForeClosureLA && !data.getForeClosureLA.justification));
						if ($scope.productType === 'VF' && initiateRequestObj.agreementList && initiateRequestObj.agreementList.length && showLAPopup) {
							initiateRequestObj.receiptType = $scope.receiptType;
							initiateRequestObj.productType = $scope.productType;
							initiateRequestObj.branchID = $scope.eReceiptModel.branchID;
							initiateRequestObj.request = 'RECEIPT';
							eReceiptService.showLinkedAgreements({
								caseDetailInfo : initiateRequestObj
							});
							messageBus.onMsg('SHOW_SIMULATION_PAGE', function() {
								setForeclosureData($scope.simulatedData);
							});
							return;
						}
						setForeclosureData(data);
					});
				}
			};
			$scope.interestTillDate = new DatePickerConfig({
				value : new Date(),
				minDate : new Date()
			// maxDate : new Date($scope.eReceiptModel.nextEMIDueDate)
			});
			$scope.closureDate = eReceiptService.getDateConfig(new Date());
			$scope.refundDetails = function() {
				$scope.refundData.agreementNo = $scope.eReceiptModel.agreementNo;
				$scope.refundData.customerName = $scope.applicantDetail.name;
				$scope.refundData.fcDetails = $scope.simulatedData.totalRefundDetails;
				eReceiptService.getRefundDetails($scope.refundData);
			};
			$scope.dueDetails = function() {
				$scope.dueData.agreementNo = $scope.eReceiptModel.agreementNo;
				$scope.dueData.customerName = $scope.applicantDetail.name;
				$scope.dueData.foreclosureDetails = $scope.simulatedData.totalDueDetails;
				eReceiptService.getDueDetails($scope.dueData);
			};
			$scope.loadRepaySchedule = function() {
				eReceiptService.getRepaySchedule($scope.applicantDetail.name, $scope.eReceiptModel.agreementNo);
			};
			if (cannotForeclose) {
				cannotForeclose();
			}
			cannotForeclose = messageBus.onMsg('CANNOT_FORECLOSE', function() {
				$scope.value.receiptType = $scope.receiptType = 'OD';
				initController();
			});
		};

		var isShortFallCase = function(){
			if($scope.receiptType === 'closed' && $scope.eReceiptModel.npaStageVal === 'SALE' || $scope.receiptType === 'closed' && $scope.eReceiptModel.npaStageID.toUpperCase() === 'WRITEOFF' && $scope.eReceiptModel.isShortfall){
				return ($scope.selectedAgreement.totalActualAmount <= $scope.selectedAgreement.allocatedAmount && Number($scope.receiptPostModel.Receipt.amountPaid) === $scope.selectedAgreement.balanceAllocationModel[0].actual);
			}
			return false;
		}
		/**
		 * method used to calculate the total actual amount. Trigger on focus
		 * out of the actual text box in the balance allocation table
		 */
		$scope.calculateActuals = function(item) { 
			if(item.chargeID == '110323') { 
				if (!$scope.receiptPostModel.Receipt.amountPaid) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.AMOUNT_CHECK);
					item.actual = 0;
					return;
				} else if(item.actual > 750) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.COPY_OF_DOCUMENT);
					item.actual = 0;
				}
			} else if(item.chargeID == '110338') {  
				var onePercentPOS = (($scope.eReceiptModel.principalOS/100)*1);
				var eighteenPercent =  ((onePercentPOS/100)*18);
				var rateResetCharge = (Math.round(onePercentPOS+eighteenPercent));
				console.log(rateResetCharge);
				if(item.actual > rateResetCharge) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.RATE_RESET_CHARGES);
					item.actual = 0;
				}
				if (!$scope.receiptPostModel.Receipt.amountPaid) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.AMOUNT_CHECK);
					item.actual = 0;
					return;
				}
			}
			else if (item.actual) {
				if (!$scope.receiptPostModel.Receipt.amountPaid) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.AMOUNT_CHECK);
					item.actual = 0;
					return;
				}else if ($scope.receiptType !== 'closed' && $scope.paymentMode.modeOfPayment === 'CASH' && item.actual > item.chargeAmount && collectionConstants.CHARGES_EXCLUDE.indexOf(item.chargeID) < 0) {
					if((item.chargeID === '240' && Number(item.actual) > Number((item.chargeAmount*0.2) + item.chargeAmount) || item.chargeID !== '240')){
						eReceiptService.showValidationMessage(item.chargeType);
						item.actual = 0;					
					}
				}else if (item.actual > item.chargeAmount && $scope.receiptType !== 'EMD' && $scope.receiptType !== 'closed' && $scope.paymentMode.modeOfPayment === 'CASH') {
					if(((item.chargeID === collectionConstants.CHARGE_IDS.AFC && item.actual > $scope.eReceiptModel.targetAFC) || (item.chargeID === collectionConstants.CHARGE_IDS.SHORT_FALL && $scope.receiptType === 'OD'))){
						eReceiptService.showValidationMessage(item.chargeType);
						item.actual = 0;
					}else if(item.chargeID === collectionConstants.CHARGE_IDS.EMI && item.actual > $scope.eReceiptModel.targetEMI){
						var msg = $scope.eReceiptModel.targetEMI == 0 ? "You cannot collect EMI greater than overdue amount" : 'You can collect EMI for an amount Rs.'+ utility.currencyFormatter($scope.eReceiptModel.targetEMI)+' in cash';
						dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', msg);
						item.actual = 0;					
					}else{						
						var exclusiveCharge = _.findWhere(collectionConstants.CHARGES_MAX_LIMIT,{'chargeID':item.chargeID});
						if(exclusiveCharge && item.actual > exclusiveCharge.maxLimit){						
							dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', "You cannot collect more than Rs." +utility.currencyFormatter(exclusiveCharge.maxLimit)+" against " +item.chargeType + " for the month. Please collect through Cheque/DD/POS/RTGS");							
							item.actual = 0;
						}else{
							dialogService.showAlert(constants.ERROR_HEADER.alert, 'Mismatch', 'Actual ' + item.chargeType + ' amount is greater than overdue amount');
						}
					}
				}
			} else {
				item.actual = 0;
			}
			if (item.chargeID === collectionConstants.CHARGE_IDS.EXCESS) {
				$scope.value.isOtherChargeEntered = (item.actual > 0);
			}
			eReceiptService.calculateActuals($scope.selectedAgreement);
			if ($scope.value.primaryAgreementNo === $scope.selectedAgreement.agreementNo) {
				$scope.value.isPrimaryAllocated = $scope.selectedAgreement.isAllocated;
			}
			$scope.eReceiptModel.isSFReceipt = isShortFallCase();
		};
		/**
		 * Reset the balance allocation table.
		 */
		$scope.doReset = function() {
			eReceiptService.resetAllocationTable($scope.selectedAgreement);
			$scope.eReceiptModel.isSFReceipt = isShortFallCase();
		};
		$scope.foucsHandler = function(item) {
			if (parseInt(item.actual) === 0) {
				item.actual = '';
			}
		};
		/**
		 * Method will call on change of payer type
		 */
		$scope.payerTypeHandler = function(value) {
			$scope.partyType = value;
			if ($scope.receiptType === 'PART PAYMENT') {
				setPartPaymentBalanceTable($scope.value.accountType);
			}
		};
		var displayAlertMessage = function(_messg){
			dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, _messg).result.then(function(){
			},function(){
				$scope.getAgreementDetails($scope.selectedAgreement);
			});
			return;
		};
		$scope.getAgreementDetails = function(value) {
			value.isSelected = !value.isSelected;
			var totalActualForAllocatedAgreement = 0;
			_.each($scope.eReceiptModel.relatedAgreementNos, function(item) {
				item.isSelected = (item.agreementNo == value.agreementNo);
				if (item.isAllocated) {
					totalActualForAllocatedAgreement += parseInt(item.totalActualAmount);
				}
			});
			if ($scope.receiptType === 'EMD') {
				$scope.selectedAgreement = value;
				$scope.selectedAgreement.balanceAllocationModel = [ {
					chargeAmount : 0,
					chargeType : 'EMD Amount',
					chargeID : collectionConstants.CHARGE_IDS.EXCESS,
					actual : value.totalActualAmount
				} ];
				$scope.selectedAgreement.totalBalanceAmount = ($scope.receiptPostModel.Receipt.amountPaid - totalActualForAllocatedAgreement);
				$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount + value.totalActualAmount;
				$scope.selectedAgreement.isDisabled = ($scope.receiptPostModel.Receipt.amountPaid && value.agreementNo !== $scope.eReceiptModel.agreementNo);
				return;
			}
			if (value.isSelected) {
				eReceiptService.getAgreementDetails(value.agreementNo, $scope.receiptType, !value.isAllocated, '', $scope.productType).then(function(data) {
					if (data) {
						if(data.agreementStatus && data.agreementStatus.toUpperCase() === 'C' && data.productGroup === 'VF'){
							return displayAlertMessage("The selected agreement has been closed already, cannot proceed OD receipting");
						}
						$scope.value.additonalAgrNo = '';
						data = eReceiptService.setAgreementChargeDetails(data, $scope.receiptType, $scope.productType);
						$scope.selectedAgreement = value;
						if (_.where($scope.eReceiptModel.relatedAgreementNos, {isAllocated : true}).length === 0) {
							$scope.receiptForm.resetFormValidation(true);
							$scope.value.isGeneralPayerUsed = false;
							getBalanceDetailsInfo = $scope.eReceiptModel = data;
							initController(true);
							$scope.value.disablePayment = false;
						} else {
							$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = ($scope.receiptPostModel.Receipt.amountPaid - totalActualForAllocatedAgreement);
							$scope.selectedAgreement.assetDetail = data.assetDetail;
							var ODInfo = {
								balanceOS : Math.round(data.balanceOS),
								billedEMI : 0,
								pendingEMI : 0,
								futureEMI : 0
							}, _bic, _pec;
							_bic = data.billedInstallmentCount ? Number(data.billedInstallmentCount) : 0;
							_pec = data.paidEMICount ? Number(data.paidEMICount) : 0;
							$scope.value.pendingEMI = ODInfo.pendingEMI = _bic - _pec;
							ODInfo.futureEMI = Number(data.futureEMICount);
							ODInfo.billedEMI = _bic;
							$scope.selectedAgreement.ODInfo = ODInfo;
							if (!$scope.selectedAgreement.balanceAllocationModel || !$scope.selectedAgreement.balanceAllocationModel.length) {
								$scope.selectedAgreement.balanceAllocationModel = data.ODDetails;
								$scope.selectedAgreement.otherODCharges = data.otherODCharges;
							}
							$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
							if ($scope.selectedAgreement.isAllocated) {
								$scope.selectedAgreement.totalBalanceAmount -= $scope.selectedAgreement.totalActualAmount;
							}
							initiateRequestObj = {
								principalOS : data.futurePrincipalAmount,
								expenseDetails : data.expenseDetails,
								agreementNo : data.agreementNo
							};
							setAgreementDetails(data);
						}
						eReceiptService.setAgreementOrder($scope.eReceiptModel.relatedAgreementNos, $scope.selectedAgreement);
						$scope.selectedAgreement.isDisabled = (value.agreementNo !== $scope.eReceiptModel.agreementNo);
						if(!$scope.value.disableCashMode){
							$scope.value.disableCashMode = ((data.allowCashReceipt && data.allowCashReceipt.toUpperCase() === 'N') || data.nextEMIAmount > collectionConstants.OTHERS.MAX_CASH_LIMIT_PER_DAY);
							$scope.paymentMode.modeOfPayment = $scope.value.disableCashMode && $scope.paymentMode.modeOfPayment === 'CASH' ? '' : $scope.paymentMode.modeOfPayment;
						}
					} else {
						value.isSelected = false;
						$scope.selectedAgreement.isSelected = true;
					}
				});
			}
		};
		/**
		 * method trigger on click of the agreement list. To get the casedetails
		 * of the selected agreement. '.then' is the call back function once
		 * receive the response.
		 */
		$scope.getAgreement = function(value) {
			if (value.isSelected) {
				return;
			}
			var _isAllocated =  _.where($scope.eReceiptModel.relatedAgreementNos, {
				isAllocated : true
			}).length > 0;
			var checkLen =  !_isAllocated && (_.where($scope.eReceiptModel.relatedAgreementNos, {
				isMoreAgreement : true
			}).length);
			if (value.isMoreAgreement && checkLen) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.PRIMARY_AGR_NOT_ALLOCATED);
				return;
			} else if (checkLen && !value.isMoreAgreement) {
				dialogService.confirm(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.LINKED_AGR_SELECTED).result.then(function() {
					$scope.getAgreementDetails(value);
				}, function() {
				});
				return;
			}else if(_isAllocated && !$scope.paymentMode.modeOfPayment && !value.isAllocated){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "Please choose the payment method before selecting the agreement");
				return;
			}
			$scope.getAgreementDetails(value);
		};
		/**
		 * method trigger on click of the Vehicle list.
		 */
		$scope.getVehicle = function(value) {
			if (value.isSelected) {
				return;
			}
			value.isSelected = !value.isSelected;
			var totalActualForAllocatedVehicle = 0, i, tempObj, item;

			for (i = $scope.eReceiptModel.loanDetails.length - 1; i >= 0; i--) {
				item = $scope.eReceiptModel.loanDetails[i];
				item.isSelected = (item.vehicleDetail.vehicleID === value.vehicleDetail.vehicleID);
				if (item.isAllocated) {
					totalActualForAllocatedVehicle += item.totalOD;
				}
				if (item.isSelected) {
					tempObj = item;
					$scope.eReceiptModel.loanDetails.splice(i, 1);
				}
			}
			$scope.eReceiptModel.loanDetails.unshift(tempObj);
			$scope.selectedAgreement = value;
			$scope.selectedAgreement.allocatedAmount = $scope.selectedAgreement.totalBalanceAmount = ($scope.receiptPostModel.Receipt.amountPaid - totalActualForAllocatedVehicle);
			getLoanCharges($scope.selectedAgreement, true);
			$scope.selectedAgreement.isDisabled = ($scope.eReceiptModel.firstSelectedLoan && $scope.eReceiptModel.firstSelectedLoan !== $scope.selectedAgreement.loanID);
		};

		var getBuyerDetails = function(buyerID,type,isKYC) {
			$scope.value.linkedSaleAgreements = [];
			eReceiptService.getBuyerName(buyerID,type,isKYC).then(function(result) {
				var data;
				if (!result || result.length == 0) {
					$scope.checkBuyer = false;
					$scope.value.buyerDetails = {};
					if(type === "vendorID"){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.invalidBuyer, "Entered Buyer ID is not exists in the system. Please enter a valid buyer ID");
						$scope.buyer = '';
						$scope.editBuyer = {				
							isBuyerName:false,		
							isGstNo: false,
							isPanNo:false,				
							isDoorNo: false,
							isStreet: false,
							isPincode:false,
							isPhoneNo :false	
						};
						$scope.buyer = {};
						$scope.receiptPostModel.AddressDetail.mobileNo = "";
						$scope.checkKYCValue('');
						if ($scope.pan_doc && $scope.pan_doc.setFiles){
							$scope.pan_doc.setFiles({});
						}
					}else if(type === 'phoneNo'){
						$scope.value.disableBuyerID = true;
						$scope.buyer = {};
						if ($scope.pan_doc && $scope.pan_doc.setFiles){
							$scope.pan_doc.setFiles({});
						}
					}
					return;
				} else {
					var buyerList = _.where(result, {vendorType:collectionConstants.OTHERS.BUYERS});
					if(buyerList.length > 0){
						$scope.checkBuyer = true;
						//data = buyerList[buyerList.length-1];
						//$scope.value.buyerDetails = data;
						if(type !== "vendorID"){
							if(buyerList.length == 1){
								data = buyerList[0];
								$scope.value.buyerDetails = data;
								dialogService.confirm(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.KYC_VERIFICATION + "("+data.vendorID+") ?").result.then(
									function() {
										$scope.value.isEditBuyer = true;
										$scope.value.buyerDetails = data;
										checkBuyerDetails(data,type,isKYC);
										getVendorAgreementSummary();
									}, function() {
										if(!isKYC){
											if(type === 'phoneNo'){
												$scope.receiptPostModel.AddressDetail.mobileNo = "";
											}else{
												$scope.buyer[type]  = "";
											}
										}else{
											$scope.buyer.kycDocument.docValue = "";
										}
									}
								);
							}else{
								dialogService.showCustomDialog('app/collections/eReceipt/receipting/partials/popup/cashTenLakh.html', 'repoStageController', {
									data: function() {
										return {
											vendors : buyerList,
											isMultiVendor : true
										};
									}
								},function(result){
									if (result.status === "success") {
										$scope.value.buyerDetails = result.data;
										$scope.value.isEditBuyer = true;
										checkBuyerDetails(result.data,type,isKYC);
										getVendorAgreementSummary();
									}else{
										if(!isKYC){
											if(type === 'phoneNo'){
												$scope.receiptPostModel.AddressDetail.mobileNo = "";
											}else{
												$scope.buyer[type]  = "";
											}
										}else{
											$scope.buyer.kycDocument.docValue = "";
										}
									}
								},'md', 'modal-custom', true);
							}
						}else{
							$scope.value.buyerDetails = data = buyerList[0];
							$scope.value.isEditBuyer = true;
							if ($scope.pan_doc && $scope.pan_doc.setFiles){
								$scope.pan_doc.setFiles({});
							}
							if ($scope.kyc_doc && $scope.kyc_doc.setFiles){
								$scope.kyc_doc.setFiles({});
							}
							checkBuyerDetails(data,type,isKYC);	
							getVendorAgreementSummary();
						}				
						if(type !== 'vendorID' && !data){
							$scope.checkBuyer = false;
							$scope.buyer.buyerId = '';
						}
					} else {
						$scope.checkBuyer = false;
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.invalidBuyer, collectionConstants.ERROR_MSG.BUYER_CHECK);
					}
				}
			
			});
		};

		$scope.getBuyerName = function(buyerId,type,isKYC) {
			if(type === "vendorID" && $scope.value.buyerDetails && $scope.value.buyerDetails.vendorID === buyerId){
				return;
			}
			if($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD'){
				if (buyerId && buyerId.length) {
					if ($scope.value.linkedSaleAgreements.length) {
							dialogService.confirm('Warning', "Warning", "Are you sure want to change the Buyer ID.? You will lose the entered data.").result.then(function() {
								getBuyerDetails(buyerId,type);
							}, function() {
						});
					} else {
						getBuyerDetails(buyerId,type,isKYC);
					}
				}else{
					if(type === "vendorID"){
						if(!buyerId){
							$scope.receiptPostModel.AddressDetail.mobileNo = "";
							$scope.editBuyer = {				
								isBuyerName:false,		
								isGstNo: false,
								isPanNo:false,				
								isDoorNo: false,
								isStreet: false,
								isPincode:false,
								isPhoneNo :false	
							};
							$scope.value.buyerDetails = {}; 
							$scope.buyer = '';
							if ($scope.pan_doc && $scope.pan_doc.setFiles){
								$scope.pan_doc.setFiles({});
							}
							if ($scope.kyc_doc && $scope.kyc_doc.setFiles){
								$scope.kyc_doc.setFiles({});
							}
							$scope.buyer = {};
							$scope.changeBuyerType("Individual");
						}
					}else if(type === 'phoneNo'){
						$scope.value.disableBuyerID = false;
					}
				}
			}
		}
		var updateBalanceFunction;
		$scope.showOtherOD = function() {
			if ($scope.value.isVishesh) {
				var obj = {
					expenseDetails : $scope.eReceiptModel.expenseDetails,
					isVishesh : true
				};
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/waiverDetails.html', 'detailsPopupController', 'sm', obj);

			} else {
				if (updateBalanceFunction) {
					updateBalanceFunction();
				}
				updateBalanceFunction = messageBus.onMsg('UPDATE_BALANCE_TABLE', function(data, value) {
					$scope.selectedAgreement.otherODCharges = value;
					$scope.selectedAgreement.showOtherODs = true;
					$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
					var otherOD = _.findWhere($scope.selectedAgreement.otherODCharges, {
						chargeID : collectionConstants.CHARGE_IDS.EXCESS
					});
					$scope.value.isOtherChargeAdded = otherOD ? true : false;
					if ($scope.value.isOtherChargeAdded) {
						$scope.value.isOtherChargeEntered = (otherOD.actual > 0);
					}
				}, $scope);
				// Exclude the charges detail which are available in UI
				var ODChargesList = _.reject(getchargesListResolver, function(item1) {
					return _.findWhere($scope.eReceiptModel.ODDetails, {
						chargeID : item1.chargeID
					});
				});
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/otherOD.html', 'otherODPopupController', 'md', {
					chargeList : ODChargesList,
					otherCharges : $scope.selectedAgreement.otherODCharges,
					productType : $scope.productType
				});
			}
		};

		$scope.removeOtherCharge = function(charges, index) {
			if (charges.isDefault) {
				return;
			}
			$scope.selectedAgreement.totalActualAmount -= charges.actual;
			$scope.selectedAgreement.totalBalanceAmount += charges.actual;
			charges.actual = 0;
			$scope.selectedAgreement.otherODCharges.splice(index, 1);
			$scope.totalOD = eReceiptService.getTotalOD($scope.selectedAgreement);
			if (charges.chargeID === collectionConstants.CHARGE_IDS.EXCESS) {
				$scope.value.isOtherChargeAdded = $scope.value.isOtherChargeEntered = false;
				$scope.receiptForm.resetSubmited();
			}
			$scope.selectedAgreement.isAllocated = ($scope.selectedAgreement.totalActualAmount > 0);
		};

		var initiatePDDVariables = function() {
			$scope.registrationDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.pddSubmitModel.pddAcknowledgement.RCDetail.registrationDate = val;
				},
				readonly : true
			});
			$scope.insuranceEndDate = new DatePickerConfig({
				value : '',
				minDate : $scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate,
				onchange : function(val) {
					$scope.insuranceEndDate.setDateVal(val);
					$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.expiryDate = val;
				},
				readonly : true
			});
			$scope.insuranceStartDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.insuranceStartDate.setDateVal(val);
					$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate = $scope.insuranceEndDate.minDate = new Date(val.getFullYear(), val.getMonth(), val.getDate() + 1);
				},
				readonly : true
			});
			$scope.invoiceDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceDate = val;
				},
				readonly : true
			});
			$scope.insReceivedDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.pddSubmitModel.pddAcknowledgement.receivedDate = val;
				}
			});
			$scope.invReceivedDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.pddSubmitModel.pddAcknowledgement.receivedDate = val;
				}
			});
			$scope.RCReceivedDate = new DatePickerConfig({
				value : '',
				maxDate : new Date(),
				onchange : function(val) {
					$scope.pddSubmitModel.pddAcknowledgement.receivedDate = val;
				}
			});
		};
		var initPDDObjects = function() {
			$scope.pddSubmitModel = eReceiptService.getAcknowledgementModel();
			var selectedDocType = '', docIndex;
			$scope.partyType = 'Applicant';
			$scope.documentTypes = angular.copy(collectionConstants.REPAY_MODES);
			$scope.imageCategory.insurance = _.findWhere($globalScope.imageCategories, {
				subCategory : 'Insurance'
			});
			$scope.imageCategory.invoice = _.findWhere($globalScope.imageCategories, {
				subCategory : 'Invoice'
			});
			$scope.imageCategory.RC = _.findWhere($globalScope.imageCategories, {
				subCategory : 'RC'
			});
			$scope.selectedAgreement.isAllocated = true;

			initiatePDDVariables();
			$scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType = $scope.documentTypes[0];
			if ($scope.pddData.RC) {
				if ($scope.pddData.RC.status === 'C') {
					docIndex = _.findIndex($scope.documentTypes, {
						id : 'RC'
					});
					$scope.documentTypes.push($scope.documentTypes.splice(docIndex, 1)[0]);
				}
				$scope.pddSubmitModel.pddAcknowledgement.RCDetail = $scope.pddData.RC.RCDetail;
			}
			if ($scope.pddData.invoice) {
				if ($scope.pddData.invoice.status === 'C') {
					docIndex = _.findIndex($scope.documentTypes, {
						id : 'INVOICE'
					});
					$scope.documentTypes.push($scope.documentTypes.splice(docIndex, 1)[0]);
				}
				$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail = $scope.pddData.invoice.invoiceDetail;
			}
			if ($scope.pddData.insurance) {
				if ($scope.pddData.insurance.status === 'C') {
					docIndex = _.findIndex($scope.documentTypes, {
						id : 'INSURANCE'
					});
					$scope.documentTypes.push($scope.documentTypes.splice(docIndex, 1)[0]);
				}
				$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail = $scope.pddData.insurance.insuranceDetail;
			}

			selectedDocType = $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType = $scope.documentTypes[0].id;
			if ($scope.pddData.invoice && !$scope.pddData.RC) {
				$scope.pddSubmitModel.pddAcknowledgement.RCDetail.engineNo = $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.engineNo;
				$scope.pddSubmitModel.pddAcknowledgement.RCDetail.chassisNo = $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.chassisNo;
			} else if (!$scope.pddData.invoice && $scope.pddData.RC) {
				$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.engineNo = $scope.pddSubmitModel.pddAcknowledgement.RCDetail.engineNo;
				$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.chassisNo = $scope.pddSubmitModel.pddAcknowledgement.RCDetail.chassisNo;
			}
			if ($scope.pddData.insurance) {
				$scope.insuranceEndDate.setDateVal(new Date($scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.expiryDate));
				$scope.insuranceStartDate.setDateVal(new Date($scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.policyDate));
				$scope.insReceivedDate.setDateVal(new Date($scope.pddData.insurance.receivedDate));
			}
			if ($scope.pddData.invoice) {
				$scope.invoiceDate.setDateVal(new Date($scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceDate));
				$scope.invReceivedDate.setDateVal(new Date($scope.pddData.invoice.receivedDate));
			}
			if ($scope.pddData.RC) {
				$scope.registrationDate.setDateVal(new Date($scope.pddSubmitModel.pddAcknowledgement.RCDetail.registrationDate));
				$scope.RCReceivedDate.setDateVal(new Date($scope.pddData.RC.receivedDate));
			}
			$scope.documentChangeHandler = function(docType) {
				var str = docType === 'RC' ? 'rc' : docType === 'INVOICE' ? 'invoice' : 'ins';
				$scope.value.disableSubmitButton = ($scope.pddData[str + 'Details'] && $scope.pddData[str + 'Details'].status === 'C');
				if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'RC' && ($scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.engineNo || $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.chassisNo)) {
					$scope.pddSubmitModel.pddAcknowledgement.RCDetail.engineNo = $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.engineNo;
					$scope.pddSubmitModel.pddAcknowledgement.RCDetail.chassisNo = $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.chassisNo;
				} else if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'INVOICE' && ($scope.pddSubmitModel.pddAcknowledgement.RCDetail.engineNo || $scope.pddSubmitModel.pddAcknowledgement.RCDetail.chassisNo)) {
					$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.engineNo = $scope.pddSubmitModel.pddAcknowledgement.RCDetail.engineNo;
					$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.chassisNo = $scope.pddSubmitModel.pddAcknowledgement.RCDetail.chassisNo;
				}
				$scope.pddSubmitModel.pddAcknowledgement.receivedDate = $scope.pddData[str + 'Details'] ? $scope.pddData[str + 'Details'].receivedDate : '';
				$scope.receiptForm.resetSubmited(true);
				$scope.pddData.interfaceDetails = $scope.pddData[str + 'Details'] ? $scope.pddData[str + 'Details'].interfaceDetails : {};
			};
			$scope.documentChangeHandler(selectedDocType);
		};
		var loadInsuranceProivders = function() {
			eReceiptService.getInsuranceProviders().then(function(data) {
				$scope.insuranceProviders = data;
				initPDDObjects();
			});
		};
		var invalidIFSC, invalidMICR, isAgreedSwap, swapOptionFunction;
		var initRPDCObjects = function() {
			if (!$scope.eReceiptModel.rpdcAgreementList || !$scope.eReceiptModel.rpdcAgreementList.length) {
				setDefaultReceiptType(constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.PDC_NOT_FOUND);
				return;
			}
			$scope.imageCategory.RPDC = _.findWhere($globalScope.imageCategories, {
				subCategory : 'RPDC'
			});
			// RPDC is only for Applicant
			$scope.partyType = 'Applicant';
			$scope.rePayBankDetails = {};
			$scope.selectedAgreement.isAllocated = true;
			$scope.repayModes = collectionConstants.RPDC_REPAY_MODES;
			var defaultValues = {};
			$scope.value.accountTypes = collectionConstants.ACCOUNT_TYPES;
			$scope.value.bank = '';
			$scope.showSwapScreen = false;
			$scope.rpdcSubmitModel = eReceiptService.getAckRpdc();
			var popUpType;
			isAgreedSwap = invalidMICR = invalidIFSC = false;
			var setRePayDetails = function() {
				_.each($scope.eReceiptModel.rightSideColumn.repaymentBankDetails, function(item) {
					if (item.PDCDetails && item.PDCDetails[0]) {
						$scope.rePayBankDetails.bankAccNo = item.PDCDetails[0].bankAccountNo;
						$scope.rePayBankDetails.bankID = item.PDCDetails[0].pdcBankID;
						$scope.rePayBankDetails.branchID = item.PDCDetails[0].bankDetail.bBranchID;
						$scope.rePayBankDetails.micrCode = item.PDCDetails[0].bankDetail.micrCode;
						$scope.rePayBankDetails.ifsCode = item.PDCDetails[0].bankDetail.ifsCode;
						$scope.rePayBankDetails.repayMode = $scope.repayModes[0];
						var bankObj = _.findWhere($scope.bankList, {
							bankID : item.PDCDetails[0].pdcBankID
						});
						$scope.rePayBankDetails.bankName = (bankObj) ? bankObj.name : '';
					}
				});
			};
			var setDefaultValues = function() {
				$scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited = !$scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited ? 0 : $scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited;
				$scope.value.emiDue = $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible + $scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited;
				if (eReceiptService.bankNames.length === 0) {
					masterService.getPDCBank().then(function(data) {
						$scope.bankList = data;
						eReceiptService.bankNames = data;
						var bankObj = _.findWhere($scope.bankList, {
							bankID : $scope.rePayBankDetails.bankID
						});
						$scope.rePayBankDetails.bankName = (bankObj) ? bankObj.name : '';
						setRePayDetails();
					});
				} else {
					$scope.bankList = eReceiptService.bankNames;
					setRePayDetails();
				}
				$scope.value.bank = '';
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = '';
				$scope.branchList = [];
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].ifsCode = '';
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].accountNo = '';
				$scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType = $scope.repayModes[0];
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].micrCode = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID = '';
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].noOfChequeCollected = $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible;
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].isDisabled = false;
				$scope.value.totalEMIOD = ($scope.eReceiptModel.linkedAgreements) ? $scope.eReceiptModel.linkedAgreements.totalEmiAmount : 0;
				if ($scope.eReceiptModel.linkedAgreements) {
					var chargeAmtArr = _.pluck($scope.eReceiptModel.linkedAgreements.linkDetails, 'emiAmount');
					$scope.value.rpdcOD = _.reduce(chargeAmtArr, function(memo, num) {
						return memo + num;
					}, 0);
				}
			};
			setDefaultValues();
			var modifiedField;
			var getPDCBankName = function(bankID, cityID) {
				masterService.getMasters("PdcBank", {
					bankID : bankID,
					cityID : cityID
				}).then(function(banks) {
					$scope.bankList = banks;
					$scope.value.bank = banks[0];
				});
			};
			var resetBankDetails = function(value) {
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0][value] = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = '';
				$scope.value.bank = '';
				$scope.bankList = eReceiptService.bankNames;
				$scope.branchList = [];
			};
			var getBankBranchDetails = function(type) {
				if (type === 'ifsc' && !invalidIFSC) {
					masterService.getBankIdFromIFSC($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].ifsCode, 'BankBranch').then(function(data) {
						if (!data || data.length === 0 || !data[0].bankID) {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.INVALID_IFSC);
							invalidIFSC = true;
							return;
						}
						var item = data[0];
						$scope.branchList = [ item ];
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = item.bankID;
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID = item.bBranchID;
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].micrCode = item.micrCode;
						getPDCBankName(item.bankID, item.cityID);
						invalidIFSC = false;
						invalidMICR = false;
						$scope.value.disableBank = true;
					});
				} else if (type === 'micr' && !invalidMICR) {
					masterService.getBankIdFromMICR($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].micrCode, 'BankBranch').then(function(data) {
						if (!data || data.length === 0) {
							invalidMICR = true;
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_MICR);
							return;
						}
						var item = data[0];
						$scope.branchList = [ item ];
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].ifsCode = (!item.ifsCode) ? '' : item.ifsCode;
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = item.bankID;
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID = item.bBranchID;
						getPDCBankName(item.bankID, item.cityID);
						invalidMICR = false;
						invalidIFSC = false;
						$scope.value.disableBank = true;
					});
				} else if (type === 'bank' || type === 'repay') {
					if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'SI') {
						$scope.bankList = eReceiptService.bankNames;
						$scope.value.bank = _findWhere($scope.bankList, {
							bankID : '002'
						});
						$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = '002';
					}
					if ($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID) {
						masterService.getBankBranches($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID).then(function(data) {
							$scope.branchList = data;
						});
					}
				}
			};
			$scope.showPopup = function(item, value) {
				var isValid = false;
				modifiedField = value;
				if (value === 'bank') {
					$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID = $scope.value.bank.bankID;
					item.bankID = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID;
					isValid = ($scope.rePayBankDetails.bankID !== item.bankID);
					getBankBranchDetails(value);
				} else if (value === 'accNo' && item.accountNo && $scope.rePayBankDetails.bankAccNo !== item.accountNo) {
					isValid = true;
				} else if (value === 'branch' && $scope.rePayBankDetails.branchID !== item.bBranchID) {
					var branchObj = _.findWhere($scope.branchList, {
						bBranchID : item.bBranchID
					}) || {};
					item.ifsCode = (!branchObj.ifsCode) ? '' : branchObj.ifsCode;
					item.micrCode = (!branchObj.micrCode) ? '' : branchObj.micrCode;
					invalidMICR = invalidIFSC = false;
					isValid = true;
				} else if (value === 'repay' && $scope.rePayBankDetails.repayMode !== item) {
					isValid = true;
				} else if (value === "ifsc") {
					if (item.ifsCode) {
						if (item.ifsCode && item.ifsCode.length < 11) {
							resetBankDetails('micrCode');
							$scope.value.disableBank = false;
							invalidIFSC = true;
						} else {
							invalidIFSC = false;
							if ($scope.rePayBankDetails.ifsCode !== item.ifsCode) {
								isValid = true;
							} else {
								getBankBranchDetails(value);
							}
						}
					} else {
						resetBankDetails('micrCode');
						$scope.value.disableBank = invalidIFSC = false;
						return;
					}
				} else if (value === "micr") {
					if (item.micrCode) {
						if (item.micrCode && item.micrCode.length < 9) {
							$scope.value.disableBank = false;
							invalidMICR = true;
							resetBankDetails('ifsCode');
						} else {
							invalidMICR = false;
							if ($scope.rePayBankDetails.micrCode !== item.micrCode) {
								isValid = true;
							} else {
								getBankBranchDetails(value);
							}
						}
					} else {
						resetBankDetails('ifsCode');
						$scope.value.disableBank = invalidMICR = false;
						return;
					}
				}
				popUpType = 'info';
				if (isAgreedSwap) {
					getBankBranchDetails(value, item);
				} else {
					$scope.showSwapPopUp(isValid, popUpType, value);
				}
			};
			var zeroArray = [ '0', '00', '000', '0000', '00000', '000000', '0000000', '00000000', '000000000' ], noOfZero;
			var sequenceCheck = function(item, index) {
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].isDisabled = false;
				if ($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.length > 1) {
					var currentRow;
					for (var i = 0; i < $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.length; i++) {
						if (index !== i && item.endingNo && item.startingNo) {
							currentRow = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[i];
							if (parseInt(item.startingNo) >= parseInt(currentRow.startingNo) && parseInt(item.startingNo) <= parseInt(currentRow.endingNo)) {
								dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "Cheque No. sequence entered in Row " + Number(index + 1) + " is overlapping with the sequence in Row " + Number(i + 1) + ". Please enter a different sequence");
								item.sequnceBreak = true;
								break;
							} else {
								item.sequnceBreak = false;
							}
						}
					}
					if (item.sequnceBreak) {
						return;
					}
				}
				var chequeFlag = (item.endingNo && item.startingNo && (item.endingNo !== item.validEndNo || item.startingNo !== item.validStartNo));
				if (chequeFlag && $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID) {
					eReceiptService.validateRPDCCheques($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID, item.startingNo, item.endingNo).then(function(data) {
						if (data && data[0] && data[0].status === "succes") {
							item.inValidCheques = false;
							item.validStartNo = item.startingNo;
							item.validEndNo = item.endingNo;
						} else {
							item.inValidCheques = true;
						}
					});
				}
			};

			$scope.calculateNoOfCheques = function(item, field, index) {
				if (item.noOfChequeCollected > 0) {
					if (field === 'end') {
						if (!item.endingNo || (parseInt(item.endingNo) - parseInt(item.noOfChequeCollected)) <= -1) {
							return;
						}
						item.startingNo = 1 + (parseInt(item.endingNo) - parseInt(item.noOfChequeCollected));
						item.noOfChequeCollected = 1 + (parseInt(item.endingNo) - parseInt(item.startingNo));

					} else {
						if (item.noOfChequeCollected === 0 || !item.startingNo) {
							return;
						}
						item.endingNo = parseInt(item.startingNo) + (parseInt(item.noOfChequeCollected) - 1);
					}
				} else {
					if (!item.endingNo || (parseInt(item.endingNo) - parseInt(item.startingNo) <= 0)) {
						return;
					}
					item.noOfChequeCollected = 1 + (parseInt(item.endingNo) - parseInt(item.startingNo));
				}
				item.endingNo = item.endingNo.toString();
				item.startingNo = item.startingNo.toString();
				if (item.startingNo.length < item.endingNo.length - 1) {
					noOfZero = (item.endingNo.length - item.startingNo.length) - 1;
					item.startingNo = zeroArray[noOfZero] + item.startingNo;
				} else if (item.endingNo.length < item.startingNo.length) {
					noOfZero = (item.startingNo.length - item.endingNo.length) - 1;
					item.endingNo = zeroArray[noOfZero] + item.endingNo;
				}
				sequenceCheck(item, index);
			};

			$scope.showSwapPopUp = function(flag, data) {
				if (flag) {
					eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/swapPopup.html', 'swapPopupController', 'md', {
						rpdcData : data
					});
					if (swapOptionFunction) {
						swapOptionFunction();
					}
					swapOptionFunction = messageBus.onMsg('SWAP_SELECTED_OPTION', function(evt, data) {
						$globalScope.receiptSubmitted = false;
						if (data.option === 'cancel') {
							setDefaultValues();
							isAgreedSwap = false;
						} else if (data.option === 'later') {
							createRPDCReceipt();
							isAgreedSwap = false;
						} else if (data.option === 'agreed') {
							isAgreedSwap = true;
							if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'SI') {
								$scope.value.bank = _.findWhere($scope.bankList, {
									bankID : '002'
								});
								modifiedField = 'bank';
							}
							getBankBranchDetails(modifiedField);
						} else {
							$scope.receiptForm.resetSubmited(true);
							$scope.showSwapScreen = true;
							$scope.receiptType = 'SWAPCHARGES';
							var selectedAgreements = _.where($scope.eReceiptModel.relatedAgreementNos, {
								isSelected : true
							});
							$scope.swapChargesAgreements = _.pluck(selectedAgreements, 'agreementNo');
							$scope.selectedAgreement.balanceAllocationModel = [];
							$scope.selectedAgreement.balanceAllocationModel.push({
								chargeType : 'SWAP CHARGES',
								chargeID : collectionConstants.CHARGE_IDS.SWAP,
								chargeAmount : $scope.eReceiptModel.rpdcDetail.swapCharges,
								actual : 0
							});
						}
					}, $scope);
				}
			};

			$scope.repayModeChange = function(item) {
				$scope.receiptForm.resetSubmited();
				if (item === 'RPDC') {
					$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected = [];
					$scope.addRow();
					setDefaultValues();
					return;
				} else if (item === 'SI') {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.SBI_ACCOUNT_NO_PROMPT).result.then(function() {
					}, function() {
						$scope.showPopup(item, 'repay');
					});
				} else {
					$scope.showPopup(item, 'repay');
				}
				$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].noOfChequeCollected = 0;
			};
			$scope.addRow = function(index) {
				if (index > -1) {
					$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.splice(index, 1);
				} else {
					var item = {};
					item.startingNo = '';
					item.endingNo = '';
					item.noOfChequeCollected = '';
					item.chequeValue = $scope.value.totalEMIOD;
					$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.push(item);
					$scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].isDisabled = true;
				}
			};
			$scope.getBankBranch = function(bankID) {
				masterService.getBankBranches(bankID).then(function(data) {
					$scope.branchList = data;
				});
			};
		};

		var changeReceiptType = function(value) {
			$scope.receiptType = value;
			$scope.receiptForm.resetSubmited();
			$scope.value.disablePayment = false;
			$scope.value.linkedSaleAgreements = [];
			$scope.selectedAgreement.showOtherODs = $scope.value.isOtherChargeAdded = false;
			$scope.value.totalAmount = '';
			if (value === "SHORTFALL" && $scope.eReceiptModel.npaStageID !== 'SALE' || $scope.eReceiptModel.agreementStatus !== 'C' && $scope.eReceiptModel.npaStageID !== 'WRITEOFF' && $scope.eReceiptModel.isShortfall) {
				setDefaultReceiptType(constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NOT_SHORT_FALL_CASE);
				return;
			} else if (value !== 'SALE' && value !== 'EMD' && value !== 'FORECLOSURE') {
				$scope.buyer = {};
				initController();
			}
			if (value === 'PDD') {
				loadInsuranceProivders();
			} else if (value === 'RPDC') {
				if ($scope.eReceiptModel.instrumentType !== 'P') {
					setDefaultReceiptType(constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NON_RPDC_CUSTOMER);
				} else if (!$scope.eReceiptModel.rpdcDetail || $scope.eReceiptModel.rpdcDetail.noOfChequesUndeposited > 2 || !$scope.eReceiptModel.rpdcDetail.noOfChequesCollectible) {
					setDefaultReceiptType(constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NOT_ELIGILBLE_RPDC);
				} else {
					initRPDCObjects();
				}
			} else if (value === 'SALE' || value === 'EMD') {
				initSaleEMDObjects();
			} else if (value === 'FORECLOSURE') {
				initController();
				initForeclosureObjects();
			} else {
				//$scope.showUpdateKycPopup(false);
			}
		};
		$scope.receiptChangeHandler = function(value,bypass) {
			$globalScope.receiptSubmitted = false;
			if (value === 'IMD' || value === 'TA' || value === 'INS-LEAD') {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Select the relevant search by option for " + value + " receipt.").result.then(function() {
				}, function() {
					$scope.value.receiptType = $scope.receiptType;
				});
				return;
			}else if($scope.eReceiptModel.npaStageID !== 'REPO' && (value === 'EMD' || value === 'SALE')){
				if(!$scope.eReceiptModel.flagStatus || ($scope.eReceiptModel.flagStatus && $scope.eReceiptModel.flagStatus.length && $scope.eReceiptModel.flagStatus.indexOf("RESALE") == -1)){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.INVALID_SALE_EMD_AGR).result.then(function() {
					}, function() {
						$scope.value.receiptType = $scope.receiptType;
					});
					return;
				}
			}
			if ($scope.receiptForm.$dirty) {
				if(bypass){
					$scope.receiptForm.$setPristine();
						changeReceiptType(value);
				} else{
					dialogService.confirm('Alert', "Alert!", collectionConstants.ERROR_MSG.RECEIPT_CHANGE_CONFIRM).result.then(function() {
						$scope.receiptForm.$setPristine();
						changeReceiptType(value);
					}, function() {
						$scope.value.receiptType = $scope.receiptType;
					});
				}
				
			} else {
				$scope.value.isMSFlag = false;
				changeReceiptType(value);
			}
		};
		$scope.cancelHandler = function() {
			dialogService.confirm('Alert', "Alert!", collectionConstants.ERROR_MSG.BACK_NAVIGATION).result.then(function() {
				if ($scope.showSwapScreen) {
					$scope.showSwapScreen = $globalScope.receiptSubmitted = false;
					$scope.value.receiptType = $scope.receiptType = 'RPDC';
					return;
				}
				$globalScope.gotoPreviousPage();
			}, function() {
			});
		};
		$scope.enableSubmitButton = function() {
			if ($scope.receiptType === 'PDD') {
				return $scope.value.disableSubmitButton;
			} else if ($scope.receiptType === 'RPDC') {
				return false;
			}
			$scope.paymentMode.validators.validateFields($scope.paymentMode.modeOfPayment);

			if ($scope.value.isVishesh || $scope.receiptType === 'FORECLOSURE' && ($scope.productType === 'VF' || $scope.productType === 'PL')) {
				return (!$scope.paymentMode.enableSubmitButton || !parseInt($scope.receiptPostModel.Receipt.amountPaid));
			} else {
				return (!$scope.paymentMode.enableSubmitButton || !$scope.receiptPostModel.Receipt.amountPaid || !($scope.selectedAgreement.totalBalanceAmount === 0 && $scope.selectedAgreement.isAllocated));
			}
		};
		$scope.checkWaiver = function() {
			if ($scope.receiptType === 'OD') {
				return;
			} else {
				return false;
			}
		};
		var createPDDReceipt = function() {
			$scope.pddSubmitModel.pddAcknowledgement.productType = $scope.productType;
			$scope.pddSubmitModel.pddAcknowledgement.agreementNos = [ $scope.eReceiptModel.agreementNo ];
			var str = ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType.toString().toLowerCase() === 'rc') ? 'RC' : $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType.toString().toLowerCase();
			if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'INVOICE') {
				$scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceAmount = $scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceAmount === '' ? 0 : parseInt($scope.pddSubmitModel.pddAcknowledgement.invoiceDetail.invoiceAmount);
			} else if ($scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'INSURANCE') {
				$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.premiumAmount = $scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.premiumAmount === '' ? 0 : parseInt($scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.premiumAmount);
				if ($scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.premiumAmount === '') {
					$scope.pddSubmitModel.pddAcknowledgement.insuranceDetail.premiumAmount = 0;
				}
			} else {
				$scope.pddSubmitModel.pddAcknowledgement[str + "Detail"].agreementNo = $scope.eReceiptModel.agreementNo;
			}
			$scope.pddSubmitModel.pddAcknowledgement[str + "Detail"].imageRef = (!$scope.pddSubmitModel.pddAcknowledgement[str + "Detail"].imageRef || $scope.pddSubmitModel.pddAcknowledgement[str + "Detail"].imageRef.length === 0) ? {} : $scope.pddSubmitModel.pddAcknowledgement[str + "Detail"].imageRef;
			$scope.pddSubmitModel.pddAcknowledgement.collectionAgentID = $rootScope.identity.userID;
			$scope.pddSubmitModel.pddAcknowledgement.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
			$scope.pddSubmitModel.pddAcknowledgement.payerType = payerType[$scope.partyType];
			$scope.pddSubmitModel.pddAcknowledgement.payerID = $scope.applicantDetail.customerID.toString();
			var selectedType = $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType !== 'RC' ? $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType.toLowerCase() : $scope.pddSubmitModel.pddAcknowledgement.pddAcknowledgementType;
			eReceiptService.submitPDD($scope.pddSubmitModel, $scope.applicantDetail, $scope.receiptForm, $scope.pddData[selectedType]).then(function(response) {
				if (response && response[str + "Detail"]) {
					$scope.pddData.interfaceDetails = response[str + "Detail"].interfaceDetails;
				}
			});
		};

		$globalScope.receiptSubmitted = false;
		var panMandatoryFunction, isTenlakhs, isTPValChanged;
		var preCreateReceipts = function() {
			$globalScope.receiptSubmitted = true;
			var updatePanFlag = (!$scope.value.isVishesh && $scope.receiptType !== 'IMD' && $scope.receiptType !== 'INS-LEAD' && $scope.receiptType !== 'EMD' && $scope.receiptType !== 'SALE' && $scope.receiptType !== 'TA' && $scope.receiptType !== 'closed');
			if (updatePanFlag && $scope.numbers.indexOf($scope.receiptPostModel.AddressDetail.mobileNo) === -1 && $scope.partyType === 'Applicant') {
				eReceiptService.postCustomerAddress($scope.applicantDetail.customerID, $scope.receiptPostModel.AddressDetail.mobileNo, $scope.receiptPostModel).then(function(data) {
					if (data) {
						$scope.numbers.unshift($scope.receiptPostModel.AddressDetail.mobileNo);
					}
				});
			}
			isTPValChanged = ($scope.partyType === 'ThirdParty' && !$scope.value.isVishesh && (($scope.paymentMode.cash.pan && $scope.paymentMode.cash.isValidPan) || ($scope.thirdPartyDetails.mobileNos && $scope.thirdPartyDetails.mobileNos.indexOf($scope.receiptPostModel.ThirdParty.mobileNos[0]) === -1) || $scope.thirdPartyDetails.name !== $scope.receiptPostModel.ThirdParty.name));
			if (updatePanFlag && isTPValChanged) {
				var tempObj = angular.copy($scope.thirdPartyDetails), agrementNos;
				delete tempObj.panNo;
				delete tempObj.mobileNos;
				tempObj.mobileNo = $scope.receiptPostModel.ThirdParty.mobileNos[0];
				agrementNos = _.pluck(_.where($scope.eReceiptModel.relatedAgreementNos, {
					isAllocated : true
				}), 'agreementNo');
				var postObj = {
					agreementNos : agrementNos,
					name : $scope.receiptPostModel.ThirdParty.name,
					panNo : $scope.paymentMode.cash.pan,
					status : 'INITIATED',
					branchID : $scope.eReceiptModel.branchID,
					thirdPartyAddresses : [ tempObj ]
				};
				$scope.popupInfo.isAddressChanged = true;
				$scope.popupInfo.postObj = postObj;
			}
			if ($scope.receiptType === 'PDD') {
				createPDDReceipt();
				return;
			} else if ($scope.receiptType === 'RPDC') {
				var mandateCheck = ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'ACH' || $scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'ECS');
				if ($scope.value.totalEMIOD <= 0) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.INVALID_RPDC_AMT);
					$globalScope.receiptSubmitted = false;
					return;
				} else if (mandateCheck && (!$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.imageRef || !$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.imageRef.imagePathReferences || !$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.imageRef.imagePathReferences.length)) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.MANDATE_DOC_CHECK);
					$globalScope.receiptSubmitted = false;
					return;
				}

				if (isAgreedSwap) {
					var validate = checkRPDCFields();
					if (!validate) {
						$globalScope.receiptSubmitted = false;
						return;
					}
					$scope.showSwapPopUp(isAgreedSwap, 'submit');
					eReceiptService.rpdcPostDataDetails = $scope.rpdcSubmitModel;
				} else {
					createRPDCReceipt();
				}
				return;
			} else if ($scope.receiptType === 'SWAPCHARGES') {
				createRPDCReceipt();
				return;
			} else if ($scope.receiptType === 'PART PAYMENT') {
				if (totalPartAmount > $scope.receiptPostModel.Receipt.amountPaid) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please pay full total over due amount (" + $scope.totalOD + ")");
					$globalScope.receiptSubmitted = false;
					return;
				}
			} else if (($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') && !$scope.buyer.buyerName) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.INVALID_BUYER);
				$globalScope.receiptSubmitted = false;
				return;
			}
			$scope.createReceipt();
		};
		var panCheck = function() {
			if ($scope.productType !== 'DEALER' && $scope.paymentMode.modeOfPayment === 'CASH' && $scope.receiptPostModel.Receipt.amountPaid >= 50000 && $scope.paymentMode.validators.panNo($scope.paymentMode.cash.pan).status === 'failed') {
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/panAlert.html', 'detailsPopupController', 'md', {
					popUpData : {},
					type : ''
				});
				if (panMandatoryFunction) {
					panMandatoryFunction();
				}
				panMandatoryFunction = messageBus.onMsg(collectionConstants.EMIT_MESSAGE.PAN_APPROVE, function(event, data) {
					$scope.receiptPostModel.Receipt.panUnavailabilityRemarks = data.remarks;
					preCreateReceipts();
				}, $scope);
				return true;
			} else {
				preCreateReceipts();
			}
		};
		var checkApprovalRequired = function() {
			isTenlakhs = false;
			if (($scope.paymentMode.modeOfPayment === 'CASH' && $scope.receiptPostModel.Receipt.amountPaid > 1000000) || ($scope.value.receiptType === 'SALE' && $scope.eReceiptModel.approvedSaleAmount > 1000000)) {
				isTenlakhs = true;
			}
			return isTenlakhs;
		};

		$scope.panVerify = function() {
			if ($globalScope.receiptSubmitted || !$scope.selectedAgreement.isAllocated) {
				return;
			} else if ($scope.receiptType === 'OD' && $scope.eReceiptModel.pendingWaiver && $scope.eReceiptModel.pendingWaiver.length) {
				dialogService.confirm(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.NORMAL_WAIVER_INVALID).result.then(function(){
									preCreateReceipts();
									},function(){});
			} else if ($scope.receiptType === 'FORECLOSURE') {
				if (($scope.productType === 'VF' || $scope.productType === 'PL') && parseInt($scope.receiptPostModel.Receipt.amountPaid) < $scope.simulatedData.amountCollected) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.FC_NET_RECEIVABLE_CHECK);
					return;
				} else if ($scope.eReceiptModel.waiverRequestStatus === 'WAIVER-INITIATED') {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.FC_WAIVER_PEDNING);
					return;
				}else if (($scope.productType === 'VF' || $scope.productType === 'PL') && utility.dateDifference(new Date($scope.interestTillDate.dateValue), new Date()) !== 0) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INTEREST_TILL_DATE_COMPARISON);
					return;
				} else if (($scope.productType === 'VF' || $scope.productType === 'PL') && utility.dateDifference(new Date($scope.interestTillDate.dateValue), new Date($scope.simulatedData.simulateDate)) !== 0) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INTEREST_TILL_DATE_VALIDATION);
					return;
				}
			} /*else if ($scope.receiptType === 'TA' && $scope.selectedAgreement.balanceAllocationModel[0].chargeAmount < $scope.selectedAgreement.balanceAllocationModel[0].actual) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.TA_POS_CHECK);
				return;
			}*/ else if ($scope.paymentMode.modeOfPayment === 'CHEQUE' && $scope.eReceiptModel.isChequeCollectionOnHold && $scope.productType !== 'VF') {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.CHEQUE_ON_HOLD);
				return;
			} else if (($scope.paymentMode.modeOfPayment === 'DD' || $scope.paymentMode.modeOfPayment === 'DRAFT') && $scope.eReceiptModel.isDDCollectionOnHold && $scope.productType !== 'VF') {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.DD_ON_HOLD);
				return;
			} else if ($scope.paymentMode.cash.pan && $scope.paymentMode.cash.isValidPan === false) {
				dialogService.showAlert(constants.ERROR_HEADER.info, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.PAN_VALIDATION_NA);
				return;
			} else if (_.where($scope.eReceiptModel.relatedAgreementNos,{isAllocated : true}).length && _.where($scope.eReceiptModel.relatedAgreementNos,{isAllocated : true}).length ===  _.where($scope.eReceiptModel.relatedAgreementNos,{isAllocated : true,isMoreAgreement:true}).length){
				dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.PRIMARY_AGR_NOT_ALLOCATED_SUBMIT);
				return;
			}else if($scope.receiptType === 'INS' && $scope.productType === 'VF' && $scope.value.cholaMSDetails && $scope.receiptPostModel.Receipt.amountPaid < $scope.value.cholaMSDetails.totalPremium){
				dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.alert, "Amount collected should not be less than LMS premium amount.");
				return;
			}else if($scope.receiptType === 'SALE' &&  !$scope.value.linkedSaleAgreements.length){
				if($scope.paymentMode.modeOfPayment === 'RTGS' || $scope.paymentMode.modeOfPayment === 'POS' || $scope.paymentMode.modeOfPayment === 'ONLINE_PAYMENT'){
					var _mode = $scope.paymentMode.modeOfPayment === 'ONLINE_PAYMENT' ? 'Online' : $scope.paymentMode.modeOfPayment;
					if(parseInt($scope.value.totalAmount) > parseInt($scope.receiptPostModel.Receipt.amountPaid)){
						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.alert, "Total " + _mode+ " amount should not be greater than approved sale amount");
						return;
					}else if(parseInt($scope.value.totalAmount) < parseInt($scope.receiptPostModel.Receipt.amountPaid)){
						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.alert, "Total " + _mode+ " amount is less than balance amount, please change the receipt type to EMD and proceed.");
						return;
					}
				}
				
			}
			/*messageBus.onMsg('PAN_CANCEL', function() {
				$globalScope.receiptSubmitted = false;
			}, $scope);*/
			isTenlakhs = false;
			preCreateReceipts();
		};
		var validateRPDCFields = function(item, index) {
			if (($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].repayMode === 'ECS' || $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].repayMode === 'ACH') && item.micrNo === '') {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_MICR);
				return false;
			}
			if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'RPDC') {
				if (item.sequnceBreak) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "Cheque No. sequence entered in row " + Number(index + 1) + " is overlapping with other row. Please enter a new sequence.");
					return false;
				}
				if (item.inValidCheques) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, 'Cheque No. sequence entered in row' + Number(index + 1) + ' already exists in Customer Records. Please enter a different sequence');
					return false;
				}
				if ((!item.startingNo || isNaN(item.endingNo) || !item.endingNo)) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, 'Enter a valid cheque Starting No. and Ending No in row ' + Number(index + 1));
					return false;
				}
				if (item && (!item.noOfChequeCollected || item.noOfChequeCollected < 5)) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, 'No. of cheques collected should be greater than 5 in row ' + Number(index + 1));
					return false;
				}
			}
			return true;
		};
		var checkRPDCFields = function() {
			if (invalidMICR) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_MICR);
				return false;
			}
			if (invalidIFSC) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.INVALID_IFSC);
				return false;
			}
			var isValid, item, totalCheques = 0;
			for (var i = 0; i < $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected.length; i++) {
				item = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[i];
				isValid = validateRPDCFields(item, i);
				if (!isValid) {
					$globalScope.receiptSubmitted = false;
					return false;
				}
				item.chequeValue = Number($scope.value.totalEMIOD);
				item.bankBranchID = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID;
				item.bankID = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bankID;
				item.micrCode = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].micrCode;
				item.accountNo = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].accountNo;
				item.noOfChequeCollected = parseInt(item.noOfChequeCollected);
				totalCheques += parseInt(item.noOfChequeCollected);
			}
			if (totalCheques > $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible) {
				var _message = $scope.eReceiptModel.rpdcAgreementList.length > 1 ? "one of the linked agreements gets" : "this agreement gets";
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "You cannot collect more than " + $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible + " cheques as " + _message + "  closed after " + $scope.eReceiptModel.linkedAgreements.noOfChequesCollectible + " payments");
				return false;
			}
			var agrList = _.pluck($scope.eReceiptModel.rpdcAgreementList, 'agreementNo');
			$scope.rpdcSubmitModel.pddAcknowledgement.parentAgreementNo = agrList[0];
			$scope.rpdcSubmitModel.pddAcknowledgement.agreementNos = agrList;
			return true;
		};
		var setPostObjects = function() {
			$scope.receiptPostModel.Receipt.agreementNos = [];
			$scope.receiptPostModel.Receipt.chargeDetails = [];
			$scope.receiptPostModel.Receipt.modeOfPayment = $scope.paymentMode.modeOfPayment;
			$scope.receiptPostModel.Receipt.receiptEnteredTime = $scope.receiptPostModel.Receipt.receiptDateTime = $scope.receiptDate;
			$scope.receiptPostModel.Receipt.productType = ($scope.receiptType === 'TA') ? 'DEALER' : $scope.productType;
			if($scope.receiptType === 'closed' || $scope.receiptType === 'SHORTFALL'){
                $scope.receiptPostModel.Receipt.receiptFor ='ClosedAgreement';
            }else if($scope.value.isVishesh && $scope.eReceiptModel.productCode === 'VISHESH'){
                $scope.receiptPostModel.Receipt.receiptFor ='VisheshAgreement';
			}else if($scope.eReceiptModel.productCode === 'TRIP'){
                $scope.receiptPostModel.Receipt.receiptFor = 'TripLoan';
            }

			if ($scope.receiptType === 'IMD' || $scope.receiptType === 'INS-LEAD') {
				$scope.receiptPostModel.Receipt.agreementNos = [ "" ];
				$scope.receiptPostModel.Receipt.applicationNos = [];
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase = $scope.receiptPostModel.Receipt.payerID = $scope.productType === 'VF' ? $scope.eReceiptModel.leadID : $scope.selectedAgreement.loanID;
			}else if ($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') {
				$scope.receiptPostModel.Receipt.payerName = $scope.buyer.buyerName;
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase = $scope.receiptPostModel.Receipt.payerID = $scope.buyer && $scope.buyer.buyerId ? $scope.buyer.buyerId : '';
			} else {
				$scope.receiptPostModel.Receipt.payerID = $scope.applicantDetail.customerID ? $scope.applicantDetail.customerID.toString() : $scope.receiptPostModel.Receipt.payerID;
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase =  $scope.applicantDetail.cifID ? $scope.applicantDetail.cifID.toString() : $scope.receiptPostModel.Receipt.payerID;
				$scope.receiptPostModel.Receipt.isPanChanged = $scope.receiptType === 'closed' ? false : $scope.paymentMode.cash.isPanChanged; // Pan  updation is not for Closed Agreement
				$scope.receiptPostModel.Receipt.cifID = $scope.receiptPostModel.Receipt.offlineReceiptReferenceCase;
				if ($scope.receiptType === 'OD') {
					$scope.receiptPostModel.Receipt.waiverRequestIDs = $scope.eReceiptModel.waiverRequestIDs;
					$scope.receiptPostModel.Receipt.initatedwaiverIDs = _.pluck($scope.eReceiptModel.pendingWaiver,'requestID');
				}else if ($scope.receiptType === 'SHORTFALL') {
					$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase =  $scope.eReceiptModel.agreementNo;
				}
			}
			if ($scope.receiptType === 'FORECLOSURE') {
				if ($scope.productType === 'VF' || $scope.productType === 'PL') {
					$scope.receiptPostModel.Receipt.waiverRequestIDs = $scope.simulatedData.waiverRequestIDs;
					$scope.receiptPostModel.Receipt.initatedwaiverIDs = _.pluck($scope.eReceiptModel.pendingForclosureWaiver,'requestID');
					var simulateObj = angular.copy($scope.simulatedData);
					var keys = [ 'agreementNo', 'agreementID', 'agreementDate', 'AmountFin', 'Frequency', 'Tenure', 'Numinist', 'DiscFactor', 'effrate', 'interestAccural', 'totalAmount', 'CustomerName', 'waiveoffAmount' ];
					var dues = [ 'advice', 'intOnTermination', 'FloatlineOnTermination', 'Overdues', 'currOverdues', 'currOverdueWaiveOff', 'intOnTerminationPerDay', 'prepaymentPenalty' ];
					var refunds = [ 'advInstallments', 'SDAmount', 'excessInt', 'excessIntIncome', 'excessIntRefund' ];
					_.each(keys, function(item) {
						delete simulateObj[item];
					});
					_.each(dues, function(item) {
						delete simulateObj.dues[item];
					});
					_.each(refunds, function(item) {
						delete simulateObj.refunds[item];
					});

					simulateObj.reFunds = simulateObj.refunds;
					delete simulateObj.totalDueDetails;
					delete simulateObj.totalRefundDetails;
					delete simulateObj.refunds;
					simulateObj.closureDate = new Date(simulateObj.closureDate);
					simulateObj.rebateCalculatedOn = simulateObj.interestTillDate = new Date(simulateObj.interestTillDate);
					simulateObj.nextDueDate = new Date(simulateObj.nextDueDate);
					$scope.receiptPostModel.Receipt.foreClosureDetail = simulateObj;
					$scope.receiptPostModel.Receipt.fcChargeDetails = [];
					_.each(simulateObj.foreClosureCharges, function(charge) {
						var _temp = _.findWhere($scope.receiptPostModel.Receipt.fcChargeDetails, {
							chargeID : charge.chargeID
						});
						if (_temp) {
							_temp.amount += Number(charge.chargeAmount);
						} else {
							if (charge.chargeAmount) {
								$scope.receiptPostModel.Receipt.fcChargeDetails.push({
									chargeID : charge.chargeID,
									amount : charge.chargeAmount,
									referenceNo : $scope.eReceiptModel.agreementNo
								});
							}
						}
					});
				} else {
					$scope.receiptPostModel.Receipt.waiverRequestIDs = $scope.eReceiptModel.foreClosurewaiverRequestIDs;
					$scope.receiptPostModel.Receipt.initatedwaiverIDs = _.pluck($scope.eReceiptModel.pendingForclosureWaiver,'requestID');
					$scope.receiptPostModel.Receipt.foreClosureDetail = {
						waiveOffAmount : $scope.eReceiptModel.fcDetail ? $scope.eReceiptModel.fcDetail.waiverAmount : 0
					};
				}
			} else if ($scope.receiptType === 'ADVANCE EMI' || $scope.receiptType === 'PART PAYMENT') {
				$scope.receiptPostModel.Receipt.reductionType = eReceiptService.data.reductionType;
			} else if($scope.receiptType === 'INS' && $scope.productType === 'VF'){
				$scope.receiptPostModel.Receipt.policyNo = $scope.value.cholaMSDetails.policyNo;
				$scope.receiptPostModel.Receipt.insuranceDetail = {
					dtdPercentageSlab : $scope.value.cholaMSDetails.dtdPercentageSlab,
					netPremium : Math.round($scope.value.cholaMSDetails.netPremium),
					totalPremium : Math.round($scope.value.cholaMSDetails.totalPremium),
					serviceTax : Math.round($scope.value.cholaMSDetails.serviceTax),
					renewalRsd : $scope.value.cholaMSDetails.renewalRsd,
					registrationNo : $scope.value.cholaMSDetails.registrationNo
				};
			}
			if ($scope.isManualReceipt) {
				$scope.receiptPostModel.Receipt.receiptNo = $scope.searchParams.receiptNo;
				$scope.receiptPostModel.Receipt.collectionAgentID = $scope.manualReceiptInfo.allocatedUserID;
				$scope.receiptPostModel.Receipt.receiptEnteredTime = new Date($scope.searchParams.receiptDate);
				$scope.receiptPostModel.Receipt.manualReceiptReferenceCase = $scope.paymentMode.modeOfPayment === 'CASH' ? $scope.value.manualReceiptReferenceCase :'';
			} else {
				$scope.receiptPostModel.Receipt.collectionAgentID = $rootScope.identity.userID;
			}
			$scope.receiptPostModel = eReceiptService.setPaymentModeInfo($scope.paymentMode, $scope.receiptPostModel);
			$scope.receiptPostModel.Receipt.payerType = payerType[$scope.partyType];
			$scope.receiptPostModel.Receipt.mobileNo = ($scope.partyType === 'Applicant') ? $scope.receiptPostModel.AddressDetail.mobileNo.toString() : $scope.receiptPostModel.ThirdParty.mobileNos[0].toString();
			$scope.receiptPostModel.Receipt.panNo = $scope.receiptPostModel.Receipt.modeOfPayment === 'CASH' ? $scope.paymentMode.cash.pan : '';
			if ($scope.receiptType === 'TA') {
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase = $scope.receiptPostModel.Receipt.payerID = $scope.eReceiptModel.dealerID;
				$scope.receiptPostModel.Receipt.payerName = $scope.eReceiptModel.dealer[0] ? $scope.eReceiptModel.dealer[0].supplierDesc : "";
			} else if ($scope.receiptType === 'closed') {
				$scope.receiptPostModel.Receipt.payerName = $scope.receiptPostModel.Receipt.payerID = $scope.eReceiptModel.customerName;
				$scope.receiptPostModel.Receipt.offlineReceiptReferenceCase = $scope.eReceiptModel.agreementNo;
				$scope.receiptPostModel.Receipt.receiptType = $scope.eReceiptModel.isSFReceipt ? 'SHORTFALL' : 'OD';
				$scope.receiptPostModel.Receipt.cifID = $scope.eReceiptModel.cifID;
			} else {
				$scope.receiptPostModel.Receipt.payerName = ($scope.partyType === 'Applicant') ? $scope.applicantDetail.name : $scope.receiptPostModel.ThirdParty.name;
			}
			if ($scope.receiptType !== 'closed') {
				$scope.receiptPostModel.Receipt.receiptType = ($scope.showSwapScreen) ? 'SWAPCHARGES' : $scope.receiptType;
			}
		};
		var createRPDCReceipt = function() {
			if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType !== 'RPDC') {
				$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.amount = Number($scope.value.totalEMIOD);
				$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.bankBranchID = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].bBranchID;
				$scope.rpdcSubmitModel.pddAcknowledgement.paymentInstructionType.accountNo = $scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected[0].accountNo;
			}
			$scope.rpdcSubmitModel.pddAcknowledgement.collectionAgentID = $rootScope.identity.userID;
			$scope.rpdcSubmitModel.pddAcknowledgement.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
			$scope.rpdcSubmitModel.pddAcknowledgement.receivedDate = new Date();
			$scope.rpdcSubmitModel.pddAcknowledgement.productType = $scope.productType;
			$scope.rpdcSubmitModel.pddAcknowledgement.payerID = $scope.applicantDetail.customerID.toString();
			$scope.rpdcSubmitModel.pddAcknowledgement.payerType = payerType[$scope.partyType];

			if (!$scope.showSwapScreen) {
				var validate = checkRPDCFields();
				if (!validate) {
					$globalScope.receiptSubmitted = false;
					return;
				}
				eReceiptService.postRPDC($scope.rpdcSubmitModel, $scope.applicantDetail, $scope.bankList, $scope.receiptForm);
				$globalScope.receiptSubmitted = false;
			} else {
				setPostObjects();
				$scope.receiptPostModel.Receipt.agreementNos = $scope.swapChargesAgreements;
				$scope.receiptPostModel.Receipt.chargeDetails.push({
					chargeType : 'SWAP CHARGES',
					chargeID : collectionConstants.CHARGE_IDS.SWAP,
					amount : $scope.receiptPostModel.Receipt.amountPaid,
					referenceNo : $scope.eReceiptModel.agreementNo
				});
				eReceiptService.postSwap($scope.receiptPostModel).then(function(data) {
					var swapPrintDetails = [];
					if (data.receiptNo) {
						data.name = $scope.applicantDetail.name;
						_.each($scope.rpdcSubmitModel.pddAcknowledgement.rpdcCollected, function(rpdcItem) {
							if (rpdcItem) {
								rpdcItem.isSwapChargeRequired = true;
								rpdcItem.swapReceiptNo = data.receiptNo;
							}
						});
						$scope.receiptPostModel.rpdcData = $scope.rpdcSubmitModel;
						$globalScope.receiptSubmitted = false;
						swapPrintDetails.push(data);
						eReceiptService.postRPDCWithSwap($scope.rpdcSubmitModel, swapPrintDetails, $scope.bankList);
					}
				});
			}
		};
		var receiptOption, fcReceipt;
		$scope.createReceipt = function() {
			setPostObjects();
			var assetDetails = [], versionObj;
			var preEligibleLoan = false;
			var noOfAgreements;
			var primarySaleDetails = [];
			if(($scope.receiptType === 'SALE'||$scope.receiptType === 'EMD') && ($scope.eReceiptModel.flagStatus && $scope.eReceiptModel.flagStatus.length>0 && $scope.eReceiptModel.flagStatus.indexOf("RESALE") > -1 &&  (!$scope.eReceiptModel.isShortfall && $scope.eReceiptModel.allowSaleReceipt))){
				$scope.receiptPostModel.Receipt.resaleCheck = true;
			}
			if ($scope.value.isVishesh) {
				$scope.receiptPostModel.Receipt.agreementNos.push($scope.eReceiptModel.agreementNo);
				assetDetails.push($scope.eReceiptModel.assetDetail);
                    $scope.receiptPostModel.Receipt.chargeDetails.push({
                        chargeID : '1000000128',
                        amount : $scope.receiptPostModel.Receipt.amountPaid,
                        'referenceNo' : $scope.eReceiptModel.agreementNo
                    });
			} else if ($scope.receiptType !== 'IMD' && $scope.receiptType !== 'INS-LEAD') {
				_.each($scope.eReceiptModel.relatedAgreementNos, function(item, ind) {
					if (item.isAllocated || ($scope.selectedAgreement.isAllocated && $scope.selectedAgreement.agreementNo === item.agreementNo)) {
						$scope.receiptPostModel.Receipt.agreementNos.push(item.agreementNo);
						item.assetDetail.agreementNo = item.agreementNo;
						assetDetails.push(item.assetDetail);
						_.each(item.balanceAllocationModel, function(charge) {
							if(collectionConstants.LEAP_DESC_CHARGES.PRIMARY_CHARGES.indexOf(charge.chargeType) > -1 || charge.actual > 0){
								$scope.receiptPostModel.Receipt.chargeDetails.push({
									'chargeID' : charge.chargeID,
									'chargeType' : charge.chargeType,
									'amount' : charge.actual,
									'referenceNo' : item.agreementNo
								});
							}
						});
						_.each(item.otherODCharges, function(charge) {
							if (charge.actual > 0) {
								$scope.receiptPostModel.Receipt.chargeDetails.push({
									'chargeID' : charge.chargeID,
									'chargeType' : charge.chargeType,
									'amount' : charge.actual,
									'referenceNo' : item.agreementNo
								});
							}
						});

					}
				});
				
				//Production issue - Charges are not sent to backend
				if(!$scope.receiptPostModel.Receipt.chargeDetails.length){
					_.each($scope.selectedAgreement.balanceAllocationModel, function(charge) {
						if (charge.actual > 0 || $scope.receiptType === 'TA') {
							$scope.receiptPostModel.Receipt.chargeDetails.push({
								'chargeID' : charge.chargeID,
								'chargeType' : charge.chargeType,
								'amount' : charge.actual,
								'referenceNo' : $scope.selectedAgreement.agreementNo
							});
						}
					});
				}

				if ($scope.receiptType === 'SALE' && ($scope.paymentMode.modeOfPayment === 'RTGS' || $scope.paymentMode.modeOfPayment === 'POS' || $scope.paymentMode.modeOfPayment === 'ONLINE_PAYMENT')) {
					_.each($scope.value.linkedSaleAgreements, function(item, ind) {
						$scope.receiptPostModel.Receipt.agreementNos.push(item.agreementNo);
						item.assetDetail.agreementNo = item.agreementNo;
						assetDetails.push(item.assetDetail);
						$scope.receiptPostModel.Receipt.chargeDetails.push({
							'chargeID' : $scope.receiptPostModel.Receipt.chargeDetails[0].chargeID,
							'chargeType' : $scope.receiptPostModel.Receipt.chargeDetails[0].chargeType,
							'amount' : item.balAmt,
							'referenceNo' : item.agreementNo
						});
					});
					if($scope.value.linkedSaleAgreements && $scope.value.linkedSaleAgreements.length == 0){
						$scope.receiptPostModel.Receipt.chargeDetails[0].amount = $scope.receiptPostModel.Receipt.amountPaid;
					}else{
						$scope.receiptPostModel.Receipt.amountPaid = $scope.value.totalAmount;
					}
					var totalChargeAmt;
					var chargeArr = _.pluck($scope.receiptPostModel.Receipt.chargeDetails, 'amount');
					totalChargeAmt = _.reduce(chargeArr, function(memo, num) {
						return Number(memo) + Number(num);
					}, 0);

					if (totalChargeAmt !== Number($scope.value.totalAmount)) {
						$globalScope.receiptSubmitted = false;
						var _mode = $scope.paymentMode.modeOfPayment === 'ONLINE_PAYMENT' ? 'Online' : $scope.paymentMode.modeOfPayment;
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "Total " + _mode + " amount does not match with sum of all total balance amount.");
						return;
					} else {
						primarySaleDetails.push({
							isPrimary : true,
							agreementNo : $scope.eReceiptModel.agreementNo,
							saleAmt : $scope.eReceiptModel.approvedSaleAmount,
							emdAmt : $scope.eReceiptModel.receiptDetails ?  $scope.eReceiptModel.receiptDetails.amountPaid : 0
						});
					}
				} else if ($scope.receiptType === 'FORECLOSURE' && $scope.productType === 'VF') {
					$scope.receiptPostModel.Receipt.chargeDetails = [];
					var _diffAmt, _charge, excessObj, excessRefund=0;
					_.each($scope.simulatedData.foreClosureCharges, function(charge) {
						_charge = _.findWhere($scope.simulatedData.chargeDetails, {
							chargeID : charge.chargeID
						});
						if (_charge) {
							_diffAmt = Number(charge.chargeAmount) - Number(_charge.waiverAmount);
						} else {
							_diffAmt = Number(charge.chargeAmount);
						}
						if (_diffAmt) {
							if (collectionConstants.LEAP_DESC_CHARGES.FC_INCLUDE_CHARGES.indexOf(charge.chargeID) > -1) {
								$scope.receiptPostModel.Receipt.chargeDetails.push({
									chargeID : charge.chargeID,
									amount : _diffAmt,
									referenceNo : $scope.eReceiptModel.agreementNo
								});
							} else {
								if (charge.receiptChargeType && charge.receiptChargeType.toUpperCase() === 'EXCESS REFUNDS') {
									excessRefund = _diffAmt;
								} else {
									if (excessObj) {
										excessObj.amount += _diffAmt;
									} else {
										$scope.receiptPostModel.Receipt.chargeDetails.push({
											chargeID : collectionConstants.CHARGE_IDS.EXCESS,
											amount : _diffAmt,
											referenceNo : $scope.eReceiptModel.agreementNo
										});
										excessObj = _.findWhere($scope.receiptPostModel.Receipt.chargeDetails, {
											chargeID : collectionConstants.CHARGE_IDS.EXCESS
										});
									}
								}
							}
						}
					});
					
					var _sum = _.reduce($scope.receiptPostModel.Receipt.chargeDetails, function(memo, item) {
						return Number(memo) + Number(item.amount);
					}, 0);
					_sum -= excessRefund;
					// adding excess collected amount to others
					if ($scope.receiptPostModel.Receipt.amountPaid > _sum) {
						if (excessObj) {
							excessObj.amount += Number($scope.receiptPostModel.Receipt.amountPaid - _sum);
						} else {
							$scope.receiptPostModel.Receipt.chargeDetails.push({
								chargeID : collectionConstants.CHARGE_IDS.EXCESS,
								amount : Number($scope.receiptPostModel.Receipt.amountPaid - _sum),
								referenceNo : $scope.eReceiptModel.agreementNo
							});
						}
					}
					var orderOfDeduction = [ '37', '110249', '8', '7', '9', '240', '110158', '110165', '242' ];
					// Deducting refund amount
					var _currentCharge, i = 0, flag;
					while (!flag && i < orderOfDeduction.length) {
						_currentCharge = _.findWhere($scope.receiptPostModel.Receipt.chargeDetails, {
							chargeID : orderOfDeduction[i]
						});
						if (_currentCharge) {
							excessRefund -= _currentCharge.amount;
							if (excessRefund > 0) {
								_currentCharge.amount = 0;
								excessRefund = Math.abs(excessRefund);
							} else {
								_currentCharge.amount = Math.abs(excessRefund); 
								flag = true;
							}
						}
						i++;
					}
				}

				if ($scope.receiptType !== 'TA' && $scope.receiptType !== 'closed') {
					var rightSideInfoParty = _.findWhere($scope.eReceiptModel.rightSideColumn.caseDetails[0].partyDetails, {
						partyType : 'A'
					});
					if (rightSideInfoParty && rightSideInfoParty.PreEligibleLoanOffer) {
						preEligibleLoan = (rightSideInfoParty.PreEligibleLoanOffer && rightSideInfoParty.PreEligibleLoanOffer.toUpperCase() === 'YES');
					}
				} else {
					$scope.receiptPostModel.Receipt.agreementNos = [];
					$scope.receiptPostModel.Receipt.agreementNos.push($scope.selectedAgreement.agreementNo);
					if($scope.receiptType === 'closed'){
						for(var i=$scope.receiptPostModel.Receipt.chargeDetails.length-1; i>-1; i--){
							if(!Number($scope.receiptPostModel.Receipt.chargeDetails[i].amount)){
								$scope.receiptPostModel.Receipt.chargeDetails.splice(i,1);
							}
						}
					}

				}
				noOfAgreements = $scope.receiptPostModel.Receipt.agreementNos.length;
			} else {
				if ($scope.productType === 'VF') {
					_.each($scope.eReceiptModel.loanDetails, function(item) {
						if (item.isAllocated) {
							$scope.receiptPostModel.Receipt.applicationNos.push(item.loanID);
							_.each(item.balanceAllocationModel, function(charge) {
								if ($scope.receiptType === 'IMD') {
									_.each(charge.charges, function(value) {
										$scope.receiptPostModel.Receipt.chargeDetails.push({
											'chargeType' : value.shortName,
											'amount' : parseInt(value.chargeAmount),
											'referenceNo' : item.loanID,
											chargeID : value.chargeID,
											chargeDetailID : value.chargeDetailID
										});
									});
								} else {
									$scope.receiptPostModel.Receipt.chargeDetails.push({
										'chargeType' : charge.chargeType,
										'amount' : parseInt(charge.actual),
										'referenceNo' : item.loanID,
										chargeID : charge.chargeID
									});
								}
							});
						}
					});
				} else {
					versionObj = {
						majorVersion : $scope.eReceiptModel.majorVersion,
						minorVersion : $scope.eReceiptModel.minorVersion
					};
					$scope.receiptPostModel.Receipt.applicationNos.push($scope.eReceiptModel.applicationID);
					_.each($scope.selectedAgreement.balanceAllocationModel[0].charges, function(charge) {
						$scope.receiptPostModel.Receipt.chargeDetails.push({
							'amount' : Number(charge.chargeAmount),
							'referenceNo' : charge.chargeDetailID,
							chargeID : charge.chargeID,
							chargeDetailID : charge.chargeDetailID
						});
					});
				}
				noOfAgreements = $scope.receiptPostModel.Receipt.applicationNos.length;
			}
			var paramObjs = {
				assetDetails : assetDetails,
				pddData : $scope.pddData,
				preEligibleLoan : preEligibleLoan,
				popupInfo : $scope.popupInfo,
				balanceOS : $scope.eReceiptModel.balanceOS,
				isTenlakhs : isTenlakhs,
				formObj : $scope.receiptForm,
				receiptType : $scope.receiptType,
				leadDisplayID : $scope.productType === 'VF' ? $scope.eReceiptModel.leadDisplayID : $scope.eReceiptModel.applicationDisplayID,
				msDetail : $scope.receiptType === "INS" ? msDetail : {},
				version : versionObj
			};
			 if ($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') {
			 	$scope.buyer.kycDocument.status = $scope.buyer.kycDocument.status ? $scope.buyer.kycDocument.status :"PENDING";
				$scope.receiptPostModel.Receipt.buyerDetails = paramObjs.buyerDetails = $scope.buyer;
				$scope.receiptPostModel.Receipt.payerID = $scope.receiptPostModel.Receipt.payerID ? $scope.receiptPostModel.Receipt.payerID :"FALSE";
				$scope.receiptPostModel.Receipt.panNo = $scope.buyer.panNo;
			}

			if (noOfAgreements > 1 && !$scope.isManualReceipt && $scope.paymentMode.modeOfPayment !== "ONLINE_PAYMENT") {
				if (typeof receiptOption === "function") {
					receiptOption();
				}
				receiptOption = messageBus.onMsg('PRINT_RECEIPT', function(eve, data) {
					paramObjs.receiptOption = data;
					if ($scope.receiptType === 'SALE') {
						paramObjs.linkedSaleAgreements = _.union(primarySaleDetails, $scope.value.linkedSaleAgreements);
					}
					eReceiptService.createReceipt($scope.receiptPostModel, paramObjs);
				}, $scope);

				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/receiptOptionPopup.html', 'optionController', 'md', {
					popUpData : noOfAgreements
				});
			} else {
				$scope.receiptPostModel.Receipt.newReceipt = false;
				/*if($scope.paymentMode.modeOfPayment === 'CASH' && !$scope.value.isVishesh && $scope.receiptPostModel.Receipt.receiptFor !== 'ClosedAgreement'){
					var _otherChargeTotal = 0,excludeOtherODCharges = _.pluck(collectionConstants.CHARGES_MAX_LIMIT, 'chargeID');
					_.each($scope.receiptPostModel.Receipt.chargeDetails, function(charge){
						if(charge.chargeID != collectionConstants.CHARGE_IDS.EMI && charge.chargeID != collectionConstants.CHARGE_IDS.AFC && charge.chargeID !== collectionConstants.CHARGE_IDS.CBC && charge.chargeID !== collectionConstants.CHARGE_IDS.FVC && excludeOtherODCharges.indexOf(charge.chargeID)===-1){
							_otherChargeTotal += Number(charge.amount);
						}
					});
					if(_otherChargeTotal > collectionConstants.CASH_AMT_RESTRICT_OTHER_CHAGRES){
							var _msg = collectionConstants.ERROR_MSG.CASH_AMT_RESTRICT_OTHER_CHAGRES;
							if($scope.receiptType === 'EMD'){
								_msg = angular.copy(collectionConstants.ERROR_MSG.CASH_AMT_RESTRICT_OTHER_CHAGRES_EMD);
								_msg = _msg.replace('AGREEMENTNO', $scope.receiptPostModel.Receipt.agreementNos[0]);
							}
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, _msg).result.then(function(){
						},function(){
							$globalScope.receiptSubmitted = false;
						});
						return;
					}
				}*/
				if($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD'){
					if ($scope.receiptType === 'SALE') {
						paramObjs.emdAmount = $scope.eReceiptModel.receiptDetails.amountPaid;
						paramObjs.saleAmount = $scope.eReceiptModel.approvedSaleAmount;
						paramObjs.linkedSaleAgreements = _.union(primarySaleDetails, $scope.value.linkedSaleAgreements);
					}
					messageBus.onMsg('VENDOR_CREATED', function(event,data) {
						$scope.buyer.buyerId = $scope.receiptPostModel.Receipt.payerID = data.vendorID;
					});
					if(validateFields($scope.receiptPostModel.Receipt.buyerDetails.kycDocument.docType)){
						eReceiptService.createReceipt($scope.receiptPostModel, paramObjs);
					}else{
						$scope.editBuyer[$scope.receiptPostModel.Receipt.buyerDetails.kycDocument.docType] = false;
					}
				}else if($scope.receiptType === 'SHORTFALL'){	
					//remove last element in chargeDetails array, ignoring current waiver amount.		
					//$scope.receiptPostModel.Receipt.chargeDetails = _.reject($scope.receiptPostModel.Receipt.chargeDetails, function(item){ return item.chargeType == 'Current Waiver Amount'; });	
					var chargeDetails = [];
					for(var i in $scope.receiptPostModel.Receipt.chargeDetails){
						if($scope.receiptPostModel.Receipt.chargeDetails[i].amount > 0 ){
							chargeDetails.push($scope.receiptPostModel.Receipt.chargeDetails[i]);
						}
					}
					$scope.receiptPostModel.Receipt.chargeDetails = chargeDetails.length ? chargeDetails :$scope.receiptPostModel.Receipt.chargeDetails;
					eReceiptService.createReceipt($scope.receiptPostModel, paramObjs);					
				}else{
					eReceiptService.createReceipt($scope.receiptPostModel, paramObjs);
				}
			}
		};
		messageBus.onMsg('ADDRESS', function(event, data) {
			if (data.address.addressType === 'CURRES') {
				$scope.customerFullAddress = utility.setAddress(data.address);
				$scope.applicantAddress = $scope.receiptPostModel.AddressDetail = data.address;
			}
			$scope.eReceiptModel.addressDetails.unshift(data.address);
			if ($scope.numbers.indexOf(data.mobileNo) === -1) {
				$scope.numbers.unshift(data.mobileNo);
				$scope.applicantDetail.mobileNos = applicantNos = angular.copy($scope.numbers);
			}
			$scope.receiptPostModel.AddressDetail.mobileNo = data.mobileNo;
		}, $scope);
		messageBus.onMsg('THIRDPARTY', function(event, data) {
			$scope.thirdPartyFullAddress = utility.setAddress(data.address);
			$scope.thirdPartyDetails.name = data.name;
			if ($scope.thirdPartyDetails.mobileNos.indexOf(data.address.mobileNo) === -1) {
				$scope.thirdPartyDetails.mobileNos.unshift(data.address.mobileNo);
			}
			$scope.receiptPostModel.ThirdParty.mobileNos[0] = data.address.mobileNo;
			tpNos = angular.copy($scope.thirdPartyDetails.mobileNos);
			$scope.receiptPostModel.ThirdParty.name = data.name;
			$scope.receiptPostModel.ThirdParty.thirdPartyAddresses = [ data.address ];
			$scope.eReceiptModel.thirdPartyDetails.unshift({
				name : data.name,
				thirdPartyAddresses : [ data.address ]
			});
		}, $scope);
		$scope.updateAddressHandler = function(data, partyDetails, type, thirdparty) {
			var params = {
				addressObj : data,
				partyDetails : partyDetails,
				customerFullAddress : $scope.customerFullAddress,
				customerType : type,
				thirdparty : thirdparty,
				selectedAgreement : _.pluck(_.where($scope.eReceiptModel.relatedAgreementNos, {
					isSelected : true
				}), 'agreementNo'),
				mobileNoValidation : $scope.receiptPostModel.Receipt.validators.mobileNo,
				addressDetails : $scope.eReceiptModel.addressDetails,
				applicant : $scope.applicantDetail,
				branchID : $scope.eReceiptModel.branchID,
				productType : $scope.productType
			};
			eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/addressPopup.html', 'addressUpdateController', 'md', params);
		};
		var checkLastThreeCheques = function() {
			var isPending;
			_.each($scope.eReceiptModel.lastThreeChequeInformation, function(item) {
				if (item.instrumentDetail.status && item.instrumentDetail.status.toUpperCase() === "PENDING") {
					isPending = true;
				}
			});
			return isPending;
		};
		var showWaiver = function() {
			eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/waiverInitiation.html', 'initiateWaiverController', 'lg', {
				caseDetailInfo : initiateRequestObj
			});
		};
		var checkAgreementList = function(_linkedAgreements) {
			initiateRequestObj.expenseDetails = initiateRequestObj.simulation.foreClosureCharges;
			initiateRequestObj.agreementList = _linkedAgreements;
			var _excess,_amount;
			var _sum = _.reduce(initiateRequestObj.expenseDetails, function(memo, item) {
				if(item.chargeID !== '20002'){
					_amount = Number(item.chargeAmount);
				}else{
					_amount = 0;
				}
				return Number(memo) + _amount;
			}, 0);
			_excess = _.findWhere(initiateRequestObj.expenseDetails,{"chargeID": "20002"});
			if(_excess){
				_sum -= _excess.chargeAmount;
			}
			if(initiateRequestObj.simulation.waiveOffAmount){
				_sum -= initiateRequestObj.simulation.waiveOffAmount;
			}
			if(_sum !== initiateRequestObj.simulation.amountCollected){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.FC_NET_NOT_MATCH);
				return;
			}
			if (_linkedAgreements && _linkedAgreements.length) {
				eReceiptService.showLinkedAgreements({
					caseDetailInfo : initiateRequestObj
				});
			} else {
				showWaiver();
			}
		};
		var showSimulatePopup = function(initiateRequestObj) {
			dialogService.showCustomDialog('app/collections/eReceipt/receipting/partials/popup/simulationPopup.html', 'simulationPopupController', {
				data : initiateRequestObj
			}, function(result) {
				if (result.status === "success") {
					
					//// If simulation date and foreclosure waiver date is same
					// service call cannot be happaen. For performance
					if (initiateRequestObj.interestTillDate && utility.dateDifference(initiateRequestObj.interestTillDate, new Date(result.data.dateValue)) === 0) {
						checkAgreementList(initiateRequestObj.simulation.getForeClosureLA.linkedAgreements);
					} else {
						eReceiptService.simulateForeclosure($scope.eReceiptModel.agreementNo, new Date(result.data.dateValue)).then(function(simulateData) {
							initiateRequestObj.simulation = simulateData;
							if(simulateData){
								/*/if(simulateData.expiredWaivers && simulateData.expiredWaivers[0] && simulateData.expiredWaivers[0].waiverStatus === "EXPIRED" ){
									var initDate =  _.findWhere(simulateData.expiredWaivers[0].workflow, {workStatus : "INITIATED" }).workDoneDate;
									dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, "The waiver initiated on " + utility.formDateString(new Date(initDate))+" got expired").result.then(function(){
									},function(){
											checkAgreementList(simulateData.getForeClosureLA.linkedAgreements);
									});
								}else{*/
									checkAgreementList(simulateData.getForeClosureLA.linkedAgreements);
								//}
							}
						});
					}
				} else {

				}
			}, 'sm', 'modal-custom', true);

		};

		$scope.initiateWaiver = function() {
			initiateRequestObj.receiptType = $scope.receiptType;
			initiateRequestObj.productType = $scope.productType;
			initiateRequestObj.branchID = $scope.eReceiptModel.branchID;
			initiateRequestObj.request = 'WAIVER';
			if ($scope.receiptType === 'FORECLOSURE') {
				if (checkLastThreeCheques()) {
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.CHEQUE_PENDING);
					return;
				}
				if ($scope.productType === 'VF') {
					showSimulatePopup(initiateRequestObj); // popup will be disaply to choose the interest till date.
				} else {
					showWaiver();
				}
			} else {
				showWaiver();
			}

		};

		var getForeClosureChargeType = function(expense) {
			var chargeObj;
			_.each(expense, function(charge) {
				if (charge.chargeID === collectionConstants.CHARGE_IDS.EXCESS) {
					charge.chargeType = "POS";
				} else if (charge.chargeID === collectionConstants.CHARGE_IDS.FOUR_PERCENT_POS) {
					charge.chargeType = collectionConstants.OTHERS.FC_POS_PERCENTAGE * 100 + "% POS";
				} else {
					chargeObj = _.findWhere(getchargesListResolver, {
						chargeID : charge.chargeID
					});
					charge.chargeType = chargeObj ? chargeObj.leapDescription : "";
				}
			});
			return expense;
		};

		$scope.showWaiverDetails = function(waiveAmount, productType) {
			var _obj = {};
			if (productType === 'VF' || productType === 'PL') {
				_obj.expenseDetails = getForeClosureChargeType($scope.simulatedData.chargeDetails);
			} else if (productType === 'HE' || productType === 'HL') {
				_obj.expenseDetails = getForeClosureChargeType($scope.eReceiptModel.fcDetail.waiverCharges);
			} else {
				_obj.expenseDetails = _.union($scope.eReceiptModel.ODDetails, $scope.eReceiptModel.otherODCharges);
			}
			if (waiveAmount) {
				eReceiptService.callShowPopUp('app/collections/eReceipt/receipting/partials/popup/waiverDetails.html', 'detailsPopupController', 'sm', _obj);
			}
		};

		$scope.downLoadStatement = function(agreementNo) {
			eReceiptService.getFullStatement(agreementNo);
		};

		/**
		 * POS & RTGS non-linked agreement changes
		 */
		$scope.value.linkedSaleAgreements = [];
		$scope.validateAndAdd = function(_agreementNo) {
			var agrCheck;
			if ($scope.receiptType === 'SALE') {
				agrCheck = _.findWhere($scope.value.linkedSaleAgreements, {
					agreementNo : _agreementNo
				}) || (_agreementNo === $scope.eReceiptModel.agreementNo);
			} else {
				agrCheck = _.findWhere($scope.eReceiptModel.relatedAgreementNos, {
					agreementNo : _agreementNo
				});
			}

			if (agrCheck) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.AGREEMENT_EXIST);
				return;
			}
			eReceiptService.validateAgreementNo(_agreementNo, $scope.productType, $scope.receiptType, $scope.buyer.buyerId).then(function(data) {
				if (data) {
					/**
					 * Sale and EMD receipt can be done for agreement with
					 * npaStageID value as REPO.
					 */
					if (($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD') && data.npaStageID !== 'REPO') {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_SALE_EMD_AGR);
						return;
					} else if ($scope.receiptType === 'SALE' && checkEMDReceiptPending(data.receiptDetails)) {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.EMD_APPROVAL_PENDING);
						return;
					} else if (data.agreementStatus === 'C'){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, "The entered agreement has been closed already, cannot proceed OD receipting");
						return;
					}
					if($scope.receiptType === 'SALE' || $scope.receiptType === 'EMD'){
						if($scope.value.currentReceiptType === 'TS'){
							if(data.approvedSaleAmount || data.buyerID){
								dialogService.showAlert('Alert', 'Alert', 'Quote received from GB. Please enter SALE/EMD receipt through Third Party GB Sale repo stage');
								return;
							}else if(!data.isSellable){
								dialogService.showAlert('Alert', 'Alert', 'Mandate repo docs pending for upload. Please upload in leap under repo queue to proceed SALE/EMD receipt');
								return;
							}
						}else if($scope.value.currentReceiptType == 'AS' || $scope.value.currentReceiptType == 'TPS' || $scope.value.currentReceiptType == 'RF'){
							if(!data.approvedSaleAmount || !data.buyerID){
								dialogService.showAlert('Alert', 'Alert', 'Sale/Quote has not been approved for ' + _agreementNo + '. You cannot add  this agreement for SALE/EMD receipt');
								return;
							}else if(data.buyerID != $scope.eReceiptModel.buyerID){
								dialogService.showAlert('Alert', 'Alert', 'Entered agreement number : ' + data.agreementNo + ' not awarded to ' + $scope.eReceiptModel.buyerID + ' buyer');
								return;
							}
						}
					}
					$scope.value.disablePayment = true;
					$scope.value.additonalAgrNo = '';
					var balAmt = 0, saleAmt = '', emdAmt = 0, unAdjAmt = 0;
					if ($scope.receiptType === 'SALE') {
						if (data.receiptDetails && data.receiptDetails.amountPaid) {
							emdAmt = parseInt(data.receiptDetails.amountPaid);
						}
						if (data.approvedSaleAmount) {
							saleAmt = parseInt(data.approvedSaleAmount);
							balAmt = saleAmt - emdAmt;
						}
						unAdjAmt = Number(data.totalEMIODAmount + data.futurePrincipalAmount) - Number(data.approvedSaleAmount);
						var item = {
							agreementNo : data.agreementNo,
							emdAmt : emdAmt,
							saleAmt : saleAmt,
							balAmt : balAmt,
							unAdjAmt : unAdjAmt < 0 ? 0 : Math.round(unAdjAmt),
							assetDetail : data.assetDetail ? data.assetDetail : {},
							disable : (data.approvedSaleAmount > 0)
						};
						$scope.value.linkedSaleAgreements.push(item);
					} else {
						$scope.eReceiptModel.relatedAgreementNos.push(data);
						$scope.eReceiptModel.totalOD = eReceiptService.calculateTotalOD($scope.eReceiptModel.relatedAgreementNos);
					}
				}
			});
		};

		$scope.removeMoreAgreement = function(_index, $event, value) {
			$event.preventDefault();
			if (!value.isSelected && !value.isAllocated) {
				$scope.eReceiptModel.relatedAgreementNos.splice(_index, 1);
				$scope.value.disablePayment = (_.where($scope.eReceiptModel.relatedAgreementNos, {
					isMoreAgreement : true
				}).length > 0);
				return;
			}
			if (value.isSelected) {
				$scope.selectedAgreement = _.findWhere($scope.eReceiptModel.relatedAgreementNos, {
					agreementNo : $scope.value.primaryAgreementNo
				});
				$scope.selectedAgreement.isSelected = true;
			}
			$scope.eReceiptModel.relatedAgreementNos.splice(_index, 1);
			var _totalActual = _.reduce($scope.eReceiptModel.relatedAgreementNos, function(memo, item) {
				return memo + item.totalActualAmount;
			}, 0);

			$scope.selectedAgreement.totalBalanceAmount = Number($scope.receiptPostModel.Receipt.amountPaid) - Number(_totalActual);
			if ($scope.value.primaryAgreementNo !== $scope.selectedAgreement.agreementNo) {
				$scope.selectedAgreement.allocatedAmount += Number(value.totalActualAmount);
			}
			$scope.value.disablePayment = (_.where($scope.eReceiptModel.relatedAgreementNos, {
				isMoreAgreement : true
			}).length > 0);
			$scope.eReceiptModel.totalOD = eReceiptService.calculateTotalOD($scope.eReceiptModel.relatedAgreementNos);
		};

		$scope.removeSaleAgreement = function(_index) {
			$scope.value.linkedSaleAgreements.splice(_index, 1);
			$scope.value.disablePayment = ($scope.value.linkedSaleAgreements.length > 0);
			checkSaleAmt();
		};

		$scope.checkBalAmount = function(item) {
			if (item.saleAmt) {
				item.balAmt = (item.saleAmt - item.emdAmt);
				item.unAdjAmt = (item.unAdjAmt - item.saleAmt) < 0 ? 0 : (item.unAdjAmt - item.saleAmt);
			} else {
				item.balAmt = 0;
			}
			checkSaleAmt();
		};
		
		$scope.showSplitUp = function(isMSFlag, msData){
			if(isMSFlag){
				eReceiptService.showMSSplitUp(msData);
			}
		};

		/***********************************pincode city state *********************************************************** */
		var setAddressObj = function(adderss){
			if(adderss && adderss.addressObj){
				$scope.buyer.address.city = adderss.addressObj.cityID;
				$scope.buyer.address.cityDesc = adderss.addressObj.cityDesc;
				$scope.buyer.address.state = adderss.addressObj.stateID;
				$scope.buyer.address.stateDesc = adderss.addressObj.stateDesc;
				$scope.buyer.address.pincodeDesc = $scope.buyer.address.pincode = adderss.addressObj.pincode;
			}						
		};
		$scope.categoryPancard = _.findWhere($globalScope.imageCategories, {
			subCategory : "Pancard"
		});
		$scope.categoryKYC = _.findWhere($globalScope.imageCategories, {
			subCategory : "KYC Document"
		});		
		var setAddress = function(pincode){
			addressLocationFactory.getStateAndCity({zipCode:pincode}).then(function(data){
				setAddressObj(data);
			});
		};
		$scope.setInScopePAN = function(pan){
			$scope.pan_doc = pan;
		};
		$scope.setInScopeKYC = function(kyc) {
			$scope.kyc_doc = kyc;
		};

		var checkBuyerDetails = function(buyerDetails,type,isKYC){
			if(buyerDetails || type === 'vendorID'){
				//$scope.value.buyerImages = buyerDetails.images;
				$scope.buyer = {				
					"buyerType": buyerDetails.buyerType ? buyerDetails.buyerType :  'Individual',
					"buyerId"	:buyerDetails.vendorID,
					"buyerName"	:buyerDetails.vendorName,		
					"gstNo": buyerDetails.gstNo,
					"panNo":buyerDetails.panNo,				
					"address": {
						"doorNo": buyerDetails.addressDetail.doorNo,
						"street": buyerDetails.addressDetail.street,				
						"pincode":buyerDetails.addressDetail.pincode
					}
				};
				
				$scope.receiptPostModel.AddressDetail.mobileNo = (buyerDetails.phoneNo && buyerDetails.phoneNo.length) ? buyerDetails.phoneNo[buyerDetails.phoneNo.length-1] : '';			
				if(buyerDetails.addressDetail.pincode){
					setAddress(buyerDetails.addressDetail.pincode);				
				}
				$scope.checkBuyer = true;
				var panData =  _.findWhere(buyerDetails.images, {imageName : "PAN NO"});
				$scope.buyer.pancardImageRef = (panData && panData.imageRef) ? panData.imageRef : {};
				if ($scope.pan_doc && $scope.pan_doc.setFiles && $scope.buyer && $scope.buyer.pancardImageRef && $scope.buyer.pancardImageRef.imagePathReferences){
					$scope.buyer.pancardImageRef.imagePathReferences = $scope.buyer.pancardImageRef.imagePathReferences.slice($scope.buyer.pancardImageRef.imagePathReferences.length-1);
					$scope.pan_doc.setFiles($scope.buyer.pancardImageRef);
				}
				$scope.editBuyer = {				
					isBuyerName:buyerDetails.vendorName ? true :false,		
					isGstNo: buyerDetails.gstNo ? true :false,
					isPanNo:buyerDetails.panNo ? true :false,				
					isDoorNo: buyerDetails.addressDetail.doorNo ? true :false,
					isStreet: buyerDetails.addressDetail.street ? true :false,
					isPincode:buyerDetails.addressDetail.pincode ? true :false,
					isPhoneNo : $scope.receiptPostModel.AddressDetail.mobileNo ? true :false	
				};
				if($scope.buyer.buyerType === "Individual" ){
					$scope.changeBuyerType("Individual");
				}
				if(isKYC){
					//$scope.buyer.buyerType = buyerType ? buyerType :'';
					$scope.checkKYCValue(type);
				}
					
			}else{
				$scope.buyer.buyerId = "";
				$scope.data.buyerDetails = {
					address : {},
					pancardImageRef : {},
					kycDocument : {}					
				};
			}
		};

		$scope.addressLocation = {};		
		$scope.getCityList=function(cityName) {
			return addressLocationFactory.getCityList(cityName,$scope.buyer.address).then(function(data){
				return data;
			});
		};
		$scope.getStateList=function(stateName) {
			return addressLocationFactory.getStateList(stateName).then(function(data){
				return data;
			});
		};	
		$scope.getPincodeList=function(pincode) {
			return addressLocationFactory.getPincodeList(pincode,$scope.buyer.address).then(function(data){
				return data;
			});			
		};	
		$scope.citySelected = function(){
			return function(item){				
				if(item){
					addressLocationFactory.citySelected(item).then(function(data){
						setAddressObj(data);
					});					
				}
			};			
		};
		$scope.stateSelected = function(){
			return function(item){								
				if(item){							
					setAddressObj(addressLocationFactory.stateSelected(item));
				}
			};			
		};		
		$scope.getStateAndCity = function() {
			return function(item){				
				if(item){
					addressLocationFactory.getStateAndCity(item).then(function(data){
						setAddressObj(data);
					});					
				}
			};						
		};
		/***********************************pincode city state *********************************************************** */
		
		var validateFields = function(docType){
			var _doc =  $scope.attrsValues[docType];
			if($scope.buyer.gstNo){
				if(!(collectionConstants.REGULAR_EXPRESSION.GST.test($scope.buyer.gstNo))){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG["INVALID_GST"]);
					$scope.editBuyer.isGstNo = $globalScope.receiptSubmitted = false;
					return false;
				}
			}
			if(_doc){
				if(!_doc.regEx.test($scope.buyer.kycDocument.docValue) && _doc.msg){
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,collectionConstants.ERROR_MSG["INVALID_"+_doc.msg.toUpperCase()]);
					$globalScope.receiptSubmitted = false;
					return false;
				}
			}
			return true;
		};
		
		$scope.checkKYCValue = function(docType){
			if(!$scope.value.buyerDetails){
				return;
			}
			var kycData = _.findWhere($scope.value.buyerDetails.images, {imageName : docType}),_flag;
			$scope.buyer.kycDocument = $scope.buyer.kycDocument || {};
			if(kycData && kycData.imageValue){
				$scope.buyer.kycDocument = {
					"docType": kycData.imageName,
					"docValue": kycData.imageValue
				};
				_flag = $scope.editBuyer[docType] = true;
			}
			if(kycData && kycData.imageRef && kycData.imageRef.imagePathReferences){
				kycData.imageRef.imagePathReferences = kycData.imageRef.imagePathReferences.slice(kycData.imageRef.imagePathReferences.length-1);
				$scope.buyer.kycDocument.docType =  kycData.imageName;
				$scope.buyer.kycDocument.imageRef =  kycData.imageRef;
				_flag = true;
			}
			if(!_flag){
				$scope.buyer.kycDocument.imageRef = {};
				if(docType === 'TIN'){
					$scope.buyer.kycDocument.docValue = $scope.value.buyerDetails ? $scope.value.buyerDetails.tinNo : '';
				}else{
					$scope.buyer.kycDocument.docValue = "";
				}
			}
			if ($scope.kyc_doc && $scope.kyc_doc.setFiles && $scope.buyer && $scope.buyer.kycDocument && $scope.buyer.kycDocument.imageRef){
				$scope.kyc_doc.setFiles($scope.buyer.kycDocument.imageRef);
			}
		};
		
		$scope.validatePanHandler = function(panNo){
			var actionResult = eReceiptService.validators.panNo(panNo);	
			if(actionResult.status === 'success'){
				$scope.paymentMode.cash.isValidPan = true;
				getBuyerName(panNo,'panNo',false);
			}
		};
		$scope.modeHandler = function(value){
			if(value === "CASH" && $scope.receiptType !== 'closed' && $scope.receiptType !== 'SHORTFALL'){
				$scope.selectedAgreement.targetAFC = $scope.eReceiptModel.targetAFC;
				$scope.selectedAgreement.receiptType = $scope.receiptType;
				$scope.selectedAgreement.targetEMI = $scope.eReceiptModel.targetEMI;
				eReceiptService.cashValidation($scope.selectedAgreement, false);
			}
		};
		/* popupModal for breakupDetails */ 
		$scope.openModal = function(option, otherDetails,waiverSplitUp,chargeDetails){
			$modal.open({
				templateUrl : 'app/collections/eReceipt/receipting/partials/popup/shortfallBreakupPopup.html',
				controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
					
					$scope.data = option;
					$scope.breakupDetails = otherDetails;
					$scope.partPaymentDetails = waiverSplitUp;
					$scope.chargeDetails = chargeDetails;

					$scope.close = function() {
						$modalInstance.dismiss();
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {

				}
			});
		};
		// To show Shortfall Child Agreements
		$scope.showChildAgreements = function(childAgreements) {
			$modal.open({
				templateUrl : 'app/collections/eReceipt/receipting/partials/popup/viewChildAgreements.html',
				controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
					$scope.childAgreements = childAgreements.length ? childAgreements : [];
					$scope.close = function() {
						$modalInstance.close();
					};
					$scope.okHandler = function() {
						$scope.close();
					};
				} ],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};
	 /*Popup for shortfall legal details //saranya 20/06/2018//*/
		var legalData,isLegalData = false; 
		var showLegalPopup = function(legalDetails){
			$modal.open({
						templateUrl : 'app/collections/eReceipt/receipting/partials/popup/legalDetail.html',
						controller : [ '$scope', '$modalInstance','data', function($scope, $modalInstance,data) {
							$scope.legalDetails = data.legalDetails;
							$scope.noRecords = (data.legalDetails && data.legalDetails.length>0) ?false:true;				

							$scope.close = function() {
								$modalInstance.dismiss();
							};
						} ],
						size : 'md',
						backdrop : 'static',
						windowClass : 'modal-custom',
						resolve : {
							data : function() {
								return {
									legalDetails:legalDetails
								}
							}
						}
					});
		}
		$scope.legalDetailsPopup = function(){
			if($scope.eReceiptModel.legalDetails && $scope.eReceiptModel.legalDetails.length>0){
					showLegalPopup($scope.eReceiptModel.legalDetails);
			}else{
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert,"Legal Details not available.");
			}
		}
	};
	eReceipt.controller('ePayController', [ '$stateParams', '$rootScope', '$scope', '$state', 'eReceiptService', 'getBalanceDetailsInfo', '$modal', 'masterService', 'dialogService', 'messageBus', 'getchargesListResolver', '$globalScope', 'appFactory', '$timeout','lazyModuleLoader','addressLocationFactory', ePayController ]);
	return ePayController;
});
