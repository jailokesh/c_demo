define([ 'require', 'eReceipt', 'utility', 'collectionConstants' ], function(require, eReceipt, utility, collectionConstants) {
'use strict';

	/**
	 * EMD Collection Controller function. getEMDReceipting is method in a EMD
	 * resolver to get the emd info before the page load. Dependency injection
	 * $stateparam ,$scope, $state, eReceiptService as a parameter.
	 */

	var manualReceiptController = function($scope, $state, eReceiptService,$globalScope) {
		$scope.$parent.isManualReceipt = true;
		$scope.$parent.isReinitiation = false;
		eReceiptService.setManualReceiptFlag($scope.$parent.isManualReceipt);
		$scope.$parent.searchParams.searchKey = '';
		$scope.$parent.searchParams.receiptNo = '';
		$scope.$parent.searchParams.receiptDate = '';
		$scope.$parent.resetHandler();
		for(var i=$scope.$parent.searchByParams.length-1;i>=0;i--){
			var option = $scope.$parent.searchByParams[i];
			if(option.value === 'ClosedAgreement'){
				$scope.$parent.searchByParams.splice(i,1);
			}
		}
		if($globalScope.isClickedViaMenu){
			$scope.$parent.receiptDateConfig.value = '';
		}
		$scope.validate = {
			receiptNo : function(value) {
				if (value && value.length) {
					return utility.getSuccessResult();
				} else {
					return utility.getFailureResult(collectionConstants.ERROR_MSG.MANUAL_RECEIPT_VALIDATION);
				}
			}
		};
	};
	eReceipt.controller('manualReceiptController', [ '$scope', '$state', 'eReceiptService','$globalScope', manualReceiptController ]);
	return manualReceiptController;
});