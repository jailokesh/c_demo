define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var detailsPopupController = function($scope, $modalInstance, $modal, $state, data, messageBus) {
		$scope.isVishesh = data.isVishesh;
		if(data.expenseDetails){
			$scope.expenseDetails = data.expenseDetails;
		}else{
			if(data.msFlag){
				$scope.data = data;
			}else{
				$scope.data = data.popUpData;
				$scope.type = data.type;
				if ($scope.type === 'chargeDetails'){
					$scope.total = _.reduce(_.pluck($scope.data.foreclosureDetails, 'chargeAmount'), function(memo, num) {
						return memo + num;
					}, 0);
				}
				$scope.isRemarksNeed = false;
			}
		}
		
		$scope.close = function() {
			$modalInstance.dismiss();
		};

		$scope.approvalHandler = function() {
			if (!$scope.data.remarks || $scope.data.remarks === '') {
				$scope.isRemarksNeed = true;
			} else {
				$scope.isRemarksNeed = false;
				$modalInstance.dismiss();
				messageBus.emitMsg(collectionConstants.EMIT_MESSAGE.PAN_APPROVE, {
					remarks : $scope.data.remarks
				});
			}
		};
	};
	eReceipt.controller('detailsPopupController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus', detailsPopupController ]);
	return detailsPopupController;
});