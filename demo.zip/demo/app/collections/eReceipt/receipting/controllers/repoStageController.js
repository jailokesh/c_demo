define([ 'require', 'eReceipt', 'collectionConstants','constants' ], function(r, eReceipt, collectionConstants,constants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var repoStageController = function($scope, $modalInstance, $modal, $state, data, messageBus,dialogService,$globalScope) {
		$scope.repoStage = data.repoStageList;
		if(data.isMultiVendor){
			$scope.data = data;
		}
		$scope.submitRepoStage = function(repoBuyerStage) {
			if(repoBuyerStage){
				$modalInstance.close(repoBuyerStage);
			}
		};
		$scope.close = function(){
			if(data.isMultiVendor){
				$modalInstance.dismiss(null);
			}else{
				$globalScope.gotoPreviousPage();	
			}
		};
		$scope.changeRepoStage = function (repoType) {
			$scope.repoBuyerStage = repoType;
		};

		$scope.approvalHandler = function () {
			$modalInstance.close(_.findWhere($scope.data.vendors, {selected : true}));
		};
	};
	eReceipt.controller('repoStageController', [ '$scope', '$modalInstance', '$modal', '$state', 'data', 'messageBus','dialogService','$globalScope', repoStageController ]);
	return repoStageController;
});