define([ 'require', 'eReceipt' ], function(r, eReceipt) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var optionController = function($scope, $modalInstance, data, messageBus) {
		$scope.totalAgreements = data.popUpData;
		$scope.receiptType = 'single';
		var isCloseFlag;
		$scope.close = function() {
			isCloseFlag = true;
			messageBus.emitMsg('PRINT_RECEIPT', $scope.receiptType);
			$modalInstance.close($scope.receiptType);
		};
		$modalInstance.result.then(function() {
		}, function() {
			if (!isCloseFlag){
				$scope.close();
			}
		});
	};
	eReceipt.controller('optionController', [ '$scope', '$modalInstance', 'data', 'messageBus', optionController ]);
	return optionController;
});