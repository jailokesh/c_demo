define([ 'require', 'eReceipt', 'collectionConstants' ], function(r, eReceipt, collectionConstants) {
'use strict';

	/**
	 * Pop up controller for details .
	 */
	var otherODPopupController = function($scope, $modalInstance, $modal, data, messageBus, dialogService) {
		
		var showOtherCharges = (data.productType == 'HE' || data.productType == 'HL') ? collectionConstants.SHOW_OTHER_CHARGES_HE_HL : collectionConstants.SHOW_OTHER_CHARGES; 

		var chargesArr = _.filter(angular.copy(data.chargeList),function(item){
			item.leapDescription = item.leapDescription.toUpperCase();
			return showOtherCharges.indexOf(item.chargeID) > -1;
		});
		$scope.otherCharges = _.sortBy(angular.copy(data.otherCharges),'leapDescription');
		
		var removeDuplicates = function() {
			var testArr = _.pluck($scope.otherCharges, 'chargeID');
			var returnArr = angular.copy(chargesArr);
			for(var i=returnArr.length-1; i>=0;i--){
				if(testArr.indexOf(returnArr[i].chargeID) > -1){
					returnArr.splice(i,1);
				}
			}
			return returnArr;
		};
		$scope.addRow = function() {
			$scope.otherCharges.push({
				chargeID : '',
				chargeType : '',
				chargeAmount : 0,
				actual : 0,
				chargesArr : removeDuplicates()
			});
		};
		$scope.addRow();

		$scope.okHandler = function() {
			var selctedItems = _.where($scope.otherCharges, {
				selected : true
			});
			messageBus.emitMsg('UPDATE_BALANCE_TABLE', selctedItems);
			$scope.close();
		};

		$scope.changeHandler = function(item, index) {
			if(_.where($scope.otherCharges, {chargeID : item.chargeID}).length > 1){
				dialogService.showAlert('Alert', 'Alert', 'Duplicate Charges is not allowed').result.then(function(){},function(){
					$scope.otherCharges.splice(index, 1);
				});
				return;
			}
			var obj = _.findWhere(item.chargesArr, {
				chargeID : item.chargeID
			}) || {};
			item.chargeType = obj.leapDescription;
			item.selected = (item.chargeType) ? true : false;
		};

		$scope.enableButton = function() {
			return (_.findWhere($scope.otherCharges, {
				showInvalid : true
			}));
		};
		$scope.foucsHandler = function(item) {
			if (parseInt(item.chargeAmount) === 0) {
				item.chargeAmount = '';
			}
		};

		$scope.close = function() {
			$modalInstance.dismiss();
		};

	};
	eReceipt.controller('otherODPopupController', [ '$scope', '$modalInstance', '$modal', 'data', 'messageBus', 'dialogService', otherODPopupController ]);
	return otherODPopupController;
});