/**
 * Represents a E-Receipt Cancellation / Modification Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'utility', 'collectionConstants' ], function(r, eReceipt, utility, collectionConstants) {
'use strict';
	/**
	 * E-receipt cancellation/modification Controller function. Dependency
	 * injection $scope,eReceiptService as parameters.
	 */
	var pddCancelController = function($scope, eReceiptService) {

		$scope.receiptInfo = "";

		/**
		 * Method to validate the receipt no
		 */
		$scope.receiptNoValidator = function(val) {
			if (collectionConstants.REGULAR_EXPRESSION.RECEIPT_NO.test(val)){
				return utility.getSuccessResult();
			}else{
				return utility.getFailureResult(collectionConstants.ERROR_MSG.INVALID_RECEIPT_NO);
			}
		};

		/**
		 * Method to get Receipt details
		 */
		$scope.getAcknowledgementDetails = function() {
			eReceiptService.getAcknowledgementDetails().then(function(data) {
				$scope.receiptInfo = data;

			});
		};

		/**
		 * Method to send acknowledgement cancellation request
		 */
		$scope.cancelAcknowledgement = function() {

		};

	};

	eReceipt.controller('pddCancelController', [ '$scope', 'eReceiptService', pddCancelController ]);
	return pddCancelController;
});