define([ 'require', 'eReceipt' ], function(require, eReceipt) {
'use strict';

	/**
	 * EMD Collection Controller function. getEMDReceipting is method in a EMD
	 * resolver to get the emd info before the page load. Dependency injection
	 * $stateparam ,$scope, $state, eReceiptService as a parameter.
	 */

	var onlineReceiptController = function($scope, $state, eReceiptService) {
		$scope.$parent.isManualReceipt = false;
		eReceiptService.setManualReceiptFlag($scope.$parent.isManualReceipt);
		$scope.$parent.resetHandler();
	};
	eReceipt.controller('onlineReceiptController', [ '$scope', '$state', 'eReceiptService', onlineReceiptController ]);
	return onlineReceiptController;
});