define([ 'require', 'eReceipt', 'DatePickerConfig' ], function(r, eReceipt, DatePickerConfig) {
	'use strict';

	/**
	 * Pop up controller for simulation popup.
	 */
	var simulationPopupController = function($scope, data,$modalInstance) {
		$scope.data = {
			tillDate : new DatePickerConfig({
	        	value: '',
	        	readonly:true,
	        	minDate:new Date(),
	        	minErrorMsg : "Interest till Date cannot be less than current date"
			}) 
		};
		$scope.simulateHandler = function() {
            $modalInstance.close($scope.data.tillDate);
        };

        $scope.close = function() {
            $modalInstance.dismiss();
        };

	};
	eReceipt.controller('simulationPopupController', [ '$scope', 'data','$modalInstance', simulationPopupController ]);
	return simulationPopupController;
});