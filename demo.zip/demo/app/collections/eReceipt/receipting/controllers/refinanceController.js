/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt' ], function(r, eReceipt) {
	'use strict';

	/**
	 * Pop up controller for My eReceiopt Swap .
	 */
	var refinancePopupController = function($scope, $modalInstance, $state, eReceiptService, data, messageBus, $rootScope) {
		$scope.refinanceDetails = data.popUpData;
		$scope.refinanceDetails.customerName = $scope.refinanceDetails.firstName;
		$scope.refinanceDetails.source = $rootScope.identity.hierarchyName;
		$scope.refinanceDetails.sourceRefID = $rootScope.identity.userID;
		$scope.refinanceDetails.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
		var isCloseFlag;
		$scope.close = function() {
			isCloseFlag = true;
			messageBus.emitMsg('CREATE_RECEIPT');
			$modalInstance.dismiss();
		};

		$scope.receiptingType = $state.params.receiptType;
		$scope.triggerFinanceLead = function() {
			var refinanceInfo = {
				source : $scope.refinanceDetails.source,
				sourceRefID : $scope.refinanceDetails.sourceRefID,
				branchID : $scope.refinanceDetails.branchID,
				loanDetails : [ {
					vehicleDetail : {
						agreementNo : $scope.refinanceDetails.agreementNo
					}
				} ],
				partyDetails : [ {
					firstName : $scope.refinanceDetails.firstName,
					lastName : $scope.refinanceDetails.lastName,
					mobileNo : $scope.refinanceDetails.mobileNos[0],
					isIndividual : true,
					partyType : "applicant"
				} ]
			};
			eReceiptService.postRefinanceInfo(refinanceInfo).then(function() {
				$scope.close();
			});
		};
		$modalInstance.result.then(function() {
		}, function() {
			if (!isCloseFlag){
				$scope.close();
			}
		});
	};
	eReceipt.controller('refinancePopupController', [ '$scope', '$modalInstance', '$state', 'eReceiptService', 'data', 'messageBus', '$rootScope', refinancePopupController ]);
	return refinancePopupController;
});