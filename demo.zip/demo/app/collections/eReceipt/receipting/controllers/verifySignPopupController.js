/**
 * Represents a My Dashboard Controller ( for pop ups ).
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'eReceipt', 'utility' ], function(r, eReceipt, utility) {
	'use strict';

	/**
	 * Pop up controller for My eReceiopt sign verification .
	 */
	var verifySignPopupController = function($scope, data,$modalInstance,eReceiptService) {
		var getName = function(obj){
			var str;
			str = (!obj.firstName) ? '-' : obj.firstName+ ' ';
			str += (!obj.middleName) ? '' : obj.middleName+ ' ';
			str += (!obj.lastName) ? '' : obj.lastName;
			return str;
		};
		if(data.popUpData){
			var partyObj = angular.copy(data.popUpData);
			$scope.verifyData = {};
			$scope.verifyData.applicant = eReceiptService.getApplicanInfo(partyObj);
			$scope.verifyData.applicant.name = getName($scope.verifyData.applicant);
			$scope.verifyData.coApplicant = _.findWhere(partyObj,{partyType : "C"}) || {}; 
			$scope.verifyData.coApplicant.name = getName($scope.verifyData.coApplicant);
			$scope.verifyData.guarantor = _.findWhere(partyObj,{partyType : "G"}) || {}; 
			$scope.verifyData.guarantor.name = getName($scope.verifyData.guarantor);
		}
		if(data.isMSFlag){
			$scope.data = data;
			$scope.data.isPolicyExsist =  data.insuranceDetail ? true : false;
			if($scope.data.insuranceDetail && $scope.data.insuranceDetail.policyExpiringDate){
				var tempDate = new Date();
				var days = utility.dateDifference(tempDate, new Date($scope.data.insuranceDetail.policyExpiringDate));
				if(days < 0){
					$scope.data.insuranceDetail.renewalRSD = tempDate;
				}else if(days > 0){
					tempDate = new Date($scope.data.insuranceDetail.policyExpiringDate);
					$scope.data.insuranceDetail.renewalRSD = new Date(tempDate.setDate(tempDate.getDate() + 1));
				}else{
					$scope.data.insuranceDetail.renewalRSD = tempDate;
				}
			}else{
				$scope.data.insuranceDetail = $scope.data.insuranceDetail || {};
				$scope.data.insuranceDetail.renewalRSD = new Date();
			}			
			// If MS registration is blank or new then registration no field is editable.
			if(!$scope.data.insuranceDetail.registrationNo || $scope.data.insuranceDetail.registrationNo.toUpperCase() === 'NEW'){
				$scope.data.insuranceDetail.registrationNo = '';
			}			
			if(!$scope.data.insuranceDetail.registrationNo){
				$scope.data.editVehicleNo = true; //if registration no is not found in insurance detail then it is editable.
				if($scope.data.assetDetail && $scope.data.assetDetail.registrationNo){
					$scope.data.insuranceDetail = $scope.data.insuranceDetail || {};
					$scope.data.insuranceDetail.registrationNo = $scope.data.assetDetail.registrationNo.toString().split('-').join('');
				}else{
					$scope.data.insuranceDetail.registrationNo = '';
				}
			}

			if($scope.data.isPolicyExsist){
				_.each(data.insuranceDetail.dtd, function(slab){
					slab.dtdVal = slab.dtdPercentageSlab * 100;
				});
				$scope.data.dtdValues = _.pluck(_.sortBy(data.insuranceDetail.dtd,'dtdVal'),'dtdVal');	
			}else{
				$scope.data.dtdValues = ['0','10','20','30','40'];
			}
		}

		$scope.close = function(isMSFlag) {
			if(isMSFlag){
				eReceiptService.getPolicyDetails($scope.data.insuranceDetail,Number($scope.data.dtdPercentageSlab / 100)).then(function(response){
					if(response && response.length){
						response[0].registrationNo = $scope.data.insuranceDetail.registrationNo;
						response[0].renewalRsd = $scope.data.insuranceDetail.renewalRSD;
						response[0].isMSFlag = isMSFlag ? isMSFlag : false;
						$modalInstance.close(response[0]);		
					}
				})
			}else{
				$modalInstance.close();
			}
        };

		$scope.cancel = function() {
			$modalInstance.dismiss();
		};

	};
	eReceipt.controller('verifySignPopupController', [ '$scope', 'data','$modalInstance','eReceiptService', verifySignPopupController ]);
	return verifySignPopupController;
});