/**
 * Represents a EReceipt Main Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require', 'eReceipt', 'collectionConstants', 'utility', 'DatePickerConfig', 'constants'], function (r, eReceipt, collectionConstants, utility, DatePickerConfig, constants) {
	'use strict';
	var eReceiptController = function ($scope, eReceiptService, $state, lazyModuleLoader, dialogService, $globalScope, appFactory, environmentConfig) {
		$scope.receiptModel = eReceiptService.getReceiptModel();
		$scope.tableResult = [];
		var paginationObj, manualReceiptInfo = {};
		$scope.agreementStatus = constants.AGREEMENT_STATUS;
		$scope.isManualReceipt = $state.current.data.isManual;
		eReceiptService.setManualReceiptFlag($scope.isManualReceipt);
		$scope.pagination = { maxSize: constants.PAGINATION_CONFIG.MAX_SIZE_TEN, totalRecord: 0, currentPage: 1, offsetlast: constants.PAGINATION_CONFIG.MAX_SIZE_TEN, offset: 1 };
		var _date = new Date();
		$scope.searchParams = {
			branchName: JSON.parse(getCookie('selectedBranch')).branchID,
			searchBy: '',
			searchKey: '',
			receiptNo: '',
			receiptDate: '',
			limit: 10
		};
		$scope.receiptDateConfig = new DatePickerConfig({
			value: '',
			readonly: true,
			maxDate: new Date(),
			minDate: new Date(_date.setFullYear(_date.getFullYear() - 1)),
			onchange: function (value) {
				var diff = utility.dateDifference(new Date(value), new Date());
				if (diff >= collectionConstants.BACK_DATED_RECEIPT_DAYS) {
					dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.BACK_DATED_RECEIPT);
				}
			}
		});
		/**
		 * Method to fetch Manual receipt Details.
		 * Event on blur of manual receipt text box
		 */
		$scope.getManualReceiptDetails = function (value) {
			if (!value) {
				manualReceiptInfo = {};
				return;
			}
			eReceiptService.getManualReceiptBookDetails(value).then(function (data) {
				manualReceiptInfo = data || {};
				if (!manualReceiptInfo.receiptBookNo) {
					if (manualReceiptInfo.isApprovalPending) {
						if (manualReceiptInfo.pendingReceipt) {
							dialogService.confirm('Alert', "Alert!", collectionConstants.ERROR_MSG.RECEIPT_APPROVAL_REJECTED).result.then(function () {
								$scope.searchParams.receiptNo = manualReceiptInfo.pendingReceipt;
								eReceiptService.setReinitiation(true);
								$scope.isReinitiation = true;
								$scope.receiptDateConfig.value = '';
								//$scope.receiptDateConfig.maxDate = new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()-collectionConstants.BACK_DATED_RECEIPT_DAYS); // date range must be less than back dated days since user re-initiating the request.								
							}, function () {
								eReceiptService.setReinitiation(false);
								$scope.isReinitiation = false;
							});
						} else if (manualReceiptInfo.isReceiptExists) {
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.RECEIPT_PUNCHED_ALREADY);
						} else {
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.RECEIPT_APPROVAL_PENDING);
						}
					} else {
						$scope.searchDone = false;
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.MANUAL_RECEIPT_VALIDATION);
					}
				} else if (!manualReceiptInfo.allocatedUserID) {
					$scope.searchDone = false;
					dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.RECEIPT_BOOK_NOT_ASSIGNED);
					manualReceiptInfo = {}; // reset the manual receipt info.
				}
			});
		};
		var initController = function () {
			var outPutArr = [];
			_.each(collectionConstants.SEARCH_BY, function (item) {
				if (!item.activityID) {
					outPutArr.push(item);
				} else if (appFactory.getActivityAccess(item.activityID)) {
					outPutArr.push(item);
				}
			});
			$scope.searchByParams = _.sortBy(outPutArr, 'name');
			$scope.searchParams.searchKey = '';
			$scope.searchDone = !$globalScope.isClickedViaMenu;
			$scope.patternVal = '^[A-Za-z0-9 ]+$';
			$scope.tableResult = [];
			paginationObj = eReceiptService.getPageValues();
			if ($globalScope.isClickedViaMenu || !paginationObj) {
				$scope.searchDone = false;
				$scope.searchParams.searchBy = $scope.searchByParams[0];
				$scope.pagination.prevPageNo = $scope.pagination.currentPage = 1;
			} else {
				$scope.searchParams = eReceiptService.getSearchParam();
				if (!$scope.searchParams.isReceiptingDone) {
					if (paginationObj.searchBy && paginationObj.searchBy.value === "NonAgreement") {
						$scope.searchParams.searchBy = paginationObj.searchBy;
						$scope.searchParams.searchKey = paginationObj.searchKey;
						$scope.searchDone = false;
					} else {
						$scope.tableResult = paginationObj.data;
						$scope.pagination = paginationObj.pagination;
						$scope.searchParams.receiptType = $scope.searchParams.searchBy === "policyNo" ? 'ins' : $scope.searchParams.receiptType;
						var serachBy = $scope.searchParams.searchBy, _type;
						if ($scope.searchParams.receiptType) {
							$scope.searchParams.searchBy = _.findWhere($scope.searchByParams, { value: serachBy, type: $scope.searchParams.receiptType.toLowerCase() });
						} else {
							switch (serachBy) {
								case 'ClosedAgreement':
									_type = 'closed';
									break;
								case 'vishesh':
								case 'trip':
									_type = serachBy;
									break;
								default:
									_type = 'common';
							}
							$scope.searchParams.searchBy = _.findWhere($scope.searchByParams, { value: serachBy, type: _type });
						}
						$scope.patternVal = eReceiptService.getPatternValue($scope.searchParams.searchBy);
					}
					if ($scope.isManualReceipt) {
						$scope.receiptDateConfig.setDateVal(new Date($scope.searchParams.receiptDate));
						$scope.receiptDateConfig.dateValue = $scope.searchParams.receiptDate;
						manualReceiptInfo = eReceiptService.getManualReceiptDetails();
					}
				} else {
					$scope.searchDone = false;
					$scope.searchParams.searchBy = $scope.searchByParams[0];
					$scope.searchParams.receiptNo = $scope.searchParams.searchKey = '';
					$scope.pagination.prevPageNo = $scope.pagination.currentPage = 1;
					$scope.searchParams.isReceiptingDone = false;
				}
			}
			$scope.searchParams.branchName = JSON.parse(getCookie('selectedBranch')).branchID;
			try {
				$scope.placeHolderAndMaxLength = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, { type: $scope.searchParams.searchBy.value });
			} catch (error) {
				console.log('Catch block executed..');
			}
		};
		initController();
		/**
		 * set place holder content
		 */
		$scope.setPlaceHolderContent = function (searchBy, form) {
			form.resetSubmited();
			$scope.searchParams.searchKey = '';
			$scope.placeHolderAndMaxLength = _.findWhere(collectionConstants.PLACEHOLDER_TEXT, { type: searchBy.value });
			$scope.searchDone = false;
			$scope.patternVal = eReceiptService.getPatternValue(searchBy);
		};
		$scope.searchHandler = function (selectedCase) {
			$globalScope.isClickedViaMenu = true;
			var stateVal = 'collections.ePayment';
			if ($scope.isManualReceipt) {
				if (manualReceiptInfo.receiptNo === $scope.searchParams.receiptNo) {
					dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, 'Receipt No : ' + manualReceiptInfo.receiptNo + ' is already punched in the systems');
					return;
				}
				$scope.searchParams.receiptDate = $scope.receiptDateConfig.dateValue;
				stateVal = 'collections.manualPayment';
				eReceiptService.setManualReceiptDetails($scope.searchParams);
			}
			eReceiptService.data.productGroup = selectedCase.productGroup;
			$scope.receiptType = ($scope.searchParams.searchBy.type === 'common') ? 'OD' : $scope.searchParams.searchBy.type.toUpperCase();
			$state.go(stateVal, {
				agreementNo: selectedCase.agreementNo || selectedCase.leadID || selectedCase.applicationID,
				receiptType: $scope.receiptType
			}); 
	};
		$scope.goHandler = function (data) {
			data.npaStageID = data.npaStageID ? data.npaStageID.toUpperCase() : '';
			data.npaStageVal = (data.npaStageID === 'SALE' || data.npaStageID === 'WRITEOFF' || data.npaStageID === 'REPO') ? "SALE" : "REGULAR";
			eReceiptService.data.closedAgreement = data;
			$state.go('collections.ePayment', {
				agreementNo: data.agreementNo,
				receiptType: 'closed'
			});
		};
		var getSearchResults = function () {
			paginationObj = {};
			$scope.searchParams.offset = ($scope.searchParams.searchBy.type === 'imd' || $scope.searchParams.searchBy.type === 'ins-lead') ? ((($scope.pagination.currentPage - 1) * $scope.searchParams.limit) + 1) : $scope.pagination.currentPage;
			$scope.searchParams.limit = 10;
			eReceiptService.doSearch($scope.searchParams).then(function (data) {
				$scope.pagination.totalRecord = paginationObj.totalRecord = (data.meta && (data.meta.totalCount || data.meta.count)) ? (data.meta.totalCount || data.meta.count) : 0;
				$scope.pagination.offsetlast = (($scope.pagination.offset + $scope.pagination.maxSize) > $scope.pagination.totalRecord) ? $scope.pagination.totalRecord : $scope.pagination.offset + ($scope.pagination.maxSize - 1);
				if ($scope.pagination.totalRecord) {
					$scope.tableResult = paginationObj.data = data.data;
					$scope.pagination.productType = $scope.tableResult[0].productGroup;
					if ($scope.searchParams.searchBy.type === 'imd' && !$scope.searchParams.searchBy.product) {
						$scope.pagination.isHEAgreement = false;
					} else {
						$scope.pagination.isHEAgreement = ($scope.pagination.productType !== "VF");
					}
					paginationObj.pagination = $scope.pagination;
					eReceiptService.setSearchResults($scope.tableResult);
				} else {
					$scope.tableResult = [];
				}
				$scope.searchDone = true;
			});
			eReceiptService.setPageValues(paginationObj);
		};
		$scope.paginationHandler = function (pageNum, agreementNo) {
			if (eReceiptService.validateSearch(agreementNo, $scope.isManualReceipt, $scope.isReinitiation, $scope.receiptDateConfig, manualReceiptInfo, $scope.searchParams.searchBy)) {
				$scope.searchParams.searchKey = agreementNo;
				$scope.pagination.prevPageNo = $scope.pagination.currentPage = pageNum;
				$scope.pagination.offset = ((($scope.pagination.currentPage - 1) * $scope.pagination.maxSize) + 1);
				getSearchResults();
			} else {
				$scope.pagination.currentPage = $scope.pagination.prevPageNo;
			}
		};
		$scope.doSearch = function (agreementNo, formObj) {
			$scope.pagination.totalRecord = 0;
			if ($scope.searchParams.searchBy.value === "NonAgreement") {
				if ($scope.isManualReceipt) {
					if (!manualReceiptInfo.receiptBookNo) {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALIDATE_RECEIPT_NO);
						return;
					}
					$scope.searchParams.receiptDate = $scope.receiptDateConfig.dateValue;
					eReceiptService.setManualReceiptDetails($scope.searchParams);
				}
				eReceiptService.setPageValues({ searchBy: $scope.searchParams.searchBy, searchKey: agreementNo });
				$state.go('collections.nonAgreements', { referenceNo: agreementNo });
				return;
			}
			if ($scope.isManualReceipt && !$scope.receiptDateConfig.dateValue) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Enter a valid Manual Receipt Date");
			} else if ($scope.isManualReceipt && manualReceiptInfo.receiptEnteredTime && utility.dateDifference(new Date(manualReceiptInfo.receiptEnteredTime), new Date($scope.receiptDateConfig.dateValue)) < 0) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Manual receipt date cannot be lesser than last receipt date. The last receipt (" + $scope.searchParams.receiptNo + ") is punched on " + utility.formDateString(new Date(manualReceiptInfo.receiptEnteredTime), true));
			} else if (eReceiptService.validateSearch(agreementNo, $scope.isManualReceipt, $scope.isReinitiation, $scope.receiptDateConfig, manualReceiptInfo, $scope.searchParams.searchBy)) {
				$scope.searchParams.receiptDate = $scope.receiptDateConfig.dateValue;
				$scope.searchParams.searchKey = agreementNo;
				$scope.tableResult = [];
				getSearchResults();
			}
		};
		var isAgreementOrApp;
		$scope.capitalizeHandler = function (val) {
			isAgreementOrApp = ($scope.searchParams.searchBy.value === 'agreementNo' || $scope.searchParams.searchBy.value === 'dealerAgreementNo' || $scope.searchParams.searchBy.value === 'ClosedAgreement');
			if (isAgreementOrApp || $scope.searchParams.searchBy.value === 'vehicleNo' || $scope.searchParams.searchBy.value === 'policyNo' || $scope.searchParams.searchBy.value === 'panCardNo' || $scope.searchParams.searchBy.value === 'vishesh' || $scope.searchParams.searchBy.value === 'trip') {
				$scope.searchParams.searchKey = (val && val.length) ? val.toUpperCase() : '';
			}
		};
		$scope.resetHandler = function () {
			initController();
		};

		$scope.pasteHandler = function (event) {
			if (event.clipboardData) {
				var item = event.clipboardData.items[0];
				item.getAsString(function (data) {
					$scope.searchParams.searchKey = data;
				});
			}
		};
	};
	eReceipt.controller('eReceiptController', ['$scope', 'eReceiptService', '$state', 'lazyModuleLoader', 'dialogService', '$globalScope', 'appFactory', 'environmentConfig', eReceiptController]);
	return eReceiptController;
});