define([], function() {
	'use strict';
	 require.config({
		waitSeconds: 200,
			paths: {
				'collectionsApp':'app/collections/collections',
					'eReceipt': 'app/collections/eReceipt/receipting/eReceipt',
					'eReceiptResolver': 'app/collections/eReceipt/receipting/resolvers/eReceiptResolver',
					'eReceiptController': 'app/collections/eReceipt/receipting/controllers/eReceiptController',
					'manualReceiptController': 'app/collections/eReceipt/receipting/controllers/manualReceiptController',
					'onlineReceiptController' : 'app/collections/eReceipt/receipting/controllers/onlineReceiptController',
					'otherODPopupController' : 'app/collections/eReceipt/receipting/controllers/otherODPopupController',
					'cancelModifyReceiptController' : 'app/collections/eReceipt/receipting/controllers/cancelModifyReceiptController',
					'cancelAckController' : 'app/collections/eReceipt/receipting/controllers/cancelAckController',
					
					'ePayController': 'app/collections/eReceipt/receipting/controllers/ePayController',
					'eReceiptService': 'app/collections/eReceipt/receipting/services/eReceiptService',
					'repoStageController': 'app/collections/eReceipt/receipting/controllers/repoStageController',
					'ePaymentModeController': 'app/collections/eReceipt/receipting/controllers/ePaymentModeController',
					'swapPopupController' : 'app/collections/eReceipt/receipting/controllers/swapPopupController',
					'foreClosurePopupController' : 'app/collections/eReceipt/receipting/controllers/foreClosurePopupController',
					'auctionDetailsPopupController' : 'app/collections/eReceipt/receipting/controllers/auctionDetailsPopupController',
					'detailsPopupController' : 'app/collections/eReceipt/receipting/controllers/detailsPopupController',
					'cashTenLakhPopupController' : 'app/collections/eReceipt/receipting/controllers/cashTenLakhPopupController',
					'partPaymentPopupController' : 'app/collections/eReceipt/receipting/controllers/partPaymentPopupController',
					'repaySchedulePopupController' : 'app/collections/eReceipt/receipting/controllers/repaySchedulePopupController',
					'addressUpdateController' : 'app/collections/eReceipt/receipting/controllers/addressUpdateController',
					
					'miniSOAController' : 'app/collections/eReceipt/receipting/controllers/miniSOAController',
					'sharedPackage' : 'app/common/shared/package',
					'generateReceiptController' : 'app/collections/eReceipt/receipting/controllers/generateReceiptController',
					'pddPopUpController' : 'app/collections/eReceipt/receipting/controllers/pddPopUpController',
					'refinancePopupController' : 'app/collections/eReceipt/receipting/controllers/refinanceController',
					'verifySignPopupController' :'app/collections/eReceipt/receipting/controllers/verifySignPopupController',
					'optionController':'app/collections/eReceipt/receipting/controllers/receiptOptionController',
					'qrCode':'content/lib/qrCode/qrCode',
					'angularQr': 'content/lib/qrCode/angular-qr',
					'initiateWaiverController' : 'app/collections/eReceipt/receipting/controllers/initiateWaiverController',
					'nonAgreementController' : 'app/collections/eReceipt/receipting/controllers/nonAgreementController',
					'simulationPopupController' : 'app/collections/eReceipt/receipting/controllers/simulationPopupController',
					'onlinePaymentController' : 'app/collections/eReceipt/receipting/controllers/onlinePaymentController',

					'shortfallUploadController' : 'app/collections/eReceipt/receipting/controllers/shortfallUploadController',
					'shortfallSOAController' : 'app/collections/eReceipt/receipting/controllers/shortfallSOAController'
			},
			shim: {
				'angularQr' : ['angular','qrCode'],
				'eReceipt' : ['angular', 'angular-ui-router', 'angularQr','eReceiptResolver'],
				'eReceiptService' : ['eReceipt'],
				'eReceiptController' : ['eReceiptService'],
				'ePayController' : ['eReceiptService'],
				'cancelModifyReceiptController': ['eReceiptService'],
				'cancelAckController': ['eReceiptService'],
					'miniSOAController' :  ['eReceiptService'],
					'generateReceiptController' :  ['eReceiptService'],
					'pddPopUpController' : ['eReceiptService'],
					'partPaymentPopupController':['eReceiptService'],
					'initiateWaiverController':['eReceiptService'],
					'shortfallUploadController':['eReceiptService'],
					'shortfallSOAController':['eReceiptService']
			}
	 });
	 return function(callback){
		 requirejs([ 'sharedPackage' ], function(commonPackageLoader) {
			commonPackageLoader(function() {
				 var cRequire = require.config({
								context: 'checkout',
								paths:{
									//'checkout':'https://www.tecprocesssolution.com/proto/P2M/server/lib/checkout',
							'checkout':'content/lib/checkout',
									'jq':'content/lib/jquery'
								},
								shim:{
									'checkout':['jq']
								}
						});
				 cRequire(['checkout'],function(){
					 requirejs(['angularQr','eReceiptController','manualReceiptController','onlineReceiptController','otherODPopupController','ePayController','repoStageController', 'swapPopupController','ePaymentModeController','foreClosurePopupController','auctionDetailsPopupController','detailsPopupController','repaySchedulePopupController','addressUpdateController','cancelModifyReceiptController','cancelAckController','miniSOAController','generateReceiptController','pddPopUpController','refinancePopupController','verifySignPopupController','optionController','partPaymentPopupController','initiateWaiverController','cashTenLakhPopupController','nonAgreementController','simulationPopupController','onlinePaymentController','shortfallUploadController','shortfallSOAController'], callback);
				});
				
			});
		});
	 };
});