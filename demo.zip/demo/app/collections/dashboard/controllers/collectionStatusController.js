
/**
 * Represents a My customer Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola. Handles the my customer list page user interactions.
 */
define([ 'require', 'dashboard', 'constants','collectionConstants' ],function(r, dashboard, constants,collectionConstants ) {
			'use strict';
			var collectionStatusController = function($scope, $state, $rootScope,dashboardService,dialogService, lazyModuleLoader,$globalScope) {
				$scope.productType = $rootScope.productType;
				$scope.allocationType = constants.ALLOCATION_TYPE;			
				$scope.data = {};				
				$scope.data.currentPage = 1;
				$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
				$scope.maxSize = constants.PAGINATION_CONFIG.MAX_SIZE_TEN;
				var headText = _.findWhere(collectionConstants.ALLOCATION_TYPES,{value:$rootScope.filterValue});
				$state.$current.data.headerText = headText.label;
				var getMycustomerlist = function(){
					var offset = ((($scope.data.currentPage-1)*$scope.maxRecordPerPage)+1);
						dashboardService.getMyCustomers($scope.maxSize,offset).then(function(data) {	
							$scope.myCustomers = data.data;
							$scope.totalRecord = (data.meta && data.meta.totalCount) ? parseInt(data.meta.totalCount) : 0;
							});
				};
				getMycustomerlist();
				/**
				 * Method will triggers clicking on the row in the customer
				 * table.
				 * 
				 * @param {object} -
				 *            customer object will navigate to customer summary
				 *            page
				 */
				$scope.rowClickedHandler = function(customerObj) {
					var param = {
						agreementNo : customerObj.agreementNo
					};
					$rootScope.agreementList = [];
					$rootScope.goPreviousState = {name:$state.current.name,params:$state.params};
					lazyModuleLoader.loadState('collections.myCustomers.summary', param);
				};
				/**
				 * Method will triggers clicking on the row receipt/contact
				 * recording icon.
				 * 
				 * @param {string,event} -
				 *            icon and $event will navigate to the respective
				 *            module (receipt/contact recording)
				 */
				$scope.iconClickedHandler = function(icon, event,item) {
					event.stopPropagation();
					$rootScope.isClickedViaMenu = false;
					$globalScope.isClickedViaMenu = false;
					if(icon === 'receipt'){
						$globalScope.goPreviousState = {name:$state.current.name,params:$state.params};
						lazyModuleLoader.loadState('collections.ePayment', {agreementNo : item.agreementNo,receiptType : 'OD'});
						$rootScope.agreementNo = item.agreementNo;
					}else{
						$globalScope.goPreviousState = {name:$state.current.name,params:$state.params};
						lazyModuleLoader.loadState('collections.contactRecording',{agreementNo : item.agreementNo});
						$rootScope.agreementNo = item.agreementNo;
					}
				};
				/**
				 * Method will triggers clicking on the button in the pagination
				 * component.
				 * 
				 * @param {Number} -
				 *            page number ".then" is the call back handler.
				 */
				$scope.paginationHandler = function(pageNum) {
					$scope.data.currentPage = pageNum;
					getMycustomerlist();
				};
			};
			dashboard.controller('collectionStatusController', [ '$scope', '$state','$rootScope', 'dashboardService','dialogService','lazyModuleLoader','$globalScope', collectionStatusController ]);
			return collectionStatusController;
		});