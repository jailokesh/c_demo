/**
 * Represents a My Dashboard Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define([ 'require', 'dashboard', 'constants', 'collectionConstants' ], function(require, dashboard, constants, collectionConstants) {
	'use strict';
	/** My Dashboard Controller function. getMyDashboardDetails is a method in the Dashboard resolver to get the Dashboard details before the page load.getMasters is a method in the Dashboard resolver to get the Master datafor Zone / Region / Area / Branch before the page load. Dependencyinjection $scope,$rootScope,$modal,dashboardService as parameters. */
	var dashboardController = function($scope, $state, $rootScope, $globalScope, $modal, dashboardService, masterService, identity, lazyModuleLoader, messageBus, dialogService, globalData, getMyDashboardDetails,getDelayNotification,waiverExpiryFactory) {
		$scope.productTypes = $rootScope.identity.productDetails;
		$scope.productType = $rootScope.productType;
		$scope.pendingTasks = constants.DASHBOARD_PENDING_TASKS;
		$scope.zones = [];
		$scope.Details = {
			region : "",
			area : "",
			branch : ""
		};
		$scope.dashboardDetails = getMyDashboardDetails;
		$scope.dropDownValues = dashboardService.locations;
		var dashBoardPendingTasks = collectionConstants.PENDING_TASKS;
			
		/**
		 * Method to load related modules from dash board fields .
		 */
		$scope.loadMyCustomers = function(value) {
			$rootScope.filterValue = value;
			$globalScope.isClickedViaMenu = false;
			$rootScope.isClickedViaMenu = false;
			$globalScope.goPreviousState = {
				name : $state.current.name,
				params : $state.params
			};
			if (value === 'All') {
				$globalScope.isClickedDashboard = true;
				lazyModuleLoader.loadState('collections.myCustomers', {
					filter : value
				});
			} else {
				lazyModuleLoader.loadState('collections.customerList', {
					filter : value
				});
			}
		};
		$scope.loadRelatedModule = function(_module) {
			$globalScope.isClickedViaMenu = false;
			$globalScope.isClickedDashboard = true;
			$rootScope.isClickedViaMenu = false;
			$globalScope.goPreviousState = {
				name : $state.current.name,
				params : $state.params
			};
			lazyModuleLoader.loadState('collections.' + _module);
		};
		$scope.pendingTaskClickHandler = function(key) {
			if (dashBoardPendingTasks[key] !== '') {
				$rootScope.filterValue = key;
				$scope.loadRelatedModule(dashBoardPendingTasks[key]);
			} else if (key === 'fakeNotesInfo') {
				var resolve = {
					data : function() {
						return dashboardService.getChallanInfo().then(function(response) {
							return response;
						});
					}
				};
				var previewDialogController = [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
					$scope.fakeHistory = data;
					$scope.totalFakeAmt = _.reduce(_.pluck($scope.fakeHistory, 'fakeAmount'), function(memo, num) {
						return memo + num;
					}, 0);
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				} ];
				var previewDialogCallback = function() {};
				dialogService.showCustomDialog('app/collections/dashboard/partials/fakeNotesInfo.html', previewDialogController, resolve, previewDialogCallback, 'lg', 'modal-custom');
			}
		};
		var loadDashBoard = function(reqObj) {
			dashboardService.getDashboardDetails($rootScope.identity.hierarchyName, reqObj).then(function(data) {
				$scope.dashboardDetails = data;
			});
		};

		/**
		 * Method to load related zone,region,area,branch for logged in user.
		 */
		var branchArr, areaArr, regionArr;
		var dropDownByArea = function() {
			if (branchArr.length > 1 && $scope.dropDownValues.branchDetails.areaID) {
				branchArr.unshift({
					branchDesc : 'All',
					branchID : ''
				});
				$scope.dropDownValues.branchDetails.branchID = '';
				$scope.dropDownValues.branchDetails.disableBranch = false;
			} else {
				$scope.dropDownValues.branchDetails.branchID = branchArr[0] ? branchArr[0].branchID : "";
				$scope.dropDownValues.branchDetails.disableBranch = (!$scope.dropDownValues.branchDetails.branchID);
			}
		};
		var dropDownByRegion = function() {
			if (areaArr.length > 1 && $scope.dropDownValues.branchDetails.regionID) {
				areaArr.unshift({
					name : 'All',
					areaID : ''
				});
				$scope.dropDownValues.branchDetails.areaID = '';
				$scope.dropDownValues.branchDetails.disableArea = false;
			} else {
				$scope.dropDownValues.branchDetails.areaID = areaArr[0] ? areaArr[0].areaID : "";
				$scope.dropDownValues.branchDetails.disableArea = (!$scope.dropDownValues.branchDetails.areaID);
			}
		};
		var dropDownByZone = function() {
			if (regionArr.length > 1 && $scope.dropDownValues.branchDetails.zoneID) {
				regionArr.unshift({
					name : 'All',
					regionID : ''
				});
				$scope.dropDownValues.branchDetails.regionID = '';
				$scope.dropDownValues.branchDetails.disableRegion = false;
			} else {
				$scope.dropDownValues.branchDetails.regionID = regionArr[0] ? regionArr[0].regionID : "";
				$scope.dropDownValues.branchDetails.disableRegion = (!$scope.dropDownValues.branchDetails.regionID);
			}
		};
		$scope.changeHandler = function(type) {
			var reqObj = {
				productGroup : $scope.productType
			};
			if (type === 'Zone') {
				regionArr = ($scope.dropDownValues.branchDetails.zoneID) ? _.where($scope.dropDownValues.branchDetails.regions, {
					ZoneID : $scope.dropDownValues.branchDetails.zoneID
				}) : $scope.dropDownValues.branchDetails.regions;
				dropDownByZone();
				$scope.dropDownValues.branchDetails.filteredRegions = regionArr;
				type = 'Region';
			}
			if (type === 'Region') {
				areaArr = ($scope.dropDownValues.branchDetails.regionID) ? _.where($scope.dropDownValues.branchDetails.areas, {
					regionID : $scope.dropDownValues.branchDetails.regionID
				}) : $scope.dropDownValues.branchDetails.areas;
				dropDownByRegion();
				$scope.dropDownValues.branchDetails.filterdAreas = areaArr;
				type = 'Area';
			}
			if (type === 'Area') {
				branchArr = ($scope.dropDownValues.branchDetails.areaID) ? _.where($scope.dropDownValues.branchDetails.branches, {
					areaID : $scope.dropDownValues.branchDetails.areaID
				}) : $scope.dropDownValues.branchDetails.branches;
				dropDownByArea();
				$scope.dropDownValues.branchDetails.filterdBranch = branchArr;
			}
			reqObj.zoneID = $scope.dropDownValues.branchDetails.zoneID;
			reqObj.regionID = $scope.dropDownValues.branchDetails.regionID;
			reqObj.areaID = $scope.dropDownValues.branchDetails.areaID;
			reqObj.branchID = $scope.dropDownValues.branchDetails.branchID;
			loadDashBoard(reqObj);
		};
		/* Method to filter by ProductGroup i.e VF,HE,HL */
		$scope.filterByProduct = function(productGroup) {
			$scope.productType = $rootScope.productType = productGroup;
			var reqObj = {
				productGroup : $scope.productType,
				zoneID : $scope.dropDownValues.branchDetails.zoneID,
				regionID : $scope.dropDownValues.branchDetails.regionID,
				areaID : $scope.dropDownValues.branchDetails.areaID,
				branchID : $scope.dropDownValues.branchDetails.branchID
			};
			loadDashBoard(reqObj);
		};

		/* WaiverExpiry*/
		var getWaiverExpiry = function() {
			if($rootScope.isWaiverExpiry){
				return waiverExpiryFactory.waiverExpData().then(function(data){
				if(data.yetToExpire && data.yetToExpire.length){
                    waiverExpPopup(data,false);
                }else if(data.expiredData && data.expiredData.length){
                    waiverExpPopup(data,true);
                }
			});	
			}			
		};
		var waiverExpPopup = function(result,isExp){
        $modal.open({
            templateUrl: 'app/collections/eReceipt/receipting/partials/popup/waiverPopup.html',
            controller: ['$scope','data','$modal','$modalInstance','messageBus',function($scope,data,$modal,$modalInstance,messageBus){
                var expData ;
                if(data.isExp){
                	expData = (data.result && data.result.expiredData) ? data.result.expiredData : [];
                }else{
                	expData = (data.result && data.result.yetToExpire) ? data.result.yetToExpire : [];
                }
                $scope.data = {
                    waiverNormal : _.where(expData,{waiverType:"Normal"}),
                    waiverForclosure: _.where(expData,{waiverType:"ForeClosure"}),
					waiverShortfall: _.where(expData,{waiverType:"Shortfall"}),
                    isExp : data.isExp
                };
                $scope.close = function(){
                	if(!$scope.data.isExp){
 						$modalInstance.close(data);
                	}else{
                		$modalInstance.close();
                	}
                   
                };
            }],
            size : 'md',
            backdrop : 'static' ,
            windowClass : 'modal-custom',
            resolve: {
               data : function() {
                    return {
                        result : result,
                        isExp : isExp
                    };
                }
            }
        }).result.then(function (data) {
              if(data && data.result && data.result.expiredData && data.result.expiredData.length>0){
              	waiverExpPopup(data.result,true);
              }
            }, function () {});
    	}
    	/**
		 *  Check login delay notification check.
		 **/
		var delayNotification = getDelayNotification;
		if(delayNotification && delayNotification.message && delayNotification.message.errors.length){			
			dialogService.showAlert('Alert', 'Alert', delayNotification.message.errors[0].message);
			getWaiverExpiry();
		}else{
			getWaiverExpiry();
		}	
    	

	};
	dashboard.controller('dashboardController', [ '$scope', '$state', '$rootScope', '$globalScope', '$modal', 'dashboardService', 'masterService', 'identity', 'lazyModuleLoader', 'messageBus', 'dialogService', 'globalData', 'getMyDashboardDetails','getDelayNotification','waiverExpiryFactory', dashboardController ]);
	return dashboardController;
});
