/**
 * Represents a My Dashboard Controller.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require', 'dashboard','collectionConstants','constants'], 
		function(require, dashboard, collectionConstants,constants) {'use strict';
    /**
     * Work Plan Controller function.
     * 
     */
    var workplanController = function($scope,$rootScope, $modal, dashboardService,dialogService,waiverExpiryFactory,getMyWorkplanDetails) {  	
    	$scope.noRecordFound = false;
    	$scope.productTypes = $rootScope.identity.productDetails;
 		$scope.productType = $rootScope.productType;
		$scope.getMyWorkplanDetails = getMyWorkplanDetails;
       

		// console.log(getMyWorkplanDetails);
		if (getMyWorkplanDetails && getMyWorkplanDetails.status && getMyWorkplanDetails.data>0) {
			$rootScope.isPendAck = false;
            dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, getMyWorkplanDetails.data + " agreements pending with your Legal Automation queue kindly check and proceed the cases.");
		}	
		 
    	$scope.getDetails = function(workInfo){
         	if (workInfo && workInfo.ChargeDetails) {
 				var emi,fvc,afc,cbc;
 				emi = _.findWhere(
 						workInfo.ChargeDetails, {
 							ITZChargeName : collectionConstants.WORK_PLAN.CHARGE_TYPE_EMI
 						});
 				emi = (emi) ? emi.chargeAmount : 0;
 				workInfo.emi = emi;

 				fvc = _.findWhere(workInfo.ChargeDetails,
 						{
 					ITZChargeName : collectionConstants.WORK_PLAN.CHARGE_TYPE_FVC
 						});
 				fvc = (fvc) ? fvc.chargeAmount : 0;
 				workInfo.fvc = fvc;

 				cbc = _.findWhere(
 						workInfo.ChargeDetails, {
 							ITZChargeName : collectionConstants.WORK_PLAN.CHARGE_TYPE_CBC
 						});
 				cbc = (cbc) ? cbc.chargeAmount : 0;
 				workInfo.cbc = cbc;

 				afc = _.findWhere(
 						workInfo.ChargeDetails, {
 							ITZChargeName : collectionConstants.WORK_PLAN.CHARGE_TYPE_AVC
 						});
 				afc = (afc) ? afc.chargeAmount : 0;
 				workInfo.afc = afc;
 			}
         };
         /**
 		 * Method to retrieve the workplan details for the logged in user.
 		 */
    	var getWorkPlanDetails = function(){
    		dashboardService.getWorkPlanDetails($rootScope.identity.userID,'').then(function(data) {
    			if (data.status === 'failed') {
    				if(data.message.errors[0].errorCode === 'WORKPLAN-1008' ||data.message.errors[0].errorCode === 'WORKPLAN-1003'){
    					$scope.errorMsg = data.message.errors[0].message;
    				}else{
    					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, data.message.errors[0].message).result.then(function() {
						}, function() {
							 $scope.noRecordFound = true;
						});
    				}
    			}else{
    				var level = 0 ;
    				 if(!data || !data[0]){
    	                    $scope.noRecordFound = true;
    	                }
    	    			 $scope.workPlanInfo = data;
    	             	_.each(data,function(workInfo){
    	             		$scope.getDetails(workInfo);
    	             		workInfo.level = level;	
    	             		workInfo.userColor = collectionConstants.WORK_PLAN.HIERARCHY_COLOR[collectionConstants.WORK_PLAN.WORK_LEVEL+ workInfo.level];
    	             		workInfo.isCustomer = workInfo.isAgreement ? false :true ;
    	             	});
    			}
    			
            });
    	};
    	getWorkPlanDetails();
    	/**
 		 * Method to retrieve the work plan details for listed user below logged in user.
 		 */
    	$scope.rowClickedHandler = function(item,index){
    		if(item.casesAllocated === 0){
    			return;
    		}
    		if(item.isOpen) {
    			var elem = $scope.workPlanInfo.length;
    			var parentCode = '';
    			for(elem = $scope.workPlanInfo.length-1; elem>-1;elem--){
    				parentCode = $scope.workPlanInfo[elem].parentCode || ''; 
    				if(parentCode.indexOf(item.unitCode) >- 1){
    					$scope.workPlanInfo.splice(elem,1);
    				}
    			}
    			item.isOpen=false;
    			return;
    		}
    		var unitCode ;
    		if(item.unitCode === 'Unallocated Cases'){
    			unitCode = item.userID;
    		}else{
    			unitCode = item.unitCode;
    		}
    		dashboardService.getWorkPlanDetails(unitCode,item.unitCode).then(function(data) {
    				_.each(data,function(workInfo){
                 		if(workInfo.unitCode){
	             			$scope.getDetails(workInfo);
	             			workInfo.level = item.level + 1; 
	             			workInfo.userColor = collectionConstants.WORK_PLAN.HIERARCHY_COLOR[collectionConstants.WORK_PLAN.WORK_LEVEL+ workInfo.level];
	             			workInfo.isCustomer = workInfo.isAgreement ? false :true ;
                 		workInfo.parentCode = (item.parentCode) ? (item.parentCode + '-' + item.unitCode) : item.unitCode;
        				$scope.workPlanInfo.splice(++index,0,workInfo);
        				}
                 	});
    			 item.isOpen = true;
            });
        };
        /* Method to filter by ProductGroup i.e VF,HE,HL*/
        $scope.filterByProduct = function(productGroup){
        	$scope.productType = $rootScope.productType = productGroup;
        	$scope.workPlanInfo = undefined;
            $scope.noRecordFound = false;  
            getWorkPlanDetails();
        };
        /* WaiverExpiry*/
        var getWaiverExpiry = function() {
            if($rootScope.isWaiverExpiry){
                return waiverExpiryFactory.waiverExpData().then(function(data){
                if(data && data.yetToExpire && data.yetToExpire.length){
                    waiverExpPopup(data,false);
                }else if(data.expiredData && data.expiredData.length){
                    waiverExpPopup(data,true);
                }
            }); 
            }
                    
        };
        var waiverExpPopup = function(result,isExp){
        $modal.open({
            templateUrl: 'app/collections/eReceipt/receipting/partials/popup/waiverPopup.html',
            controller: ['$scope','data','$modal','$modalInstance','messageBus',function($scope,data,$modal,$modalInstance,messageBus){
                var expData ;
                if(data.isExp){
                    expData = (data.result && data.result.expiredData) ? data.result.expiredData : [];
                }else{
                    expData = (data.result && data.result.yetToExpire) ? data.result.yetToExpire : [];
                }
                $scope.data = {
                    waiverNormal : _.where(expData,{waiverType:"Normal"}),
                    waiverForclosure: _.where(expData,{waiverType:"ForeClosure"}),
					waiverShortfall: _.where(expData,{waiverType:"Shortfall"}),
                    isExp : data.isExp
                };
                $scope.close = function(){
                    if(!$scope.data.isExp){
                        $modalInstance.close(data);
                    }else{
                        $modalInstance.close();
                    }
                   
                };
            }],
            size : 'md',
            backdrop : 'static' ,
            windowClass : 'modal-custom',
            resolve: {
               data : function() {
                    return {
                        result : result,
                        isExp : isExp
                    };
                }
            }
        }).result.then(function (data) {
              if(data && data.result && data.result.expiredData && data.result.expiredData.length > 0){
                waiverExpPopup(data.result,true);
              }
            }, function () {
              //  $log.info('Modal dismissed at: ' + new Date());
            });
        }
            getWaiverExpiry();  
    };
    dashboard.controller('workplanController', ['$scope', '$rootScope', '$modal','dashboardService','dialogService','waiverExpiryFactory','getMyWorkplanDetails', workplanController]);
    return workplanController;
});
