define([], function() {
    'use strict';

    /**
     * Contains the dashboard module file names with their paths.
     * Contains the dashboard module required dependency configuration.
     */
    require.config({
        paths: {
        	'collectionsApp':'app/collections/collections',
            'dashboard': 'app/collections/dashboard/dashboard',
            'dashboardController': 'app/collections/dashboard/controllers/dashboardController',
            'dashboardResolver': 'app/collections/dashboard/resolvers/dashboardResolver',
            'workplanResolver': 'app/collections/dashboard/resolvers/workplanResolver',
            'dashboardService': 'app/collections/dashboard/services/dashboardService',
            'sharedPackage': 'app/common/shared/package',
            'workplanController': 'app/collections/dashboard/controllers/workplanController',
            'staticHeader':'app/collections/dashboard/directives/staticHeader',
            'collectionStatusController':'app/collections/dashboard/controllers/collectionStatusController'
        },
        shim: {
            'dashboard': ['angular', 'angular-ui-router', 'dashboardResolver', 'workplanResolver'],
            'dashboardController': ['dashboardService'],
            'workplanController': ['dashboard', 'dashboardService'],
            'dashboardService': ['dashboard'],
            'collectionStatusController':['dashboardService']

        }
    });

    /**
     * Call back method will get trigger once the dependency files gets loaded for the dashboard module.
     *  @param {method} call back.
     */

    return function(callback) {
        requirejs(['sharedPackage'], function(commonPackageLoader) {
            commonPackageLoader(function() {
                requirejs(['staticHeader','dashboardController', 'workplanController','collectionStatusController'], callback);
            });
        });
    };
});
