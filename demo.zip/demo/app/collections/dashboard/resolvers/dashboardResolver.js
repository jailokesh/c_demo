define([], 
	function() {'use strict';
	/**
	 * Represents a Dashboard Resolver. Dependency injection
	 * dashboardService,$rootScope,$globalScope and masterService  as parameters.
	 */
	return {
		getMyDashboardDetails : [ 'dashboardService', '$rootScope', 'masterService', '$globalScope', function(dashboardService, $rootScope, masterService, $globalScope) {
			$globalScope.isOpsManager = true;
			return dashboardService.loadDashBoardDetails($rootScope.identity.hierarchyName).then(function(data) {
				$globalScope.isOpsManager = false;
				return data;
			});
		}],
		getDelayNotification : ['dashboardService', '$rootScope',function(dashboardService, $rootScope){
			return dashboardService.getDelayNotificationDetails($rootScope.identity.hierarchyName);
		}]
	};

});
