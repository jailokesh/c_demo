define([], 
	function() {'use strict';
	/**
	 * Represents a Dashboard Resolver. Dependency injection
	 * dashboardService,$rootScope,$globalScope and masterService  as parameters.
	 */
	return {
		getMyWorkplanDetails : [ 'dashboardService', '$rootScope', 'masterService', '$globalScope', function(dashboardService, $rootScope, masterService, $globalScope) {
			if($rootScope.identity.hierarchyName.toUpperCase() == 'BRM'){
				return dashboardService.pendingCaseAlertData($rootScope.identity.hierarchyName).then(function(data) {
					return data;
				});
			}
		}]
	};
});
