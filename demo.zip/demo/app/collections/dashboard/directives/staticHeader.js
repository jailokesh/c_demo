define(['dashboard'], function(dashboard){
	'use strict';

	var staticHeader = function($compile, $window){
		return {
			restrict:'A',
			link: function($scope, $elem){
				
				var elem = angular.element($elem.find('thead'));
				var domElement = $elem[0];
				var tableWidth = domElement.clientWidth;
				var $page= angular.element($window);
				var elScrollTopOriginal = $elem[0].getBoundingClientRect().top - 40;
				//console.log(elem, $window,elScrollTopOriginal);

				angular.element($window).on('scroll',function(event){
					var windowScrollTop = $page[0].pageYOffset;
	                var elScrollTop     = $elem[0].offsetTop-50;
	                //console.log(windowScrollTop, elScrollTop);
	                if ( windowScrollTop > elScrollTop) {
	                    //elScrollTopOriginal = elScrollTop;
	                    angular.element(elem[0]).css('position', 'fixed')
	                    .css('top', '57px')
	                    .css('width',tableWidth+'px')
	                    .css('display','inherit')
	                   	.css('z-index',100);
	                }
	                else if ( windowScrollTop < elScrollTop ) {
	                    angular.element(elem[0]).css('position', 'relative').css('top', '0').css('margin-left', '0');
	                }
				});

			}
		};
	};

	dashboard.directive('staticHeader',['$compile', '$window', staticHeader]);

	return staticHeader;
});