define(['require','dashboardResolver','workplanResolver','collectionsApp'],
		function(require,dashboardResolver,workplanResolver,collectionsApp) {'use strict';
		/**
		 * Contains the dashboard routing information.
		 * Create and return the My dashboard module.
		 */
		var baseViewUrl = 'app/collections/dashboard/';
		var app = angular.module('dashboard', [ 'common','ui.router','collections' ]);
		var dashboard = {
			name : 'collections.dashboard',
			url : '/dashboard',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'dashboard.html',
					controller : 'dashboardController',
					resolve : dashboardResolver
				}
			},
			data:{'headerText':'My Dashboard',
				  'stateActivity' : ['COL_TELLER_AND_ABOVE_DASHBOARD']
			}
		};
		
		var workPlanDashboard = {
			name : 'collections.workPlan',
			url : '/workplan',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl + 'partials/workPlan.html',
					controller : 'workplanController',
					resolve : workplanResolver
				}
			},
			data:{'headerText':'Work Plan',
				  'stateActivity' : ['COL_WORKPLANS']
			}
		};
		
		var blankPage = {
			name : 'collections.blankPage',
			url : '/landingPage',
			views : {
				'mainContent' : {
					template : '<div class="container"><div class="row"><section class="well well-sm well-custom margin-b-1 clearfix"><h4>You are Logged In Successfully !</h4></section></div>',
					controller : ['masterService','$rootScope',function(masterService,$rootScope){
						if(!$rootScope.identity.headerLabel && $rootScope.identity.branchIDs[0]){
							masterService.getBranches({branchID:$rootScope.identity.branchIDs[0]}).then(function(branchName){
								if(branchName && branchName[0]){
									var expiryTime = new Date(getCookie('token_expiry'));
									$rootScope.identity.headerLabel = "Branch ";
									$rootScope.identity.selectedBranch = branchName[0];
									$rootScope.identity.branchName = branchName[0].branchDesc;
									setCookie('selectedBranch', angular.toJson(branchName[0]), expiryTime);
								}
							});
						}
					}]
				}
			},
			data:{'headerText':'Welcome'}
		};
		
		var myCustomerPage = {
					name : 'collections.customerList',
					url : '/customerList/:filter',
					views : {
						'mainContent' : {
							templateUrl : baseViewUrl + 'partials/collectionStatus.html',
							controller : 'collectionStatusController'
						}
					},
					data : {
						'headerText' : 'My Customer',
						//'backState': 'collections.dashboard',
						'stateActivity' : ['COL_MY_CUSTOMER']
					}
		};
		/**
		 * Contains the My dashboard configuration details.
		 */
		var dashboardConfiguration = function($stateProvider) {
			$stateProvider.state(dashboard).state(workPlanDashboard).state(blankPage).state(myCustomerPage);
		};
		
		app.config([ '$stateProvider',dashboardConfiguration ]);
		return app;

	});
