/**
 * Represents a Dashboard Service. Dependency injection $q,restProxy as
 * parameters.
 */
define([ 'require', 'dashboard', 'utility', 'constants', 'collectionConstants', 'collectionServiceURLs' ], function(require, dashboard, utility, constants, collectionConstants, collectionsServiceURL) {
	'use strict';
	var dashboardService = function($q, restProxy, $rootScope, masterService, $globalScope) {
		var serviceObj = this;
		var queryParams = {};
		$rootScope.notificationService = true;
		var selectedBranch = getCookie('selectedBranch');
		this.locations = {
			branchDetails : {}
		};
		/**
		 * @description - Fetch the fake notes information.
		 * @return - challan amount,branch and challan information will return.
		 */
		this.getChallanInfo = function() {
			var queryParams = {
				userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			};
			queryParams.view = 'fakeNotesSummary';
			queryParams.fromDate = "01-" + utility.formDateString(new Date(), true).split('-')[1] + "-" + utility.formDateString(new Date(), true).split('-')[2];
			queryParams.toDate = utility.formDateString(new Date(), true);
			queryParams.product = $rootScope.productType;

			collectionsServiceURL.fakeNoteServices.GET_CHALLANS_SUMMARY.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.fakeNoteServices.GET_CHALLANS_SUMMARY).then(function(data) {
				if (data.status === 'success') {
					return data.data;
				} else {
					return utility.getFailureResult();
				}
			});
		};

		/**
		 * Method to retrieve the dashboard details for logged
		 * user(Teller,AOM,ROM,ZOM,NOM).
		 * 
		 * @param {string}
		 *            userRole and mapped zone,region,area,branch ids.
		 */

		this.getDashboardDetails = function(userRole, reqObj) {
			var url = {};
			if (userRole === constants.USERTYPE.TELLER.value) {
				url = collectionsServiceURL.dashboardServices.DASHBOARD_TELLER;
				url.queryParams.branchID = reqObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
			} else {
				url = collectionsServiceURL.dashboardServices.DASHBOARD_MANAGER;
			}
			if ($globalScope.isOpsManager !== true) {
				$globalScope.dashBoardFilters = url.queryParams = reqObj;
			} else {
				url.queryParams.productGroup = $rootScope.productType;
			}
			return restProxy.get(url).then(function(data) {
				if (data.data && data.data[0]) {
					data.data[0].collection = {
						pddObj : {},
						rpdcObj : {},
						odObj : {},
						chObj : {},
						miObj : {},
						crObj : {},
						irObj : {}
					};
					data.data[0].collection.pddObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "PDD"
					});
					data.data[0].collection.rpdcObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "RPDC"
					});
					data.data[0].collection.odObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "OD collected"
					});
					data.data[0].collection.chObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "Charges collected"
					});
					data.data[0].collection.miObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "MI Renewed"
					});
					data.data[0].collection.irObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "IR"
					});
					data.data[0].collection.crObj = _.findWhere(data.data[0].CollectionStatus, {
						collectionType : "AllocatedVsFirstContactRecordingDone"
					});
					return data.data[0];
				}
				return data;
			});
		};
		var getNewDashBoardData = function(userRole) {
			if (userRole === constants.USERTYPE.TELLER.value) {
				serviceObj.locations.branchDetails.branchID = queryParams.branchID = selectedBranch ? JSON.parse(selectedBranch).branchID : '';
			} else {
				masterService.getBranches({
					branchID : $rootScope.identity.branchIDs.toString()
				}).then(function(userBranches) {
					userBranches.unshift({
						branchDesc : 'All',
						branchID : ''
					});
					serviceObj.locations.branchDetails.branchID = '';
					serviceObj.locations.branchDetails.branches = userBranches;
					if (userRole === 'AOM') {
						serviceObj.locations.branchDetails.filterdBranch = _.where(userBranches, {
							areaID : serviceObj.locations.branchDetails.areaID
						});
						if (serviceObj.locations.branchDetails.filterdBranch.length > 1) {
							serviceObj.locations.branchDetails.filterdBranch.unshift({
								branchDesc : 'All',
								branchID : ''
							});
						} else {
							serviceObj.locations.branchDetails.branchID = serviceObj.locations.branchDetails.filterdBranch[0].branchID;
						}
					} else {
						serviceObj.locations.branchDetails.filterdBranch = userBranches;
					}
				});
			}
		};
		var getRomAboveData = function(userRole) {
			if (userRole === 'ZOM') {
				serviceObj.locations.branchDetails.zoneID = queryParams.zoneID = selectedBranch ? JSON.parse(selectedBranch).ZoneID : '';
			} else {
				if (serviceObj.locations.branchDetails.zones && serviceObj.locations.branchDetails.zones.length > 1) {
					serviceObj.locations.branchDetails.zones.unshift({
						name : 'All',
						ZoneID : ''
					});
					serviceObj.locations.branchDetails.zoneID = '';
				} else {
					serviceObj.locations.branchDetails.zoneID = serviceObj.locations.branchDetails.zones[0].ZoneID;
				}
				serviceObj.locations.branchDetails.disableRegion = (serviceObj.locations.branchDetails.zones.length > 1);
			}
			masterService.getAreas({
				regionID : $rootScope.identity.regionIDs.toString()
			}, 'region').then(function(regions) {
				regions.unshift({
					name : 'All',
					regionID : ''
				});
				serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = regions;
				serviceObj.locations.branchDetails.regionID = '';
				serviceObj.locations.branchDetails.disableArea = (serviceObj.locations.branchDetails.filteredRegions.length > 1);
			});
		};

		this.loadDashBoardDetails = function(userRole) {
			if ($globalScope.dashBoardFilters && $globalScope.dashBoardFilters.branchID) {
				$globalScope.dashBoardFilters.productGroup = $rootScope.productType;
				return serviceObj.getDashboardDetails(userRole, $globalScope.dashBoardFilters);
			}
			selectedBranch = getCookie('selectedBranch');
			if (userRole === 'AOM') {
				serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = $rootScope.identity.userAreas;
				serviceObj.locations.branchDetails.areaID = queryParams.areaID = selectedBranch ? JSON.parse(selectedBranch).areaID : '';
			} else if (userRole === 'ROM' || userRole === 'ZOM' || userRole === 'BH') {
				if (userRole === 'ROM') {
					serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = $rootScope.identity.userRegions;
					serviceObj.locations.branchDetails.regionID = queryParams.regionID = selectedBranch ? JSON.parse(selectedBranch).regionID : '';
				} else if (userRole === 'ZOM' || userRole === 'BH') {
					serviceObj.locations.branchDetails.zones = $rootScope.identity.userZones;
					getRomAboveData(userRole);
				}
				var regionID = selectedBranch ? JSON.parse(selectedBranch).regionID : '';
				masterService.getAreas({
					areaID : $rootScope.identity.areaIDs.toString(),
					regionID : regionID
				}, 'area').then(function(areas) {
					areas.unshift({
						name : 'All',
						areaID : ''
					});
					serviceObj.locations.branchDetails.areaID = '';
					serviceObj.locations.branchDetails.filterdAreas = serviceObj.locations.branchDetails.areas = areas;
					serviceObj.locations.branchDetails.disableBranch = (serviceObj.locations.branchDetails.filterdAreas.length > 1);
				});
			}
			getNewDashBoardData(userRole);

			return serviceObj.getDashboardDetails(userRole, queryParams);
		};
		this.getDelayNotificationDetails = function(userRole) {
			if(userRole.toUpperCase() === "TELLER" && $rootScope.notificationService){
				var queryParams = {
					userrole : ($rootScope.identity.hierarchyName).toUpperCase(),
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					collectionAgentID : $rootScope.identity.userID
				};
				collectionsServiceURL.dashboardServices.DELAY_NOTIFICATION.notify = false;
				collectionsServiceURL.dashboardServices.DELAY_NOTIFICATION.queryParams = queryParams;
				return restProxy.get(collectionsServiceURL.dashboardServices.DELAY_NOTIFICATION).then(function(data) {					
					$rootScope.notificationService = false;
					return data;					
				});
			}else{
				return [];
			}	
		};
		/**
		 * Method to retrieve the workplan details for logged
		 * user(BRM,ARM,RRM,ZRM,NRM).
		 * 
		 * @param {string}
		 *            user id.
		 */
		this.getWorkPlanDetails = function(userId, userCode) {
			var urlParams = {
				'empId' : userId
			};
			collectionsServiceURL.dashboardServices.WORK_PLAN.urlParams = urlParams;
			var queryParams = {
				productGroup : $rootScope.productType ? $rootScope.productType : ''
			};
			switch ($rootScope.identity.hierarchyName.toUpperCase()) {
			case 'BRM':
				queryParams.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
				break;
			case 'ARM':
				queryParams.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
				break;
			case 'RRM':
				queryParams.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
				break;
			case 'ZRM':
				queryParams.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
				break;
			default:
				break;
			}

			if (userCode === 'Unallocated Cases') {
				queryParams.view = "unallocated";
			}
			collectionsServiceURL.dashboardServices.WORK_PLAN.queryParams = queryParams;
			collectionsServiceURL.dashboardServices.WORK_PLAN.notify = false;
			return restProxy.get(collectionsServiceURL.dashboardServices.WORK_PLAN, undefined, undefined).then(function(data) {
				if (data.status === 'failed') {
					return data;
				} else {
					return data.data;
				}
			});
		};
		/**
		 * Method to retrieve the customers details for logged user.
		 * 
		 * @param {string}
		 *            user id.
		 */
		var getApplicanInfo = function(partyDetails) {
			var partyObj = _.findWhere(partyDetails, {
				'partyType' : 'Applicant'
			});
			if (!partyObj) {
				partyObj = _.findWhere(partyDetails, {
					'partyType' : 'A'
				});
			}
			return partyObj;
		};

		this.getMyCustomers = function(limit, offset) {
			var queryParams = {}, mobileObj;
			if ($rootScope.filterValue === collectionConstants.MY_CUSTOMER_VALUES.COLLECTED_PTP) {
				queryParams = {
					'searchby' : 'collectedptps'
				};
			} else {
				queryParams = {
					filter : $rootScope.filterValue,
					collected : true,
					limit : limit,
					offset : offset,
					productGroup : $rootScope.productType
				};
			}
			queryParams.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
			collectionsServiceURL.myCustomerServices.CUSTOMER_LIST.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.myCustomerServices.CUSTOMER_LIST).then(function(data) {
				var response = data;
				if (response.data) {
					_.each(response.data, function(item, index) {
						if (item.agreementNo) {
							item.applicantDetails = getApplicanInfo(item.partyDetails);
							item.applicantDetails.fullName = (item.applicantDetails.firstName) ? item.applicantDetails.firstName + ' ' : '';
							item.applicantDetails.fullName += (!item.applicantDetails.middleName) ? '' : item.applicantDetails.middleName + ' ';
							item.applicantDetails.fullName += (!item.applicantDetails.lastName) ? '' : item.applicantDetails.lastName;
						} else {
							response.data.splice(i, index);
						}
					});
					return response;
				} else {
					return {};
				}
			});
		};
		this.pendingCaseAlertData = function() {
			$rootScope.isPendAck = true;
			var queryParams = {
				source : 'LEGAL',
				isPendingCount : true
			};
				switch ($rootScope.identity.hierarchyName.toUpperCase()) {
				case 'BRM':
					queryParams.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				case 'ARM':
					queryParams.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					break;
				case 'ALM':
					queryParams.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					break;					
				case 'RRM':
					queryParams.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					break;
				case 'RLM':
					queryParams.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					break;					
				case 'ZRM':
					queryParams.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
					break;
				case 'ZLM':
					queryParams.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
					break;					
				default:
					break;
				}	

			collectionsServiceURL.legalServices.LEGAL_PENDING_CASE_ALERT.queryParams = queryParams;
			return restProxy.get(collectionsServiceURL.legalServices.LEGAL_PENDING_CASE_ALERT).then(function(response) {
				return response;
			});
		};					
	};
	dashboard.service('dashboardService', [ '$q', 'restProxy', '$rootScope', 'masterService', '$globalScope', dashboardService ]);
});
