define(['constants','collectionConstants','utility','legalConstants'], function(constants,collectionConstants,utility,legalConstants) {
    'use strict';
    var app = angular.module('collections', ['ui.router']);
    var collectionsConfiguration = function($stateProvider,$httpProvider) {
        $stateProvider.state('collections', {
            abstract: true,
            resolve: {
                identity: ['authService', '$q', '$modal','$rootScope','environmentConfig','masterService',function(authService, $q, $modal,$rootScope,environmentConfig,masterService) {
                        return authService.authorize().then(function(result) {
                        	$rootScope.isMiniSOAReceipt = (environmentConfig.miniSOA_Receipt_Enable.toUpperCase() === 'YES');
                            if (result && result.status === 'success') {
                                $rootScope.maxResults = 200;
                                // selected role detail will be saved in consumer data, this is for redirecting to application after online payment done.  
                                var _consumerData = window.sessionStorage.consumerData ? JSON.parse(window.sessionStorage.consumerData) : '';
                                if(_consumerData){
                                	$rootScope.identity.selectedRoleID = _consumerData.selectedRoleID;
                                	$httpProvider.defaults.headers.common.selectedRoleID = $rootScope.identity.selectedRoleID;
                                }
                                switch (result.data.hierarchyName.toUpperCase()) {
                                    case 'TELLER' :
                                    case 'BRM':
                                    case 'NRM':
                                    case 'BCM_COL':
                                    case 'BBM_COL':
                                    case 'HO_CORP_LEGAL_JR_MANAGER':
                                    case 'HO_CORP_LEGAL_SUPPORT_EXECUTIVE' :
                                    case 'CORP_LEGAL_SR_MANAGER' :
                                    case 'COMP_SEC' :
                                        if (!result.data.branchName) {
                                            return authService.getUserBranches(result.data).then(function(branches) {
                                                _.each(branches,function(branch){
                                                    branch.name = branch.branchDesc; 
                                                });
                                                return authService.getUserPopupSelectionByRole(result.data, branches);
                                            });
                                        } else{
                                            $rootScope.identity.headerLabel = 'Branch';
                                            return result.data;
                                        }
                                        break;										
                                    case 'AOM' :
                                    case 'ARM' :
                                    case 'ALM' :
                                    case 'AVP_LEGAL' :
                                    case 'ACM_COL':
                                    case 'ABM_COL':
                                        if (!result.data.branchName) {
                                        return authService.getUserAreas(result.data).then(function(areas) {
                                            return authService.getUserPopupSelectionByRole(result.data, areas);
                                        });
                                        }else {
                                            $rootScope.identity.headerLabel = 'Area';
                                            return result.data;
                                        }
                                        break;
                                    case 'ROM' :
                                    case 'RRM' :
                                    case 'RLM' :
                                    case 'RCM_COL':
                                    case 'RBM_COL':
                                    case 'PUCOORDINATOR' :
                                        if (!result.data.branchName) {
                                            return authService.getUserRegions(result.data).then(function(regions) {
                                            return authService.getUserPopupSelectionByRole(result.data, regions);
                                            });
                                        }else {
                                            $rootScope.identity.headerLabel = 'Region';
                                            return result.data;
                                        }
                                        break;
                                    case 'ZOM' :
                                    case 'ZRM' :
                                    case 'ZLM' :
                                    case 'ZCM_COL':
                                    case 'ZBM_COL':
                                    case 'TELECALLING_MGR':
                                        if (!result.data.branchName) {
                                            return authService.getUserZones(result.data).then(function(zones) {
                                            return authService.getUserPopupSelectionByRole(result.data, zones);
                                            });
                                        }else {
                                            $rootScope.identity.headerLabel = 'Zone';
                                            return result.data;
                                        }
                                        break;
                                    case 'BH' :
                                    /*case 'NRM' :*/
                                    	if (!result.data.branchName) {
                                            authService.getUserZones(result.data).then(function(){
                                                result.data.headerLabel = '';
                                                return result.data;
                                            });
                                        }else{
                                            return result.data;
                                        }
                                        break;
                                    	 //return result.data;
                                    default:
                                        if(result.data.branchIDs[0]){                                            
                                            return masterService.getBranches({branchID:result.data.branchIDs[0]}).then(function(branchName){
                                                // return masterService.getBranches({branchID:6}).then(function(branchName){
                                                branchName[0].name = branchName[0].branchDesc;
                                                $rootScope.identity.headerLabel = 'Branch';
                                                return authService.getUserPopupSelectionByRole(result.data,branchName);  
                                            });
                                        }else{
                                            return result.data;
                                        }
                                        //return result.data;
                                }
                            } else {
                                return $q.reject('Unauthorized');
                            }
                        });
                    }],
                imageCategories : ['masterService','$globalScope',function(masterService,$globalScope){
            	    return masterService.getImageCategoryList().then(function(data){
            		   $globalScope.imageCategories = data;
                       return data;
                    });      
                }]
            },
            views: {
                'moduleHeaderTemplate': {
                    templateUrl: 'app/collections/header/partials/header.html',
                    controller: 'collectionsHeaderController'
                },
                'moduleTemplate': {
                    template: '<div data-ui-view="mainContent"></div>'
                }
            }
        }).state('collections.dummyDashboard', {
            views: {
                'mainContent': {
                    template: '',
                    controller: ['authService', 'identity', 'lazyModuleLoader', '$globalScope','$rootScope','masterLegalConstants','restProxy','$modal',function(authService, identity, lazyModuleLoader, $globalScope,$rootScope,masterLegalConstants,restProxy,$modal){
                            $globalScope.defaultState = 'collections.blankPage';
                            $globalScope.isClickedViaMenu = true;
                            $httpProvider.defaults.headers.common.selectedRoleID = $rootScope.identity.selectedRoleID;
                            delete $httpProvider.defaults.headers.common.selectedZoneID;
                            delete $httpProvider.defaults.headers.common.selectedRegionID;
                            delete $httpProvider.defaults.headers.common.selectedAreaID;
                            delete $httpProvider.defaults.headers.common.selectedBranchID;
                            if($rootScope.identity.headerLabel === "Zone"){
                            	$httpProvider.defaults.headers.common.selectedZoneID = $rootScope.identity.selectedBranch.ZoneID;
                            }else if($rootScope.identity.headerLabel === "Region"){
                            	$httpProvider.defaults.headers.common.selectedRegionID = $rootScope.identity.selectedBranch.regionID;
                            }else if($rootScope.identity.headerLabel === "Area"){
                            	$httpProvider.defaults.headers.common.selectedAreaID = $rootScope.identity.selectedBranch.areaID;
                            }else{
                            	$httpProvider.defaults.headers.common.selectedBranchID = $rootScope.identity.selectedBranch.branchID;
                            }
                            masterLegalConstants.update(legalConstants).then(function(result){
                        		if (result) {
                        			legalConstants.LEGAL_CASE_MAPPING = result.LEGAL_CASE_MAPPING;
                        			legalConstants.LEGAL_CASE_MAPPING_HEHL = result.LEGAL_CASE_MAPPING_HEHL;
                        			legalConstants.LEGAL_VALUES = result.LEGAL_VALUES;
                        		}
                        	});
                            switch (identity && identity.hierarchyName.toUpperCase()) {
                                case 'AUCTIONEER':
                                	$globalScope.defaultState = 'collections.auctioneersList';
                                    break;
                                case 'TELLER':
                                case 'AOM':
                                case 'ROM':
                                case 'ZOM':
                                case 'BH':
                                    $globalScope.defaultState = 'collections.dashboard';
                                    break;
                                case 'BRM':
                                case 'ARM':
                                case 'NRM':
                                case 'ZRM':
                                case 'RRM':
                                    $globalScope.defaultState = 'collections.workPlan';
                                    break;
								case 'ALM':
                                case 'RLM':
                                case 'ZLM':
                                    $globalScope.defaultState = 'collections.legalSummary';
                                    break;  
								/*case 'REPO_AGENT':
								 	$globalScope.defaultState = 'collections.repoAgentDashboard';
								 	break;
								case 'YARD_MANAGER':	
								 	$globalScope.defaultState = 'collections.yardManagerDashboard';
								 	break;*/
                                case 'SM_OPS12':
                                    $globalScope.defaultState = 'collections.receiptsToBeDispatched';
                                    break;
                                case 'TELECALLING_MGR' :
                                    $globalScope.defaultState = 'collections.tcmDashboard';
                                    break;
                                case 'PUCOORDINATOR' :
                                    $globalScope.defaultState = 'collections.puDashboard';
                                    break;
                                case 'HO_CORP_LEGAL_JR_MANAGER' :
                                case 'HO_CORP_LEGAL_SUPPORT_EXECUTIVE' :
                                case 'CORP_LEGAL_SR_MANAGER' :
                                case 'COMP_SEC' :
                                    $globalScope.defaultState = 'collections.corpDashboard';
                                
                                default:
                                    break;
                            }
							
                            if(identity.hierarchyName.toUpperCase() === 'TELLER'){
								authService.checkStandByTeller(identity, $globalScope.defaultState);															
                            }else{
                                lazyModuleLoader.loadState($globalScope.defaultState);
                            }			
										
                            //lazyModuleLoader.loadState($globalScope.defaultState);
                        }
                    ]
                }
            }
        });
    };

    app.config(['$stateProvider','$httpProvider', collectionsConfiguration]);
    app.factory('collectionFactory',['dialogService',function(dialogService){
        
        	var isAllSelected = function(options,isAll){
        		_.each(options, function(item) {
        			item.selected = isAll;
        			_.each(item.subMenu, function(subitem) {
        				subitem.selected = isAll;
        			});
        		});
        	};
        	
        	var filterCheckAll = function(options){
        		var selectedMenu = _.where(options, { selected : true }),isAll;
        		if (selectedMenu && (selectedMenu.length === options.length)) {
        			isAll = true;
        			for (var mainIndex = 0; mainIndex < selectedMenu.length; mainIndex++) {
        				for (var subIndex = 0; subIndex < selectedMenu[mainIndex].subMenu.length; subIndex++) {
        					if (!selectedMenu[mainIndex].subMenu[subIndex].selected) {
        						isAll = false;
        						return isAll;
        					}
                            if(!selectedMenu[mainIndex].selected){
                                selectedMenu[mainIndex].subMenu[subIndex].selected=false;
                            }
        				}
        			}
        		} else {
        			isAll = false;
                    for (var mainIndex = 0; mainIndex < options.length; mainIndex++) {
                        for (var subIndex = 0; subIndex < options[mainIndex].subMenu.length; subIndex++) {
                             if(!options[mainIndex].selected){
                                options[mainIndex].subMenu[subIndex].selected=false;
                            }
                        }
                    }
        		}
        		return isAll;
        	};
        	
        	var filterQueue = function(options,filterPopup,isAll,isReset){
        		for (var i = 0; i < options.length; i++) {
        			if (options[i].selected) {
        				filterPopup[options[i].value] = [];
        				for (var j = 0; j < options[i].subMenu.length; j++) {
        					if (options[i].subMenu[j].selected) {
        						filterPopup[options[i].value].push(options[i].subMenu[j].value);
        					}
        				}
        				if (!isReset && !filterPopup[options[i].value].length) {
        					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, 'Please choose a ' + options[i].label + '!');
        					return;
        				}
        			}
        		}
        		if (!isReset && !Object.keys(filterPopup).length) {
        			dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.SELECT_OPTION);
        			return;
        		}
        		filterPopup.isAll = isAll;
        		return filterPopup;
        	};
        	var initDate = function(dateRange){
        		var dateArr = dateRange.split(' / ');
				var fromDate = dateArr[0].split('-');
				var toDate = dateArr[1].split('-');
				return {
					fromDate : new Date(fromDate[2],parseInt(fromDate[1])-1,fromDate[0]),
					toDate : new Date(toDate[2],parseInt(toDate[1])-1,toDate[0])
				};
        	};
        	
        	var applyDateRange = function(contentData){
        		var fromDate = utility.formDateString(contentData.fromDate,true);
				var toDate = utility.formDateString(contentData.toDate,true);
				contentData.close();
				return {
					fromDate : fromDate,
					toDate : toDate
				};
        	};
        return {
               isAllSelected : isAllSelected,
               filterCheckAll : filterCheckAll,
               filterQueue : filterQueue,
               initDate : initDate,
               applyDateRange : applyDateRange
        };
        
     }]);
	 app.factory('repoFilterFactory',['dialogService',function(dialogService){        
		var validateMinMaxValue = function(min, max, type){
            if(isNaN(min) && isNaN(max)){
              return true;
            }else if (min > 0 && max > 0) {
                if (min >= max) {
                  dialogService.showAlert('Message', "Message", type + " minimum amount cannot be greater than maximum amount");
                  return false;
                }
            }else if(min === 0 & max === 0){
                dialogService.showAlert('Message', "Message", type + " minimum amount and maximum amount cannot be zero");
                return false;
            }
            return true;
        };
        var checkboxAlert = function(subItemValue, subItem, subItemSelected,mainMenu){          
            var arrayDPD=_.findWhere(mainMenu, {
                value: 'allocationDPD'
            }).subMenu;
            var categoryArray =_.pluck(_.where(_.findWhere(mainMenu, {
                value: 'catagory'
            }).subMenu,{selected : true}),"value");
            if(categoryArray.length){                
                _.each(arrayDPD ,function(subItem){                        
                    if(subItem.selected && categoryArray.indexOf(subItem.key) != -1) {
                        subItem.isDisabled = false;
                    }else{
                        subItem.isDisabled = !(categoryArray.indexOf(subItem.key) != -1);
                        subItem.selected = false;  
                    }                        
                });                
            }else{
                _.each(arrayDPD ,function(subItem){
                    subItem.selected = false; 
                    subItem.isDisabled = false; 
                });    
            }                                
            /*if(subItemSelected){
                _.each(arrayDPD, function (item) {
                    if(item.key === subItemValue)
                        item.isDisabled = false;                    
                }); 
            }else{
                _.each(arrayDPD, function (item) {
                    if(item.key === subItemValue){
                        item.isDisabled = true;
                        item.selected = false;                  
                    }                       
                });
            }*/           
        };        
		var setAllCheckBoxes = function(selected, arrValues){
			for (var i = 0; i < arrValues.length; i++) {
				arrValues[i].selected = selected;
			}
		};
		var setCheckBoxes = function(selected, arrValues){
			var checkSelectedAll = true;
			for (var i = 1; i < arrValues.length; i++) {
				if (!arrValues[i].selected) {
					checkSelectedAll = false;
					break;
				}
			}
			if (arrValues[0].label == "All" || arrValues[0].name == "All" || arrValues[0].subCategoryDesc == "All") {
				arrValues[0].selected = checkSelectedAll;
			}
		}; 
		var filter = function(mainMenu){
			var min = _.findWhere(mainMenu, {
					value: 'loanToValue'
			}).subMenu[0].value;
			var max = _.findWhere(mainMenu, {
				value: 'loanToValue'
			}).subMenu[1].value; 
			var validity = validateMinMaxValue(parseInt(min),parseInt(max), "Loan To Value");				
			if (validity) {
				var queryObj = {
					"allocationDPD": _.pluck(_.where(_.findWhere(mainMenu, {
						value: 'allocationDPD'
					}).subMenu, {
						selected: true
					}), 'value'),
					"vehicleCategory": _.compact(_.without(_.pluck(_.where(_.findWhere(mainMenu, {
						value: 'vehicleCategory'
					}).subMenu, {
						selected: true
					}), 'leapSubCategoryID'), "0")),
					"productCategory": _.without(_.pluck(_.where(_.findWhere(mainMenu, {
						value: 'productCategory'
					}).subMenu, {
						selected: true
					}), 'value'), "All"),
					"paymentPattern": _.without(_.pluck(_.where(_.findWhere(mainMenu, {
						value: 'paymentPattern'
					}).subMenu, {
						selected: true
					}), 'value'), "All"),
					"seasoning": _.flatten(_.without(_.pluck(_.where(_.findWhere(mainMenu, {
						value: 'seasoning'
					}).subMenu, {
						selected: true
					}), 'value'), "All")),
					"loanToValueFrom": _.findWhere(mainMenu, {
						value: 'loanToValue'
					}).subMenu[0].value,
					"loanToValueTo": _.findWhere(mainMenu, {
						value: 'loanToValue'
					}).subMenu[1].value,
					"CAUFlag": _.findWhere(mainMenu, {
						value: 'cauFlag'
					}).selected,
					"legalStock": _.findWhere(mainMenu, {
						value: 'legalStock'
					}).selected,
					"legalHold": _.findWhere(mainMenu, {
						value: 'legalHold'
					}).selected,
					"contactRecordingREPO": _.findWhere(mainMenu, {
						value: 'contactRecordingRepo'
					}).selected,
					"POSComfort": _.findWhere(mainMenu, {
                        value: 'posComfort'
                    }).selected,
					"manualAgreementsFlag": "FALSE",
					"letterTypeOthers":"",
					"getRepoFlag":"FALSE"					
				};
				return queryObj;			
			}
		};
        var filterLegalCases = function(mainMenu){
            var min = _.findWhere(mainMenu.groupOne,{
                    value: 'loanToValue'
            }).subMenu[0].value;
            var max = _.findWhere(mainMenu.groupOne, {
                value: 'loanToValue'
            }).subMenu[1].value; 
            var validity = validateMinMaxValue(parseInt(min),parseInt(max), "Loan To Value");               
            if (validity) {
                var queryObj = {
                    "allocationDPD": _.without(_.pluck(_.where(_.findWhere(mainMenu.groupOne, {
                        value: 'allocationDPD'
                    }).subMenu, {
                        selected: true
                    }), 'value'),"All"),
                    "vehicleCategory": _.compact(_.without(_.pluck(_.where(_.findWhere(mainMenu.groupOne, {
                        value: 'vehicleCategory'
                    }).subMenu, {
                        selected: true
                    }), 'leapSubCategoryID'), "0")),
                    "productCategory": _.without(_.pluck(_.where(_.findWhere(mainMenu.groupOne, {
                        value: 'productCategory'
                    }).subMenu, {
                        selected: true
                    }), 'value'), "All"),
                    "paymentPattern": _.without(_.pluck(_.where(_.findWhere(mainMenu.groupOne, {
                        value: 'paymentPattern'
                    }).subMenu, {
                        selected: true
                    }), 'value'), "All"),
                    "seasoning": _.flatten(_.without(_.pluck(_.where(_.findWhere(mainMenu.groupOne, {
                        value: 'seasoning'
                    }).subMenu, {
                        selected: true
                    }), 'value'), "All")),
                    "loanToValueFrom": _.findWhere(mainMenu.groupOne, {
                        value: 'loanToValue'
                    }).subMenu[0].value,
                    "loanToValueTo": _.findWhere(mainMenu.groupOne, {
                        value: 'loanToValue'
                    }).subMenu[1].value,                    
                    "CAUFlag": _.findWhere(mainMenu.groupTwo, {value: 'cauFlag'}).subMenu.selected ? "NA" : "TRUE",
                    "legalStock": _.findWhere(mainMenu.groupTwo, {value: 'legalStock'}).subMenu.selected ? "NA" : "TRUE",
                    "legalHold": _.findWhere(mainMenu.groupTwo, {value: 'legalHold'}).subMenu.selected ? "NA" : "TRUE",
                    // "chargesonlycases": _.findWhere(mainMenu.groupTwo, {value: 'chargesOnlyCases'}).subMenu.selected ? _.findWhere(mainMenu.groupTwo, {value: 'chargesOnlyCases'}).subMenu.selected.toString().toUpperCase() :"NA",
                    // "MaturedCases":_.findWhere(mainMenu.groupTwo, {value: 'maturedCases'}).subMenu.selected ? _.findWhere(mainMenu.groupTwo, {value: 'maturedCases'}).subMenu.selected.toString().toUpperCase(): "NA",
                    // "posComfort": _.findWhere(mainMenu.groupTwo, {value: 'posComfort'}).subMenu.selected ? _.findWhere(mainMenu.groupTwo, {value: 'posComfort'}).subMenu.selected.toString().toUpperCase() :"NA",
                    "repoApproved": _.findWhere(mainMenu.groupTwo, {value: 'repoApproved'}).subMenu.selected ? "NA" : "TRUE",
                    // "writeOffCases":_.findWhere(mainMenu.groupTwo, {value: 'writeoffCases'}).subMenu.selected ? _.findWhere(mainMenu.groupTwo, {value: 'writeoffCases'}).subMenu.selected.toString().toUpperCase() :"NA",
                    // "legalAlreadyInitiated" :_.findWhere(mainMenu.groupTwo, {value: 'legalAlreadyInitiated'}).subMenu.selected ? "NA" : "TRUE",
                    "manualAgreementsFlag": "FALSE",
                    "getRepoFlag":"FALSE",
                    "getLegalFlag":"TRUE"                  
                };
                return queryObj;            
            }
        };			
        return {			
			validateMinMaxValue : validateMinMaxValue,
			checkboxAlert : checkboxAlert,
			setAllCheckBoxes : setAllCheckBoxes,
			setCheckBoxes : setCheckBoxes,
			filter : filter,
            filterLegalCases : filterLegalCases               
        };
    }]);
    app.factory('repoMasterService',['$q','$rootScope','restProxy','masterService',function($q,$rootScope,restProxy,masterService){
        var serviceObj = this;
        this.locations = {
            branchDetails : {}
        };
        var globalMasterData = '';
		var getGlobalMasterData = function(){
            var defered = $q.defer();
            defered.resolve(globalMasterData);   
			return defered.promise;
		};
		var setGlobalMasterData = function(){
             globalMasterData = '';
		};
		var setDropDownValues = function(){
			return {
				branchDetails: {
					zones : [],
					filteredRegions : [],
					filteredAreas : [],
					filteredBranch : []	
				}
			};
		};
		var changeHandler = function(type, ID, getZones, _branchDetails){
			var result = {
                zones : getZones.locations.branchDetails.zones || [],
                filteredRegions : getZones.locations.branchDetails.regions || [],
                filteredAreas : getZones.locations.branchDetails.areas || [],
                filteredBranch : getZones.locations.branchDetails.branches || []
            };
			if (type === 'zoneID') {        
				result.zoneID = ID;
				result.regionID = "";
				result.areaID = "";
				result.branchID = "";
				result.filteredRegions = [];
				result.filteredAreas = [];
				result.filteredBranch = [];			
				if(ID){
                    if(_branchDetails){
                        result.zones = _branchDetails.zones;
                    }
                    result.filteredRegions = _.where(getZones.locations.branchDetails.regions,{"ZoneID":ID});
				}
			}
			if (type === 'regionID') {
                result.regionID = ID;
			    result.areaID = "";
				result.branchID = "";
				result.filteredAreas = [];
				result.filteredBranch = [];				
				if(ID){
                    if(_branchDetails){
                        result.filteredRegions = _branchDetails.filteredRegions;
                        result.zoneID = _branchDetails.zoneID;
                        result.zones = _branchDetails.zones;
                    }else{
                        var zID = _.findWhere(getZones.locations.branchDetails.regions,{"regionID":ID}).ZoneID;
                        result.zoneID = zID; 
                        result.filteredRegions = _.where(getZones.locations.branchDetails.regions,{"ZoneID":zID});
                    }
					result.filteredAreas = _.where(getZones.locations.branchDetails.areas,{"regionID":ID});
				}
			}
			if (type === 'areaID') {
                result.areaID = ID;	
				result.branchID = "";
				result.filteredBranch = [];
				if(ID){
                    if(_branchDetails){
                        result.filteredAreas = _branchDetails.filteredAreas;
                        result.filteredRegions = _branchDetails.filteredRegions;
                        result.regionID = _branchDetails.regionID;
                        result.zoneID = _branchDetails.zoneID;
                    }else{
                        var rID = _.findWhere(getZones.locations.branchDetails.areas,{"areaID":ID}).regionID;
                        var zID = _.findWhere(getZones.locations.branchDetails.regions,{"regionID":rID}).ZoneID;
						result.regionID = rID;
                        result.zoneID = zID;
                        result.filteredRegions = _.where(getZones.locations.branchDetails.regions,{"ZoneID":zID});
    					result.filteredAreas = _.where(getZones.locations.branchDetails.areas,{"regionID":rID});
                    }
                    result.filteredBranch = _.where(getZones.locations.branchDetails.branches,{"areaID":ID});
				}
			}
			if(type === 'branchID' && ID){
                result.branchID  = ID;
                if(_branchDetails){
                    result.filteredBranch = _branchDetails.filteredBranch;
                    result.areaID = _branchDetails.areaID;
                    result.regionID = _branchDetails.regionID;
                    result.zoneID = _branchDetails.zoneID;
                    result.filteredAreas = _.where(result.filteredAreas, {regionID : result.regionID});
                    result.filteredRegions = _.where(result.filteredRegions,{"ZoneID":result.zoneID});
                }else{
                    var aID = _.findWhere(getZones.locations.branchDetails.branches,{"branchID": ID}).areaID; 
                    result.areaID = aID;
                }
			}
			return result;
		};
		var setDefaultValues = function(hierarchyName,getZones){
			if(hierarchyName==='ZRM' || hierarchyName==='ZCM_COL' || hierarchyName==='ZBM_COL' || hierarchyName==='ZLM' || hierarchyName==='JR_MGR_LEGAL'|| hierarchyName==='SM_LEGAL'|| hierarchyName==='AVP_LEGAL'){
                return changeHandler('zoneID',JSON.parse(getCookie('selectedBranch')).ZoneID,getZones);				
			}else if(hierarchyName==='RRM' || hierarchyName==='RCM_COL' || hierarchyName==='RBM_COL'|| hierarchyName==='RLM'){				
                return changeHandler('regionID',JSON.parse(getCookie('selectedBranch')).regionID,getZones);
			}else if(hierarchyName==='ARM' || hierarchyName==='ACM_COL' || hierarchyName==='ABM_COL' ||  hierarchyName==='ALM'){				
                return changeHandler('areaID',JSON.parse(getCookie('selectedBranch')).areaID,getZones);				
			}else if(hierarchyName==='BRM'|| hierarchyName==='BCM_COL' || hierarchyName==='BBM_COL' || hierarchyName==='TELLER'){
				return changeHandler('branchID',JSON.parse(getCookie('selectedBranch')).branchID,getZones);			
			}else if(hierarchyName==='NRM'){
                return changeHandler('zoneID','PAN INDIA',getZones);
			}			
		};		
        var getMasterData = function(panIndiaCheck){
            var defered = $q.defer();                                
			masterService.getAreas(panIndiaCheck ? {} :{
				ZoneID : $rootScope.identity.zoneIDs.toString()
			}, 'zone').then(function(userZones) {                
				serviceObj.locations.branchDetails.zones = userZones;                   
				masterService.getAreas(panIndiaCheck ? {} :{
					regionID : $rootScope.identity.regionIDs.toString()
				}, 'region').then(function(userRegions) {                
					serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;                  
					masterService.getAreas(panIndiaCheck ? {} :{
						areaID : $rootScope.identity.areaIDs.toString()
					}, 'area').then(function(userAreas) {                
						serviceObj.locations.branchDetails.filteredAreas = serviceObj.locations.branchDetails.areas = userAreas;                    
						masterService.getBranches(panIndiaCheck ? {} :{
							branchID : $rootScope.identity.branchIDs.toString()
						}).then(function(userBranches) {                
							serviceObj.locations.branchDetails.filteredBranch = serviceObj.locations.branchDetails.branches = userBranches;            
							globalMasterData = serviceObj;
							defered.resolve(serviceObj); 
						});
					});
				});
			});                     
            return defered.promise;
        };
         var validateMobileNo = function(val) {
            val = typeof val === 'string' ? val : val.toString();
            if (val.length === 10) {
                if (collectionConstants.REGULAR_EXPRESSION.MOBILE_NO.test(val) && constants.REGULAR_EXPRESSION.mobileNoRepeat.test(val)) {
                    return utility.getSuccessResult();
                } else {
                    return utility.getFailureResult("Invalid Mobile Number");
                }
            } else if (val.length === 11) {
                if (val.indexOf('0') === 0) {
                    if (collectionConstants.REGULAR_EXPRESSION.MOBILE_NO.test(val.substring(1, val.length)) && constants.REGULAR_EXPRESSION.mobileNoRepeat.test(val)) {
                        return utility.getSuccessResult();
                    } else {
                        return utility.getFailureResult("Invalid Mobile Number");
                    }
                } else {
                    return utility.getFailureResult("Invalid Mobile Number");
                }
            } else {
                return utility.getFailureResult("Invalid Mobile Number");
            }
        };
        var setDefaultGeoValues = function(_role, data){
            switch (_role.toUpperCase()) {
                case 'TELLER':
                case 'BRM':
                case 'BBM_COL':
                case 'BCM_COL':
                    data.branchDetails.areaID = data.branchDetails.filteredAreas[0].areaID;
                    break;
                case 'ARM':
                case 'ABM_COL':
                case 'ACM_COL':
                    data.branchDetails.regionID = data.branchDetails.filteredRegions[0].regionID;
                    break;
                case 'RRM':
                case 'RBM_COL':
                case 'RCM_COL':
                    data.branchDetails.zoneID = data.branchDetails.filteredRegions[0].ZoneID;
                    break;
            }
            return data;
        };
        return {            
            getMasterData : getMasterData,
			getGlobalMasterData : getGlobalMasterData,
			setGlobalMasterData : setGlobalMasterData,
			setDropDownValues : setDropDownValues,
			changeHandler : changeHandler,
			setDefaultValues : setDefaultValues,
            validateMobileNo : validateMobileNo,
            setDefaultGeoValues : setDefaultGeoValues       
        };
    }]);
	app.factory('addressLocationFactory',['$q','$rootScope','restProxy','masterService','dialogService',function($q,$rootScope,restProxy,masterService,dialogService){       
		var data = {
			addressObj : {},
			cityObject : {},
			stateObject : {},
			zipObject : {}
		};
        var getCityList = function(cityName,address){
           	var _stateID;
			_stateID = (data.stateObject && data.stateObject.stateID && address.cityDesc) ? data.stateObject.stateID : '';
			var urlString = 'commonapi/mastersapi/masters/City?cityName='+cityName+'&limit=10&stateID='+_stateID;            
            return restProxy.getnode(urlString, undefined).then(function(response) {
                return response.data;
            });
        };
		var getStateList = function(stateName){
			var _cityID;															
			var urlString = 'commonapi/mastersapi/masters/State?stateDesc='+stateName+'&limit=10';            
            return restProxy.getnode(urlString, undefined).then(function(response) {
                return response.data;
            });
		};
		var getPincodeList = function(pincode,address){
			var _stateID,_cityID;			
			_stateID = (data.stateObject && data.addressObj.stateDesc && address.stateDesc) ? data.stateObject.stateID : '';
			_cityID = (data.cityObject && data.addressObj.cityDesc && address.cityDesc) ? data.cityObject.cityID : '';
			var urlString = 'commonapi/mastersapi/masters/CityZip?zipCode='+pincode+'&limit=10&stateID='+_stateID+'&cityID='+_cityID;            
            return restProxy.getnode(urlString, undefined).then(function(response) {
                return response.data;
            });
		};
		var citySelected = function(item){			
			if(item){
				var defered = $q.defer();				
				data.cityObject = item;
				data.addressObj.cityDesc = (item.cityName) ? item.cityName : '';
				data.addressObj.cityID = (item.cityID) ? item.cityID : '';
				if(!data.zipObject || !data.zipObject.cityID || data.zipObject.cityID !== item.cityID){
					data.addressObj.pincode = '';
				}
				if(!data.stateObject || data.stateObject.stateID || !data.addressObj.stateDesc || data.stateObject.stateID !== item.stateID){
					var urlString = 'commonapi/mastersapi/masters/State?stateID='+item.stateID;            
					restProxy.getnode(urlString, undefined).then(function(response) {
						data.addressObj.stateDesc = (response.data[0] && response.data[0].stateDesc) ? response.data[0].stateDesc : '';
						data.addressObj.stateID = (response.data[0] && response.data[0].stateID) ? response.data[0].stateID : '';						
						defered.resolve(data);
					});						
				}else{
					defered.resolve(data);
				}
				return defered.promise;	
			}else{
				data.cityObject = {};
			}		
		};
		var stateSelected = function(item){			
			if(item){				
				data.stateObject = item;
				data.addressObj.stateDesc = (item.stateDesc) ? item.stateDesc : '';
				data.addressObj.stateID = (item.stateID) ? item.stateID : '';				
				if(!data.cityObject || !data.cityObject.cityID || item.stateID !== data.cityObject.stateID){
					data.addressObj.cityDesc = '';
					data.addressObj.pincode = '';
				}
				return data;
			}else{
				data.stateObject = {};
			}		
		};		
		var getStateAndCity = function(item){			
			if(item){
				var defered = $q.defer(); 				
				data.zipObject = item;				
				masterService.getStateAndCity(item.zipCode).then(function(response) {
					if(response.status === "success" && response.data.City.length > 0) {
						data.cityObject = response.data.City[0];
						data.stateObject = response.data.State[0];
						data.addressObj.stateDesc = (response.data.State[0]) ? response.data.State[0].stateDesc : '';
						data.addressObj.stateID = (response.data.State[0]) ? response.data.State[0].stateID : '';
						data.addressObj.cityDesc = (response.data.City[0]) ? response.data.City[0].cityName : '';
						data.addressObj.cityID = (response.data.City[0]) ? response.data.City[0].cityID : '';
						data.addressObj.pincode = data.zipObject.zipCode;
						defered.resolve(data); 													
					}else{
						dialogService.showAlert('info', "No Mapping found", collectionConstants.ERROR_MSG.PINCODE_NO_MAPPING);
						data.addressObj.stateDesc = data.addressObj.stateID = '';
						data.addressObj.cityDesc = data.addressObj.cityID = '';
						defered.resolve(data); 
					}					
				});
				return defered.promise;				
			}				
		};		
        return {            
            getCityList : getCityList,
			getStateList : getStateList,
			getPincodeList : getPincodeList,
			citySelected : citySelected,
			stateSelected: stateSelected,
			getStateAndCity : getStateAndCity				  
        };
    }]);
    app.factory('masterLegalConstants',['restProxy','$q',function(restProxy,$q){
       var mapSections = function(sections, legalConstants, sectionsObjString, caseMappingObjString) {
            legalConstants.LEGAL_VALUES[sectionsObjString] = _.map(sections, function(item, k) {
                var obj = {};
                obj.label = item.replace(/_/g, " ");
                obj.value = item;
                if(_.contains(legalConstants.BULK_SECTIONS,item)){
                  obj.bulk = true;
                }else{
                  obj.bulk = false;
                }
                return obj;
            });
            legalConstants.LEGAL_VALUES[sectionsObjString] = _.sortBy(legalConstants.LEGAL_VALUES[sectionsObjString] , 'label');
            legalConstants[caseMappingObjString] = _.map(sections, function(item, k) {
                var obj = {};
                obj.caseDesc = item;
                obj.caseValue = item;
                return obj;
            });
        };
        var update = function(legalConstants) {
            var updatedConstants = angular.copy(legalConstants);
            var defered = $q.defer();
            var config = {
                EDS : "mastersapi/masters/LegalStage?sort='legalStageID'",
                isEPS : false,
                queryParams : {
                    sort : ''
                },
            };
            return restProxy.get(config).then(function(data) {
                if (data.status === "success") {
                    // Update legal cases and sections from the masters will
                    // affect the below properties
                    // LEGAL_CASE_MAPPING, LEGAL_CASE_MAPPING_HEHL, SECTIONS, SECTIONS_HEHL , LEGAL_VALUES
                    legalConstants.LEGAL_VALUES = _.omit(legalConstants.LEGAL_VALUES, function(item, key) {
                        return (key.indexOf('_STAGES') > -1 && key !== 'OTHER_STAGES');
                    });
                    var VFStages = [], HEHLStages = [], VFSections, HEHLSections;
                    _.each(data.data, function(item, key) {
                        if (item.productGroup === 'VF') {
                            VFStages.push(item);
                        } else if (item.productGroup === 'HEHL') {
                            HEHLStages.push(item);
                        }
                    });
                    VFSections = _.uniq(_.pluck(VFStages, 'section'));
                    HEHLSections = _.uniq(_.pluck(HEHLStages, 'section'));
                    mapSections(VFSections, legalConstants, 'SECTIONS', 'LEGAL_CASE_MAPPING');
                    mapSections(HEHLSections, legalConstants, 'SECTIONS_HEHL', 'LEGAL_CASE_MAPPING_HEHL');
                    // Mapping Legal Cases
                    var legalStages = _.groupBy(data.data, 'section');
                    _.each(legalStages, function(stages, key) {
                        legalStages[key] = _.map(stages, function(item, key) {
                            var stageObj = {};
                            stageObj.caseStage = item.stageName;
                            stageObj.productGroup = item.productGroup;
                            stageObj.caseStageID = item.caseStageID ? item.caseStageID.toString() : '';
                            return stageObj;
                        });
                        legalConstants.LEGAL_VALUES[key] = legalStages[key];
                    });
				 return legalConstants;
                }
            });
        };
        return {
            update : update
        };
    }]);
	app.factory('waiverExpiryFactory',['restProxy','$q','$rootScope','appFactory',function(restProxy,$q,$rootScope,appFactory){
        $rootScope.isWaiverExpiry = true;
        var waiverExpData =  function(){
        var waiverActivity = appFactory.getActivityAccess(collectionConstants.COLL_MODULE_ACTIVITIES.RECEIPT.WAIVER);
           if($rootScope.isWaiverExpiry && waiverActivity){
                var waiverCheckConf = {
                    EDS: 'collectionsapi/loginWaiverCheck',
                    ENTITY: '',
                    queryParams: {},
                    isEPS: false
                };
                 return restProxy.get(waiverCheckConf).then(function(result) {
                    $rootScope.isWaiverExpiry = false;
                    // This check to be removed for shortfall prod movement
                    if(result.data.yetToExpire && result.data.yetToExpire.length){
                        result.data.yetToExpire = _.reject(result.data.yetToExpire, function(item){
                            return item.waiverType == "ShortfallWaiver";
                        });
                    }
                    return result.data;
                 });
            }else{
                return $q.when([]);
            }
        }   
        return {
            waiverExpData : waiverExpData
        };
        }]);
    return app;
});
