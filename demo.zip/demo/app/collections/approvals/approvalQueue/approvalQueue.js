define(['require','collectionsApp','approvalQueueResolver'],function(require,collectionsApp,approvalQueueResolver){
   'use strict';
	/**
	* Contains the batching routing information.
	* Create and return the batching module.
	*/	
	var baseViewUrl = 'app/collections/approvals/approvalQueue/'; 
	var app = angular.module('approvalQueue',['ui.router','collections']);
   
	var approvalQueue = {
		name : 'collections.approvalQueue',
		url : '/approvalQueue',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'approvalQueue.html',
				controller : 'approvalQueueController',
				resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)
			}
		},
		data : {'headerText':'Approvals Queue',
			'stateActivity' : ['COL_APPROVALS_QUEUE','COL_VENDOR_APPROVAL','COL_RECOMMEND_REQUEST', 'COL_APPROVE_REQUEST']
		}
	};
	
	var approvalFilterQueue = {
		name : 'collections.approvalFilterQueue',
		url : '/approvalFilterQueue/:filter/:tab',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'approvalQueue.html',
				controller : 'approvalQueueController',
				resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)
			}
		},
		data : {'headerText':'Approvals Queue',
			'stateActivity' : ['COL_APPROVALS_QUEUE'],
			'backState':'collections.repoSummary'
		}
	};
	var approvalQueueFromSummary = {
		name : 'collections.approvalQueueFromSummary',
		url : '/approvals/:filters/:tabSelected',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'approvalQueue.html',
				controller : 'approvalQueueController',
				resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)
			}
		},
		data : {
			'headerText':'Approvals Queue',
			'backState':'collections.legalSummary',
			'stateActivity' : ['COL_APPROVALS_QUEUE','COL_VENDOR_APPROVAL','COL_VENDOR_MANAGEMENT_DASHBOARD']
		}
	};
	
	var approvalRequest = {
			name : 'collections.approvalRequest',
			url : '/approvals/:reqStatus/:requestType/:agreementNo',
			views : {
				'mainContent' : {
					templateUrl : baseViewUrl+'/partials/approvalRequest.html',
					controller : 'approvalRequestController',
					resolve : angular.extend({},approvalQueueResolver.getAgreementInfo,approvalQueueResolver.getUserZones)
				}
			},
			data : {'headerText':'Approval Request',
					'backState':'collections.approvalQueue',
					'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
					}
		};
	
	var backDatedChallan = {
		name : 'collections.approveBDChallan',
		url : '/bdchallan/:reqStatus/:challanNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/backDatedChallaning.html',
				controller : 'approveBDChallanController',
				resolve : approvalQueueResolver.getChallanInfo
			}
		},
		data : {
			'headerText':'Approvals - Back dated Challaning',
			'backState':'collections.approvalQueue'
		}
	};
	var repoMarkingLMS = {
		name : 'collections.repoMarkingLMS',
		url : '/repoMarkingLMS',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/repoMarkingLMS.html',
				controller : 'approvalQueueController',
			    resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)
			}
		},
		data : {
			'headerText':'Approvals - Repo Marking in LMS',
			'backState':'collections.approvalQueue'
		}
	};
	var documentWaiver = {
		name : 'collections.documentWaiver',
		url : '/documentWaiver',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/documentWaiver.html',
				controller : 'approvalQueueController',
			    resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)
			}
		},
		data : {
			'headerText':'Approvals - Document Waiver',
			'backState':'collections.documentWaiver'
		}
	};
	
	
	var wrongRepoMarkingLMS = {
		name : 'collections.wrongRepoMarkingLMS',
		url : '/wrongRepoMarkingLMS',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/wrongRepoMarkingLMS.html',
				controller : 'approvalQueueController',
				resolve : angular.extend({},approvalQueueResolver.getPendingReqs,approvalQueueResolver.getInitiatedReqs,approvalQueueResolver.getApprovedReqs)			
			}
		},
		data : {
			'headerText':'Approvals - Wrong Repo Marking in LMS',
			'backState':'collections.approvalQueue'
		}
	};
	var approvalRequestLegal = {
		name : 'collections.approvalRequestLegal',
		url : '/approvals/:reqStatus/:requestType/:agreementNo/:caseID/:requestNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/approvalRequest.html',
				controller : 'approvalRequestController',
				resolve : angular.extend({},approvalQueueResolver.getAgreementInfo,approvalQueueResolver.getUserZones)
			}
		},
		data : {'headerText':'Approval Request',
				'backState':'collections.approvalQueue',
				'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
				}
	};
	var approvalRequestFilterLegal = {
		name : 'collections.approvalRequestFilterLegal',
		url : '/approvals/:reqStatus/:requestType/:agreementNo/:caseID',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/approveLegal.html',
				controller : 'legalRequestController',
				resolve : angular.extend({},approvalQueueResolver.getAgreementInfo,approvalQueueResolver.getUserZones)
			}
		},
		data : {'headerText':'Approval Request',
				'backState':'collections.approvalQueue',
				'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
				}
	};
	var advocateApprovalRequestLegal = {
		name : 'collections.advocateApprovalRequestLegal',
		url : '/approvals/:reqStatus/:requestType/:agreementNo/:caseID/:requestNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/advocateApprovalRequest.html',
				controller : 'advocateApprovalRequestController',
				resolve : angular.extend({},approvalQueueResolver.getAgreementInfo)
			}
		},
		data : {'headerText':'Advocate Approval Request',
				'backState':'collections.approvalQueue',
				'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
				}
	};
	var advocateApprovalRequestLegalFeeChange = {
		name : 'collections.advocateApprovalRequestLegalFeeChange',
		url : '/approvals/:reqStatus/:requestType/:agreementNo/:caseID/:requestNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/advocateFeeApprovalRequest.html',
				controller : 'advocateApprovalRequestFeeController',
				resolve : angular.extend({},approvalQueueResolver.getAgreementInfo)
			}
		},
		data : {'headerText':'Advocate Approval Request Fee Change',
				'backState':'collections.approvalQueue',
				'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
				}
	};
	var agreementBlockApprovalRequestLegal = {
		name : 'collections.agreementBlockApprovalRequestLegal',
		url : '/approvals/:reqStatus/:requestType/:agreementNo/:caseID/:requestNo',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'/partials/agreementBlockApprovalRequest.html',
				controller : 'agreementBlockApprovalRequestController',
				resolve : angular.extend({},approvalQueueResolver.getAgreementInfo)
			}
		},
		data : {'headerText':'Agreement Block Approval Request',
				'backState':'collections.approvalQueue',
				'stateActivity' : ['COL_APPROVE_REQUEST','COL_RECOMMEND_REQUEST','COL_APPROVALS_QUEUE']
				}
	};
	/**
	* Contains the batching configuration details.
	*/
	var approvalQueueConfiguration = function($stateProvider,$urlRouterProvider){
		$stateProvider.state(approvalQueue).state(approvalFilterQueue).state(approvalQueueFromSummary).state(approvalRequest).state(backDatedChallan).state(repoMarkingLMS).state(wrongRepoMarkingLMS).state(approvalRequestLegal).state(approvalRequestFilterLegal).state(advocateApprovalRequestLegal).state(agreementBlockApprovalRequestLegal).state(advocateApprovalRequestLegalFeeChange);
	};
   
	app.config(['$stateProvider', '$urlRouterProvider', approvalQueueConfiguration]);
	return app;
});
