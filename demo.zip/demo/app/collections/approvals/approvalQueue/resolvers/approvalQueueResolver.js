/**
 * Represents a approvalQueue Resolver.
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 * 
 */
define([], function() {
	'use strict';
	 var getFilterObj = function(selectedtab,approvalQueueService,$globalScope,stateParams){
		 var filterObj =  {
			offset:1,
			limit:5
		 };
		 filterObj.todate = new Date();
		 filterObj.fromdate  = new Date(new Date(filterObj.todate).setDate(new Date(filterObj.todate).getDate()-6));
		 if(!$globalScope.isClickedViaMenu){
			 if(approvalQueueService.clickedTab === selectedtab){
				filterObj.offset = approvalQueueService.pageFields.offset;
			 }
			 if($globalScope.isClickedDashboard){
				 filterObj.history = false;
				 approvalQueueService.pageFields = null;
			 }
			 if(approvalQueueService.pageFields && approvalQueueService.pageFields.currentPage){
				 filterObj.agreementNo = approvalQueueService.pageFields.agreementNo;
				 filterObj.fromdate = approvalQueueService.pageFields.agreementNo ? '' :(approvalQueueService.pageFields.filterparam.length !== 0 ? "" :(approvalQueueService.pageFields.startDate ? new Date(approvalQueueService.pageFields.startDate) : filterObj.fromdate));
				 filterObj.todate = approvalQueueService.pageFields.agreementNo ? '' :(approvalQueueService.pageFields.filterparam.length !== 0 ? "" : (approvalQueueService.pageFields.endDate ? new Date(approvalQueueService.pageFields.endDate) : filterObj.todate));
				 filterObj.filters = approvalQueueService.pageFields.filterparam.toString();
				 filterObj.history = approvalQueueService.pageFields.history ? '' : false; 
			 }

			 if(stateParams.filter && stateParams.tab){
			 	filterObj.filters = stateParams.filter;
			 	filterObj.fromdate = new Date($globalScope.dateObj.fromDate);
			 	filterObj.todate = new Date($globalScope.dateObj.toDate);
			 }
		 }
		 if(stateParams.filters){
			 filterObj.filters = stateParams.filters;
		 }
		 return filterObj;
	 };	 
 	 var pendingRequests = {
		pendingReqsResolver:['approvalQueueService','appFactory','$globalScope','$stateParams', function(approvalQueueService,appFactory,$globalScope,$stateParams) {
			if(!appFactory.getActivityAccess(['COL_APPROVE_REQUEST'])){
				return {
					data : [],
					meta : {}
				};
			}
			else{
				var filterObj = getFilterObj('PENDING',approvalQueueService,$globalScope,$stateParams);
				return approvalQueueService.getQueueDetails(filterObj,'PENDING').then(function(data){
					return data;
				});
			}
		}]
	};
	var initiatedRequests = {
		initiatedReqsResolver:['approvalQueueService','$globalScope','$stateParams', function(approvalQueueService,$globalScope,$stateParams) {
			var filterObj = getFilterObj('INITIATED',approvalQueueService,$globalScope,$stateParams);
			//filterObj.history = (!$globalScope.isClickedViaMenu && $globalScope.isClickedDashboard) ? false : '';
			return approvalQueueService.getQueueDetails(filterObj,'INITIATED').then(function(data){
				return data;
			});	
		}]
	};
	var approvedRequests = {
		approvedReqsResolver:['approvalQueueService','appFactory','$globalScope','$stateParams', function(approvalQueueService,appFactory,$globalScope,$stateParams) {
			if(!appFactory.getActivityAccess(['COL_APPROVE_REQUEST'])){
				return {
					data : [],
					meta : {}
				};
			}
			else{
				var filterObj = getFilterObj('APPROVED',approvalQueueService,$globalScope,$stateParams);
				return approvalQueueService.getQueueDetails(filterObj,'APPROVED').then(function(data){
					return data;
				});
			}
		}]
	};
	var agreementDetails = {		
		getAgreementDetails:['approvalQueueService','$stateParams', function(approvalQueueService,$stateParams) {
			var selectedReq = approvalQueueService.getSelectedRequest();
			if($stateParams.agreementNo){
				if(selectedReq.receiptType === 'TA'){
					return approvalQueueService.getTAAgreementDetails(selectedReq.agreementNo).then(function(data){
						return data;
					});	
				}
				else{
					return approvalQueueService.getAgreementDetails($stateParams.agreementNo).then(function(data){
						return data;
					});	
				}
			}else if(selectedReq.receiptType === 'IMD' || (selectedReq.applicationNos && selectedReq.applicationNos[0])){
				var referenceID = selectedReq.productGroup === 'VF' ? selectedReq.payerID : selectedReq.applicationNos[0]; 
				return approvalQueueService.getLeadDetails(referenceID,selectedReq.productGroup).then(function(data){
					return data;
				});
			}
		}]
	};
	
	var getChallanDetails = {		
			getChallanDetails:['approvalQueueService','$stateParams', function(approvalQueueService,$stateParams) {
			return approvalQueueService.getChallanDetails($stateParams.challanNo).then(function(data){
				return data;
			});	
		}]
	};
	var getUserZones = {		
		getUserZones:[ 'approvalQueueService', function(approvalQueueService) {
			return approvalQueueService.getUserDataMapping().then(function(data){
				if(data && data.locations && data.locations.branchDetails && data.locations.branchDetails.zones){
					var zone =_.filter(data.locations.branchDetails.zones,  
						function(eachZone){ 
							return ([1,2,3,4].indexOf(parseInt(eachZone.ZoneID)) !== -1);
						}); 
						data.locations.branchDetails.zones = zone;
				}
				return data;
			});
		} ]
	};
	
    return {
    	getPendingReqs : pendingRequests,
    	getInitiatedReqs : initiatedRequests,
    	getApprovedReqs : approvedRequests,
    	getAgreementInfo : agreementDetails,
    	getChallanInfo : getChallanDetails,
    	getUserZones : getUserZones
    };

});