define([ 'require', 'approvalQueue', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility', 'approvalQueueConstants' ], function(r, approvalQueue, constants, DatePickerConfig, collectionConstants, utility, approvalQueueConstants) {
	'use strict';

	var approveStandByTellerController = function($scope, $rootScope, $modal, $stateParams, approvalQueueService, dialogService, lazyModuleLoader, $globalScope, messageBus) {
		$scope.requestObj = { };
		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
		$scope.isPending = $stateParams.reqStatus === 'PENDING' ? true : false;
		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
		$scope.requestObj = approvalQueueService.getSelectedRequest();
		$scope.currentuserID = $rootScope.identity.userID;
		var init = function(){
			approvalQueueService.getStandByTellerDetails($scope.requestObj).then(function(data) {
				if(data){
					$scope.requestObj.getStandByTellerDetails = data;
					//get workDoneBy userID to enable RESENDOTP option for approved cases
					$scope.requestObj.getStandByTellerDetails.isInitiatedBy = data.workflow[0].workDoneBy;
					$scope.requestObj.getStandByTellerDetails.remarksData = utility.getApprovalsRemarks(data.workflow,approvalQueueConstants.APPROVALSTATUS);			
				}
			});									
		};

		$scope.handleRequest = function(requestType) {

			if (requestType === 'REINITIATE') {		
				$globalScope.isClickedViaMenu = false;		
				lazyModuleLoader.loadState('collections.reInitiateRequest',{reqType : "standByTeller"});
			}	

			if (requestType === 'REJECTED' && !$scope.requestObj.rejectionReason) {
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {
				branchID : $scope.requestObj.branchId,
				tellerID: $scope.requestObj.tellerID,
				majorVersion : $scope.requestObj.majorVersion,
				minorVersion : $scope.requestObj.minorVersion,
				status : requestType,
				remarks : $scope.requestObj.rejectionReason,
				standByTellerID: $scope.requestObj.standByTellerID,
				uID : $scope.requestObj.uID,
				mobileNo : $scope.requestObj.getStandByTellerDetails.mobileNumber
			};		

			var approvalService = 'STANDBYTELLER';
			
			if (requestType === 'ESCALATE') {
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
			}else if(requestType === 'INITIATED'){
				approvalService = 'RESENDOTP';
				reqObj.mobileNumber =  $scope.requestObj.getStandByTellerDetails.mobileNumber;
			}else{
				reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			}

			approvalQueueService.handleRequest(reqObj, approvalService).then(function(data) {
				if (data) {
					var successString = "";
					if (requestType === 'ESCALATE') {
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					} else {
						successString = "Request is " + requestType.toLowerCase() + " successfully";
					}
					if(requestType != 'INITIATED'){
						dialogService.showAlert('Success', "Success", successString).result.then(function() {
						}, function() {
							approvalQueueService.updateInitiatedQueue(true);
						});
					}else{
						approvalQueueService.updateInitiatedQueue(true);
					}
				} else {
					approvalQueueService.updateInitiatedQueue();
				}
			});
		};
		
		var escalateFn;
		$scope.getNextlevelMgrs = function() {
			var queryParams = {
				requestID : $scope.requestObj.requestID
			};	
			approvalQueueService.getNextlevelMgrs($stateParams.requestType, $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {
				if (data) {
					if (!data.length) {
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					} else {
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
		};

		init();
	};

	approvalQueue.controller('approveStandByTellerController', [ '$scope', '$rootScope', '$modal', '$stateParams', 'approvalQueueService', 'dialogService', 'lazyModuleLoader', '$globalScope', 'messageBus', approveStandByTellerController ]);
	return approveStandByTellerController;
});