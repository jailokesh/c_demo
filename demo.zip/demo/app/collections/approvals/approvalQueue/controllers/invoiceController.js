define([ 'require', 'approvalQueue', 'collectionConstants', 'utility','approvalQueueConstants'], function(r, approvalQueue, collectionConstants, utility,approvalQueueConstants) {
	'use strict';

	var invoiceController = function($scope,  $stateParams, approvalQueueService, dialogService, lazyModuleLoader, messageBus) {
		$scope.requestObj = approvalQueueService.getSelectedRequest();
        $scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
        $scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
		$scope.data = {};
		function init() {
			approvalQueueService.getDetailService($scope.requestObj, $stateParams.agreementNo).then(function(data) {
				$scope.invoiceDetails = data;
                if($scope.invoiceDetails) {
                    var approvedStatus = _.findWhere($scope.invoiceDetails.workflow,{"workStatus":"APPROVED"});
                    $scope.invoiceDetails.initObj = _.findWhere($scope.invoiceDetails.workflow,{workStatus:'INITIATED'});
                    if($scope.invoiceDetails.workflow){
                        $scope.invoiceDetails.remarksData = utility.getApprovalsRemarks($scope.invoiceDetails.workflow,approvalQueueConstants.APPROVALSTATUS);
                    }
				}
                if($scope.requestObj.requestType === 'ADDITIONALSEIZURECHARGE'){
                	$scope.invoiceDetails.approvedAmt = $scope.invoiceDetails.total = 0;
                    $scope.data.lmsExpenses = [];$scope.data.additonalExpenses = [];
                    $scope.seizureCharge = $scope.requestObj.seizureCharge;

                    var _workflow, _sezWorkflow,
                     _status = $scope.requestObj.rowclass === 'req_rejected' ? 'REJECTED' : $scope.requestObj.rowclass === 'req_approved' ? 'APPROVED' : '';
                    if(_status){
                        _workflow = _.findWhere($scope.invoiceDetails.workflow, {workStatus : _status, requestType: $scope.requestObj.requestType});
                        if(_workflow.expenseDetails){
                            _sezWorkflow = _.findWhere($scope.invoiceDetails.workflow, {requestType : 'REPOMARKINGLMS', workStatus : 'APPROVED'});
                            $scope.invoiceDetails.expenseDetails = _.union(_workflow.expenseDetails, _sezWorkflow.expenseDetails);
                        }
                    }
                    

                	_.each($scope.invoiceDetails.expenseDetails, function(_charge){
                		_charge.desc = _.findWhere(collectionConstants.MARKING_LMS_CHARGES, {chargeID : _charge.chargeID.toString()}).chargeDescription;
                        if(_charge.isAdditionalAmount){
                            $scope.data.additonalExpenses.push(_charge);
                            $scope.invoiceDetails.total += Number(_charge.amount);
                        }else{
                            $scope.data.lmsExpenses.push(_charge);
                            $scope.invoiceDetails.approvedAmt += Number(_charge.amount); 
                        }
                	});
                }
            });
		};
		init();
		$scope.handleRequest = function(reqType) {
            var reqObj = {};
			console.log("Enter Handle request :",reqType)
			if (reqType === 'REJECTED'&& !$scope.invoiceDetails.remarks) {
				dialogService.showAlert('Alert', "Alert", "Enter the reason for additional seizure charge rejection");
				return;
			}
            var reqObj = {
                majorVersion : $scope.requestObj.majorVersion,
                minorVersion : $scope.requestObj.minorVersion,
                actionID : $scope.requestObj.approvalDetails.actionID,
                branchID : $scope.requestObj.branchId,
                status : reqType,
                remarks : $scope.invoiceDetails.remarks
            };
            if($scope.requestObj.requestType === 'ADDITIONALSEIZURECHARGE'){
                reqObj.agreementNo = $scope.invoiceDetails.agreementNo;
                reqObj.expenseDetails = $scope.data.additonalExpenses;
            }else if($scope.requestObj.requestType === 'INVOICEGENERATION'){
                reqObj.invoiceNo = $scope.invoiceDetails.invoiceNo;
                reqObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
                reqObj.details = $scope.invoiceDetails.details;
            }
            if(reqType === 'ESCALATE'){
                reqObj.levelChange = true;
                reqObj.actionID = $scope.requestObj.selectedManager;
                reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
            }
            approvalQueueService.handleReceiptRequest($scope.requestObj.requestType,reqObj).then(function(data){
                if(data){
                    var successString = "";
                    if(reqType === 'ESCALATE'){
                        successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
                    }
                    else{
                        successString = "Request is "+reqType.toLowerCase()+" successfully";
                    }
                    dialogService.showAlert('Success', "Success", successString).result.then(function(){},
                        function(){
                            approvalQueueService.updateInitiatedQueue(true);
                        });
                }
                else{
                    approvalQueueService.updateInitiatedQueue();
                }
            });
        };

		var escalateFn;
		$scope.getNextlevelMgrs = function() {
			var queryParams = {};
			queryParams.requestID = $scope.requestObj.requestID;
            queryParams.agreementNo = $scope.invoiceDetails.agreementNo;
			approvalQueueService.getNextlevelMgrs($stateParams.requestType, $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {
				if (data) {
					if (!data.length) {
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					} else {
						approvalQueueService.openUserPopup(data);
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
		};

        $scope.showExpenseDetails = function(){
            approvalQueueService.showExpenseDetails($scope.data.lmsExpenses);
        };

        $scope.reInitiate = function(){
            if($scope.requestObj.requestType === 'ADDITIONALSEIZURECHARGE'){
                lazyModuleLoader.loadState('collections.addSeizureCharges',{agreementNo : $scope.invoiceDetails.agreementNo});
            }
        };


	};
	approvalQueue.controller('invoiceController', [ '$scope', '$stateParams', 'approvalQueueService', 'dialogService', 'lazyModuleLoader', 'messageBus', invoiceController ]);
	return invoiceController;
});