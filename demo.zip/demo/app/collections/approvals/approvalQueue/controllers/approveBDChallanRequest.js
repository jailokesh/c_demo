define([ 'require', 'approvalQueue', 'constants', 'collectionConstants','approvalQueueConstants','utility' ], function(r, approvalQueue, constants, collectionConstants,approvalQueueConstants,utility) {
	'use strict';

	var approveBDChallanController = function($scope, lazyModuleLoader, dialogService, approvalQueueService, $stateParams, getChallanDetails, $modal, $globalScope, messageBus, $rootScope) {
		try {
			$scope.data = {};
			$scope.data.requestDetails = approvalQueueService.getSelectedRequest();
			$scope.data.batchDetails = getChallanDetails.batchDetails;
			$scope.data.receiptDetails = getChallanDetails.receiptDetails;
			$scope.data.readOnlyMode = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
			$scope.data.isInitiated = ($stateParams.reqStatus.toUpperCase() === 'INITIATED');
			$scope.data.workFlow = getChallanDetails.workflow;
			$scope.data.bdcDays = getChallanDetails.bdcDays;
			if($scope.data.workFlow){
				$scope.data.remarksData = utility.getApprovalsRemarks($scope.data.workFlow,approvalQueueConstants.APPROVALSTATUS);
			}	
			$scope.data.initObj = _.findWhere($scope.data.workFlow, {
				workStatus : 'INITIATED',
				requestType : 'BACKDATEDCHALLANING'
			});
			if($scope.data.initObj && ($scope.data.initObj.workDoneBy === $rootScope.identity.userID || $scope.data.initObj.workDoneBy === approvalQueueService.pageFields.tellerID)){
                $scope.data.reInitiatFlag = true;
            }
			if ($scope.data.requestDetails.approvalDetails && $scope.data.requestDetails.approvalDetails.currentStatus) {
				$scope.data.rejectionObj = _.findWhere($scope.data.workFlow, {
					workStatus : $scope.data.requestDetails.approvalDetails.currentStatus,
					requestType : 'BACKDATEDCHALLANING'
				});
			}
			$scope.handleRequest = function(status) {
				if (status === 'REJECTED' && !$scope.data.remarks) {
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;
				}
				var postObject = {
					"challanNo" : $scope.data.requestDetails.challanNo,
					"remarks" : $scope.data.remarks,
					"status" : status,
					"majorVersion" : getChallanDetails.majorVersion,
					"minorVersion" : getChallanDetails.minorVersion,
					"branchID" : $scope.data.requestDetails.branchId,
					"actionID" : $scope.data.requestDetails.approvalDetails.actionID,
					"bdcdays" : $scope.data.bdcDays
				};
				if(status === 'ESCALATE'){
					postObject.actionID = $scope.data.selectedManager;
					postObject.levelChange = true;
					postObject.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.data.requestDetails.approvalDetails.nextLevelAction];
					postObject.remarks = $scope.data.initObj ? $scope.data.initObj.comments : '';
				}
				if( $scope.data.reInitiatFlag){
                    if (status === 'REINITIATED' && !$scope.data.reInitiateRemarks) {
	                    dialogService.showAlert('Error', "Warning", "Enter the reason for Reinitiate");
	                    return;
                    }else{
                    	postObject.remarks = $scope.data.reInitiateRemarks;
                    	postObject.status = "INITIATED";
                    }
                }
				approvalQueueService.proccedRequest(postObject).then(function(data) {
					if (data) {
						var successString = "";
						if(status === 'ESCALATE'){
							successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
						}
						else{
							successString = "Request is " + status.toLowerCase() + " successfully";
						}
						dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
							approvalQueueService.updateInitiatedQueue(true);
						});
					}
					else{
						approvalQueueService.updateInitiatedQueue();
					}
				});
			};

			$scope.showReceipts = function(batchID, value) {
				approvalQueueService.viewReceipts(batchID, value.modeOfPayment, value.productType).then(function(data) {
					if (data && data.length > 0) {
						$modal.open({
							templateUrl : 'app/collections/challan/challaning/partials/viewChallaning.html',
							controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
								value.batchID = batchID;
								$scope.viewChallanModel = data.data;
								$scope.viewSelData = data.selectedValue;
								$scope.viewSelData.mode = data.selectedValue.modeOfPayment;
								$scope.noRecords = $scope.viewChallanModel && $scope.viewChallanModel.length ? false : true;
								$scope.close = function() {
									$modalInstance.dismiss();
								};
							} ],
							size : 'lg',
							backdrop : 'static',
							windowClass : 'modal-custom',
							resolve : {
								data : function() {
									return {
										data : data,
										selectedValue : value
									};
								}
							}
						});
					}
				});
			};
			
			$scope.getNextlevelMgrs = function(){
				approvalQueueService.getNextlevelMgrs('BACKDATEDCHALLANING',$scope.data.requestDetails.approvalDetails.actionID,'',{'bdcdays':$scope.data.bdcDays}).then(function(data){
					if(data){
						if(!data.length){
							dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
						}
						else{
							approvalQueueService.openUserPopup(data);
							messageBus.onMsg("UPDATE_MANAGER",function(event,data){
				 				$scope.data.selectedManager = data;
				 				$scope.handleRequest('ESCALATE');
				 			},$scope);
						}
					}
				});
	 		};

		} catch (error) {
			return;
		}
	};

	approvalQueue.controller('approveBDChallanController', [ '$scope', 'lazyModuleLoader', 'dialogService', 'approvalQueueService', '$stateParams', 'getChallanDetails', '$modal', '$globalScope','messageBus', '$rootScope', approveBDChallanController ]);
	return approveBDChallanController;
});
