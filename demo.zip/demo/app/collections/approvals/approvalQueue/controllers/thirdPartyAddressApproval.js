define(['require','approvalQueue','constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var thirdPartyAddressController = function($scope,lazyModuleLoader,dialogService,approvalQueueService,messageBus,$modal,$stateParams,$globalScope,masterService){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
    	var getAddressDetails = function() {
			approvalQueueService.getAddressDetails($scope.requestObj.thirdPartyID,$scope.requestObj.requestID).then(function(data){
				if(data && data.length){
					$scope.requestInfo = data[0];
					if($scope.requestInfo.newAddress && $scope.requestInfo.newAddress.workflow){
						$scope.requestInfo.remarksData = utility.getApprovalsRemarks($scope.requestInfo.newAddress.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.requestInfo.rejectedObj = _.findWhere($scope.requestInfo.newAddress.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
					if($scope.requestInfo.newAddress && $scope.requestInfo.newAddress.pincode){
						return masterService.getStateAndCity($scope.requestInfo.newAddress.pincode).then(function(data) {
							$scope.requestInfo.newAddress.city = (data.data.City[0]) ? data.data.City[0].cityID : '';
							$scope.requestInfo.newAddress.state = (data.data.State[0]) ? data.data.State[0].stateID : '';
							$scope.requestInfo.newAddress.cityDesc = (data.data.City[0]) ? data.data.City[0].cityName : '';
							$scope.requestInfo.newAddress.stateDesc = (data.data.State[0]) ? data.data.State[0].stateDesc : '';
						});
					}
					
				}
				else{
					$scope.requestInfo = {};
				}
			});	
    	};

 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 			getAddressDetails();
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.requestInfo.rejectionReason){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};
			reqObj.requestID = $scope.requestObj.requestID;
			reqObj.thirdPartyID = $scope.requestObj.thirdPartyID;
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.requestObj.majorVersion;
			reqObj.minorVersion = $scope.requestObj.minorVersion;
			reqObj.rejectionReason = $scope.requestInfo.rejectionReason;
			reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			reqObj.branchID = $scope.requestObj.branchId;
			delete $scope.requestInfo.newAddress.workflow;
			delete $scope.requestInfo.newAddress.stateDesc;
			delete $scope.requestInfo.newAddress.cityDesc;
			reqObj.thirdPartyAddresses = [$scope.requestInfo.newAddress];
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
			}
			approvalQueueService.handleRequest(reqObj,'THIRDPARTY').then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};
 	
 	approvalQueue.controller('thirdPartyAddressController',['$scope','lazyModuleLoader','dialogService','approvalQueueService','messageBus','$modal','$stateParams','$globalScope','masterService',thirdPartyAddressController]);
	return thirdPartyAddressController;
});
