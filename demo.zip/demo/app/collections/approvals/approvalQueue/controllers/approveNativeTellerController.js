define([ 'require', 'approvalQueue', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility', 'approvalQueueConstants' ], function(r, approvalQueue, constants, DatePickerConfig, collectionConstants, utility, approvalQueueConstants) {
	'use strict';

	var approveNativeTellerController = function($scope, $rootScope, $modal, $stateParams, approvalQueueService, dialogService, lazyModuleLoader, $globalScope, messageBus) {
		$scope.requestObj = { };
		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
		$scope.isPending = $stateParams.reqStatus === 'PENDING' ? true : false;
		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
		$scope.requestObj = approvalQueueService.getSelectedRequest();

		var init = function(){
			approvalQueueService.getNativeTellerDetails($scope.requestObj).then(function(data) {
				if(data){
					$scope.requestObj.getNativeTellerDetails = data;
					$scope.requestObj.getNativeTellerDetails.remarksData = utility.getApprovalsRemarks(data.workflow,approvalQueueConstants.APPROVALSTATUS);			
				}
			});									
		}

		$scope.handleRequest = function(reqType) {
			if (reqType === 'REJECTED' && !$scope.requestObj.rejectionReason) {
				dialogService.showAlert('Alert', "Alert", "Enter the reason for rejection");
				return;
			}
			var reqObj = {
				status : reqType,
				branchID : $scope.requestObj.branchId,
				majorVersion : $scope.requestObj.majorVersion,
				minorVersion : $scope.requestObj.minorVersion,
				remarks : $scope.requestObj.rejectionReason,
				tellerID: $scope.requestObj.tellerID,
				standByTellerID: $scope.requestObj.standByTellerID,
				uID : $scope.requestObj.uID
			};
			var approvalService = 'NATIVETELLER';
			if (reqType === 'ESCALATE') {
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
			}else{
				reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
				reqObj.levelChange = false;
			}
			approvalQueueService.handleRequest(reqObj, approvalService).then(function(data) {
				if (data) {
					var successString = "";
					if (reqType === 'ESCALATE') {
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					} else {
						successString = "Request is " + reqType.toLowerCase() + " successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function() {
					}, function() {
						approvalQueueService.updateInitiatedQueue(true);
					});
				} else {
					approvalQueueService.updateInitiatedQueue();
				}
			});
		};
		
		var escalateFn;
		$scope.getNextlevelMgrs = function() {
			var queryParams = {
				requestID : $scope.requestObj.requestID
			};
			approvalQueueService.getNextlevelMgrs('nativeteller', $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {	
			//approvalQueueService.getNextlevelMgrs($stateParams.requestType, $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {
				if (data) {
					if (!data.length) {
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					} else {
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
		};

		init();
	};

	approvalQueue.controller('approveNativeTellerController', [ '$scope', '$rootScope', '$modal', '$stateParams', 'approvalQueueService', 'dialogService', 'lazyModuleLoader', '$globalScope', 'messageBus', approveNativeTellerController ]);
	return approveNativeTellerController;
});