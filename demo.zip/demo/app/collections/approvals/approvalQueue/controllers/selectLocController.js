define([ 'require','approvalQueue','utility', 'collectionConstants', 'constants', 'legalConstants' ], function(r,approvalQueue, utility, collectionConstants, constants, legalConstants) {
	'use strict';
	var selectLocController = function($scope,$modalInstance,repoMasterService,data) {
		$scope.content={
			modalHeader :data.header
		};
		$scope.data = {
			isDispLoc : data.isDispLoc ? data.isDispLoc : false,
			isDispLocation:false
		};
		
		$scope.dropDownValues = angular.copy(repoMasterService.setDropDownValues());		
		$scope.dropDownValues.branchDetails = angular.copy(data.zones.locations.branchDetails);

		if(data.isDispLoc && data.zoneID){
			$scope.dropDownValues.branchDetails.zones = angular.copy(_.where(data.zones.locations.branchDetails.zones,{ZoneID :data.zoneID}));
		}else{
			$scope.dropDownValues.branchDetails.zones = angular.copy(data.zones.locations.branchDetails.zones);
		}


		if($scope.content.modalHeader=='Select Document Dispatch Location'){
			$scope.dropDownValues.branchDetails.branchID = 'DOCNOTREQ';
		}
		$scope.changeHandler = function(type,ID,sKeyID,tKeyID,fKey){
			if(ID){
				$scope.dropDownValues.branchDetails = repoMasterService.changeHandler(type, ID,data.zones);
			}else{
				$scope.dropDownValues.branchDetails[sKeyID]='';$scope.dropDownValues.branchDetails[tKeyID]='';$scope.dropDownValues.branchDetails[fKey]='';
			}
		};
		$scope.selectBranch = function(isDispLocation){
			var branchObj = {};
			/*if(!isDispLocation){
				branchObj = {branchID: "DOCNOTREQ",branchDesc:"DOCNOTREQ"};
			}
			if($scope.dropDownValues.branchDetails.branchID && $scope.dropDownValues.branchDetails.branchID!='DOCNOTREQ'){
				branchObj={"branchID":$scope.dropDownValues.branchDetails.branchID};
				branchObj.branchDesc = _.findWhere($scope.dropDownValues.branchDetails.filteredBranch, {'branchID':$scope.dropDownValues.branchDetails.branchID}).branchDesc;	
			}*/
			if($scope.dropDownValues.branchDetails.branchID){
				var branchObj={"branchID":$scope.dropDownValues.branchDetails.branchID,'zoneID':$scope.dropDownValues.branchDetails.zoneID};
				branchObj.branchDesc = _.findWhere($scope.dropDownValues.branchDetails.filteredBranch, {'branchID':$scope.dropDownValues.branchDetails.branchID}).branchDesc;					
			}
			$modalInstance.dismiss(branchObj);
		};
		$scope.setBranch = function(isDispLocation){
			$scope.data.isDispLocation = isDispLocation;
		};
		$scope.close = function(){
			$modalInstance.dismiss();
		};
	};
    approvalQueue.controller('selectLocController', [ '$scope','$modalInstance', 'repoMasterService','data',selectLocController ]);
	return selectLocController;
});