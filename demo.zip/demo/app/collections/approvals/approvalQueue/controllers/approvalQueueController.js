define(['require','approvalQueue', 'approvalQueueConstants','DatePickerConfig','collectionConstants'], function(r,approvalQueue,approvalConstants,DatePickerConfig,collectionConstants) {
'use strict';

 	var approvalQueueController = function($scope,$state,$rootScope,$globalScope,$modal,approvalQueueService,pendingReqsResolver,initiatedReqsResolver,approvedReqsResolver,lazyModuleLoader,dialogService,appFactory){
 		var selectedTab = 'PENDING';
 		var initiateMenus = [],placeHolderData = angular.copy(collectionConstants.PLACEHOLDER_TEXT);
 		$scope.maxRecordPerPage = approvalConstants.PAGINATION_CONFIG.FIVE_RECORD_PER_PAGE;
		$scope.maxSize = approvalConstants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
		var isHistory = (!$globalScope.isClickedViaMenu && $globalScope.isClickedDashboard) ? false : true;
		$scope.canApprove = appFactory.getActivityAccess(['COL_APPROVE_REQUEST']);
		approvalQueueService.clickedTab = !$scope.canApprove ? 'INITIATED' : $globalScope.isClickedViaMenu ? 'PENDING' : approvalQueueService.clickedTab;
		var filterList = approvalConstants.FILTER,isAll = false;
		$scope.data = {};
		$scope.data.initiateMenus = [];
		$scope.data.hidePanels = !($state.params.filters || !isHistory); // to hide the search panels.
		$scope.todate = new Date();
		$scope.fromdate  = new Date(new Date($scope.todate).setDate(new Date($scope.todate).getDate()-collectionConstants.APPROVAL_LAND_DATE_DIFF));
		$scope.data.isFlag = false;
		$scope.agreementNoinput = true;
		var getDateDifference = function(a, b) {
			var one_day = 1000 * 60 * 60 * 24;
			var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
			var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

			return Math.floor((utc2 - utc1) / one_day);
		};
		$scope.data.searchTypes = _.sortBy(collectionConstants.APPROVAL_QUEUE_SEARCH_OPTIONS,'name');
		$scope.activity = {};
		if($rootScope.identity.standByTeller){
			$scope.activity.standByTellerID = "";
			$scope.activity.standByTeller = $rootScope.identity.standByTeller.status;
			$scope.activity.userTypes = ($rootScope.identity.standByTeller.tellerID) ? [{ text: $rootScope.identity.standByTeller.tellerID + "-TELLER", value: $rootScope.identity.standByTeller.tellerID }] :  [{ text: $rootScope.identity.standByTeller.standByTellerID + "-STANDBYTELLER", value: $rootScope.identity.standByTeller.standByTellerID }];
		}

		$scope.setPlaceHolderContent = function(searchBy){
			$scope.data.searchValue = '';
			if(searchBy){
				$scope.data.inputValidation = _.findWhere(placeHolderData,{type:searchBy.value});
				if(searchBy.value == 'vishesh'){
					$scope.data.inputValidation.value = 'Enter Vishesh Agreement No';
				}else if(searchBy.value == 'trip'){
					$scope.data.inputValidation.value = 'Enter Trip Agreement No';
				}
			}else{
				$scope.data.inputValidation = {value : ''};
			}
		};

		$scope.startDate = new DatePickerConfig({
			value : $scope.fromdate,
			readonly : true,
			maxDate : new Date(),
			onchange:function(val){
				$scope.endDate.minDate = val;
				$scope.fromdate = val;
				var toDate = new Date(new Date(val).setDate(new Date(val).getDate()+ collectionConstants.APPROVAL_DATE_DIFF));
				var _diffDate = getDateDifference(new Date(),toDate);
				$scope.endDate.dateValue = $scope.endDate.maxDate = (_diffDate < 0) ? toDate : new Date();
				$scope.endDate.setDateVal($scope.endDate.dateValue);				
			}
		});
		$scope.endDate = new DatePickerConfig({
			value : $scope.todate,
			readonly : true,
			maxDate : new Date(),
			onchange : function(val) {
				$scope.todate = val;
			},
		});
		$scope.endDate.minDate = $scope.fromdate;
		$scope.filterPopup = {
				reqObj : [],
				onOpen : function(contentData) {
					contentData.options = angular.copy(filterList);
					contentData.isAll = isAll;
				},
				isAllSelected : function(options) {
					_.each(options, function(item) {
						item.selected = $scope.filterPopup.isAll;						
					});
				},
				checkAll : function(options){
					$scope.filterPopup.isAll = true;
					_.each(options, function(item) {
						if(!item.selected){
							$scope.filterPopup.isAll = false;
						}
					});		
				},
				filterQueue : function(options,flag,isReset) {						
					$scope.filterPopup.reqObj  = [];
					for(var i=0;i<options.length;i++){
						if(options[i].selected){
							$scope.filterPopup.reqObj.push(options[i].id);
						}
					}
					if(!$scope.filterPopup.reqObj.length && flag){
						dialogService.showAlert('Error','Error!','Please select an option!');
						return;
					}
					filterList = angular.copy(options);
					isAll = $scope.filterPopup.isAll;
					$scope.data.isFlag = flag;
					if(!isReset){
						$scope.todate = $scope.endDate.dateValue = new Date();
						$scope.fromdate = $scope.startDate.dateValue  = new Date(new Date($scope.todate).setDate(new Date($scope.todate).getDate()-collectionConstants.APPROVAL_LAND_DATE_DIFF));	
						$scope.endDate.setDateVal($scope.todate);
						$scope.startDate.setDateVal($scope.fromdate);
					}
					$scope.getRequests();	
					if (typeof $scope.filterPopup.close === 'function'){
						$scope.filterPopup.close();				
					}
				},
				resetAndClose : function() {
					$scope.filterPopup.close();
				}
			};
 		function init(){
 			$scope.queue = {
 					pending : {
 						currentPage : 1,
 						offset : 1, 
 						offsetlast : $scope.maxRecordPerPage,
 						data : pendingReqsResolver ? pendingReqsResolver.data : [],
 						totalRecords : pendingReqsResolver.meta.totalCount ? pendingReqsResolver.meta.totalCount : 0 						
 					},
 					initiated : {
 						currentPage : 1,
 						offset : 1,
 						offsetlast : $scope.maxRecordPerPage,
 						data : initiatedReqsResolver ? initiatedReqsResolver.data : [],
 						totalRecords : initiatedReqsResolver.meta.totalCount ? initiatedReqsResolver.meta.totalCount : 0
 					},
 					approved : {
 						currentPage : 1,
 						offset : 1, 
 						offsetlast : $scope.maxRecordPerPage,
 						data : approvedReqsResolver ? approvedReqsResolver.data : [],
 						totalRecords : approvedReqsResolver.meta.totalCount ? approvedReqsResolver.meta.totalCount : 0
 					} 					
 			}; 			
			$rootScope.filterValue = $rootScope.filterValue ? $rootScope.filterValue.toUpperCase() : ""	;
			if($state.params.tabSelected){
				switch($state.params.tabSelected) {
					case 'PENDING':
					  	approvalQueueService.clickedTab = 'PENDING';
					  	break;
					case 'INITIATED':
						approvalQueueService.clickedTab = 'INITIATED';
						break;
					case 'APPROVED':
						approvalQueueService.clickedTab = 'APPROVED';
					  	break;
				}
			}

			if(approvalQueueService.clickedTab === 'PENDING' || (!approvalQueueService.clickedTab && $rootScope.filterValue !== 'INITIATED' && $rootScope.filterValue !== 'APPROVED')){
				$scope.isPendingTab = true;
				selectedTab = 'PENDING';
			}else if(approvalQueueService.clickedTab === 'INITIATED' || ($rootScope.filterValue === 'INITIATED' && !$globalScope.isClickedViaMenu)){
				$scope.isInitiatedTab = true;
				selectedTab = 'INITIATED'; 
				$rootScope.filterValue = '';
			}else if(approvalQueueService.clickedTab === 'APPROVED' || ($rootScope.filterValue === 'APPROVED' && !$globalScope.isClickedViaMenu)){
				$scope.isApprovedTab = true;
				selectedTab = 'APPROVED'; 
			}	
			if(!$globalScope.isClickedViaMenu && approvalQueueService.pageFields){
				var tab = selectedTab.toLowerCase();
				$scope.queue[tab].currentPage = approvalQueueService.pageFields.currentPage;
				$scope.queue[tab].offset = approvalQueueService.pageFields.offset;
				$scope.queue[tab].offsetlast = approvalQueueService.pageFields.offsetLast;
				$scope.data.agreementNo = approvalQueueService.pageFields.agreementNo;
				$scope.startDate.dateValue = approvalQueueService.pageFields.startDate;
				$scope.startDate.endDate = approvalQueueService.pageFields.endDate;
				filterList = approvalQueueService.pageFields.filter;
				$scope.filterPopup.reqObj = approvalQueueService.pageFields.filterparam;
				$scope.startDate.dateValue = (approvalQueueService.pageFields.filterparam.length===0 ?approvalQueueService.pageFields.startDate:"");
				$scope.startDate.endDate = (approvalQueueService.pageFields.filterparam.length===0 ?approvalQueueService.pageFields.endDate : "");
				$scope.data.hidePanels = approvalQueueService.pageFields.hidePanels;
				$scope.activity.standByTellerID = approvalQueueService.pageFields.tellerID;
				isHistory = approvalQueueService.pageFields.history;
				$scope.data.isFlag = approvalQueueService.pageFields.flag;
				approvalQueueService.pageFields = null;
				
			}
			approvalQueueService.clickedTab = '';
			_.each(collectionConstants.APPROVAL_ACTIVITIES,function(activityItem){
				if(appFactory.getActivityAccess(activityItem.activityID)){
					$scope.data.initiateMenus.push(activityItem);
				}
			});
			$globalScope.isClickedViaMenu = true;
			$globalScope.isClickedDashboard = false;
 		}
		init();
		
 		var fetchAllRequests = function(isPagination,filterObj){
 			if(isPagination){
 				var tab = selectedTab.toLowerCase();
 				approvalQueueService.getQueueDetails(filterObj,selectedTab).then(function(data){
 					$scope.queue[tab].data = data.data ? data.data : [];
 					$scope.queue[tab].totalRecords = data.meta && data.meta.totalCount ? data.meta.totalCount:0;
 	 			});
 			}else{
 				if($scope.canApprove){
 					approvalQueueService.getQueueDetails(filterObj,'PENDING').then(function(data){
 	 					$scope.queue.pending = {
 							currentPage : 1,
 	 						offset : 1, 
 	 						offsetlast : $scope.maxRecordPerPage,
 	 						data : data.data ? data.data : [],
 	 						totalRecords : data.meta && data.meta.totalCount ? data.meta.totalCount:0 	
 	 					};
 	 	 			});
 					approvalQueueService.getQueueDetails(filterObj,'APPROVED').then(function(data){
 						$scope.queue.approved = {
 							currentPage : 1,
 							offset : 1, 
 							offsetlast : $scope.maxRecordPerPage,
 							data : data.data ? data.data : [],
 							totalRecords : data.meta && data.meta.totalCount ? data.meta.totalCount:0 	
 						};
 					});
 				}
 				approvalQueueService.getQueueDetails(filterObj,'INITIATED').then(function(data){
						$scope.queue.initiated = {
						currentPage : 1,
 						offset : 1, 
 						offsetlast : $scope.maxRecordPerPage,
 						data : data.data ? data.data : [],
 						totalRecords : data.meta && data.meta.totalCount ? data.meta.totalCount:0 	
 					};
				});
 			} 				
 		};

 		$scope.changeSearchInputBox = function(searchType){
 			$scope.data.agreementNo = "";
 			$scope.data.physicalChallan = "";
 			$scope.physicalchallanNoinput = false;
 			$scope.agreementNoinput = false;			
 			if(searchType == 'physicalChallan'){
 				$scope.physicalchallanNoinput = true;
 			}else{
 				$scope.agreementNoinput = true;
 			}
 		};
 		
 		$scope.resetDate = function(flag){
 			$scope.data.isFlag = flag;
 			if(!flag){
 				var options = angular.copy(filterList);
 				$scope.filterPopup.isAll = false;
 				$scope.filterPopup.isAllSelected(options);
 				$scope.filterPopup.filterQueue(options,false,true)
 			}else{
				$scope.getRequests();
			}
 		};
 		
 		$scope.getRequests  = function(offset){
 			var filterObj =  { 				
 				offset : offset ? offset : 1,
 				limit : 5,
 				history : isHistory ? '' : false
 			};
 			if($scope.data.searchValue && $scope.data.isFlag && $scope.data.searchBy){
 				filterObj[$scope.data.searchBy.searchBy] = $scope.data.searchValue;
 			}else if($scope.startDate.dateValue && $scope.endDate.dateValue && !$scope.data.isFlag){
 				filterObj.fromdate = new Date($scope.startDate.dateValue);
 				filterObj.todate =  new Date($scope.endDate.dateValue);
 			}

			if($rootScope.identity.standByTeller && $scope.activity.standByTellerID){
				filterObj.tellerID = $scope.activity.standByTellerID;
 			}

 			if($scope.filterPopup.reqObj && $scope.filterPopup.reqObj.length > 0){
 				filterObj.filters = $scope.filterPopup.reqObj.toString();
 			}else if(!$scope.data.hidePanels){
 				filterObj.filters = $state.params.filters;
 			}
 			if($scope.data.physicalChallan && $scope.data.isFlag){
 				if($scope.data.physicalChallan != ""){
 					filterObj.physicalChallan = $scope.data.physicalChallan;
 				}
 			}
 			fetchAllRequests(offset,filterObj);
 		};

 		$scope.paginationHandler = function(pageNum){
 			var tab = selectedTab.toLowerCase();
			$scope.queue[tab].offset = (((pageNum-1) * $scope.maxRecordPerPage) + 1);
			$scope.queue[tab].offsetlast = (($scope.queue[tab].offset+5) > $scope.queue[tab].totalRecords) ? $scope.queue[tab].totalRecords : $scope.queue[tab].offset + 4;
			$scope.getRequests($scope.queue[tab].offset);
		};
		var setCacheObjects = function(){
			approvalQueueService.clickedTab = selectedTab;
			var tab = selectedTab.toLowerCase();
			approvalQueueService.pageFields = {
				currentPage : $scope.queue[tab].currentPage,
				offset : $scope.queue[tab].offset,
				offsetLast : $scope.queue[tab].offsetlast ,
				agreementNo : $scope.data.agreementNo,
				startDate : $scope.data.agreementNo ? '': $scope.startDate.dateValue,
				endDate :  $scope.data.agreementNo ? '': $scope.endDate.dateValue,
				filter : angular.copy(filterList),
				filterparam : $scope.filterPopup.reqObj,
				history : isHistory,
				hidePanels : $scope.data.hidePanels,
				tellerID : $scope.activity.standByTellerID
			};
		};
		$scope.moreHandler = function(e,request){
			e.preventDefault();
			e.stopPropagation();
			approvalQueueService.setSelectedRequest(request);
			setCacheObjects();
			$globalScope.goPreviousState = '';
			if(request.requestType === "BACKDATEDCHALLANING"){
				$state.go('collections.approveBDChallan',{challanNo:request.challanNo,reqStatus:selectedTab});
			} else if(request.requestType === "INVOICEGENERATION"){
                $state.go('collections.approvalRequest',{agreementNo:request.invoiceNo,reqStatus:selectedTab,requestType:request.requestType});
			}else if(request.requestType === "LEGALCASE"){
				//$state.go('collections.approvalRequestLegal',{reqStatus:selectedTab,requestType:request.requestType,agreementNo:request.agreementNo,caseID:request.caseID});
				$state.go('collections.approvalRequestFilterLegal',{reqStatus:selectedTab,requestType:request.requestType,agreementNo:request.agreementNo,caseID:request.caseID});
			}else if(request.requestType === "LEGALADVOCATECHANGE"){
				$state.go('collections.advocateApprovalRequestLegal',{reqStatus:selectedTab,requestType:request.requestType,agreementNo:request.agreementNo,caseID:request.caseID});
			}else if(request.requestType === "LEGALADVOCATEFEECHANGE"){
				$state.go('collections.advocateApprovalRequestLegalFeeChange',{reqStatus:selectedTab,requestType:request.requestType,agreementNo:request.agreementNo,caseID:request.caseID});
			}else if(request.requestType === "LEGALAGREEMENTBLOCK"){
				$state.go('collections.agreementBlockApprovalRequestLegal',{reqStatus:selectedTab,requestType:request.requestType,agreementNo:request.agreementNo,caseID:request.caseID});
			}else{
				$state.go('collections.approvalRequest',{agreementNo:request.agreementNo,reqStatus:selectedTab,requestType:request.requestType});
			}
		};		

		$scope.gotoCasedetails = function(e,agreementNo){
			e.preventDefault();
			e.stopPropagation();
			setCacheObjects();
			lazyModuleLoader.loadState('collections.myCustomers.summary', {'agreementNo':agreementNo});
		};
		
		
		$scope.showOptions = function(){
			if(!$scope.data.initiateMenus.length){
				dialogService.showAlert('Error','Error','Access Denied, Please contact admin');
				return;
			}
			$modal.open({
                templateUrl: 'app/collections/approvals/approvalQueue/partials/initiatePopup.html',
                controller: ['$scope','$modalInstance','dialogService','lazyModuleLoader','appFactory','data',function($scope,$modalInstance,dialogService,lazyModuleLoader,appFactory,data){
                	$scope.menus = data.menuArr;
                	$scope.data = { initiateType : '' };
             		$scope.close = function(){
            			$modalInstance.dismiss();
            		};
            		
            		$scope.goToInitiate = function(reqType){
                		lazyModuleLoader.loadState('collections.initiateRequest',{reqType:reqType});
            			$modalInstance.dismiss();
            		};
                }],
                backdrop : 'static',
                size : 'sm',
                resolve:{
					data : function() {
						return {
							menuArr : $scope.data.initiateMenus
						};
					}
				}
            });
		};				
		$scope.openModalPendingWith = function (e,pendingUserDetails) {
			e.preventDefault();
			e.stopPropagation();
			$modal.open({
				templateUrl: 'app/collections/caseDetail/partials/pendingUserDetails.html',
				controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {
					$scope.pendingUserDetails = pendingUserDetails;
					$scope.close = function () {
						$modalInstance.dismiss();
					};
				}],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};
		$scope.tabChangeHandler = function(tabName){
			selectedTab = tabName;
		};
 		$scope.legalHistoryPopup = function(workFlow){
			var history = [];
			for(var i=0;i<workFlow.length;i++){
				if(!workFlow[i-1] || (workFlow[i-1] && workFlow[i-1].workStatus !=="ESCALATED")){
                    history.push(workFlow[i]);
				}
				// else if(workFlow[i].workStatus !== "INITIATED"){
				// 	history.push(workFlow[i]);
				// }
			};

			$modal.open({
                templateUrl: 'app/collections/approvals/approvalQueue/partials/legalHistoryPopup.html',
                controller: ['$scope','$modalInstance','dialogService','lazyModuleLoader','appFactory','data',function($scope,$modalInstance,dialogService,lazyModuleLoader,appFactory,data){
                	$scope.content = data.workflow;
                	console.log($scope.content);
             		$scope.close = function(){
            			$modalInstance.dismiss();
            		};
            		$scope.initLegalHistory = function(){
            			$scope.legalHistoryData = _.sortBy( $scope.content, 'workDoneDate');
            		};
                }],
                backdrop : 'static',
                size : 'md',
                resolve:{
					data : function() {
						return {
							workflow : history
						};
					}
				}
            });
		};
 	};

 	approvalQueue.controller('approvalQueueController',['$scope','$state','$rootScope','$globalScope','$modal','approvalQueueService','pendingReqsResolver','initiatedReqsResolver','approvedReqsResolver','lazyModuleLoader','dialogService','appFactory',approvalQueueController]);
	return approvalQueueController;
});