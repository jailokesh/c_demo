define(['require','approvalQueue','constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approveLegalChildCase = function($scope,lazyModuleLoader,dialogService,approvalQueueService,messageBus,$modal,$stateParams,$globalScope){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.data = {};
    	var getLegalChildCase = function() {
			approvalQueueService.getLegalChildCase($scope.requestObj.caseID).then(function(data){
				if(data && data.length){
					$scope.requestInfo = data[0];				
					if(Object.keys($scope.requestInfo.parentCaseDetails.corporateCaseStage).length){
						$scope.requestInfo.caseDetails = $scope.requestInfo.parentCaseDetails.corporateCaseStage;
					}else{
						$scope.requestInfo.caseDetails = $scope.requestInfo.parentCaseDetails.caseStageDetails;
					}
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.requestInfo.rejectedObj = _.findWhere($scope.requestInfo.childCaseDetails.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
					$scope.requestInfo.initObj = _.findWhere($scope.requestInfo.childCaseDetails.workflow,{workStatus:'INITIATED'});
					
					if($scope.requestInfo.childCaseDetails.workflow[0].workStatus === 'ESCALATED'){
						$scope.requestInfo.childCaseDetails.workflow.shift();
					}
					if($scope.requestInfo.childCaseDetails && $scope.requestInfo.childCaseDetails.workflow){
						$scope.data.remarksData = utility.getApprovalsRemarks($scope.requestInfo.childCaseDetails.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
				}
				else{
					$scope.requestInfo = {};
				}
			});	
    	};

 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 			getLegalChildCase();
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.requestObj.remarks){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};					
			reqObj.caseID = $scope.requestInfo.childCaseDetails.caseID;
			reqObj.agreementNos = $scope.requestInfo.childCaseDetails.workflow[0].agreementNos;
			reqObj.legalSections = $scope.requestInfo.childCaseDetails.workflow[0].legalSections;
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.requestInfo.childCaseDetails.majorVersion;
			reqObj.minorVersion = $scope.requestInfo.childCaseDetails.minorVersion;
			reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			reqObj.branchID = $scope.requestObj.branchId;
			reqObj.agreementStatus = $scope.customerInfo.agreementStatus;
			reqObj.remarks = $scope.requestObj.remarks;
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.requestInfo.initObj ? $scope.requestInfo.initObj.comments : '';
			}
			/*reqObj.caseToBeFiledAt = $scope.requestInfo.caseToBeFiledAt;
			reqObj.documentToBeSendTo = $scope.requestInfo.documentToBeSendTo;			
			reqObj.remarks = $scope.requestInfo.rejectionReason;			
			
			*/
			approvalQueueService.handleRequest(reqObj,'LEGAL_CHILD_CASE').then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}					
			});	
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID,$scope.customerInfo.agreementStatus,null,$scope.requestObj.legalSections.toString()).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};
 	
 	approvalQueue.controller('approveLegalChildCase',['$scope','lazyModuleLoader','dialogService','approvalQueueService','messageBus','$modal','$stateParams','$globalScope',approveLegalChildCase]);
	return approveLegalChildCase;
});
