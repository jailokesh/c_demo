define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var panCardController = function($scope,$stateParams,$modal,approvalQueueService,dialogService,lazyModuleLoader,masterService,$globalScope,messageBus,$rootScope){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.panCardDetails = {};
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.reInitiatFlag = false;
		var getPanCardDetails = function() {
			approvalQueueService.getPanCardUnavailabilityDetails($stateParams.agreementNo,$scope.requestObj).then(function(data){
				if(data && data.length){
					$scope.panCardDetails = data[0];

					if($scope.requestObj.requestType === 'RTGS' || $scope.requestObj.requestType === 'POS'){
						var isCancelReceiptInitiated, cancelObj = _.findWhere($scope.panCardDetails.receiptDetail.workflow, {requestType : "RECEIPTCANCELLATION"});
						if(cancelObj){
							isCancelReceiptInitiated = cancelObj.workStatus !== 'REJECTED';
						}
						if(isCancelReceiptInitiated){
							var _msg, _status;
							_status = cancelObj.workStatus === 'APPROVED' ? 'approved' : 'pending';
							_msg = collectionConstants.ERROR_MSG.RECEIPT_CANCELLATION_VALIDATION.replace('STATUS', _status);
							dialogService.showAlert(collectionConstants.REPO_MSG.WARNING, collectionConstants.REPO_MSG.WARNING, _msg);
							$scope.requestObj.hideAll = true;
						}
						$scope.panCardDetails.receiptDetail.workflow = _.filter($scope.panCardDetails.receiptDetail.workflow, function(item) {
				            return item.requestType === ($scope.requestObj.requestType).toUpperCase();
				        });
					}
					var approvedStatus = _.findWhere($scope.panCardDetails.receiptDetail.workflow,{"workStatus":"APPROVED"});
					if($scope.requestObj.requestType === 'RECEIPTMODIFICATION' && approvedStatus){
						$scope.panCardDetails.receiptDetail.modifiedDetails.instrumentDetail = $scope.panCardDetails.receiptDetail.instrumentDetail;
					}
					$scope.panCardDetails.initObj = _.findWhere($scope.panCardDetails.receiptDetail.workflow,{workStatus:'INITIATED'});
					if($scope.panCardDetails.initObj.workDoneBy === $rootScope.identity.userID || $scope.panCardDetails.initObj.workDoneBy === approvalQueueService.pageFields.tellerID){
						$scope.reInitiatFlag = true;
					}					
					if($scope.panCardDetails.receiptDetail.workflow){
						$scope.panCardDetails.remarksData = utility.getApprovalsRemarks($scope.panCardDetails.receiptDetail.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.panCardDetails.rejectionObj = _.findWhere($scope.panCardDetails.receiptDetail.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
				}
			});   			
		};
		
		var getMemoUploadDetails = function() {
			approvalQueueService.getMemoUploadDetails($scope.requestObj.challanNo).then(function(data){
				if(data && data.length)
					$scope.memoDetails = data[0];
					$scope.memoDetails.collectorBranchName = approvalQueueService.getBranchName($scope.memoDetails.branchID);
					$scope.memoDetails.initObj = _.findWhere($scope.memoDetails.workflow,{workStatus:'INITIATED',requestType:$scope.requestObj.requestType});
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.memoDetails.rejectionObj = _.findWhere($scope.memoDetails.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus,requestType:$scope.requestObj.requestType});
					}
					masterService.getBankName('','C').then(function(data){
						var cholabankNames = data;
						$scope.memoDetails.bankObj = _.findWhere(cholabankNames,{bankID:$scope.memoDetails.bankID});						
					});
			});   			
		};
		
 		function init(){
 			if($scope.requestObj.requestType === 'NOMEMOUPLOAD'){
 				getMemoUploadDetails();
 			}else{
 				$scope.customerInfo = approvalQueueService.getAgreementObj();
 				$scope.requestObj.isVishesh = ($scope.requestObj.receiptFor.toUpperCase() === 'VISHESHAGREEMENT' || $scope.requestObj.receiptFor.toUpperCase() === 'TRIPLOAN');
 				$scope.requestObj.isReceiptFor = (!$scope.requestObj.isVishesh && $scope.requestObj.receiptFor && $scope.requestObj.receiptType !== 'SHORTFALL');
 				if($scope.requestObj.isReceiptFor || $scope.requestObj.receiptType === "IMD" || $scope.requestObj.receiptType === "TA" || ($scope.requestObj.applicationNos && $scope.requestObj.applicationNos[0])){
 					$scope.customerInfo.productType = !$scope.customerInfo.product ? "VF" : $scope.customerInfo.product;
 					$scope.requestObj.receiptType = $scope.requestObj.receiptType === 'INS' ? 'INS-LEAD' : $scope.requestObj.receiptType;
 					if($scope.requestObj.receiptFor === "ClosedAgreement" || $scope.requestObj.receiptFor === "NonAgreement"){
 						$scope.customerInfo.agreementStatus = $scope.requestObj.receiptFor === "NonAgreement" ? 'NA': 'C';
 						$scope.customerInfo.productGroup = $scope.requestObj.productGroup;
 						$scope.customerInfo.agreementNo = $scope.requestObj.receiptFor === "ClosedAgreement" ? $scope.requestObj.agreementNo : $scope.requestObj.payerID;
 					}
 				}else{
 					$scope.customerInfo = utility.getCustomerInfo($scope.customerInfo);
 				}
 				
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 	 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 				getPanCardDetails();
 			}
 		}
		init();
		
		$scope.fetchBatchDetails = function(batchId,mode,product){
			approvalQueueService.getBatchDetails(batchId,mode,product).then(function(response){
				$modal.open({
					templateUrl: 'app/collections/approvals/approvalQueue/partials/batchDetailsPopup.html',
					controller: ['$scope','$modalInstance','$state','data',function($scope,$modalInstance,$state,data){
						$scope.batchDetails = data.batchDetails;	  
                    	$scope.batchInfo = data.batchInfo;	  
                    	$scope.noRecords = ($scope.batchInfo && $scope.batchInfo.length)?false:true;
                    	$scope.close = function(){	  
	            			$modalInstance.close();
	            		};
					}],
					size: 'lg',
					backdrop: 'static',
					windowClass: 'modal-custom',
					resolve: {
						data: function(){
							return {
								batchDetails: {
									batchID: batchId,
									mode: mode,
									product: product
								},
								batchInfo: response
							};
						}
					}
				});
			});
		};
		
		$scope.viewOtherAgreements = function(){
 			$modal.open({
				templateUrl: 'app/collections/approvals/approvalQueue/partials/agreementSelection.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.data = {};
					$scope.data.totalRecords = [];
					if(data.agreementNos.length){
						_.each(data.agreementNos,function(item){						
							var obj = {};
							var refNo = _.where(data.chargeDetails,{referenceNo:item});
							var amt = _.pluck(refNo, 'amount');
							var sum = _.reduce(amt, function(memo, num){ return memo + num; }, 0);
							obj.agreementNo = item;
							obj.amount = sum;
							$scope.data.totalRecords.push(obj);
						});
					}					
					$scope.close = function(){
						$modalInstance.dismiss();
					};
				}],
				size : 'sm',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return {
	                    	agreementNos : $scope.panCardDetails ? $scope.panCardDetails.receiptDetail.agreementNos : [],
	                    	chargeDetails : $scope.panCardDetails ? $scope.panCardDetails.receiptDetail.chargeDetails : [],		
	                    	isViewOnly : true
	                    };
	                }
				}
			});
		};
		$scope.reInitiate = function(){
			$globalScope.isClickedViaMenu = $rootScope.isClickedViaMenu = false;
			if($scope.requestObj.requestType === 'LMSCANCELLATIONRECEIPT'){
				lazyModuleLoader.loadState('collections.lmsCancellationDetail', {mode : $scope.panCardDetails.receiptDetail.modeOfPayment, receiptNo : $scope.panCardDetails.receiptDetail.receiptNo});
			}else{
				lazyModuleLoader.loadState('collections.cancelReceipts',{receiptNo:$scope.requestObj.receiptNo,type:"cancel"});
			}
		};

		
		$scope.handleRequest = function(reqType){
			var reqObj = {},msg;
			if(reqType !== 'ESCALATE'){
				var isInstrumentImg = ($scope.panCardDetails.receiptDetail.modifiedDetails && $scope.panCardDetails.receiptDetail.modifiedDetails.modeOfPayment !== "CASH") ? ($scope.panCardDetails.receiptDetail.modifiedDetails.instrumentDetail && $scope.panCardDetails.receiptDetail.modifiedDetails.instrumentDetail.imageRef && $scope.panCardDetails.receiptDetail.modifiedDetails.instrumentDetail.imageRef.imagePathReferences.length>0):false;
				var isRTGSInstrumentImg = ($scope.panCardDetails.receiptDetail.instrumentDetail && $scope.panCardDetails.receiptDetail.instrumentDetail.imageRef && $scope.panCardDetails.receiptDetail.instrumentDetail.imageRef.imagePathReferences.length>0);
				var isLMSCancelledReceipt = ($scope.panCardDetails.receiptDetail.cancelledReceiptImageRef && $scope.panCardDetails.receiptDetail.cancelledReceiptImageRef.imagePathReferences.length>0);
				if($scope.requestObj.requestType === 'RECEIPTMODIFICATION' && (!$scope.panCardDetails.isViewedManual || (!$scope.panCardDetails.isViewedInstrument && isInstrumentImg))){
					msg = "Please verify the Receipt image ";
					msg += isInstrumentImg ? 'and Instrument image' : ''; 
					msg += 'to proceed';
					dialogService.showAlert(collectionConstants.REPO_MSG.WARNING, collectionConstants.REPO_MSG.WARNING, msg);
					return;
				}else if(($scope.requestObj.requestType === 'RTGS' || $scope.requestObj.requestType === 'POS') && !$scope.panCardDetails.isViewedInstrument && isRTGSInstrumentImg){
					msg = $scope.requestObj.requestType === 'RTGS' ? collectionConstants.ERROR_MSG.VERIFY_EMAIL : collectionConstants.ERROR_MSG.VERIFY_PROOF;
					dialogService.showAlert(collectionConstants.REPO_MSG.WARNING, collectionConstants.REPO_MSG.WARNING,msg);
					return;
				}else if(($scope.requestObj.requestType === 'LMSCANCELLATIONRECEIPT') && !$scope.panCardDetails.isViewedCancelled && isLMSCancelledReceipt){
					msg = collectionConstants.ERROR_MSG.VERIFY_LMS_RECEIPT;
					dialogService.showAlert(collectionConstants.REPO_MSG.WARNING, collectionConstants.REPO_MSG.WARNING,msg);
					return;
				}
			}
			if($scope.requestObj.requestType === 'NOMEMOUPLOAD'){
				if(reqType === 'REJECTED' && !$scope.memoDetails.rejectionReason){
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;
				}	
				reqObj = [{
					challanNo : $scope.memoDetails.challanNo,
					remarks : $scope.memoDetails.rejectionReason,
					status : reqType,
					majorVersion : $scope.requestObj.majorVersion,
					minorVersion : $scope.requestObj.minorVersion,
					actionID : $scope.requestObj.approvalDetails.actionID,
					branchID : $scope.requestObj.branchId
				}];
				if(reqType === 'ESCALATE'){
					reqObj[0].actionID = $scope.requestObj.selectedManager;
					reqObj[0].levelChange = true;
					reqObj[0].status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
					reqObj[0].remarks = $scope.memoDetails.initObj ? $scope.memoDetails.initObj.comments : '';
				}
			}else{
				if(reqType === 'REJECTED' && !$scope.panCardDetails.remarks){
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;
				}	
				reqObj = {
					receiptNo :	$scope.panCardDetails.receiptDetail.receiptNo,
					remarks : $scope.panCardDetails.remarks,
					status : reqType,
					majorVersion : $scope.requestObj.majorVersion,
					minorVersion : $scope.requestObj.minorVersion,
					actionID : $scope.requestObj.approvalDetails.actionID,
					branchID : $scope.requestObj.requestType === 'LMSCANCELLATIONRECEIPT' ? $scope.panCardDetails.receiptDetail.branchID : $scope.requestObj.branchId
				};
				if(reqType === 'ESCALATE'){
					reqObj.actionID = $scope.requestObj.selectedManager;
					reqObj.levelChange = true;
					reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
					reqObj.remarks = $scope.panCardDetails.initObj ? $scope.panCardDetails.initObj.comments : '';
				}
			}
			approvalQueueService.handleReceiptRequest($scope.requestObj.requestType,reqObj).then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						
						if (reqType === "APPROVED" && $scope.requestObj.productGroup === 'VF' && ($scope.requestObj.requestType === 'RTGS' || $scope.requestObj.requestType === 'POS')) {
								approvalQueueService.updateLead($scope.panCardDetails.receiptDetail,$scope.customerInfo.loanDetails);
								
						} 
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
 		
 		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('panCardController',['$scope','$stateParams','$modal','approvalQueueService','dialogService','lazyModuleLoader','masterService','$globalScope','messageBus','$rootScope',panCardController]);
	return panCardController;
});