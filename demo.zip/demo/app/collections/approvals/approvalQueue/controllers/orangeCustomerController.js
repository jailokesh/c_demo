define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var orangeCustomerController = function($scope,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus){
 		$scope.ratings = collectionConstants.SUGGESTED_RATING;
 		var remarksObj;
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.refinanced = constants.STATUS;
 		$scope.cashDenominations = {};
 		$scope.calculateCash = {};
    	var getCustomerDetails = function() {
			approvalQueueService.getOrangeCustomer($stateParams.agreementNo).then(function(data){
				$scope.customerInfo.categorization = data.categorization;
				$scope.customerInfo.questions = data.questions;
				$scope.customerInfo.isApproved = false;
				if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
					remarksObj = _.findWhere($scope.customerInfo.questions.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					$scope.customerInfo.isApproved = $scope.requestObj.approvalDetails.currentStatus === 'APPROVED';
					$scope.customerInfo.remarks = remarksObj && remarksObj.comments ? remarksObj.comments : '-';
				}
				$scope.customerInfo.categorization.suggestedRating = (_.findWhere($scope.customerInfo.questions.questionnaire,{question:'Suggested Rating'})).response;
				$scope.customerInfo.noOfYrs = $scope.customerInfo.categorization?(new Date().getFullYear()-$scope.customerInfo.categorization.yearsOfStay):0;
			});	
    	};

    	var getTotalInOutflow = function(){
    		$scope.eodDcrInfo.totalInflowAmount = 0;
    		$scope.eodDcrInfo.totalOutflow = 0;
    		_.each($scope.eodDcrInfo.inflowReceipts,function(item){
    			$scope.eodDcrInfo.totalInflowAmount = $scope.eodDcrInfo.totalInflowAmount + item.amountPaid;
    		});
    		_.each($scope.eodDcrInfo.outflowChallans,function(item){
    			$scope.eodDcrInfo.totalOutflow = $scope.eodDcrInfo.totalOutflow + item.receiptAmount;
    		});
    	};
    	
    	var getDCRDetails = function(){
    		approvalQueueService.getDCRDetails($scope.requestObj.reportID).then(function(data){
    			if(data && data.length){
    				$scope.eodDcrInfo = data[0];
    				$scope.eodDcrInfo.HOAdjustmentAmount = Math.abs($scope.eodDcrInfo.HOAdjustmentAmount);
    				 getTotalInOutflow();
    				if($scope.eodDcrInfo.workflow){
						$scope.eodDcrInfo.remarksData = utility.getApprovalsRemarks($scope.eodDcrInfo.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
    				if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
    					remarksObj = _.findWhere($scope.eodDcrInfo.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
    					$scope.eodDcrInfo.remarks = remarksObj && remarksObj.comments?remarksObj.comments:'-';
    				}
    				_.each($scope.eodDcrInfo.cashDenominations,function(cash){
    					if(!cash.denomination){
    						$scope.calculateCash[constants.CASH_DENOMINATIONS[cash.denomination.toString()]] = cash.noOfCoins;
    					}
    					else{
    						$scope.cashDenominations[constants.CASH_DENOMINATIONS[cash.denomination.toString()]] = cash.noOfNotes;
        					$scope.calculateCash[constants.CASH_DENOMINATIONS[cash.denomination.toString()]] = cash.noOfNotes*cash.denomination;
    					}
    				});
    			}
			});	
    	};
    	
 		function init(){
 			if($stateParams.requestType === 'ORANGECUSTOMER'){
 				$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 	 			getCustomerDetails();
 			} 				
 			else{
 				getDCRDetails();
 			}
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			var reqObj,requestType;
			if($stateParams.requestType === 'ORANGECUSTOMER'){
				if(reqType === 'REJECTED' && !$scope.customerInfo.rejectionReason){
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;
				}	
				if(!(/^[abcdABCD]$/).test($scope.customerInfo.categorization.suggestedRating)){
					dialogService.showAlert('Error', "Error", "Please enter a valid rating");
					return;
				}
				reqObj = {
						groupID : $scope.requestObj.groupID?$scope.requestObj.groupID:'',
						agreementNo : $stateParams.agreementNo,
						actionCode : 'ORANGECUSTOMER',
						status : reqType,
						suggestedRating : $scope.customerInfo.categorization.suggestedRating,
						currentRating : $scope.customerInfo.categorization.rating,
						majorVersion : $scope.customerInfo.questions.majorVersion,
						minorVersion : $scope.customerInfo.questions.minorVersion,
						contactedDateTime : $scope.customerInfo.questions.contactedDateTime,
						comments : $scope.customerInfo.rejectionReason,
						actionID : $scope.requestObj.approvalDetails.actionID,
						branchID : $scope.requestObj.branchId
				};
				requestType = 'ORANGE_CUSTOMER';
				if(reqType === 'ESCALATE'){
					reqObj.actionID = $scope.requestObj.selectedManager;
					reqObj.levelChange = true;
					reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
					reqObj.remarks = remarksObj ? remarksObj.comments : '';
				}
			}
			else{
				if(reqType === 'REJECTED' && !$scope.eodDcrInfo.rejectionReason){
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;
				}
				reqObj = [{				        
				        reportID : $scope.requestObj.reportID,
				        remarks: $scope.eodDcrInfo.rejectionReason,
				        status : reqType,
				        majorVersion : $scope.eodDcrInfo.majorVersion,
				        minorVersion : $scope.eodDcrInfo.minorVersion,
				        actionID : $scope.requestObj.approvalDetails.actionID,
				        branchID : $scope.requestObj.branchId
				    }];
				requestType = 'EOD_DCR';
				if(reqType === 'ESCALATE'){
					reqObj[0].actionID = $scope.requestObj.selectedManager;
					reqObj[0].levelChange = true;
					reqObj[0].status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
					reqObj[0].remarks = remarksObj ? remarksObj.comments : '';
				}
			}
			approvalQueueService.handleRequest(reqObj,requestType).then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}					
			});	
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('orangeCustomerController',['$scope','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus',orangeCustomerController]);
	return orangeCustomerController;
});