define(['require','approvalQueue','constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var duplicateDocRequestController = function($scope,lazyModuleLoader,dialogService,approvalQueueService,messageBus,$modal,$stateParams,$globalScope){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.data = {};
    	var getLegalDetails = function() {
			approvalQueueService.getDocumentsDetails($scope.requestObj.requestNo,$scope.requestObj.caseID).then(function(data){
				if(data && data.length){
					$scope.requestInfo = data[0];
					$scope.requestInfo.initObj = _.findWhere($scope.requestInfo.workflow,{workStatus:'INITIATED'});
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.requestInfo.rejectedObj = _.findWhere($scope.requestInfo.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
					if($scope.requestInfo.workflow[0].workStatus === 'ESCALATED'){
						$scope.requestInfo.workflow.shift();
					}
					if($scope.requestInfo.workflow){
						$scope.data.remarksData = utility.getApprovalsRemarks($scope.requestInfo.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
				}
				else{
					$scope.requestInfo = {};
				}
			});	
    	};

 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 			getLegalDetails();
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.requestObj.remarks){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};
			reqObj.caseID = $scope.requestInfo.caseID;
			reqObj.requestNo = $scope.requestInfo.requestNo;		
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.requestInfo.majorVersion;
			reqObj.minorVersion = $scope.requestInfo.minorVersion;
			reqObj.remarks = $scope.requestInfo.rejectionReason;
			reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			reqObj.branchID = $scope.requestObj.branchId;
			reqObj.agreementStatus = $scope.customerInfo.agreementStatus;
			reqObj.remarks = $scope.requestObj.remarks;
			/*reqObj.workflow = $scope.requestObj.workflow;
			reqObj.initObj = $scope.requestObj.initObj;*/

			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.requestInfo.initObj ? $scope.requestInfo.initObj.comments : '';
			}
			approvalQueueService.handleRequest(reqObj,'DUPLICATE_DOCUMENT').then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}					
			});	
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID,$scope.customerInfo.agreementStatus).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};
 	
 	approvalQueue.controller('duplicateDocRequestController',['$scope','lazyModuleLoader','dialogService','approvalQueueService','messageBus','$modal','$stateParams','$globalScope',duplicateDocRequestController]);
	return duplicateDocRequestController;
});
