/* Date : 29-Mar-2017
Modified by : Saranya Sankar R
Modification details : CR- Book Request Approvals */

define(['require','approvalQueue', 'constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approveNMController = function($scope,$modal,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus,$rootScope){
 		$scope.duplicateDispletterInfo = approvalQueueService.getSelectedRequest();
 		$scope.duplicateDispletterInfo.branchName = approvalQueueService.getBranchName($scope.duplicateDispletterInfo.branchId);
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestType = $stateParams.requestType;
 		$scope.actionId = $scope.duplicateDispletterInfo.approvalDetails.actionID;
 		$scope.dispatcheTo = approvalQueueConstants.PARTYTYPE;
 		$scope.submitFlag = false;
		$scope.linkedAgrNos = [];
 		var agreementInfo = approvalQueueService.getAgreementObj();
 		$scope.dropDownValues = {};
 		
 		var initController = function(){
 			$scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
 	 		if(agreementInfo && agreementInfo.agreementNo){
 	 			$scope.customerInfo = utility.getCustomerInfo(agreementInfo);
 	 			$scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
				_.each(agreementInfo.relatedAgreementNos, function(item) {
					if(item.agreementNo !== agreementInfo.agreementNo){
						$scope.linkedAgrNos.push(item);
					}
				});	  
 	 		}
 		};
 		initController();
 		var getDuplicateDispatchLetter = function(){
 			approvalQueueService.getDuplicateDispatchLetters($stateParams.agreementNo,$scope.duplicateDispletterInfo.letterType,$scope.duplicateDispletterInfo.dispatchedTo).then(function(response){
 				$scope.duplicateDispletterInfo.letterDetails = response ? response[0]:{};				 						
 				if($scope.duplicateDispletterInfo.letterDetails && $scope.duplicateDispletterInfo.letterDetails.workflow){
 					$scope.duplicateDispletterInfo.letterDetails.remarksData = utility.getApprovalsRemarks($scope.duplicateDispletterInfo.letterDetails.workflow,approvalQueueConstants.APPROVALSTATUS);
 				}
 			});
 		};
 		getDuplicateDispatchLetter();
 		$scope.showAgreementPopup = function() {
			$modal.open({
				templateUrl : 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller : [ '$scope', 'data', '$modalInstance', function($scope, data, $modalInstance) {
					$scope.data = {};
					$scope.data.isViewOnly = data.isViewOnly;
					$scope.data.totalRecords = data.agreementNos;
					$scope.data.productType = data.productType;					
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.saveHandler = function() {
						$modalInstance.dismiss();
					};
					$scope.paginationHandler = function(pageNo) {
						var startLen = $scope.data.recordPerPage * (pageNo - 1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage * (pageNo - 1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen, endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							agreementNos : $scope.linkedAgrNos,
							isViewOnly : true,
							productType : $scope.customerInfo.productGroup
						};
					}
				}
			});
		};
 		$scope.proceedLetterDispatch = function(status){
 			if(status === 'REJECTED' && !$scope.duplicateDispletterInfo.letterDetails.remarks){
 				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
 				return;
 			}
 			
 			var postObj =  {
 					 agreementNo : $scope.duplicateDispletterInfo.letterDetails.agreementNo,
					 letterType : $scope.duplicateDispletterInfo.letterDetails.letterType,
					 status : status,
					 dispatchedTo:$scope.duplicateDispletterInfo.letterDetails.letterDetails.dispatchedTo,
					 actionID : $scope.actionId,
					 remarks: $scope.duplicateDispletterInfo.letterDetails.remarks,
					 majorVersion :$scope.duplicateDispletterInfo.letterDetails.majorVersion,
					 minorVersion : $scope.duplicateDispletterInfo.letterDetails.minorVersion	
 					
 		    };
 			if(status === 'ESCALATE'){
 				postObj.actionID = $scope.duplicateDispletterInfo.selectedManager;
 				postObj.levelChange = true;
 				postObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.duplicateDispletterInfo.approvalDetails.nextLevelAction];
 				postObj.remarks = $scope.duplicateDispletterInfo.letterDetails.initObj ? $scope.duplicateDispletterInfo.letterDetails.initObj.comments : '';
			}
 			if($scope.duplicateDispletterInfo.approvalDetails.originalStatus === 'REJECTED'){
 				if(status === 'REJECTED'){
 					postObj.status = $scope.duplicateDispletterInfo.approvalDetails.nextLevelAction=='RECOMMEND'?'RECOMMENDED':'APPROVED';
 				}
 				else{
 					postObj.status = 'REJECTED';
 				}
 			}
 			approvalQueueService.approveRejectNM(postObj).then(function(data){
 				if(data){
					var successString = "";
					if(status === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+status.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
 			});
 		};
 		
 		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs('DUPLICATELETTERDISPATCH',$scope.duplicateDispletterInfo.approvalDetails.actionID,$scope.customerInfo.agrstatus.status).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.duplicateDispletterInfo.selectedManager = data;
			 				$scope.proceedLetterDispatch('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('approveNMController',['$scope','$modal','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus','$rootScope',approveNMController]);
	return approveNMController;
});