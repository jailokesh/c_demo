define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approveFCHEHLController = function($scope,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
    	var getForeclosureDetails = function() {
			approvalQueueService.getForeclosureDetails($stateParams.agreementNo,$scope.requestObj.requestNo).then(function(data){
				if(data && data.foreClosureReqDetails){
					$scope.requestInfo = data;
					if($scope.requestInfo.foreClosureReqDetails && $scope.requestInfo.foreClosureReqDetails.workflow){
	 					$scope.requestInfo.remarksData = utility.getApprovalsRemarks($scope.requestInfo.foreClosureReqDetails.workflow,approvalQueueConstants.APPROVALSTATUS);
	 				}
					$scope.requestInfo.initObj = _.findWhere($scope.requestInfo.foreClosureReqDetails.workflow,{workStatus:'INITIATED'});
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.requestInfo.rejectedObj = _.findWhere($scope.requestInfo.foreClosureReqDetails.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
				}
				else{
					$scope.requestInfo = {};
				}
			});	
    	};
    	if($scope.requestInfo && $scope.requestInfo.workflow){
			$scope.data.remarksData = utility.getApprovalsRemarks($scope.requestInfo.workflow,approvalQueueConstants.APPROVALSTATUS);
		}
 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 			getForeclosureDetails();
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.requestInfo.rejectionReason){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};
			reqObj.agreementNo = $scope.requestInfo.caseDetail.agreementNo;
			reqObj.requestNo = $scope.requestObj.requestNo;
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.requestInfo.foreClosureReqDetails.majorVersion;
			reqObj.minorVersion = $scope.requestInfo.foreClosureReqDetails.minorVersion;
			reqObj.remarks = $scope.requestInfo.rejectionReason;
			reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			reqObj.branchID = $scope.requestObj.branchId;
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.requestInfo.initObj ? $scope.requestInfo.initObj.comments : '';
			}
			approvalQueueService.handleRequest(reqObj,'FORECLOSUREHEHL').then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}					
			});	
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('approveFCHEHLController',['$scope','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus',approveFCHEHLController]);
	return approveFCHEHLController;
});