/**
 * Represents a Approvals Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','approvalQueue', 'collectionConstants'], function(r,approvalQueue,collectionConstants) {
    'use strict';
    
        var advocateApprovalRequestFeeController = function($scope,$state,$stateParams,approvalQueueService){
            var selectedAgr = approvalQueueService.getSelectedRequest();
            $state.$current.data.headerText = 'Approvals - '+collectionConstants.REQUEST_TYPES[selectedAgr.requestType].title;
            $scope.requestPage = 'app/collections/approvals/approvalQueue/partials/'+collectionConstants.REQUEST_TYPES[selectedAgr.requestType].template+'.html';
            
        };

        approvalQueue.controller('advocateApprovalRequestFeeController',['$scope','$state','$stateParams','approvalQueueService',advocateApprovalRequestFeeController]);
    return advocateApprovalRequestFeeController;
});