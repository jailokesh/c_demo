define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var waiverController = function($scope,$modal,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.waiverInfo = {};
 		$scope.linkedAgrNos = [];
 		$scope.splicRow = function(currentPage){
    		var _cp = (currentPage-1) * $scope.waiverInfo.maxSize;
    		$scope.waiverInfo.offset = _cp + 1;
    		$scope.waiverInfo.offsetLast = ((_cp+$scope.waiverInfo.maxSize)>$scope.waiverInfo.totalRecord) ? $scope.waiverInfo.totalRecord : $scope.waiverInfo.offset+($scope.waiverInfo.maxSize-1);
    		$scope.waiverInfo.data = $scope.waiverInfo.foreCloseLADetails.linkedAgreements.slice(_cp,_cp+$scope.waiverInfo.maxSize);
    	};
    	
    	var getLinkedAgreementDetails = function(){
    		$scope.waiverInfo.isLinkedAgreement = ($scope.waiverInfo.foreCloseLADetails && $scope.waiverInfo.foreCloseLADetails.linkedAgreements) ? true : false;
    		if($scope.waiverInfo.isLinkedAgreement){
				$scope.linkedAgrNos = $scope.waiverInfo.foreCloseLADetails.linkedAgreements;
				//$scope.linkedAgrNos.unshift({agreementNo : $scope.customerInfo.agreementNo,vehicleNumber : $scope.customerInfo.assetDetail ? $scope.customerInfo.assetDetail.lmsRegistrationNo : ''});
    			$scope.waiverInfo.totalRecord = $scope.waiverInfo.foreCloseLADetails.linkedAgreements.length;
    			$scope.waiverInfo.maxSize = 5;
    			$scope.waiverInfo.currentPage = 1;
    			$scope.splicRow(1);
    		}
    	};
    	
    	var getWaiverDetails = function() {    		
			approvalQueueService.getWaiverDetails($scope.requestObj,$stateParams.agreementNo).then(function(data){
				if(data && data.length){
					$scope.waiverInfo = data[0];
					if($scope.waiverInfo.workflow){
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.workflow,approvalQueueConstants.APPROVALSTATUS);
					}else if($scope.waiverInfo.foreCloseLADetails && $scope.waiverInfo.foreCloseLADetails.workflow){
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.foreCloseLADetails.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
					$scope.waiverInfo.initObj = _.findWhere($scope.waiverInfo.workflow,{workStatus:'INITIATED'});
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.waiverInfo.rejectedObj = _.findWhere($scope.waiverInfo.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
					getLinkedAgreementDetails();
				}
			});	
    	};
    	
 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			if($scope.requestObj.requestType !== 'FORECLOSURELA'){
				approvalQueueService.getUserAgreementList($stateParams.agreementNo, $scope.customerInfo.APPLICANT.cifID).then(function(data) {
					$scope.linkedAgrNos = data;
					var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos, {
						agreementNo : $stateParams.agreementNo
					}), 1);
					selectedAgr[0].isDefault = false;
					$scope.linkedAgrNos.unshift(selectedAgr[0]);
				});
			}
 			getWaiverDetails(); 			
 		}
		init();
		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.waiverInfo.rejectionReason){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}	
			var reqObj = {
				status : reqType,
				actionID : $scope.requestObj.approvalDetails.actionID,
				branchID : $scope.requestObj.branchId,
				agreementNos : $scope.waiverInfo.agreementNos,
				receiptNo : $scope.waiverInfo.receiptNo,
				waiverType : $scope.waiverInfo.waiverType,
				justification : $scope.waiverInfo.justification,
				customerBackground : $scope.waiverInfo.customerBackground,
				chargeDetails : approvalQueueService.getWaiverCharges(),
				majorVersion : $scope.waiverInfo.majorVersion,
				minorVersion : $scope.waiverInfo.minorVersion,
				requestID : $scope.waiverInfo.requestID,
				remarks : $scope.waiverInfo.rejectionReason,
				collectionType : $scope.waiverInfo.collectionType
			};
			var approvalService;
			if($scope.requestObj.requestType == 'FORECLOSURELA'){
				approvalService = 'FORECLOSURELA';
				reqObj = {
						status : reqType,
						actionID : $scope.requestObj.approvalDetails.actionID,
						branchID : $scope.requestObj.branchId,
						agreementNo : $scope.waiverInfo.foreCloseLADetails.agreementNo,						
						majorVersion : $scope.waiverInfo.foreCloseLADetails.majorVersion,
						minorVersion : $scope.waiverInfo.foreCloseLADetails.minorVersion,
						requestType : $scope.waiverInfo.foreCloseLADetails.requestType,
						remarks : $scope.waiverInfo.rejectionReason,
						requestID : $scope.requestObj.requestID,
						LAType : $scope.waiverInfo.foreCloseLADetails.LAType
				};				
			}else{
				approvalService = 'WAIVER';
			}
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.waiverInfo.initObj ? $scope.waiverInfo.initObj.comments : '';
			}
			approvalQueueService.handleRequest(reqObj,approvalService).then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
		
		$scope.showAgreementPopup = function(){
 			$modal.open({
					templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
					controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
						$scope.data = {};
						$scope.data.isViewOnly = data.isViewOnly;
						$scope.data.totalRecords = data.agreementNos;
						$scope.data.productType = data.productType;
						$scope.data.currentPage = 1;
						$scope.data.recordPerPage = 5;
						$scope.saveHandler = function(){
							$modalInstance.dismiss();
						};
						$scope.paginationHandler = function(pageNo){
							var startLen = $scope.data.recordPerPage * (pageNo-1);
							var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
							$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
						};
						$scope.paginationHandler(1);
						$scope.close = function(){
							$modalInstance.dismiss();
						};
					}],
					size : 'md',
					backdrop : 'static' ,
					windowClass : 'modal-custom',
					resolve: {
						data: function() {
		                    return {
		                    	agreementNos : $scope.linkedAgrNos,
		                    	isViewOnly : true,
								productType :$scope.customerInfo.productGroup
		                    };
		                }
					}
				});
 		};
 		
 		var escalateFn;
 		$scope.getNextlevelMgrs = function(){
 			var queryParams = {};
 			if($stateParams.requestType === 'FORECLOSURELA'){
 				queryParams.type = $scope.waiverInfo.foreCloseLADetails.LAType;
 			}else if($stateParams.requestType === 'FORECLOSURE' || $stateParams.requestType ==='NORMAL'){
 				queryParams.requestID  = $scope.requestObj.requestID;
 			}
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID,'',queryParams).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
 		};
 		
 	};

 	approvalQueue.controller('waiverController',['$scope','$modal','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus',waiverController]);
	return waiverController;
});