define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility) {
'use strict';

 	var repoRequestController = function($scope,$modal,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.selectedReqType = $stateParams.requestType;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.linkedAgrNos = [];
 		var getProvisionDetails = function(){
 			approvalQueueService.getProvisionDetails($stateParams.agreementNo,$scope.repoDetails.saleDetail.salesInitiationDetail.provisionAmount).then(function(data){
				if(data && Object.keys(data).length){
					$scope.repoDetails.sale = data;
				}
			});	
 		};
 		$scope.repoDate = new DatePickerConfig({    		 	
			value:'',
			maxDate:new Date(),
			readonly: true
		});	
 		
 		var fetchYardVendors = function(agreementNo){
 			approvalQueueService.getYardVendors(agreementNo).then(function(yardResponse){
				if(yardResponse && Object.keys(yardResponse).length){
					$scope.repoDetails.yardInfo = yardResponse;
					$scope.noRecords = false;
				}
				else{
					$scope.repoDetails.yardInfo = {};
					$scope.noRecords = true;
				}
			});
 		};
 		
 		var fetchRepoAgents = function(agreementNo){
 			$scope.repoDate.setDateVal(new Date($scope.repoDetails.proposedSurrenderExpense.repoDate));
 			approvalQueueService.getRepoAgents(agreementNo).then(function(agentResponse){
				if(agentResponse && agentResponse.length){
					$scope.repoDetails.repoAgents = agentResponse;
					$scope.noRecords = false;
					fetchYardVendors(agreementNo);
				}
				else{
					$scope.repoDetails.repoAgents = [];
					$scope.noRecords = true;
				}
			});
 		};
 		
 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			$scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
 			approvalQueueService.getRepoDetails($stateParams.agreementNo,$stateParams.requestType,$scope.requestObj.releaseletterType).then(function(data){
				if(data && Object.keys(data).length){
					$scope.repoDetails = data;
					$scope.repoDetails.repoType = constants.REPO_TYPES[$scope.repoDetails.repoType];
					$scope.repoDetails.requestBody = { agreementNo : $stateParams.agreementNo };
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.repoDetails.rejectedObj = _.findWhere($scope.repoDetails.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus,requestType:$stateParams.requestType});
					}	
	 				if($stateParams.requestType === 'SALEAPPROVAL'||$scope.requestObj.releaseletterType === 'SALE'){
	 					getProvisionDetails();
	 					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
							$scope.repoDetails.rejectedObj = _.findWhere($scope.repoDetails.saleDetail.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus,requestType:$stateParams.requestType});
						}
	 				}
	 				else if($stateParams.requestType === 'SURRENDEREXPENSE'){
	 					fetchRepoAgents($stateParams.agreementNo);
	 					$scope.repoDetails.initiatedObj = _.findWhere($scope.repoDetails.workflow,{workStatus:'INITIATED',requestType:$stateParams.requestType});
	 				}
				}
			});
 			approvalQueueService.getUserAgreementList($stateParams.agreementNo,$scope.customerInfo.APPLICANT.cifID).then(function(data) {
 				$scope.linkedAgrNos = data;
 				var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos,{agreementNo:$stateParams.agreementNo}),1);
 				selectedAgr[0].isDefault = false;
 				$scope.linkedAgrNos.unshift(selectedAgr[0]);
			});
 		}
		init();
		
		$scope.showAgreementPopup = function(){
 			$modal.open({
				templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.data = {};
					$scope.data.isViewOnly = data.isViewOnly;
					$scope.data.totalRecords = data.agreementNos;
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.saveHandler = function(){
						$modalInstance.dismiss();
					};
					$scope.paginationHandler = function(pageNo){
						var startLen = $scope.data.recordPerPage * (pageNo-1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function(){
						$modalInstance.dismiss();
					};
				}],
				size : 'md',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return {
	                    	agreementNos : $scope.linkedAgrNos,
	                    	isViewOnly : true,
							productType :$scope.customerInfo.productGroup
	                    };
	                }
				}
			});
 		};
 		
 		var submitRequest = function(reqObj){
 			approvalQueueService.handleRequest(reqObj,$stateParams.requestType).then(function(data){
 				if(data){
 					if($stateParams.requestType === 'SURRENDEREXPENSE') {
 						reqObj = reqObj[0];
 					}
					var successString = "";
					if(reqObj.status === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqObj.status.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
					
			});	
 		};
 		
		$scope.handleRequest = function(reqType){
			if(reqType === 'REJECTED' && !$scope.repoDetails.requestBody.remarks){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.requestObj.majorVersion;
			reqObj.minorVersion = $scope.requestObj.minorVersion;
			reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			reqObj.branchID = $scope.requestObj.branchId;
			if($stateParams.requestType === 'SURRENDEREXPENSE'){
				reqObj.agreementNo = $stateParams.agreementNo;
				reqObj.remarks = $scope.repoDetails.requestBody.remarks;
				reqObj.repoAgencyID = $scope.repoDetails.repoAgencyID;
				reqObj.parkingYardID = $scope.repoDetails.parkingYardID;
				reqObj.repoDate = $scope.repoDetails.repoDate;
				reqObj.totalSurrenderExpense = $scope.repoDetails.totalSurrenderExpense;
				reqObj.expenseDetails = $scope.repoDetails.expenseDetails;				
				reqObj = [reqObj];
			}
			else if($stateParams.requestType === 'RELEASELETTER'){
				reqObj.agreementNo = $stateParams.agreementNo;
				reqObj.remarks = $scope.repoDetails.requestBody.remarks;
				reqObj.releaseletterType = $scope.requestObj.releaseletterType;
			}
			else{
				reqObj = $scope.repoDetails.requestBody;				
				if($stateParams.requestType === 'SALEAPPROVAL' && reqType !== 'ESCALATE'){
					var highestQuote = '';
					_.each($scope.repoDetails.saleDetail.quotes,function(quote){
						if(quote.isSelected){
							highestQuote = quote;
							return;
						}
					});
					if(!highestQuote && reqType !== 'REJECTED'){
						dialogService.showAlert('Error', "Error", "Please select a quote to proceed");
						return;
					}
					if(highestQuote){
						reqObj.approvedSaleAmount = highestQuote.bidValue ;
						reqObj.buyerID = highestQuote.buyerID;
						reqObj.phoneNo = highestQuote.bidderPhoneNo;
						reqObj.auctionType = highestQuote.auctionType;
					}
				}
				reqObj.status = reqType;
				reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
				reqObj.branchID = $scope.requestObj.branchId;
				reqObj.majorVersion = $scope.requestObj.majorVersion;
				reqObj.minorVersion = $scope.requestObj.minorVersion;
			}
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.repoDetails.initiatedObj ? $scope.repoDetails.initiatedObj.comments : '';
			}
			if($stateParams.requestType === 'REPO' && $scope.linkedAgrNos.length>1 && reqType === 'RECOMMENDED'){
				dialogService.showAlert('Message', "Message", "The selected agreement belongs to a group account").result.then(function(){},function(){
					submitRequest(reqObj);
				});
			}
			else{
				submitRequest(reqObj);
			}
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('repoRequestController',['$scope','$modal','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus',repoRequestController]);
	return repoRequestController;
});