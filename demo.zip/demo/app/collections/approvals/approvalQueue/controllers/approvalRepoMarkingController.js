define(['require','approvalQueue', 'constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approvalRepoMarkingController = function($scope,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus,$rootScope){
 		$scope.markingLMSInfo = approvalQueueService.getSelectedRequest();
 		$scope.markingLMSInfo.branchName = approvalQueueService.getBranchName($scope.markingLMSInfo.branchId);
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestType = $stateParams.requestType;
 		$scope.markingLMSInfo.fcImageCheck=false;
 		$scope.markingLMSInfo.vehicleImageCheck=false;
 		$scope.actionId = $scope.markingLMSInfo.approvalDetails.actionID;
 		$scope.dispatcheTo = approvalQueueConstants.PARTYTYPE;
 		$scope.submitFlag = false;
 		var agreementInfo = approvalQueueService.getAgreementObj();
 		$scope.markingLMSInfo.chargeConstants=collectionConstants.MARKING_LMS_CHARGES; 		
 		$scope.dropDownValues = {}; 		
 		var initController = function(){
 			$scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
 	 		if(agreementInfo && agreementInfo.agreementNo){
 	 			$scope.customerInfo = utility.getCustomerInfo(agreementInfo);
 	 			$scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 	 		}
 		};
 		initController();
 		$scope.setInScope = function (name, signed_doc) {
			$scope[name] = signed_doc;
		};

 		var getMarkingLMSCaseDetails = function(){
 			approvalQueueService.getMarkingLMSCaseDetails($stateParams.reqStatus,$scope.customerInfo.agreementNo,$scope.requestType.toLowerCase()).then(function(response){
  				$scope.markingLMSInfo.markingLMSDetails = response ? response[0]:{};
  				$scope.markingLMSInfo.markingLMSDetails.repoDesc = _.findWhere(collectionConstants.NOTICE_MANAGEMENT_CONSTANTS.REPO_TYPES, {value : $scope.markingLMSInfo.markingLMSDetails.repoType});
  				var _status = $scope.markingLMSInfo.rowclass === 'req_rejected' ? 'REJECTED' : $scope.markingLMSInfo.rowclass === 'req_approved' ? 'APPROVED' : '';
  				var _workflow;
  				if(_status){
  					_workflow = _.where($scope.markingLMSInfo.markingLMSDetails.workflow, {workStatus : _status});
  					if(_workflow.length && _workflow[_workflow.length-1].expenseDetails){
	  					$scope.markingLMSInfo.markingLMSDetails.expenseDetails = _workflow[_workflow.length-1].expenseDetails;
	  				}
  				}
  				$scope.markingLMSInfo.markingLMSDetails.seizureCharge = $scope.markingLMSInfo.seizureCharge;
  				_.each($scope.markingLMSInfo.markingLMSDetails.expenseDetails, function(item){
  					item.chargeDesc = _.findWhere($scope.markingLMSInfo.chargeConstants,{chargeID:item.chargeID.toString()}).chargeDescription;
  				});
 				var _role = _.without(_.pluck($scope.markingLMSInfo.markingLMSDetails.vehicleDetail, 'entryType'),'REPO_AGENT','YARD_MANAGER');
  				$scope.markingLMSInfo.vehicleDocuments = _.findWhere($scope.markingLMSInfo.markingLMSDetails.vehicleDetail,{'entryType':_role[0]});
  				if($scope.markingLMSInfo.vehicleDocuments && $scope.markingLMSInfo.vehicleDocuments.vehicleImageRef){
  					$scope.markingLMSInfo.vehicleImageCheck=Object.keys($scope.markingLMSInfo.vehicleDocuments.vehicleImageRef).length>0 && $scope.markingLMSInfo.vehicleDocuments.vehicleImageRef.imagePathReferences;
  				}
  				if($scope.markingLMSInfo.vehicleDocuments && $scope.markingLMSInfo.vehicleDocuments.fintnessCertificateImageRef){
  					$scope.markingLMSInfo.fcImageCheck=Object.keys($scope.markingLMSInfo.vehicleDocuments.fintnessCertificateImageRef).length>0 && $scope.markingLMSInfo.vehicleDocuments.fintnessCertificateImageRef.imagePathReferences;
  				}
  				if($scope.markingLMSInfo.markingLMSDetails && $scope.markingLMSInfo.markingLMSDetails.workflow){
					var workflow = _.where($scope.markingLMSInfo.markingLMSDetails.workflow,{requestType:$scope.requestType}); 
 					$scope.markingLMSInfo.markingLMSDetails.remarksData = utility.getApprovalsRemarks(workflow,approvalQueueConstants.APPROVALSTATUS); 					
 				} 	 				
				$scope.markingLMSInfo.reInitiatFlag = ($scope.markingLMSInfo.approvalDetails.initiatedBy && ($scope.markingLMSInfo.approvalDetails.initiatedBy.userID === $rootScope.identity.userID || $scope.markingLMSInfo.approvalDetails.initiatedBy.userID === approvalQueueService.pageFields.tellerID));
				$scope.markingLMSInfo.markingLMSDetails.posComfort = false;
                if($scope.markingLMSInfo.markingLMSDetails && $scope.markingLMSInfo.markingLMSDetails.prinicipalPaidAmount && $scope.markingLMSInfo.markingLMSDetails.amountFinanced){
                    var posComfortValue = (($scope.markingLMSInfo.markingLMSDetails.prinicipalPaidAmount / $scope.markingLMSInfo.markingLMSDetails.amountFinanced) * 100 );
                    $scope.markingLMSInfo.markingLMSDetails.posComfort = (posComfortValue > 70);
                }
 			});
 		};
 		getMarkingLMSCaseDetails();
		 		
 		$scope.handleRequest = function(reqType,requestType){
			if(reqType === 'REJECTED' && !$scope.markingLMSInfo.markingLMSDetails.rejectionReason){
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = {};
			reqObj.agreementNo = $scope.customerInfo.agreementNo;					
			reqObj.status = reqType;
			reqObj.majorVersion = $scope.markingLMSInfo.markingLMSDetails.majorVersion;
			reqObj.minorVersion = $scope.markingLMSInfo.markingLMSDetails.minorVersion;
			reqObj.remarks = $scope.markingLMSInfo.markingLMSDetails.rejectionReason;
			reqObj.actionID = $scope.markingLMSInfo.approvalDetails.actionID;
			reqObj.branchID = $scope.markingLMSInfo.branchId;			
			if(requestType==='REPOMARKINGLMS'){
 				//reqObj.seizureCharge= $scope.markingLMSInfo.markingLMSDetails.yardDetail.seizureExpense;
 				//$scope.isBill ?	reqObj.isWithBill=true : reqObj.isWithBill=false;
 				reqObj.expenseDetails = $scope.markingLMSInfo.markingLMSDetails.expenseDetails;
 			}
 			if(requestType==='REPOWRONGMARKING'){
 				reqObj.allocationDPD = $scope.markingLMSInfo.markingLMSDetails.allocationDPD ? $scope.markingLMSInfo.markingLMSDetails.allocationDPD :'';
                reqObj.posComfort = $scope.markingLMSInfo.markingLMSDetails.posComfort;
			}
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.markingLMSInfo.markingLMSDetails.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.markingLMSInfo.approvalDetails.nextLevelAction];
				//$scope.isBill ?	reqObj.isWithBill=true : reqObj.isWithBill=false;
			}
			approvalQueueService.handleRequest(reqObj,requestType).then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
		var updateMgr;
 		$scope.getNextlevelMgrs = function(requestType){
 			var reqObj = {};
 			if(requestType==='REPOMARKINGLMS'){
 				//reqObj.seizureCharge = $scope.markingLMSInfo.markingLMSDetails.yardDetail.seizureExpense; 				
 				//reqObj.isWithBill = $scope.isBill;
 				reqObj.agreementNo = $scope.customerInfo.agreementNo;
 			}
 			if(requestType==='REPOWRONGMARKING'){
 				reqObj.allocationDPD= $scope.markingLMSInfo.markingLMSDetails.allocationDPD ? $scope.markingLMSInfo.markingLMSDetails.allocationDPD : '';
                reqObj.posComfort = $scope.markingLMSInfo.markingLMSDetails.posComfort;
			}
			approvalQueueService.getNextlevelMgrs(requestType,$scope.markingLMSInfo.approvalDetails.actionID,$scope.customerInfo.agrstatus.status,reqObj).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
						if(updateMgr){
							updateMgr();
						}
			 			updateMgr = messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.markingLMSInfo.markingLMSDetails.selectedManager = data;
			 				$scope.handleRequest('ESCALATE',requestType);
			 			},$scope);
					}
				}
			});
 		};

 		$scope.reInitiate = function(agreementNo){
 			$rootScope.isClickedViaMenu = false;
			lazyModuleLoader.loadState('collections.repoMarking',{agreementNo : agreementNo});
 		};
        $scope.reInitiateWrongRepoMarking = function(agreementNo){
            $rootScope.isClickedViaMenu = false;
            lazyModuleLoader.loadState('collections.wrongRepoMarking',{agreementNo : agreementNo,type : 'unmark',posComfort : $scope.markingLMSInfo.markingLMSDetails.posComfort});
        };
 	};
 	approvalQueue.controller('approvalRepoMarkingController',['$scope','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus','$rootScope',approvalRepoMarkingController]);
	return approvalRepoMarkingController;
});