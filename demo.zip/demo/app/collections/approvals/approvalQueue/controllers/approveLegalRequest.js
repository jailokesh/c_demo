define(['require','approvalQueue','constants','collectionConstants','utility','legalConstants','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,legalConstants,approvalQueueConstants) {
'use strict';

 	var approveLegalRequestController = function($scope,lazyModuleLoader,dialogService,approvalQueueService,messageBus,$modal,$stateParams,$globalScope){
 		try{
	 		$scope.financeStatus = constants.STATUS;
	 		$scope.allStatus = constants.AGREEMENT_STATUS;
	 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
	 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
	 		$scope.legalInitiatedInfo  = {};
	 		$scope.dropDownValues = {};
	 		$scope.dropDownValues.caseFiledAt = [{'name':'HO LEGAL'}];
	 		var agreementInfo = approvalQueueService.getAgreementObj();
	 		 $scope.availability ={borrower:false,coApplicant:false,guarantor:false,vehicle:false,property:false,isAvailable:false};
	 	//	var legalSelectedData = {};
	 		if(agreementInfo && agreementInfo.agreementNo){
	 			$scope.customerInfo = utility.getCustomerInfo(agreementInfo);
	 			$scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
	 			if ($scope.customerInfo.productGroup === 'HE' || $scope.customerInfo.productGroup === 'HL') {
					$scope.dropDownValues.sections = angular.copy(legalConstants.LEGAL_VALUES.SECTIONS_HEHL);
				} else {
					$scope.dropDownValues.sections = angular.copy(legalConstants.LEGAL_VALUES.SECTIONS);
				}
	 		}
	 		var fetchLegalDetails = function(agreementNo,cifID,count){
	 			approvalQueueService.getLegalAgreementDetails(agreementNo,cifID,count);
			};
			var getAvailability = function(questionnaire){
				$scope.availability.borrower =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.borowerID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.borowerID}).response ==='Yes')?true:false;
				$scope.availability.coApplicant =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.coApplicantID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.coApplicantID}).response ==='Yes')?true:false;
				$scope.availability.guarantor =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.guarantorID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.guarantorID}).response ==='Yes')?true:false;
				$scope.availability.vehicle =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.vehicleID}) && _.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.vehicleID}).response ==='Yes')?true:false;
				$scope.availability.property =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.propertyID}) && _.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.propertyID}).response ==='Yes')?true:false;
			};
		 
	 		var initController = function(){
	 			$scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
	 			$scope.dropDownValues.caseFiledAtReady = false;
	 			$scope.legalInitiatedInfo = approvalQueueService.getSelectedRequest();
	 			approvalQueueService.getLegalInitiatedInfo($scope.legalInitiatedInfo.agreementNo,$scope.legalInitiatedInfo.caseID).then(function(data){
	 				$scope.legalInitiatedInfo.legalData = data.legalData;
	 				$scope.legalInitiatedInfo.workflowUserDetails = data.workflowUserDetails;
	 				$scope.legalInitiatedInfo.legalData.initObj = _.findWhere($scope.legalInitiatedInfo.legalData.workflow,{workStatus:'INITIATED'});
	 				var caseFiledAtName = _.findWhere($scope.dropDownValues.caseFiledAt, {name :$scope.legalInitiatedInfo.legalData.caseToBeFiledAt});
					if(!caseFiledAtName){$scope.dropDownValues.caseFiledAt.push({name : $scope.legalInitiatedInfo.legalData.caseToBeFiledAt});}
					var documentToBeSendToName = _.findWhere($scope.dropDownValues.caseFiledAt, {name :$scope.legalInitiatedInfo.legalData.documentToBeSendTo});
					if(!documentToBeSendToName){$scope.dropDownValues.caseFiledAt.push({name : $scope.legalInitiatedInfo.legalData.documentToBeSendTo});}
	 				if($scope.legalInitiatedInfo.approvalDetails && $scope.legalInitiatedInfo.approvalDetails.currentStatus){
						if($scope.legalInitiatedInfo.approvalDetails.originalStatus === 'REJECTED'){
							if($scope.isPending){
								dialogService.showAlert('Alert','Alert','The legal request has been rejected. Kindly confirm/reject the action done.');
								$scope.legalInitiatedInfo.legalData.initObj = _.findWhere($scope.legalInitiatedInfo.legalData.workflow,{workStatus:'REJECTED'});
								$scope.legalInitiatedInfo.legalData.approvedObj = {};
							}else{
								$scope.legalInitiatedInfo.legalData.approvedObj = _.findWhere($scope.legalInitiatedInfo.legalData.workflow,{workStatus:'REJECTED'});
							}
						}else{
							$scope.legalInitiatedInfo.legalData.approvedObj = _.findWhere($scope.legalInitiatedInfo.legalData.workflow,{workStatus:$scope.legalInitiatedInfo.approvalDetails.currentStatus});
						}
					}
	 				if($scope.legalInitiatedInfo.legalData && $scope.legalInitiatedInfo.legalData.workflow){
	 					$scope.legalInitiatedInfo.remarksData = utility.getApprovalsRemarks($scope.legalInitiatedInfo.legalData.workflow,approvalQueueConstants.APPROVALSTATUS);
	 				}
					if($scope.legalInitiatedInfo.legalData.workflow[0].workStatus === 'ESCALATED')
						$scope.legalInitiatedInfo.legalData.workflow.shift();
	 				if($scope.legalInitiatedInfo.legalData.workflow[0].legalSections[0] && !_.findWhere($scope.dropDownValues.sections,{value:$scope.legalInitiatedInfo.legalData.workflow[0].legalSections[0]})){
	 					$scope.legalInitiatedInfo.legalData.workflow[0].legalSections.unshift('Others');
	 				}
	 				approvalQueueService.getUserAgreementList($scope.legalInitiatedInfo.agreementNo,$scope.customerInfo.APPLICANT.cifID,$scope.customerInfo.productGroup).then(function(data){
		 				$scope.dropDownValues.initiatedAgreements = [];
		 				var workFlowAgreements = $scope.legalInitiatedInfo.legalData.workflow[0].agreementNos;
		 				_.each(workFlowAgreements.reverse(),function(item){
		 					var agreementObj = _.findWhere(data,{agreementNo:item});
		 					var index = _.findIndex(data,{agreementNo:item});
		 					data.splice(index,1);
		 					if(agreementObj){
		 						agreementObj.selected = true;
		 						agreementObj.defaultAgreement = (agreementObj.agreementNo === $scope.legalInitiatedInfo.agreementNo);
		 						$scope.dropDownValues.initiatedAgreements.push(agreementObj);
		 						data.unshift(agreementObj);
		 					}
		 				});
		 				$scope.dropDownValues.initiatedAgreements.reverse();
		 				$scope.dropDownValues.userAgreements = angular.copy(data);		 				
						fetchLegalDetails($scope.legalInitiatedInfo.agreementNo,$scope.customerInfo.APPLICANT.cifID,$scope.dropDownValues.userAgreements.length-1);		 				
		 			});

	 				approvalQueueService.getCholaBranches().then(function(branches) {
						try {
							var name = _.findWhere(branches, {
								branchID : $scope.customerInfo.branchID
							}).branchDesc;
							var newName = _.findWhere($scope.dropDownValues.caseFiledAt, {name :name});
							if(!newName){
								$scope.dropDownValues.caseFiledAt.push({name : $scope.legalInitiatedInfo.legalData.documentToBeSendTo});
							}
						} catch (error) {
							return;
						}
					});
	 				approvalQueueService.getAgreementCases($scope.legalInitiatedInfo.agreementNo,$scope.legalInitiatedInfo.caseID).then(function(data) {
	 					$scope.agreementDetails = data;
	 					if($scope.agreementDetails.questionnaire && $scope.agreementDetails.questionnaire.length){
	 						getAvailability($scope.agreementDetails.questionnaire);
						}else{
							$scope.availability.isAvailable = true;
					 }
	 					
	 				});
	 				
	 			});
	 			
	 			if(!$scope.dropDownValues.isReadOnly){
		 			messageBus.onMsg("UPDATE_SELECTED_AGREEMENTS",function(event,data){
		 				$scope.dropDownValues.initiatedAgreements = data;
		 			},$scope);
		 			
		 			$scope.editHandler = function(){
		 				$scope.dropDownValues.isEdit = !$scope.dropDownValues.isEdit;
		 				approvalQueueService.getCholaBranchesByZone().then(function(zoneBranches){
		 					try{
		 						_.each(zoneBranches,function(item){
		 							var name = _.findWhere($scope.dropDownValues.caseFiledAt, {name :item.branchDesc});
		 							if(!name){
		 								$scope.dropDownValues.caseFiledAt.push({
										name : item.branchDesc
									});
		 							}
		 						});
		 					}catch(error){
		 						return;
		 					}
		 					$scope.dropDownValues.caseFiledAtReady = true;	
		 				});
			 		};
			 		
			 		
			 		$scope.removeItem = function(index,item){
			 			$scope.dropDownValues.initiatedAgreements.splice(index,1);
			 			_.findWhere($scope.dropDownValues.userAgreements,{agreementNo: item.agreementNo}).selected = false;
			 		};
			 		
			 		$scope.openPopUp = function(value){
			 			if(!value){
			 				return;
			 			}
						$modal.open({
							templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
							controller: ['$scope','data','$modal','$modalInstance','messageBus',function($scope,data,$modal,$modalInstance,messageBus){
								$scope.data = {};
								$scope.data.totalRecords = data;
								$scope.data.currentPage = 1;
								$scope.data.recordPerPage = 5;
								$scope.saveHandler = function(){
									messageBus.emitMsg("UPDATE_SELECTED_AGREEMENTS",_.where($scope.data.totalRecords,{selected:true}));
									$scope.close();
								};
								$scope.paginationHandler = function(pageNo){
									var startLen = $scope.data.recordPerPage * (pageNo-1);
									var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
									$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
								};
								$scope.paginationHandler(1);
								$scope.close = function(){
									$modalInstance.dismiss();
								};
							}],
							size : 'md',
							backdrop : 'static' ,
							windowClass : 'modal-custom',
							resolve: {
								data: function() {
				                    return  $scope.dropDownValues.userAgreements;
				                }
							}
						});
			 		};
			 		
	 			}
	 		};
	 		initController();
	 		
	 		$scope.getNextlevelMgrs = function(){
				approvalQueueService.getNextlevelMgrs('LEGALCASE',$scope.legalInitiatedInfo.approvalDetails.actionID,$scope.legalInitiatedInfo.agreementStatus).then(function(data){
					if(data){
						if(!data.length){
							dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
						}
						else{
							approvalQueueService.openUserPopup(data);
				 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
				 				$scope.legalInitiatedInfo.selectedManager = data;
				 				$scope.proceedLegalCase('ESCALATE');
				 			},$scope);
						}
					}
				});
	 		};
	 		
	 		$scope.proceedLegalCase = function(status,reInitiate){
	 			var legalSection = [];
	 			if(status !== 'REJECTED' && !$scope.legalInitiatedInfo.legalData.workflow[0].legalSections[0]){
	 				dialogService.showAlert('Error', "Error", "Please select a legal section");
	 				return;
	 			}
	 			if(status === 'REJECTED' && !$scope.legalInitiatedInfo.legalData.remarks){
	 				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
	 				return;
	 			}
	 			if(!$scope.dropDownValues.initiatedAgreements || $scope.dropDownValues.initiatedAgreements.length === 0){
	 				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NO_AGREEMENT_SELECTED);
	 				return;
	 			}
	 			if($scope.legalInitiatedInfo.legalData.workflow[0].legalSections[0] === 'Others'){
	 				legalSection.push($scope.legalInitiatedInfo.legalData.workflow[0].legalSections[1]);
	 			}
	 			else{
	 				legalSection.push($scope.legalInitiatedInfo.legalData.workflow[0].legalSections[0]);
	 			}
	 			var postObj =  {
	 				"caseID": $scope.legalInitiatedInfo.caseID,
		 		    "agreementNos": _.pluck($scope.dropDownValues.initiatedAgreements,'agreementNo'),
		 		    "caseToBeFiledAt": $scope.legalInitiatedInfo.legalData.caseToBeFiledAt,
		 		    "documentToBeSendTo": $scope.legalInitiatedInfo.legalData.documentToBeSendTo,
		 		    "remarks": $scope.legalInitiatedInfo.legalData.remarks,
		 		    "legalSections": legalSection,
		 		    "status": status,
		 		    "majorVersion" : $scope.legalInitiatedInfo.legalData.majorVersion,
		 		    "minorVersion" : $scope.legalInitiatedInfo.legalData.minorVersion,
		 		    "actionID" : $scope.legalInitiatedInfo.approvalDetails.actionID,
		 		    "branchID" : $scope.legalInitiatedInfo.branchId,
		 		    "agreementStatus" : $scope.legalInitiatedInfo.agreementStatus
	 		    };
	 			if(status === 'ESCALATE'){
	 				postObj.actionID = $scope.legalInitiatedInfo.selectedManager;
	 				postObj.levelChange = true;
	 				postObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.legalInitiatedInfo.approvalDetails.nextLevelAction];
	 				postObj.remarks = $scope.legalInitiatedInfo.legalData.initObj ? $scope.legalInitiatedInfo.legalData.initObj.comments : '';
				}
	 			if($scope.legalInitiatedInfo.approvalDetails.originalStatus === 'REJECTED'){
	 				if(status === 'REJECTED'){
	 					postObj.status = $scope.legalInitiatedInfo.approvalDetails.nextLevelAction=='RECOMMEND'?'RECOMMENDED':'APPROVED';
	 				}
	 				else{
	 					postObj.status = 'REJECTED';
	 				}
	 			}
	 			approvalQueueService.approveRejectLegalCase(postObj).then(function(data){
	 				if(data){
						var successString = "";
						if(status === 'ESCALATE'){
							successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
						}
						else{
							if(reInitiate){
								successString = "Request is Re-Initiated successfully";
							}else{
								successString = "Request is "+status.toLowerCase()+" successfully";
							}
							
						}
						dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
							approvalQueueService.updateInitiatedQueue(true);
						});
					}
					else{
						approvalQueueService.updateInitiatedQueue();
					}
	 			});
	 		};
	 		/** Bucket trend pop-up */
			$scope.bucketPop = function() {
				$modal.open({
					templateUrl : 'app/collections/legal/documentsQueue/partials/bucketTrendPopup.html',
					controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
						$scope.agreementBuckets = data.bucketTrends;
						$scope.close = function() {
							$modalInstance.close();
						};
					} ],
					size : 'md',
					backdrop : 'static',
					windowClass : 'modal-custom',
					resolve : {
						data : function() {
							return {
								bucketTrends : $scope.agreementDetails ? $scope.agreementDetails.bucketTrend :''
							};
						}
					}
				});
			};
 		}catch(error){
 			$scope.dropDownValues.isReadOnly = true;
 		}
 	};
 	
 	approvalQueue.controller('approveLegalRequestController',['$scope','lazyModuleLoader','dialogService','approvalQueueService','messageBus','$modal','$stateParams','$globalScope',approveLegalRequestController]);
	return approveLegalRequestController;
});
