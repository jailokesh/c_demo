/**
 * Represents a Approvals Controller.
 * 
 * @version v1.0 - 2014-01-29 The Chola finance All Rights Reserved.
 * @author Chola.
 */
define(['require','approvalQueue', 'collectionConstants'], function(r,approvalQueue,collectionConstants) {
'use strict';

 	var approvalRequestController = function($scope,$state,$stateParams,getUserZones,approvalQueueService){
 		var selectedAgr = approvalQueueService.getSelectedRequest();
		 $state.$current.data.headerText = 'Approvals - '+collectionConstants.REQUEST_TYPES[selectedAgr.requestType].title;
		 if($stateParams.requestType == "LEGALCASE"){
			$state.go('collections.approvalRequestFilterLegal',{reqStatus:$stateParams.reqStatus,requestType:$stateParams.requestType,agreementNo:$stateParams.agreementNo,caseID:$stateParams.caseID});
		 } else{
			$scope.requestPage = 'app/collections/approvals/approvalQueue/partials/'+collectionConstants.REQUEST_TYPES[selectedAgr.requestType].template+'.html';
		 }
 	};

 	approvalQueue.controller('approvalRequestController',['$scope','$state','$stateParams','getUserZones','approvalQueueService',approvalRequestController]);
	return approvalRequestController;
});