/* Date : 29-Mar-2017
Modified by : Saranya Sankar R
Modification details : CR- Book Request Approvals */

define(['require','approvalQueue', 'constants','collectionConstants'], function(r,approvalQueue,constants,collectionConstants) {
'use strict';

 	var receiptBookController = function($scope,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus,$rootScope){
 		$scope.requestDetails = approvalQueueService.getSelectedRequest();
 		$scope.requestDetails.branchName = approvalQueueService.getBranchName($scope.requestDetails.branchId);
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestType = $stateParams.requestType;
 		$scope.actionId = $scope.requestDetails.approvalDetails.actionID;
 		$scope.submitFlag = false;
 		var getReceiptBookReqs = function(){
 			approvalQueueService.getReceiptBookReqs($scope.requestType,$stateParams.reqStatus).then(function(response){
 				$scope.receiptBooks = [];
 				_.each(response.data,function(item){
 					if(item.requestType && item.requestType!==$scope.requestType){
 						return;
 					}
 					if($scope.requestType === 'RECEIPTBOOKISSUANCE' || $scope.requestType === 'RECEIPTBOOKREQUEST'){
						var index = _.findLastIndex(item.workflow,{workStatus:'INITIATED'});
						if($stateParams.reqStatus === 'APPROVED'){
							index = _.findLastIndex(item.workflow,{workStatus:'APPROVED'});
						}
						if($stateParams.reqStatus === 'REJECTED'){
							index = _.findLastIndex(item.workflow,{workStatus:'REJECTED'});
						}
						item.remarks = "";
						item.initObj = item.workflow[index];
					}
 					if($stateParams.reqStatus === 'PENDING'){
 						if(item.workflow[0] && (item.workflow[0].workStatus === 'INITIATED'||item.workflow[0].workStatus === 'RECOMMENDED')){
 							item.initObj = item.workflow[0];
 						}
 					}
 					else{
 					    if(item.workflow[0]){
 					    	if(item.workflow[0].workStatus === 'APPROVED'||item.workflow[0].workStatus === 'REJECTED'){
 					    		item.initObj = item.workflow[1];
 	 					    	item.rejectObj = item.workflow[0];
 					    	}
 					    	else{
 					    		item.initObj = item.workflow[0];
 					    	}
 					    }
 					}
 					if($stateParams.reqStatus === 'PENDING' && item.workflow[0].workStatus !== 'APPROVED' && item.workflow[0].workStatus !== 'REJECTED'){
 						$scope.receiptBooks.push(item);
 					}
 					else if($stateParams.reqStatus === 'APPROVED' && (item.workflow[0].workStatus === 'APPROVED' || item.workflow[0].workStatus === 'REJECTED' || item.workflow[0].workStatus === 'RECOMMENDED')){
 						$scope.receiptBooks.push(item);
 					}
 					else if($stateParams.reqStatus === 'INITIATED'){
 						$scope.receiptBooks.push(item);
 					}
 				});
 			});
 		};
 		getReceiptBookReqs();
 		var selectedBooks;
 		$scope.enableSubmit = function(){
 			$scope.canEscalate = false;
 			var selectedRows = _.where($scope.receiptBooks,{isSelected:true});
 			$scope.requestDetails.checkAll = selectedRows.length === $scope.receiptBooks.length;
 			$scope.submitFlag = selectedRows.length ? true : false;
 			if(selectedRows.length === 1){
 				$scope.canEscalate = true;
 				selectedBooks = selectedRows[0];
 			}
 		};
 		
 		$scope.checkAllRows = function(event){
 			$scope.submitFlag = event.target.checked;
 			_.each($scope.receiptBooks,function(book){
 				book.isSelected = event.target.checked;
 			});
 			$scope.canEscalate = false;
 		};
 		
 		$scope.handleRequest = function(reqStatus){
 			if(reqStatus==='REJECTED'){
 				for(var index=0;index<$scope.receiptBooks.length;index++){
 	 				if($scope.receiptBooks[index].isSelected&&!$scope.receiptBooks[index].remarks)
 	 				{
 	 					dialogService.showAlert('Error!', "Error!", "Remarks is required for rejection");
 	 					return;
 	 				}
 	 			}
 			}
 			if(reqStatus === 'ESCALATE'){
 				selectedBooks.actionId = $scope.requestDetails.selectedManager;
 				selectedBooks.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestDetails.approvalDetails.nextLevelAction];
 				selectedBooks.remarks = selectedBooks.initObj ? selectedBooks.initObj.comments : '';
 				selectedBooks = [selectedBooks];
 			}
 			else{
 				selectedBooks = $scope.receiptBooks;
 			}
 			approvalQueueService.postReceiptBookReq(selectedBooks,reqStatus,$scope.requestType,$scope.actionId,$scope.requestDetails.branchId).then(function(data){
 				if(data){
					var successString = "";
					if(reqStatus === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqStatus.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
 			});
 		};
 		
 		$scope.getNextlevelMgrs = function(){
 			if(selectedBooks.workflow[0].workStatus	=== 'APPROVED' || selectedBooks.workflow[0].workStatus	=== 'REJECTED'){
 				dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.REQUEST_HANDLED);
 				return;
 			}
			approvalQueueService.getNextlevelMgrs($scope.requestType,$scope.actionId).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestDetails.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 		$scope.getBranchStocks = function(productType,totalBooks,selectedBranch){
 			/* Total count Books Details */
							
				var resolve = {
	 					data: function() {
	 						return {
	 							productType : productType,
	 							totalBooks : totalBooks,
	 							branchID :selectedBranch
	 							};
	 					}
	 			};
	 			var controller = ['$scope', '$modalInstance', 'data',function($scope, $modalInstance, data) { 
	 				$scope.branchID = data.branchID;
	 				$scope.bookTotalRecord = data.totalBooks;
	 				$scope.productTypes = $rootScope.identity.productDetails;
		 			$scope.selectedProductType = data.productType;	
	 		    	$scope.close = function() {
	 		            $modalInstance.dismiss();
	 		        };
	 		        
	 		        $scope.maxSize = constants.PAGINATION_CONFIG.MAX_SIZE_FIVE;
	 				$scope.maxRecordPerPage = constants.PAGINATION_CONFIG.MAX_SIZE_TEN;
	 				$scope.currentPage = 1;
	 				$scope.offset = 1;
	 				$scope.offsetlast = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
	 				$scope.getStocks = function(){
	 					approvalQueueService.getStockList($scope.currentPage,$scope.selectedProductType,$scope.branchID).then(function(data){
	 						$scope.totalRecord = (data.meta && data.meta.totalCount) ? parseInt(data.meta.totalCount) : 0;
	 						$scope.bookTotalRecord = $scope.totalRecord - (data.data[0].damagelostusedcount ? data.data[0].damagelostusedcount:0);
	 						$scope.booksDetails = data.data[0].stocks;
	 						$scope.offset = ((($scope.currentPage-1)*10)+1);	
	 						$scope.offsetlast = (($scope.offset+10)>$scope.totalRecord) ? $scope.totalRecord : $scope.offset+9;
	 					});
	 				};
	 				$scope.getStocks();
	 		        $scope.paginationHandler = function(pageNum){
	 		        	$scope.currentPage = pageNum;
	 		        	if(!$scope.selectedProductType){
	 						delete searchObj.product;
	 					}
	 		        	$scope.getStocks();
	 		        };
	 		        
	 				$scope.productChange = function(){
	 				
	 					if(!$scope.selectedProductType){
	 						delete searchObj.product;
	 					}
	 					$scope.currentPage = 1;
	 					$scope.getStocks();
	 					
	 				};
	 			}];
	 			var callback = function(result) {
	 				//$scope.vendorDetails.vendorList = result.data;
	 			};
	 			dialogService.showCustomDialog('app/collections/receiptBookHO/hoStock/partials/stockBooksAllottedPopup.html',controller, resolve, callback, 'md', 'modal-custom');		 			
	 		};
 		
 	};

 	approvalQueue.controller('receiptBookController',['$scope','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus','$rootScope',receiptBookController]);
	return receiptBookController;
});