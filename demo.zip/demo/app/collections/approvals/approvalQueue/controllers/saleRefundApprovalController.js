define([ 'require', 'approvalQueue', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility', 'approvalQueueConstants' ], function(r, approvalQueue, constants, DatePickerConfig, collectionConstants, utility, approvalQueueConstants) {
	'use strict';

	var saleRefundApprovalController = function($scope, $modal, $stateParams, approvalQueueService, dialogService, lazyModuleLoader, $globalScope, messageBus,$rootScope) {
		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
		$scope.isPending = $stateParams.reqStatus === 'PENDING' ? true : false;
		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
		
		$scope.requestObj = approvalQueueService.getSelectedRequest();
		$scope.waiverInfo = {};
		$scope.linkedAgrNos = [];

		function init() {
		
			approvalQueueService.getSaleRefundDetails($scope.requestObj.agreementNo, $scope.requestObj.receiptNo).then(function(data) {
				if (data && data.length) {
					$scope.refundReceiptDetails = data[0].receiptDetail;
					$scope.isRejected = $scope.refundReceiptDetails && $scope.refundReceiptDetails.workflow && $scope.refundReceiptDetails.workflow.length && $scope.refundReceiptDetails.workflow[0].workStatus  == "REJECTED";
					
					if ($scope.refundReceiptDetails.workflow) {
						$scope.refundReceiptDetails.remarksData = utility.getApprovalsRemarks($scope.refundReceiptDetails.workflow, approvalQueueConstants.APPROVALSTATUS);					
					}
					$scope.reInitiatFlag = $scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.initiatedBy&& ($scope.requestObj.approvalDetails.initiatedBy.userID === $rootScope.identity.userID);
				}
			});

			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
				status : $scope.customerInfo.agreementStatus
			});
			
				approvalQueueService.getUserAgreementList($stateParams.agreementNo, $scope.customerInfo.APPLICANT.cifID).then(function(data) {
					$scope.linkedAgrNos = data;
					var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos, {
						agreementNo : $stateParams.agreementNo
					}), 1);
					selectedAgr[0].isDefault = false;
					$scope.linkedAgrNos.unshift(selectedAgr[0]);
				});
				
		}
		init();

		$scope.initiateRequest = function(reqType) {	

			if (reqType === 'REJECTED' && !$scope.refundReceiptDetails.rejectionReason) {
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}	
			var emdAmount = ($scope.refundReceiptDetails.emdAmount)? parseInt($scope.refundReceiptDetails.emdAmount) : 0;
			var reqObj = {
				//'actionID' : $scope.requestObj.approvalDetails.actionID,
				'agreementNo' : $scope.refundReceiptDetails.agreementNos[0],
				'receiptNo' : $scope.refundReceiptDetails.receiptNo,
				'branchID' : $scope.requestObj.branchId,
				'productType' : $scope.refundReceiptDetails.productType,
				'majorVersion' : $scope.refundReceiptDetails.majorVersion,
				'minorVersion' : $scope.refundReceiptDetails.minorVersion,
				'status' : reqType,
				'remarks' : $scope.refundReceiptDetails.rejectionReason,
				'buyerID' : $scope.refundReceiptDetails.payerID,
				'buyerName':  $scope.refundReceiptDetails.buyerName,
				'amountPaid': $scope.refundReceiptDetails.amountPaid,
				'emdAmount': $scope.refundReceiptDetails.emdAmount,
				'approvedSaleAmount': $scope.refundReceiptDetails.amountPaid + emdAmount
			};

			if (reqType === 'ESCALATE') {
				reqObj.levelChange = true;
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.refundReceiptDetails.initObj ? $scope.refundReceiptDetails.initObj.comments : '';
			}else{
				reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			}						


				approvalQueueService.initiateSaleRefundRequest(reqObj).then(function(response) {

						if (response) {
							var successString = "";
							if (reqType === 'ESCALATE') {
								successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
							} else {
								successString = "Sale Refund is " + reqType.toLowerCase() + " successfully";
							}
							dialogService.showAlert('Success', "Success", successString).result.then(function() {
							}, function() {
								approvalQueueService.updateInitiatedQueue(true);
							});
						} else {
							approvalQueueService.updateInitiatedQueue();
						}	

				});

		};
        $scope.reInitiateSaleRefund = function(agreementNo){
            $globalScope.isClickedViaMenu = false;
            lazyModuleLoader.loadState('collections.reInitiateRequest',{reqType : "saleRefund",agreementNo:agreementNo});
        };
		
		var escalateFn;
		$scope.getNextlevelMgrs = function() {
			var queryParams = {};
			approvalQueueService.getNextlevelMgrs($stateParams.requestType, $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {
				if (data) {
					if (!data.length) {
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					} else {
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.initiateRequest('ESCALATE');
						}, $scope);
					}
				}
			});
		};

	};

	approvalQueue.controller('saleRefundApprovalController', [ '$scope', '$modal', '$stateParams', 'approvalQueueService', 'dialogService', 'lazyModuleLoader', '$globalScope', 'messageBus','$rootScope', saleRefundApprovalController ]);
	return saleRefundApprovalController;
});