/* Date : 21-Jan-2019
Modified by : OFS
Modification details : Advocate CR- Book Request Approvals */

define(['require','approvalQueue', 'constants','collectionConstants','utility','legalConstants','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,legalConstants,approvalQueueConstants) {
    'use strict';
    var advocateLegalRequestController = function($scope,$q,lazyModuleLoader,dialogService,approvalQueueService,repoFilterFactory,masterService,messageBus,$modal,$stateParams,$rootScope,appFactory,$globalScope) {
        var agreementInfo = approvalQueueService.getAgreementObj();
        // console.log('approvalQueueService.getAgreementObj()'  agreementInfo);
        $scope.data={
            checkALM:true,
            autoCases:[],
            disableInitiateBulk:true,
            selectedAgreement:[],
            sectionConstants:collectionConstants.NOTICE_MANAGEMENT_CONSTANTS.LEGAL_ACTION_OPTIONS,
            source:"LEGAL",
            limit:10,
            pageNo:1,
            offset: 1,
            offsetLast: constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE,
            totalRecord: 0,
            maxRecordPerPage:10,
            checkAllDisabled:false,
            sectionCheck : legalConstants.SECTION_CHECK,
            mainMenu:{groupOne:[],groupTwo:[]}
        };
       
        $scope.requestType = $stateParams.requestType;
        $scope.redirectToLegalInitiation = function(){
            lazyModuleLoader.loadState('collections.legalInitiation');
        };
        var initFilter = function () {
            $scope.data.amountType = "";
            $scope.data.mainMenu.groupOne=angular.copy(collectionConstants.LEGAL_FILTER1);
            $scope.data.mainMenu.groupTwo=angular.copy(collectionConstants.LEGAL_FILTER2);
            if (!$scope.data.vehicleGroup) {
                approvalQueueService.getVehicleGroup().then(function (data) {
                    $scope.data.vehicleGroup = data;
                    _.findWhere($scope.data.mainMenu.groupOne, {
                        value: "vehicleCategory"
                    }).subMenu = angular.copy($scope.data.vehicleGroup);
                });
            }
            _.findWhere($scope.data.mainMenu.groupOne, {value: "vehicleCategory"}).subMenu = angular.copy($scope.data.vehicleGroup);
            _.findWhere($scope.data.mainMenu.groupOne, {value: "productCategory"}).subMenu.unshift({label: "All",value: "All",selected: false});
            _.findWhere($scope.data.mainMenu.groupOne, {value: "paymentPattern"}).subMenu.unshift({label: "All",value: "All",selected: false});
            _.findWhere($scope.data.mainMenu.groupOne, {value: "seasoning"}).subMenu.unshift({label: "All",value: "All",selected: false});
            // _.findWhere($scope.data.mainMenu.groupOne, {value: "allocationDPD"}).subMenu.unshift({label: "All",value: "All",selected: false});
        };
        var loginDetails = function (queryObj) {
            queryObj = queryObj || {};
            switch ($rootScope.identity.hierarchyName.toUpperCase()) {
                case 'TELLER':
                    queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
                    break;
                case 'BRM':
                    queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
                    break;
                case 'ARM':
                    queryObj.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
                    break;
                case 'ALM':
                    queryObj.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
                    break;  
                case 'RRM':
                    queryObj.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
                    break;
                case 'RLM':
                    queryObj.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
                    break;  
                case 'ZRM':
                    queryObj.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
                    break;
                default:
                    queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;                   
                    break;
            }
            return queryObj;
        };
        
        var globalRequestObj,tempObj={};
        $scope.filterPopup = {
            onOpen: function (contentData) {
                contentData.options = $scope.data.mainMenu;
                contentData.options.amountTypeList=collectionConstants.AMT_TYPE_LEGAL_OPTIONS;
                contentData.options.dropDownValue=$scope.data.selectedItem;
                tempObj=contentData.options;
            },
            checkboxAlert: function (subItemValue, subItem, subItemSelected) {
                repoFilterFactory.checkboxAlert(subItemValue, subItem, subItemSelected, $scope.data.mainMenu.groupOne);
            },          
            setAllCheckBoxes: function (selected, arrValues) {
                repoFilterFactory.setAllCheckBoxes(selected, arrValues);
            },
            setCheckBoxes: function (selected, arrValues) {
                repoFilterFactory.setCheckBoxes(selected, arrValues);
            },
			legalConfirmCheck : function (event, categoryName, index) {			
				var string = "You have un selected " + categoryName + " category of cases and the said category will be included in the legal initiation list. Are you sure you want to initiate legal action for " + categoryName + " category of cases also";			
				if(!event.target.checked){
					dialogService.confirm(collectionConstants.REPO_MSG.CONFIRM, collectionConstants.REPO_MSG.CONFIRM, string).result.then(function (data) {				
						event.target.checked = false;												
					}, function () {
						event.preventDefault();	
						event.target.checked = true;	
						$scope.data.mainMenu.groupTwo[index].subMenu.selected = true;	
						//_.findWhere($scope.data.mainMenu.groupTwo, {label: categoryName}).subMenu.selected = true;	
							
					});						
				}			
			},		            
            filter: function () {       
                // if($scope.data.selectedItem=='Initiate Legal - Bulk'){
                    var queryObj = repoFilterFactory.filterLegalCases($scope.data.mainMenu);
                    queryObj.amountCategory= tempObj.amountType;
                    queryObj.ruleAmountMinimum= tempObj.minAmount;
                    queryObj.ruleAmountMaximum= tempObj.maxAmount;
                    queryObj.productGroup = $scope.dropDownValues.selectedProductType ? $scope.dropDownValues.selectedProductType :'VF';

                    var minMax = repoFilterFactory.validateMinMaxValue(queryObj.ruleAmountMinimum, queryObj.ruleAmountMaximum, "amount Rule");
                    if(tempObj.amountType && (!tempObj.minAmount || !tempObj.maxAmount)){
                        dialogService.showAlert("WARNING","WARNING",collectionConstants.ERROR_MSG.MIN_MAX_MANDATORY_MSG);
                        return;
                    };
                    if(queryObj && minMax){
                        console.log($scope.caseList);
                        globalRequestObj = queryObj;
                        approvalQueueService.getZoneFromBrAreaRgnID().then(function(result){
                            queryObj.zoneID = result[0].ZoneID; 
                            if($rootScope.identity.hierarchyName.toUpperCase()=='ZRM' || $rootScope.identity.hierarchyName.toUpperCase()=='ZLM'){
                               queryObj = loginDetails(queryObj); 
                            }
                            console.log(queryObj.zoneID);
                            approvalQueueService.filterLegalCases(queryObj).then(function(result){
                                $scope.caseList  =$scope.data.paginationList =[];
                                $scope.data.agreementDetails = result; 
                                var agrFilteredData = _.pluck($scope.data.agreementDetails,'agreementNo');
                                 
                                var agrApprovalData = _.pluck(globalCaseList,'agreementNo');
                                 
                                var matchedAgrData = _.intersection(agrFilteredData,agrApprovalData); 
                                
                                var newCaseList = [];
                                _.each(matchedAgrData,function(item){
                                    newCaseList.push(_.findWhere(globalCaseList,{'agreementNo':item}));
                                });
                                $scope.caseList  =[];
                                $scope.caseList  = newCaseList;
                                if($scope.caseList.length >0){
                                    setCaseList();
                                }                                
                            });
                        
                        });
                         // $scope.paginate(1);
                        if (typeof $scope.filterPopup.close === 'function') {
                            $scope.filterPopup.close();
                        }
                    }
                // }else if($scope.data.selectedItem=='Initiate Legal - Shortfall'){
                //     var queryObj={};    
                //     if(tempObj.AVminAmount){
                //         queryObj.avLossMin = tempObj.AVminAmount;
                //         queryObj.avLossMax = tempObj.AVmaxAmount;
                //     }else if(tempObj.BVminAmount){
                //         queryObj.bvLossMin = tempObj.BVminAmount;
                //         queryObj.bvLossMax = tempObj.BVmaxAmount;
                //     }                   
                // }                   
            },
            resetAndClose: function () {
                $scope.filterPopup.close();
            },
            resetAll: function (contentData) {
                initFilter();
                contentData.options = $scope.data.mainMenu;
            }
        };


        var getAllZones = function(){
            masterService.getAreas({},'zone').then(function(userZones) {
                serviceObj.locations.branchDetails.zones = userZones;
                masterService.getAreas({}, 'region').then(function(userRegions) {
                    serviceObj.locations.branchDetails.filteredRegions = serviceObj.locations.branchDetails.regions = userRegions;
                    masterService.getAreas({},'area').then(function(userAreas) {
                        serviceObj.locations.branchDetails.filteredAreas = serviceObj.locations.branchDetails.areas = userAreas;
                        masterService.getBranches({}).then(function(userBranches) {
                            serviceObj.locations.branchDetails.filteredBranch = serviceObj.locations.branchDetails.branches = userBranches;
                            $scope.zones = serviceObj;
                            return  $scope.zones;
                        });
                    });
                });
            });
        };
        $scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
        $scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');

        $scope.legalInitiatedInfo  = {};
        $scope.dropDownValues = {
            docDisLocListBulkAll:angular.copy(legalConstants.DOCUMENT_DISPATCH_LOCATION),
            caseFileLocListBulkAll:angular.copy(legalConstants.CASE_FILING_LOCATION)
        };
        $scope.availability ={borrower:false,coApplicant:false,guarantor:false,vehicle:false,property:false,isAvailable:false};

        if (agreementInfo && agreementInfo.agreementNo) {
            $scope.customerInfo = utility.getCustomerInfo(agreementInfo);
            $scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
            $scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {status: $scope.customerInfo.agreementStatus});
        }

        var setCaseList = function(){
             $scope.allocatedbranch =  $scope.caseList.length >0 && _.find($scope.caseList, function(num){ return (num && num.allocatedAlmSittingBranchDesc!=''); }) ? _.find($scope.caseList, function(num){ return num.allocatedAlmSittingBranchDesc!=''; }).allocatedAlmSittingBranchDesc : '';
             _.each($scope.caseList, function(item){                    
                    item.remarksList=[];
                    var legalCaseWf = _.where(item.workflow,{requestType:'LEGALADVOCATECHANGE'});
                    item.wf = legalCaseWf[legalCaseWf.length-1];
                    item.isDisabled = false;
                    if($scope.isInitiated){
                        if(item.wf && item.wf.workStatus!='APPROVED'){
                            item.isDisabled = true;
                            if(item.caseID == $stateParams.caseID){
                                item.selected = true;
                                $scope.selectCheckBox();
                            }else{
                                item.isDisabled = true;
                            }
                        }
                        $scope.data.checkAllDisabled = true;
                    }
                    item.caseFilingDisabled=false;item.documentDisabled=false;item.recepientDisabled=false;
                    if(item.caseToBeFiledAt){item.caseFilingDisabled = true;}
                    if(item.documentToBeSendTo){item.documentDisabled = true;}
                    if(item.mandatoryFields && item.mandatoryFields.recepientName){item.recepientDisabled = true;}
                    if(item.wf && (item.wf.workStatus=='APPROVED' || item.wf.workStatus=='REJECTED')){
                        item.isDisabled = true;
                    }   
                    if(item.mandatoryFields && item.mandatoryFields.recepientName){
                        item.recepientName = item.mandatoryFields.recepientName;
                    }
                    _.each(legalCaseWf,function(subItem){
                        if(subItem.comments && ( (subItem.workStatus=='INITIATED' && subItem.levelCode=='R0') || subItem.workStatus=='REJECTED' || subItem.workStatus=='APPROVED' || subItem.workStatus=='RECOMMENDED')){
                            item.remarksList.push({'comments':subItem.comments,'color':subItem.workStatus=='RECOMMENDED'? 'orange':subItem.workStatus=='APPROVED'?'green':subItem.workStatus=='REJECTED'?'red':'black'});
                        }
                    });
                    if(item.wf && item.wf.legalSections[0]){
                    item.sectionName = item.wf.legalSections[0].replace(/_/g, " ");
                    }
                    item.caseFileLoc = item.docDisLoc=item.caseFileLocID=item.docDisLoc='';

                    $scope.dropDownValues.caseFileLocListBulkAll.length==1 ? $scope.dropDownValues.caseFileLocListBulkAll.push($scope.allocatedbranch):'';                            
                    if($scope.dropDownValues.caseFileLocListBulkAll.length>=2){
                        $scope.dropDownValues.caseFileLocListBulkAll.pop();$scope.dropDownValues.caseFileLocListBulkAll.push($scope.allocatedbranch);
                    }
                    $scope.dropDownValues.docDisLocListBulkAll.length ==1 ? $scope.dropDownValues.docDisLocListBulkAll.push($scope.allocatedbranch):'';              
                    if($scope.dropDownValues.docDisLocListBulkAll.length>=2){
                        $scope.dropDownValues.docDisLocListBulkAll.pop();$scope.dropDownValues.docDisLocListBulkAll.push($scope.allocatedbranch);             
                    }
                    item.docDisLocList=angular.copy(legalConstants.DOCUMENT_DISPATCH_LOCATION);
                    item.caseFileLocList=angular.copy(legalConstants.CASE_FILING_LOCATION);
                    item.caseFileLocList.length ==1 ? item.caseFileLocList.push(item.allocatedAlmSittingBranchDesc):'';              
                    if(item.caseFileLocList.length>=2){
                        item.caseFileLocList.pop();item.caseFileLocList.push(item.allocatedAlmSittingBranchDesc);                
                    }
                    item.docDisLocList.length ==1 ? item.docDisLocList.push(item.allocatedAlmSittingBranchDesc):'';              
                    if(item.docDisLocList.length>=2){
                        item.docDisLocList.pop();item.docDisLocList.push(item.allocatedAlmSittingBranchDesc);              
                    }
                    item.caseFileLoc = item.docDisLoc=item.allocatedAlmSittingBranchDesc;
                    item.caseFileLocID =item.docDisLocID = item.allocatedAlmSittingBranchID;
                    
                    if(item.caseToBeFiledAt == '3' && item.documentToBeSendTo == '3'){                        
                        item.caseFilingLocation = item.documentDispatchLocation ='HO_LEGAL';
                    }else if(item.caseToBeFiledAt == '3' && item.documentToBeSendTo == 'DOCNOTREQ'){
                        item.caseFilingLocation ='HO_LEGAL'; item.documentDispatchLocation ='DOCNOTREQ';
                        item.docDisLocID = item.docDisLoc ='DOCNOTREQ';
                        if(item.docDisLoc =='DOCNOTREQ'){
                            item.docNotReq = true;
                            // if( _.every($scope.caseList,function(listItem){return listItem.docNotReq}) ){
                            //     $scope.data.docNotReqAll = true;
                            // }
                        }
                        if(item.docDisLocList.length>=2){
                            item.docDisLocList.pop();
                            item.docDisLocList.push(item.docDisLoc);                                                                        
                        }
                    }else if(!item.caseToBeFiledAt || !item.documentToBeSendTo){
                        item.caseToBeFiledAt = '';item.documentToBeSendTo = '';

                    }else{                        
                        if($scope.zones && $scope.zones.locations && $scope.zones.locations.branchDetails && $scope.zones.locations.branchDetails.filteredBranch  && $scope.zones.locations.branchDetails.filteredBranch.length>0){
                           
                            var caseFiled = (_.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.caseToBeFiledAt}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.caseToBeFiledAt}).branchDesc) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.caseToBeFiledAt}).branchDesc :"";
                            var docDisPatched = item.documentToBeSendTo=='DOCNOTREQ' ? 'DOCNOTREQ': ((_.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.documentToBeSendTo}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.documentToBeSendTo}).branchDesc) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch, {'branchID':item.documentToBeSendTo}).branchDesc :"");
                            item.caseFileLocList.length ==1 ? item.caseFileLocList.push(caseFiled):'';              
                            if(item.caseFileLocList.length>=2){
                                item.caseFileLocList.pop();item.caseFileLocList.push(caseFiled);                
                            }
                            item.docDisLocList.length ==1 ? item.docDisLocList.push(docDisPatched):'';              
                            if(item.docDisLocList.length>=2){
                                item.docDisLocList.pop();item.docDisLocList.push(docDisPatched);              
                            }
                            item.caseFilingLocation = caseFiled; item.documentDispatchLocation = docDisPatched;                            
                            item.caseFileLocID = item.caseToBeFiledAt;item.caseFileLoc = caseFiled;
                            item.docDisLocID = item.documentToBeSendTo;item.docDisLoc = docDisPatched;
                            if(docDisPatched =='DOCNOTREQ'){
                                item.docNotReq = true;
                                // if( _.every($scope.caseList,function(listItem){return listItem.docNotReq}) ){
                                //     $scope.data.docNotReqAll = true;
                                // }
                            }
                        }
                    }
                $scope.legalInitiatedInfo.legalData = item;
                $scope.legalInitiatedInfo.workflowUserDetails = _.findLastIndex(item.workflow,{requestType:'LEGALADVOCATECHANGE'});                
                    
                $scope.dropDownValues.documentDispatchLocationAll = $scope.dropDownValues.caseFilingLocationAll ='';
                item.isRecommended=item.recommendedSittingLocationDesc=item.recommendedSittingLocationID = '';
                var recommendedSittingDetails =  _.findWhere(item.recommendedSittingData,{"section":item.wf.legalSections[0]});
                if(recommendedSittingDetails && !item.caseFilingDisabled && !item.documentDisabled && !$scope.isInitiated){
                    // item.caseFilingLocation= item.allocatedAlmSittingBranchDesc;
                    item.isRecommended = recommendedSittingDetails.isRecommended;
                    item.recommendedSittingLocationDesc = recommendedSittingDetails.recomSittingLocDesc;
                    item.recommendedSittingLocationID = recommendedSittingDetails.recommendedSittingLocation;                    
                    // item.documentDispatchLocation= item.isRecommended ? item.recommendedSittingLocationDesc: item.allocatedAlmSittingBranchDesc;
                    item.docDisLocList.length ==1 ? item.docDisLocList.push(item.allocatedAlmSittingBranchDesc) :'';              
                    if(item.docDisLocList.length>=2){
                        item.docDisLocList.pop();
                        if(item.isRecommended){
                            item.docDisLocList.push(item.recommendedSittingLocationDesc);
                            // item["documentDispatchLocation"] =item.docDisLoc = item.recommendedSittingLocationDesc;item.docDisLocID = item.recommendedSittingLocationID;
                        }else{
                            item.docDisLocList.push(item.allocatedAlmSittingBranchDesc);
                            // item["documentDispatchLocation"] = item.docDisLoc = item.allocatedAlmSittingBranchDesc;item.docDisLocID = item.allocatedAlmSittingBranchID;
                        }                                            
                    }
                }  
                
            });
            $scope.paginate(1);
            $scope.selectSingleDropDown($scope.caseList[0].caseFilingLocation,'caseFilingLocation','caseFilingLocationAll','caseFileLoc','caseFileLocID');
            $scope.selectSingleDropDown($scope.caseList[0].documentDispatchLocation,'documentDispatchLocation','documentDispatchLocationAll','docDisLoc','docDisLocID');
            $scope.selectSingleLocation('docDisLoc',{'branchID':$scope.caseList[0].docDisLocID,'branchDesc':$scope.caseList[0].docDisLoc},'docDisLocAll');
            $scope.selectSingleLocation('caseFileLoc',{'branchID':$scope.caseList[0].caseFileLocID,'branchDesc':$scope.caseList[0].caseFileLoc},'caseFileLocAll');
                
        }
        var globalCaseList = [];
        var initController = function(){
            $scope.zones = getAllZones();
            $scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
            $scope.dropDownValues.caseFiledAtReady = false;
            $scope.legalInitiatedInfo = approvalQueueService.getSelectedRequest();
            $scope.showReason = $stateParams.reqStatus=='APPROVED';
             $scope.reInitiatFlag = $scope.legalInitiatedInfo.approvalDetails && $scope.legalInitiatedInfo.approvalDetails.initiatedBy&& ($scope.legalInitiatedInfo.approvalDetails.initiatedBy.userID === $rootScope.identity.userID);
            approvalQueueService.getLegalInitiatedInfo($stateParams.reqStatus, $stateParams.requestType).then(function(data){
               if(data.length>0){    
                    $scope.caseList = data;
                    $scope.data.checkAll = false;  
                    if($scope.caseList.length>0){              
                        var clickedCase = _.findWhere($scope.caseList,{'caseID':$stateParams.caseID});
                        $scope.caseList = _.reject($scope.caseList, function(num){ return num.caseID == $stateParams.caseID; });
                        if(clickedCase){
                            $scope.caseList.unshift(clickedCase);                 
                        }
                        globalCaseList = $scope.caseList;
                        setCaseList();             
                    }
                }
            })
            initFilter();
        };
        initController();

        //selecting single row of a table
        $scope.selectCheckBox = function(checked,key,sKey){
            var selectAll = true;
            _.each($scope.caseList, function(item){
                if (!item[key]) {
                    selectAll=false;
                }
            });
            $scope.data[sKey] = selectAll;
            $scope.data.selectedAgreement = _.pluck(_.where($scope.caseList, {
                'selected': true
            }),"caseID");
            $scope.data.selectedLegalInfo = (_.where($scope.caseList, {
                'selected': true
            }));
        };
        $scope.selectAll =function(checked,key,sKey){
            $scope.data[key] = checked;
            _.each($scope.caseList, function (item) {
                // if(item.isDisabled){
                    // item[sKey] = false;
                    // $scope.data[key] = false;
                // }else{
                    item[sKey] = checked;
                // }    
                // if(key=='docNotReqAll'){
                //     if(!item.caseToBeFiledAt){
                //         item[sKey]=true;
                //     }
                // }else{
                //     item[sKey]=true;
                // }
            });
            $scope.data.selectedAgreement = _.pluck(_.where($scope.caseList, {
                'selected': true
            }),"caseID");
        };
        $scope.paginate = function (pageNo) {
            var startLen = $scope.data.maxRecordPerPage * (pageNo - 1);
            var endLen = $scope.data.maxRecordPerPage + ($scope.data.maxRecordPerPage * (pageNo - 1));
            $scope.data.paginationList = $scope.caseList.slice(startLen, endLen);
            $scope.data.offset = $scope.data.maxRecordPerPage * (pageNo - 1) + 1;
            $scope.data.offsetLast = (pageNo * $scope.data.maxRecordPerPage < $scope.caseList.length) ? pageNo * $scope.data.maxRecordPerPage : $scope.caseList.length;
            if($scope.data.checkAll){
                $scope.selectAll($scope.data.checkAll,'checkAll','selected');
            }
        };      
       $scope.selectAllDropDown = function(selectedValue,keyName,addKey,newKey){
            
            _.each($scope.caseList,function(item){
                if(selectedValue && selectedValue!='HO_LEGAL'){
                    if(!item.caseFilingDisabled && keyName == 'caseFilingLocation'){
                        if(item.caseFileLocList.length>=2){
                            item.caseFileLocList.pop();item.caseFileLocList.push(selectedValue);item["caseFilingLocation"] = selectedValue;
                            item.caseFileLoc = selectedValue;item.caseFileLocID = (_.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':selectedValue}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':selectedValue}).branchID) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':selectedValue}).branchID :"";                           
                            item.docDisLocList.pop();
                            if(item.isRecommended){
                                item.docDisLocList.push(item.recommendedSittingLocationDesc);item["documentDispatchLocation"] =item.docDisLoc = item.recommendedSittingLocationDesc;item.docDisLocID = item.recommendedSittingLocationID;
                            }else{
                                item.docDisLocList.push(item.allocatedAlmSittingBranchDesc);item["documentDispatchLocation"] = item.docDisLoc = item.allocatedAlmSittingBranchDesc;item.docDisLocID =item.allocatedAlmSittingBranchID;
                            }
                            if($scope.dropDownValues.docDisLocListBulkAll.length>=2){
                                $scope.dropDownValues.docDisLocListBulkAll.pop();
                                if(_.every($scope.caseList, function(item){return $scope.caseList[0].documentDispatchLocation && item['documentDispatchLocation']==$scope.caseList[0].documentDispatchLocation;}) ){
                                    $scope.dropDownValues.docDisLocListBulkAll.push($scope.caseList.documentDispatchLocation);$scope.dropDownValues['documentDispatchLocationAll'] = $scope.dropDownValues.docDisLocAll = $scope.caseList[0].documentDispatchLocation;$scope.dropDownValues.docDisLocAllID = $scope.caseList[0].docDisLocID;
                                }else{
                                    $scope.dropDownValues.docDisLocListBulkAll.push(item.allocatedAlmSittingBranchDesc); $scope.dropDownValues['documentDispatchLocationAll'] = $scope.dropDownValues.docDisLocAll = '';$scope.dropDownValues.docDisLocAllID = '';            
                                }
                                // if(item.isRecommended){
                                //     $scope.dropDownValues.docDisLocListBulkAll.push(item.recommendedSittingLocationDesc);$scope.dropDownValues['documentDispatchLocationAll'] = $scope.dropDownValues.docDisLocAll = item.recommendedSittingLocationDesc;$scope.dropDownValues.docDisLocAllID = item.recommendedSittingLocationID;
                                // }else{
                                //     $scope.dropDownValues.docDisLocListBulkAll.push(item.allocatedAlmSittingBranchDesc); $scope.dropDownValues['documentDispatchLocationAll'] = $scope.dropDownValues.docDisLocAll = item.allocatedAlmSittingBranchDesc;$scope.dropDownValues.docDisLocAllID = item.allocatedAlmSittingBranchID;            
                                // }                               
                            }
                            if($scope.dropDownValues.caseFileLocListBulkAll.length>=2){
                                $scope.dropDownValues.caseFileLocListBulkAll.pop();$scope.dropDownValues.caseFileLocListBulkAll.push(selectedValue);
                            }
                            $scope.dropDownValues['caseFilingLocationAll'] = selectedValue;
                            $scope.dropDownValues.caseFileLocAll = item.allocatedAlmSittingBranchDesc;$scope.dropDownValues.caseFileLocAllID = ( _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':item.allocatedAlmSittingBranchDesc}) &&  _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':item.allocatedAlmSittingBranchDesc}).branchID) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':item.allocatedAlmSittingBranchDesc}).branchID :"";
                        }                       
                    }                   
                }
                else if(!item.caseFilingDisabled){
                    item["caseFilingLocation"] = item['documentDispatchLocation'] = selectedValue;$scope.dropDownValues['documentDispatchLocationAll'] = selectedValue;
                }               

            }); 
        };
        var setAllReceipient =  function(item){
            //_.each(dataList,function(item){
                if(item.caseFilingLocation && item.documentDispatchLocation && item.caseFilingLocation!='HO_LEGAL' && item.documentDispatchLocation!='DOCNOTREQ'){
                    item.recepientName = item.allocatedAlmUser;
                    if(item.workflow && item.workflow.length>0 && item.workflow[0].legalSections && item.workflow[0].legalSections.length >0 && item.workflow[0].legalSections[0] && item.workflow[0].legalSections[0] != ""){
                        var recommendedSittingDetail =  (item.branchID ? _.findWhere(item.recommendedSittingData,{"section":item.workflow[0].legalSections[0],branchID:item.branchID}) :"");
                        if(recommendedSittingDetail){
                            if(recommendedSittingDetail.isRecommended){
                                item.recepientName = recommendedSittingDetail.recomAlmUser;
                            }
                        }
                    }
                }else{
                    item.recepientName = '';
                }
           // });
        };
        $scope.selectSingleDropDown = function(singleValue,singleKeyName,allKeyName,addKey,newKey,caseID,flag){
            if(caseID){
                var temp = _.findWhere($scope.caseList,{'caseID':caseID});
                if(singleValue && singleValue!='HO_LEGAL'){
                    if(singleKeyName=='documentDispatchLocation'){
                        temp.docDisLocList.pop();
                        temp.docDisLocList.push(singleValue);
                        temp.documentDispatchLocation = singleValue;
                        temp.docDisLoc=singleValue;temp.docDisLocID = (singleValue=='DOCNOTREQ') ? singleValue : ((_.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}).branchID) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}).branchID :"");                      
                    }else{
                        if(!flag){                      
                            temp.docDisLocList.pop();
                            if(temp.isRecommended){
                                temp.docDisLocList.push(temp.recommendedSittingLocationDesc);   
                                temp.documentDispatchLocation = temp.docDisLoc= temp.recommendedSittingLocationDesc;
                                temp.docDisLocID = temp.recommendedSittingLocationID;
                            }else{
                                temp.docDisLocList.push(temp.allocatedAlmSittingBranchDesc);
                                temp.documentDispatchLocation =temp.docDisLoc= temp.allocatedAlmSittingBranchDesc;
                                temp.docDisLocID = temp.allocatedAlmSittingBranchID;
                            }                           
                        }
                        $scope.dropDownValues['caseFilingLocationAll']=singleValue;
                        if( _.every($scope.caseList, function(item){return item['caseFilingLocation']==singleValue;}) ){
                            if($scope.dropDownValues.caseFileLocListBulkAll.length>=2){
                                $scope.dropDownValues.caseFileLocListBulkAll.pop();$scope.dropDownValues.caseFileLocListBulkAll.push(singleValue);
                            }
                            $scope.dropDownValues['caseFilingLocationAll']=singleValue;
                            $scope.dropDownValues.caseFileLocAll = singleValue;$scope.dropDownValues.caseFileLocAllID = _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}).branchID;
                        }else{
                            $scope.dropDownValues['caseFilingLocationAll'] ='';
                            $scope.dropDownValues.caseFileLocAll = '';$scope.dropDownValues.caseFileLocAllID = '';
                        }
                    }   
                    if( _.every($scope.caseList, function(item){return $scope.caseList[0].documentDispatchLocation && item['documentDispatchLocation']==$scope.caseList[0].documentDispatchLocation;}) ){
                        if($scope.dropDownValues.docDisLocListBulkAll.length>=2){
                            $scope.dropDownValues.docDisLocListBulkAll.pop();$scope.dropDownValues.docDisLocListBulkAll.push($scope.caseList[0].documentDispatchLocation);             
                        }
                        $scope.dropDownValues['documentDispatchLocationAll']=$scope.caseList[0].documentDispatchLocation;
                        $scope.dropDownValues.docDisLocAll = $scope.caseList[0].documentDispatchLocation;$scope.dropDownValues.docDisLocAllID = ((_.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':temp.allocatedAlmSittingBranchDesc}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':temp.allocatedAlmSittingBranchDesc}).branchID) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':temp.allocatedAlmSittingBranchDesc}).branchID :"");
                    }else{                      
                        $scope.dropDownValues['documentDispatchLocationAll'] = '';
                        $scope.dropDownValues.docDisLocAll='';$scope.dropDownValues.docDisLocAllID = '';
                    }
                }else{
                    if(_.findWhere($scope.caseList,{'caseID':caseID})){
                        _.findWhere($scope.caseList,{'caseID':caseID}).documentDispatchLocation = singleValue;
                    }
                    if( _.every($scope.caseList, function(item){return item['caseFilingLocation']=='HO_LEGAL';}) ){
                        $scope.dropDownValues['documentDispatchLocationAll']='HO_LEGAL';$scope.dropDownValues['caseFilingLocationAll']='HO_LEGAL';
                    }else{
                        $scope.dropDownValues['documentDispatchLocationAll'] = '';$scope.dropDownValues['caseFilingLocationAll']='';$scope.dropDownValues.docDisLocAll = $scope.dropDownValues.caseFileLocAll = '';
                    }
                }
                setAllReceipient(temp);
            }
            if(singleValue && _.every($scope.caseList, function(item){return item['documentDispatchLocation']==singleValue;}) ){                   
                if(singleValue != 'HO_LEGAL' && $scope.dropDownValues.docDisLocListBulkAll.length>=2){
                    $scope.dropDownValues.docDisLocListBulkAll.pop();$scope.dropDownValues.docDisLocListBulkAll.push(singleValue);             
                }
                $scope.dropDownValues['documentDispatchLocationAll']=singleValue;$scope.dropDownValues.docDisLocAll = singleValue;
                if(singleValue == 'HO_LEGAL'){
                    $scope.dropDownValues.docDisLocAllID = collectionConstants.HO_BRANCH_ID;
                }else{
                    $scope.dropDownValues.docDisLocAllID = singleValue =='DOCNOTREQ' ? 'DOCNOTREQ': _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}).branchID;
                }
            }else{
                $scope.dropDownValues['documentDispatchLocationAll'] ='';
                $scope.dropDownValues.docDisLocAll = '';$scope.dropDownValues.docDisLocAllID = '';
            }
            if(singleKeyName !='documentDispatchLocation'){
                    if(singleValue && _.every($scope.caseList, function(item){return item['caseFilingLocation']==singleValue;}) ){
                        if(singleValue != 'HO_LEGAL' && $scope.dropDownValues.caseFileLocListBulkAll.length>=2){
                            $scope.dropDownValues.caseFileLocListBulkAll.pop();$scope.dropDownValues.caseFileLocListBulkAll.push(singleValue);
                        }
                        $scope.dropDownValues['caseFilingLocationAll']=singleValue;$scope.dropDownValues.caseFileLocAll = singleValue;
                        if(singleValue == 'HO_LEGAL'){
                            $scope.dropDownValues.caseFileLocAllID = collectionConstants.HO_BRANCH_ID;
                        }else{
                            $scope.dropDownValues.caseFileLocAllID = singleValue =='DOCNOTREQ'?'DOCNOTREQ': _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':singleValue}).branchID;
                        }
                    }else{
                        $scope.dropDownValues['caseFilingLocationAll'] ='';
                        $scope.dropDownValues.caseFileLocAll = '';$scope.dropDownValues.caseFileLocAllID = '';
                    }
                }
            // } 

            if( _.every($scope.caseList, function(item){return $scope.caseList[0].documentDispatchLocation && item['documentDispatchLocation']==$scope.caseList[0].documentDispatchLocation;}) ){
                if($scope.dropDownValues.docDisLocListBulkAll.length>=2){
                    $scope.dropDownValues.docDisLocListBulkAll.pop();$scope.dropDownValues.docDisLocListBulkAll.push($scope.caseList[0].documentDispatchLocation);             
                    $scope.dropDownValues['documentDispatchLocationAll']=$scope.caseList[0].documentDispatchLocation; $scope.dropDownValues.docDisLocAll = $scope.caseList[0].documentDispatchLocation;   
                    if($scope.caseList[0].documentDispatchLocation=='HO_LEGAL'){
                        $scope.dropDownValues.docDisLocAllID =collectionConstants.HO_BRANCH_ID;
                    }else if($scope.caseList[0].documentDispatchLocation=='DOCNOTREQ'){
                        $scope.dropDownValues.docDisLocAllID = 'DOCNOTREQ';
                    }else{
                        $scope.dropDownValues.docDisLocAllID = (( _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].documentDispatchLocation}) && _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].documentDispatchLocation}).branchID) ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].documentDispatchLocation}).branchID :"");
                    }                   
                }
                // $scope.dropDownValues['documentDispatchLocationAll']=$scope.caseList[0].documentDispatchLocation; $scope.dropDownValues.docDisLocAll = $scope.caseList[0].documentDispatchLocation;   $scope.dropDownValues.docDisLocAllID = $scope.caseList[0].documentDispatchLocation =='DOCNOTREQ'? 'DOCNOTREQ' :  _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].documentDispatchLocation}).branchID;
            }else{                      
                $scope.dropDownValues['documentDispatchLocationAll'] = '';
                $scope.dropDownValues.docDisLocAll='';$scope.dropDownValues.docDisLocAllID = '';
            }  

            if( _.every($scope.caseList, function(item){return $scope.caseList[0].caseFilingLocation && item['caseFilingLocation']==$scope.caseList[0].caseFilingLocation;}) ){
                if($scope.dropDownValues.caseFileLocListBulkAll.length>=2 && $scope.caseList[0].caseFilingLocation !='HO_LEGAL'){
                    $scope.dropDownValues.caseFileLocListBulkAll.pop();$scope.dropDownValues.caseFileLocListBulkAll.push($scope.caseList[0].caseFilingLocation);             
                    $scope.dropDownValues['caseFilingLocationAll']=$scope.caseList[0].caseFilingLocation; $scope.dropDownValues.caseFileLocAll = $scope.caseList[0].caseFilingLocation;  
                    if($scope.caseList[0].caseFilingLocation =='DOCNOTREQ'){
                         $scope.dropDownValues.caseFileLocAllID = 'DOCNOTREQ';
                    }else{
                        $scope.dropDownValues.caseFileLocAllID = $scope.caseList[0].caseFilingLocation ? _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].caseFilingLocation}).branchID :'';
                    }
                }
                if ($scope.caseList[0].caseFilingLocation =='HO_LEGAL') {
                    $scope.dropDownValues.caseFileLocAllID = collectionConstants.HO_BRANCH_ID;
                }
                // $scope.dropDownValues['caseFilingLocationAll']=$scope.caseList[0].caseFilingLocation; $scope.dropDownValues.caseFileLocAll = $scope.caseList[0].caseFilingLocation;   $scope.dropDownValues.caseFileLocAllID = $scope.caseList[0].caseFilingLocation =='DOCNOTREQ'? 'DOCNOTREQ' :  _.findWhere($scope.zones.locations.branchDetails.filteredBranch,{'branchDesc':$scope.caseList[0].caseFilingLocation}).branchID;
            }else{                      
                $scope.dropDownValues['caseFilingLocationAll'] = '';
                $scope.dropDownValues.caseFileLocAll='';$scope.dropDownValues.caseFileLocAllID = '';
            }   
        }; 
        //method to show popup when caseFiling/documentDispatch Location is set to LOCAL for selecting branch Name
        $scope.showLocationPopup = function(header,singleAllCheck,key,skey,caseID,addKey,isDispLoc){
            if(singleAllCheck=='All'){
                for(var index=0;index<$scope.caseList.length;index++){
                    if($scope.caseList[index].caseFilingLocation){
                        // dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.ERROR_MSG.CASE_DOC_HOLEGAL);
                        return;
                    }
                }
            }

            $modal.open({
                templateUrl: 'app/collections/legal/legalAutomation/partials/selectLocation.html',
                controller : 'selectLocController',
                backdrop: 'static',
                size: 'lg',
                resolve: {
                    data: function () {
                        return {
                            header: header,
                            zones: $scope.zones,
                            isDispLoc : isDispLoc ? isDispLoc :false
                        };
                    }
                }
            }).result.then(function () {}, function (value) {
                if(value && value!="escape key press"){
                    if(singleAllCheck=='All'){
                        if(key =='docDisLocAll'){
                            $scope.data.docNotReqAll = false;
                            _.each($scope.caseList ,function(subItem){
                                subItem.docNotReq = false;
                            });
                        }   
                        $scope.selectAllLocation(key,value,skey,addKey,key=='docDisLocAll' ? 'docDisLocList':'caseFileLocList',key=='docDisLocAll' ? 'documentDispatchLocation':'caseFilingLocation',key=='docDisLocAll' ? 'docDisLocListBulkAll':'caseFileLocListBulkAll',key=='docDisLocAll' ? 'documentDispatchLocationAll':'caseFilingLocationAll');
                    }else{
                        if(key=='docDisLoc'){
                            $scope.data.docNotReqAll = false;
                            _.findWhere($scope.caseList,{"caseID":caseID}).docNotReq = false;
                        }   
                        $scope.selectSingleLocation(key,value,skey,caseID,addKey,singleAllCheck,key=='docDisLoc' ? 'docDisLocList':'caseFileLocList',key=='docDisLoc' ? 'documentDispatchLocation':'caseFilingLocation',key=='docDisLoc' ? 'docDisLocListBulk':'caseFileLocListBulk',key=='docDisLoc' ? 'documentDispatchLocation':'caseFilingLocation',key=='docDisLoc' ? 'documentDispatchLocationAll':'caseFilingLocationAll');
                    }
                }
            });
        };


        var serviceObj ={
            locations:{
                branchDetails:{
                    zones:[],
                    filteredRegions:[],
                    filteredAreas :[],
                    filteredBranch:[]
                }
            }
        };


        //method for selecting All rows's casefiling/documentDispatch Location branch Name(Map-Marker icon)
        $scope.selectAllLocation = function(key,value,skey,addKey,listKey,modelKey,allListKey,allmodelKey){
            $scope.dropDownValues[key] =value.branchDesc;
             _.each($scope.caseList,function(item){
                if(item.caseFilingLocation){
                    item[skey] = value.branchDesc;
                    item[addKey] = value.branchID;
                    if(item[listKey].length>=2){
                        item[listKey].pop();item[listKey].push(value.branchDesc);
                        item[modelKey] = value.branchDesc;
                        $scope.dropDownValues[allListKey].pop();$scope.dropDownValues[allListKey].push(value.branchDesc);
                        $scope.dropDownValues[allmodelKey] = value.branchDesc;
                    }
                }                    
            });
        };
        //method for selecting single rows's casefiling/documentDispatch Location branch Name(Map-Marker icon)
        $scope.selectSingleLocation = function(key,value,skey,caseID,addKey,singleAllCheck,listKey,modelKey,sModelKey,allListKey,allmodelKey){  
            if(caseID){
                var temp = _.findWhere($scope.caseList,{"caseID":caseID});
                _.findWhere($scope.caseList,{"caseID":caseID})[key] = value.branchDesc;
                _.findWhere($scope.caseList, {"caseID":caseID})[addKey] = value.branchID;                                                     
                if(temp[listKey].length>=2){
                    temp[listKey].pop();
                    temp[listKey].push(value.branchDesc);
                    temp[modelKey] = value.branchDesc;
                   $scope.selectSingleDropDown(value.branchDesc,modelKey,allmodelKey,key,addKey,caseID,'flag');
                }                    
            }
            if(_.every($scope.caseList,function(item){return item[modelKey]==value.branchDesc;})){
                $scope.dropDownValues[skey]=value.branchDesc;
                $scope.dropDownValues[addKey]=value.branchID;
            }else{
                $scope.dropDownValues[skey]='';
                $scope.dropDownValues[addKey]='';
            }                      
        };
        $scope.proceedLegalCase = function(status){
            var legalSection = [];
            var postArray = [];
            var repoArray = [];
            var postObj = {};
            var agrList = _.where($scope.caseList,{selected:true});
            var queryObj=[];
            for(var i=0;i<agrList.length;i++){  
                if((!agrList[i].caseFilingLocation && !$scope.isInitiated) || (agrList[i].caseFilingLocation && agrList[i].caseFilingLocation !='HO_LEGAL' && !agrList[i].caseFileLoc)){
                    dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.ERROR_MSG.CHOOSE_CASE_LOC);
                    queryObj=[];break;
                }else if((!agrList[i].documentDispatchLocation && !$scope.isInitiated) || (agrList[i].documentDispatchLocation && agrList[i].documentDispatchLocation !='HO_LEGAL' && !agrList[i].docDisLoc)){
                    dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.ERROR_MSG.CHOOSE_DOC_LOC);
                    queryObj=[];break;
                }else if(!$scope.isInitiated && agrList[i].documentDispatchLocation && agrList[i].documentDispatchLocation !='HO_LEGAL' && agrList[i].documentDispatchLocation !='DOCNOTREQ' && !agrList[i].mandatoryFields.recepientName){
                    dialogService.showAlert(collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.POPUP_HEADER.MESSAGE_STRING, collectionConstants.ERROR_MSG.RECEPIENT_MANDATORY);
                    queryObj=[];break;
                }else if(status === 'REJECTED' && agrList[i].selected && !agrList[i].remarks){
                    dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
                    queryObj=[];break;                
                }else{
                    queryObj.push(agrList[i]);
                }
            }
            if(queryObj.length>0){
                _.each(queryObj,function (item) {                  
                    if(item.currentValues.npaStageID != collectionConstants.OTHERS.REPO_MARKED){
                        postObj =  {
                        "caseID": item.caseID,
                        "agreementNos":[item.agreementNo],
                        "caseToBeFiledAt": item.caseFilingLocation=='HO_LEGAL' || !item.caseFilingLocation ? item.caseFilingLocation : item.caseFileLocID,
                        "documentToBeSendTo": item.documentDispatchLocation=='HO_LEGAL' || !item.documentDispatchLocation ? item.documentDispatchLocation : item.docDisLocID,
                        "remarks":  item.remarks,
                        "legalSections": [item.workflow[item.workflow.length-1].legalSections[0]],
                        "status": status,
                        "majorVersion" : item.majorVersion,
                        "minorVersion" : item.minorVersion,
                        "actionID" : $scope.legalInitiatedInfo.approvalDetails.actionID,
                        "branchID" : $scope.legalInitiatedInfo.branchId,
                        "agreementStatus" : item.agreementDetailsHistory[item.agreementDetailsHistory.length-1].agreementStatus,
                        "workflow":item.workflow,
                        "agreementDetailsHistory":item.agreementDetailsHistory,
                        "legalQADetails":item.legalQADetails,
                        "mandatoryFields":item.mandatoryFields
                    };
                    if(postObj.caseToBeFiledAt =='HO_LEGAL'){
                        postObj.caseToBeFiledAt =collectionConstants.HEAD_OFFICE_BRANCH_ID;
                    }else if(!postObj.caseToBeFiledAt){
                        postObj.caseToBeFiledAt = "";
                    }
                    if(postObj.documentToBeSendTo =='HO_LEGAL'){
                        postObj.documentToBeSendTo =collectionConstants.HEAD_OFFICE_BRANCH_ID;
                        postObj.caseFilledAtHo = true;
                    }else if(!postObj.documentToBeSendTo){
                        postObj.documentToBeSendTo ="";
                    }
                    if(item.caseFilingLocation == 'LOCAL'){
                        postObj.mandatoryFields = {'recepientName':item.recepientName};
                    }
                    if(status === 'ESCALATE'){
                        postObj.actionID = $scope.legalInitiatedInfo.selectedManager;
                        postObj.levelChange = true;
                        postObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.legalInitiatedInfo.approvalDetails.nextLevelAction];
                        postObj.remarks = item.wf.comments
                    }
                    if($scope.legalInitiatedInfo.approvalDetails.originalStatus === 'REJECTED'){
                        if(status === 'REJECTED'){
                            postObj.status = $scope.legalInitiatedInfo.approvalDetails.nextLevelAction=='RECOMMEND'?'RECOMMENDED':'APPROVED';
                        }
                        else{
                            postObj.status = 'REJECTED';
                        }
                    }
                    if(typeof $scope.data.reinitiateRemarks != 'undefined'){
                        postObj.mandatoryFields.deviationRemarks = $scope.data.reinitiateRemarks;
                        postObj.agreementNos = [$scope.data.reinitiateAgreement];
                    }
                    postArray.push(postObj);   
                    }else{
                        repoArray.push(item.agreementNo);
                    }
                                      
                });
                if(repoArray && repoArray.length > 0 && status !== 'REJECTED'){
                    dialogService.showAlert(collectionConstants.ERROR_MSG.ERROR_MESSAGE, collectionConstants.ERROR_MSG.ERROR_MESSAGE, "Can't proceed Agreements ("+repoArray.toString() +" ) with NPA stage REPO.Only Rejection allowed for this cases.");
                    return;
                }else{
                    approvalQueueService.approveRejectLegalCase(postArray).then(function(data){
                    if(data){
                        var successString = "";
                        if(status === 'ESCALATE'){
                            successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
                        }
                        else{
                            successString = "Request is "+status.toLowerCase()+" successfully";
                        }
                        var reInitiateCheck = $scope.checkReinitiateValidate(data,'failedCases');
                        if(reInitiateCheck && data.isReInit){
                            var response = data;
                            $scope.showErrorPopup(data); 
                        }else{
                            dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
                                approvalQueueService.updateInitiatedQueue(true);
                            });      
                        }
                    }
                    else{
                        approvalQueueService.updateInitiatedQueue();
                    }
                });
                }

                
            }   
        };

       $scope.checkReinitiateValidate = function(data,variable){
            var logicalData = false;
            if(typeof data[variable] !== 'undefined'){
                if(data[variable].length > 0 ){
                    logicalData = true;
                }
            }
            return logicalData;
       };
        $scope.getNextlevelMgrs = function(){
            var queryObj = [];
            var agrList =  _.where($scope.caseList,{selected:true});
            var legalCaseWorkflow = _.where(agrList[0].workflow,{'requestType':'LEGALADVOCATECHANGE'});
            var checkIndex = legalCaseWorkflow[legalCaseWorkflow.length-1];
            if( checkIndex.workStatus=='APPROVED' || checkIndex.workStatus=='REJECTED'){
                dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.REQUEST_HANDLED);
                return;
            } 
            for(var i=0;i<agrList.length;i++){ 
                queryObj.push(agrList[i]);
            }
            if(queryObj.length>0){
                var actionID = _.findWhere($scope.caseList,{selected:true}).actionID,
               // aggrementStatus = _.findWhere($scope.caseList,{selected:true}).agreementDetailsHistory[_.findWhere($scope.caseList,{selected:true}).agreementDetailsHistory.length-1].agreementStatus;
                aggrementStatus=_.findWhere($scope.caseList,{selected:true}).agreementStatus;
                //aggrementStatus = (aggrementStatus)? aggrementStatus : 'A';
                var qObj = {};
                qObj.legalSections = agrList[0].sectionName;
                qObj.caseFilledAtHo = (agrList[0].caseFilingLocation === 'HO_LEGAL') ? true : false;
                approvalQueueService.getNextlevelMgrs($scope.requestType,actionID,aggrementStatus,qObj).then(function(data){
                    if(data){
                        if(!data.length){
                            dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
                        }
                        else{
                            approvalQueueService.openUserPopup(data);
                            messageBus.onMsg("UPDATE_MANAGER",function(event,data){
                                $scope.legalInitiatedInfo.selectedManager = data;
                                $scope.proceedLegalCase('ESCALATE');
                            },$scope);
                        }
                    }
                });
            }
        };
        $scope.getQnDeials = function(header,details){
            if(details){
                $modal.open({
                    templateUrl: 'app/collections/approvals/approvalQueue/partials/showContactQuestions.html',
                    controller : [ '$scope', '$modalInstance', 'dialogService', 'lazyModuleLoader', 'appFactory', 'data', function($scope, $modalInstance, dialogService, lazyModuleLoader, appFactory, data) {                 
                        $scope.queueDetails={};$scope.queueDetails.header=data.header;$scope.queueDetails.content=angular.copy(data.details);
                        
                        function convertTime (isoTime) {
                          var hours   = parseInt(isoTime.substring(0, 2), 10),
                              minutes = isoTime.substring(3, 5),
                              ampm    = 'am';

                          if (hours == 12) {
                            ampm = 'pm';
                          } else if (hours == 0) {
                            hours = 12;
                          } else if (hours > 12) {
                            hours -= 12;
                            ampm = 'pm';
                          }

                          return hours + ':' + minutes + ' ' + ampm;
                        };
                        var setDateObject = function(value){
                            if(typeof value === "string"){
                                var time = value.split('T');
                                var data = time[0].split('-');                                
                                return data[2]+'/'+data[1]+'/'+data[0]+' - '+convertTime(time[1]);
                            }else{
                                return utility.formDateString(value);               
                            }           
                        };
                        $scope.queueDetails.content.contactedDateTime = setDateObject($scope.queueDetails.content.contactedDateTime); 
                        $scope.queueDetails.content.nextPtpDateTime = setDateObject($scope.queueDetails.content.nextPtpDateTime);                 
                        
                        $scope.close = function() {
                            $modalInstance.dismiss();
                        };
                        }],
                    backdrop: 'static',
                    size: 'md',
                    resolve: {
                        data: function () {
                            return {
                                header:header,
                                details: details
                            };
                        }
                    }
                }); 
            }
        };
        $scope.setAllRemarks = function(value){
            _.each($scope.caseList, function(item){
                item.remarks = value;
            });
        };
        $scope.singleRemarks = function(value){
            _.each($scope.caseList, function(item){
                if(item.remarks != value){
                    $scope.dropDownValues.remarksAll='';
                }
            });
            if(_.every($scope.caseList, function(item){return item.remarks == value;})){
                $scope.dropDownValues.remarksAll=value;
            }
        };
        $scope.setDocNotReq = function(docNotReq,item,singleOrBulk){
            if(singleOrBulk =='single'){
                if(docNotReq && !item.caseToBeFiledAt && item.caseFilingLocation){              
                    $scope.selectSingleLocation('docDisLoc',{branchID: "DOCNOTREQ",branchDesc:"DOCNOTREQ"},'docDisLocAll',item.caseID,'docDisLocID','','docDisLocList','documentDispatchLocation','docDisLocListBulk','documentDispatchLocation','documentDispatchLocationAll');
                }else{
                    if(item.caseFilingLocation == 'HO_LEGAL'){
                        $scope.selectSingleDropDown(item.caseFilingLocation,'caseFilingLocation','caseFilingLocationAll','caseFileLoc','caseFileLocID',item.caseID);
                    }else{                      
                        $scope.selectSingleLocation('docDisLoc',{branchID: item.isRecommended ? item.recommendedSittingLocationID : item.allocatedAlmSittingBranchID,branchDesc:item.isRecommended ? item.recommendedSittingLocationDesc : item.allocatedAlmSittingBranchDesc},'docDisLocAll',item.caseID,'docDisLocID','','docDisLocList','documentDispatchLocation','docDisLocListBulk','documentDispatchLocation','documentDispatchLocationAll');
                    }                    
                }
            }else{
                if(docNotReq){
                    _.each($scope.caseList, function(subItem){
                        if(!subItem.caseToBeFiledAt)
                            $scope.selectSingleLocation('docDisLoc',{branchID: "DOCNOTREQ",branchDesc:"DOCNOTREQ"},'docDisLocAll',subItem.caseID,'docDisLocID','','docDisLocList','documentDispatchLocation','docDisLocListBulk','documentDispatchLocation','documentDispatchLocationAll');
                    });              
                    // $scope.selectAllLocation('docDisLocAll',{branchID: "DOCNOTREQ",branchDesc:"DOCNOTREQ"},'docDisLoc','docDisLocAllID','docDisLocList','documentDispatchLocation','docDisLocListBulkAll','documentDispatchLocationAll');
                }else{
                    _.each($scope.caseList, function(subItem){
                        if(subItem.caseFilingLocation == 'HO_LEGAL'){
                            $scope.selectSingleDropDown(subItem.caseFilingLocation,'caseFilingLocation','caseFilingLocationAll','caseFileLoc','caseFileLocID',subItem.caseID);
                        }else{
                            $scope.selectSingleLocation('docDisLoc',{branchID: subItem.isRecommended ? subItem.recommendedSittingLocationID : subItem.allocatedAlmSittingBranchID,branchDesc:subItem.isRecommended ? subItem.recommendedSittingLocationDesc : subItem.allocatedAlmSittingBranchDesc},'docDisLocAll',subItem.caseID,'docDisLocID','','docDisLocList','documentDispatchLocation','docDisLocListBulk','documentDispatchLocation','documentDispatchLocationAll');
                        }
                    });                                            
                }
            }                       
        };
        $scope.resetDocNotReq = function(){
            $scope.data.docNotReqAll = false;
            _.each($scope.caseList,function(item){
                item.docNotReq = false;
            });
        };
        var successCount = 0;
        var successCountCalculation =  function(successCases){
            if(successCases.length && successCases.length >0){
                var workflowsList = _.pluck(successCases,'workflow');
                successCount =  _.uniq(_.flatten(_.pluck(_.flatten( workflowsList), 'agreementNos'))) ? _.uniq(_.flatten(_.pluck(_.flatten( workflowsList), 'agreementNos'))).length :0;
            }
        }
        $scope.showErrorPopup = function(response,queryLength,isSingle,isPop,queryObj){
            var failedResp;
            var repoAgreements = response.repoAgreements;
            var withdrawnAgreements = response.withdrawnCases;
            //var successCases = response.successCases;
            var seizureCases = response.sec9Seiz;
            successCountCalculation(response.successCases);
            failedResp = utility.getLegalErrorMsgs(response.failedCases,$scope.data.sectionCheck);
            var agrToBeSent = [];
            $scope.agreementsList = [];
            $modal.open({
                templateUrl : 'app/collections/legal/legalInitiation/partials/legalError.html',
                controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
                    $scope.errorData = data.errorData;
                    $scope.repoAgreements = data.repoAgreements;
                    $scope.withdrawnAgreements = data.withdrawnAgreements;
                    $scope.successCases = data.successCases;
                    $scope.seizureCases = data.seizureCases;
                    //$scope.isPending = data.isPending ? data.isPending :false;
                    $scope.data = {
                        agrSelected:[],
                        remarks : ""
                    };
                    $scope.close = function() {
                        $modalInstance.close({status :"cancel"});
                    };
                    $scope.initiate = function() {
                        console.log("------->",$scope.errorData);
                        if($scope.data.agrSelected && $scope.data.agrSelected.length>0){
                            if($scope.data.remarks !=""){
                                $modalInstance.close({status : "success",data:$scope.data.agrSelected,remarks:$scope.data.remarks});
                            }else{
                                dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.REMARKS_MANDATORY);
                            }
                        }else{
                            $modalInstance.close({status :"success"});
                        }
                    };
                    $scope.checkAgrSelected = function(agreementData){
                        $scope.data.agrSelected = $scope.data.agrSelected.concat(_.where(agreementData,{'selected':true}));
                        console.log($scope.data.agrSelected);
                    };
                } ],
                size : 'md',
                backdrop : 'static',
                windowClass : 'modal-custom',
                resolve : {
                    data : function() {
                        return {
                            errorData : failedResp,
                            repoAgreements :repoAgreements,
                            withdrawnAgreements:withdrawnAgreements,
                            successCases : successCount,
                            seizureCases: seizureCases
                        };
                    }
                }
            }).result.then(function (value) {
                if(value.status == "success" && value.data && value.data.length>0){
                    $scope.data.reinitiateAgreement = value.data[0].agreementNo;
                    $scope.data.reinitiateRemarks = value.remarks;
                    $scope.proceedLegalCase('INITIATED');
                }else{

                }
                
            }, function (value) {});
        };
    };
    approvalQueue.controller('advocateLegalRequestController',['$scope','$q','lazyModuleLoader','dialogService','approvalQueueService','repoFilterFactory','masterService','messageBus','$modal','$stateParams','$rootScope','appFactory','$globalScope',advocateLegalRequestController]);
    return advocateLegalRequestController;
});