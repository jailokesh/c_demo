define(['require','approvalQueue','constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approveLegalCompController = function($scope,lazyModuleLoader,dialogService,approvalQueueService,messageBus,$modal,$stateParams,$globalScope){
 		try{
 			$scope.dropDownValues ={};
	 		$scope.allStatus = constants.AGREEMENT_STATUS;
	 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
	 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
	 		$scope.legalInitiatedInfo  = {};
	 		$scope.data = {};
	 		var agreementInfo = approvalQueueService.getAgreementObj();
	 		if(agreementInfo && agreementInfo.agreementNo){
	 			$scope.customerInfo = utility.getCustomerInfo(agreementInfo);
	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
	 		}
	 		var initController = function(){
	 			$scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
	 			$scope.initiatedInfo = approvalQueueService.getSelectedRequest();
	 			approvalQueueService.getLegalCaseDetails($scope.initiatedInfo.agreementNo,$scope.initiatedInfo.caseID,$stateParams.requestType).then(function(data){
	 				$scope.legalInitiatedInfo = data[0];
	 				if($scope.legalInitiatedInfo.legalData && $scope.legalInitiatedInfo.legalData.workflow){
						$scope.data.remarksData = utility.getApprovalsRemarks($scope.legalInitiatedInfo.legalData.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
	 			});
	 			
			 		$scope.proceedLegalCompCase = function(status){
			 			/*if(!$scope.dropDownValues.initiatedAgreements || $scope.dropDownValues.initiatedAgreements.length === 0){
			 				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NO_AGREEMENT_SELECTED);
			 				return;
			 			}
			 			*/
			 			if(status === 'REJECTED' && !$scope.legalInitiatedInfo.rejectionReason){
			 				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
							return;
			 			}
			 			var postObj =  {
			 				"caseID": $scope.legalInitiatedInfo.caseID,
				 		    "agreementNos":$scope.legalInitiatedInfo.legalData.workflow[0].agreementNos,
				 		    "remarks": $scope.legalInitiatedInfo.rejectionReason,
				 		    "status": status,
				 		    "majorVersion" : $scope.legalInitiatedInfo.legalData.majorVersion,
				 		    "minorVersion" : $scope.legalInitiatedInfo.legalData.minorVersion,
				 		    "actionID" : $scope.initiatedInfo.approvalDetails.actionID,
				 		    "branchID" : $scope.initiatedInfo.branchId
			 		    };
			 			if(status === 'ESCALATE'){
			 				postObj.actionID = $scope.initiatedInfo.selectedManager;
			 				postObj.levelChange = true;
			 				postObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.initiatedInfo.approvalDetails.nextLevelAction];
						}
			 			approvalQueueService.updateLegalCompliance(postObj,$stateParams.requestType).then(function(data){
			 				if(data){
								var successString = "";
								if(status === 'ESCALATE'){
									successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
								}
								else{
									successString = "Request is "+status.toLowerCase()+" successfully";
								}
								dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
									approvalQueueService.updateInitiatedQueue(true);
								});
							}
							else{
								approvalQueueService.updateInitiatedQueue();
							}
			 			});
			 		};
			 		
	 			
	 		};
	 		initController();
	 		
	 		$scope.getNextlevelMgrs = function(){
				approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.initiatedInfo.approvalDetails.actionID).then(function(data){
					if(data){
						if(!data.length){
							dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
						}
						else{
							approvalQueueService.openUserPopup(data);
				 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
				 				$scope.initiatedInfo.selectedManager = data;
				 				$scope.proceedLegalCompCase('ESCALATE');
				 			},$scope);
						}
					}
				});
	 		};
	 		
 		}catch(error){
 			$scope.dropDownValues.isReadOnly = true;
 		}
 	};
 	
 	approvalQueue.controller('approveLegalCompController',['$scope','lazyModuleLoader','dialogService','approvalQueueService','messageBus','$modal','$stateParams','$globalScope',approveLegalCompController]);
	return approveLegalCompController;
});
