define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var documentWaiverController = function($scope,$modal,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestObj = approvalQueueService.getSelectedRequest();
 		$scope.waiverInfo = {};
 		$scope.linkedAgrNos = [];
 		$scope.enableReject = false;
 		$scope.enableApprove = false;
 		$scope.repoLetterDetails = collectionConstants.REPO_LETTER_LABEL;
 		$scope.categoryDetails  = _.findWhere($globalScope.imageCategories, {subCategory: "REPO LETTERS"}) || {};
 		
 		$scope.splicRow = function(currentPage){
    		var _cp = (currentPage-1) * $scope.waiverInfo.maxSize;
    		$scope.waiverInfo.offset = _cp + 1;
    		$scope.waiverInfo.offsetLast = ((_cp+$scope.waiverInfo.maxSize)>$scope.waiverInfo.totalRecord) ? $scope.waiverInfo.totalRecord : $scope.waiverInfo.offset+($scope.waiverInfo.maxSize-1);
    		$scope.waiverInfo.data = $scope.waiverInfo.foreCloseLADetails.linkedAgreements.slice(_cp,_cp+$scope.waiverInfo.maxSize);
    	};
    	
    	var getLinkedAgreementDetails = function(){
    		$scope.waiverInfo.isLinkedAgreement = ($scope.waiverInfo.foreCloseLADetails && $scope.waiverInfo.foreCloseLADetails.linkedAgreements) ? true : false;
    		if($scope.waiverInfo.isLinkedAgreement){
				$scope.linkedAgrNos = $scope.waiverInfo.foreCloseLADetails.linkedAgreements;
				//$scope.linkedAgrNos.unshift({agreementNo : $scope.customerInfo.agreementNo,vehicleNumber : $scope.customerInfo.assetDetail ? $scope.customerInfo.assetDetail.lmsRegistrationNo : ''});
    			$scope.waiverInfo.totalRecord = $scope.waiverInfo.foreCloseLADetails.linkedAgreements.length;
    			$scope.waiverInfo.maxSize = 5;
    			$scope.waiverInfo.currentPage = 1;
    			$scope.splicRow(1);
    		}
    	};
    	
    	var getWaiverDetails = function() {    		
			approvalQueueService.getWaiverDetails($scope.requestObj,$stateParams.agreementNo).then(function(data){
				if(data && data.length){
					$scope.waiverInfo = data[0];
					if($scope.waiverInfo.workflow){
						$scope.waiverInfo.workflow = _.sortBy(_.filter($scope.waiverInfo.workflow, function(item) {
						return item.requestType && item.requestType.toUpperCase() === "DOCUMENTWAIVER";
						}),'workDoneDate');
						if($scope.waiverInfo.workflow.length > 0){
							var getLastIniLetterType = _.find(_.sortBy($scope.waiverInfo.workflow,'workDoneDate').reverse(),{"workStatus":"INITIATED"});
							var letterTypeInitiated = getLastIniLetterType.letterType.split(",");

							$scope.waiverInfo.updatedLettersReverse = angular.copy($scope.waiverInfo.uploadedLetters);
							if($scope.waiverInfo.uploadedLetters && $scope.waiverInfo.uploadedLetters.length > 0){
								$scope.waiverInfo.updatedLettersReverse.reverse();
							}
							if(letterTypeInitiated.length > 0){
								$scope.waiverInfo.uploadedWaiverLetters = _.filter($scope.waiverInfo.uploadedLetters.reverse(), function(item) {
									return (letterTypeInitiated.indexOf(item.letterType.toUpperCase()) !== -1);
								});	
								$scope.waiverInfo.uploadedWaiverLetters = _.uniq($scope.waiverInfo.uploadedWaiverLetters,'letterType');	
							}
							$scope.waiverInfo.alreadyRequestedDocTemp = [];
							$scope.waiverInfo.alreadyRequestedDoc = [];
							var increReqDoc = 0;
							_.each($scope.waiverInfo.workflow,function(item,key){
								if(typeof $scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc] === 'undefined'){
									$scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc] = [];	
								}
								$scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc].push(item);
								if(item.workStatus == 'REJECTED' || item.workStatus == 'APPROVED'){
									var deviatedDocTypes = $scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc][0].letterType;
									deviatedDocTypes = deviatedDocTypes.split(',');
									var filteredLetterByReq = _.filter($scope.waiverInfo.uploadedLetters, function(item) {
										return (deviatedDocTypes.indexOf(item.letterType.toUpperCase()) !== -1);
									});
									_.each(filteredLetterByReq,function(v){
										if($scope.waiverInfo.alreadyRequestedDoc.length > 0){
											$scope.waiverInfo.alreadyRequestedDoc = _.reject($scope.waiverInfo.alreadyRequestedDoc, function(d){ 
												return d.letterType === v.letterType;
											});	
										}
										v.initiateBy = _.first($scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc]).workDoneBy;
										v.initiateByName = _.first($scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc]).userName;
										v.completedBy = _.last($scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc]).workDoneBy;
										v.completedByName = _.last($scope.waiverInfo.alreadyRequestedDocTemp[increReqDoc]).userName;
										$scope.waiverInfo.alreadyRequestedDoc.push(v);
									});
									increReqDoc++;
								}
							});
						}
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.workflow,approvalQueueConstants.APPROVALSTATUS);
					}else if($scope.waiverInfo.foreCloseLADetails && $scope.waiverInfo.foreCloseLADetails.workflow){
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.foreCloseLADetails.workflow,approvalQueueConstants.APPROVALSTATUS);
					}
					$scope.waiverInfo.initObj = _.findWhere($scope.waiverInfo.workflow,{workStatus:'INITIATED'});
					if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
						$scope.waiverInfo.rejectedObj = _.findWhere($scope.waiverInfo.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
					}
					getLinkedAgreementDetails();
				}
			});	
    	};
    	var openModal = function(_url, _modalData){
			var paramObj = {
				templateUrl: _url,
				controller: ['$scope', '$modalInstance', '$modal', 'data', function($scope, $modalInstance, $modal, data){
					$scope.data = data;
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				}],
				size : 'xs',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return  _modalData;
	                }
				}	
			};
			$modal.open(paramObj);
		};
 		function init(){
 			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 			getWaiverDetails(); 			
 		}
		init();
		$scope.rejectHandleRequest = function(reqType){
			if(reqType === 'REJECTED'){
				if(!$scope.waiverInfo.rejectionReason){
					dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
					return;	
				}else{
					var rejectString,approvedCnt=0,rejectedCnt=0;
					_.each($scope.waiverInfo.letterStatus,function(val,key){
						if(val === "REJECTED"){
							rejectedCnt++;
						}
						if(val === "APPROVED"){
							approvedCnt++;
						}
					});
					//rejectString = "Are you sure you want to Reject "+rejectedCnt+" Document and Approve "+approvedCnt+" Document";
					rejectString = "Are you sure you want to Reject the Document(s)";
					dialogService.confirm("ssss", collectionConstants.POPUP_HEADER.CONFIRM_STRING,rejectString).result.then(function(){
            				$scope.handleRequest(reqType);
            		},function(){});
				}
			}	
		};
		$scope.handleRequest = function(reqType){
			var reqObj = {
				status : reqType,
				actionID : $scope.requestObj.approvalDetails.actionID,
				branchID : $scope.requestObj.branchId,
				agreementNo : $scope.waiverInfo.agreementNo,
				repoType : $scope.waiverInfo.repoType,
				majorVersion : $scope.waiverInfo.majorVersion,
				minorVersion : $scope.waiverInfo.minorVersion,
				remarks : $scope.waiverInfo.rejectionReason,
				body : {
					remarks : $scope.waiverInfo.letterRemarks || "", 
					status: reqType == 'REJECTED' ? 'RETURNED' : reqType == 'APPROVED' ? 'VERIFIED' : 'INITIATED'
				}
			};
			var approvalService = "DOCUMENTWAIVER";
			if(reqType === 'ESCALATE'){
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.waiverInfo.initObj ? $scope.waiverInfo.initObj.comments : '';
			}
			approvalQueueService.handleRequest(reqObj,approvalService).then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
		
		$scope.showAgreementPopup = function(){
 			$modal.open({
					templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
					controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
						$scope.data = {};
						$scope.data.isViewOnly = data.isViewOnly;
						$scope.data.totalRecords = data.agreementNos;
						$scope.data.productType = data.productType;
						$scope.data.currentPage = 1;
						$scope.data.recordPerPage = 5;
						$scope.saveHandler = function(){
							$modalInstance.dismiss();
						};
						$scope.paginationHandler = function(pageNo){
							var startLen = $scope.data.recordPerPage * (pageNo-1);
							var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
							$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
						};
						$scope.paginationHandler(1);
						$scope.close = function(){
							$modalInstance.dismiss();
						};
					}],
					size : 'md',
					backdrop : 'static' ,
					windowClass : 'modal-custom',
					resolve: {
						data: function() {
		                    return {
		                    	agreementNos : $scope.linkedAgrNos,
		                    	isViewOnly : true,
								productType :$scope.customerInfo.productGroup
		                    };
		                }
					}
				});
 		};
 		
 		var escalateFn;
 		$scope.getNextlevelMgrs = function(){
 			var queryParams = {};
 			if($stateParams.requestType === 'FORECLOSURELA'){
 				queryParams.type = $scope.waiverInfo.foreCloseLADetails.LAType;
 			}else if($stateParams.requestType === 'FORECLOSURE' || $stateParams.requestType ==='NORMAL'){
 				queryParams.requestID  = $scope.requestObj.requestID;
 			}
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID,'',queryParams).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
 		};

		$scope.reInitiateWaiver = function(repoDetails,categoryDetails) {
			$modal.open({
				templateUrl: 'app/collections/repossession/repoQueue/partials/showDocDeviation.html',
				controller : [ '$scope', '$modalInstance', 'dialogService', 'lazyModuleLoader', 'appFactory', 'data', function($scope, $modalInstance, dialogService, lazyModuleLoader, appFactory, data) {					
					$scope.deviateDocDet={};
					$scope.deviateDocDet.header=data.header;
					$scope.deviateDocDet.repoDet=data.details;
					$scope.deviateDocDet.letterTypes=collectionConstants.REPO_QUEUE_DOC_TYPES[data.details.repoType];
					$scope.deviateDocDet.repoReqLetters = collectionConstants.REPO_MANDATORY_DOC;
					$scope.deviateDocDet.letterLables = collectionConstants.REPO_LETTER_LABEL;
					$scope.deviateDocDet.deviationDoc = {"uploadDoc":[],"deviation":[]};
					$scope.deviateDocDet.categoryDetails = data.categoryDetails;
					$scope.deviateDocDet.disableBtn = true;
					$scope.deviateDocDet.fullDeviationAccord = true;
					$scope.deviateDocDet.timeDeviationAccord = false;
				
					$scope.initDiviationPopup = function() {
						var uploadedLettersData = $scope.deviateDocDet.repoDet.updatedLettersReverse;
						_.each($scope.deviateDocDet.letterTypes,function (a){
							var letterStatus = _.find(uploadedLettersData,{letterType:a.value});
							if(typeof letterStatus !== "undefined"){
								$scope.deviateDocDet.deviationDoc.uploadDoc.push(letterStatus);
								if(letterStatus.status === "RETURNED"){
									var g = _.filter(uploadedLettersData,function(s){
										return s.letterType == letterStatus.letterType && s.status != 'RETURNED';
									});
									if(g && typeof g[0] === 'undefined'){
										letterStatus.value = letterStatus.letterType;
										$scope.deviateDocDet.deviationDoc.deviation.push(letterStatus);
									}
								}
							}else{
								a.letterType = a.value;
								//a.status = "PENDING";
								$scope.deviateDocDet.deviationDoc.deviation.push(a);
								$scope.deviateDocDet.deviationDoc.uploadDoc.push(a);
							}
						});
					};
					$scope.disableSumbit = function(checkBoxAttr){
						$scope.deviateDocDet.disableBtn = true;
						if(checkBoxAttr.letterChkBox){
							_.each(checkBoxAttr.letterChkBox,function(val,key){
								if(val === true){
									$scope.deviateDocDet.disableBtn = false;
								}
							});
						}
					};
					$scope.remarkHistory = function(letterType,remarkData,viewRemarks=true){
						if(typeof remarkData == 'undefined'){
							remarkData = [];
						}
						var obj = {
							letterType :letterType,
							viewRemarks:viewRemarks,
							remarkData:remarkData
						};
						openModal('app/collections/repossession/repoQueue/partials/remarkHistory.html',obj);
					};
					$scope.submitDeviation = function(deviateDocDet){
						var documentToWaiver = [];
						if(deviateDocDet.letterChkBox){
							_.each(deviateDocDet.letterChkBox,function(val,key){
								var waiverObj = {};
								if(val === true){
									waiverObj.letterType = key;
									waiverObj.remarks = deviateDocDet.deviateRemarks;
									waiverObj.imgRef = deviateDocDet.deviateEmailApprovalArr;
									documentToWaiver.push(waiverObj);
								}
							});
							var bodyData = {};
							bodyData.documentToWaiver = documentToWaiver;
							bodyData.type = "INITIATE";
							bodyData.agreementNo = deviateDocDet.repoDet.agreementNo;
							approvalQueueService.docWaiverRequest(bodyData).then(function (result) {
								if(result.status === "success"){
									dialogService.showAlert('Success', "Success", "Approval has been Re-Initiated Successfully for document waiver").result.then(function(){},function(){
											lazyModuleLoader.loadState('collections.approvalQueue');
										});
								}else{
									lazyModuleLoader.loadState('collections.approvalQueue');
								}
								$scope.close();
								
							});
						}
						
					};
					$scope.close = function() {
						$modalInstance.dismiss();
					};					
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				}],
				backdrop: 'static',
				size: 'lg',
				resolve: {
					data: function () {
						return {
							header:"Deviation",
							details: repoDetails,
							categoryDetails :categoryDetails
						};
					}
				}
			});
		};

		$scope.enableRejectFuncChange = function(radioVal){
			var rejectState = 0,approvedState=0;
			$scope.enableReject = false;
			$scope.enableApprove = false;
			_.each(radioVal, function(s){
				if(s === "REJECTED"){
					rejectState = 1;
				}
				if(s === "APPROVED"){
					approvedState = 1;
				}
			});
			if(approvedState === 1){
				$scope.enableApprove = true;
			}
			if(rejectState === 1){
				$scope.enableReject = true;
			}
	 	};
 	};
 	
 	approvalQueue.controller('documentWaiverController',['$scope','$modal','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus',documentWaiverController]);
	return documentWaiverController;
});