define(['require','approvalQueue', 'constants','DatePickerConfig','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,DatePickerConfig,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var receiptController = function($scope,$modal,$stateParams,approvalQueueService,lazyModuleLoader,dialogService,$globalScope,messageBus){
 		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		function init(){
 			$scope.requestObj = approvalQueueService.getSelectedRequest();
 			$scope.requestBody = {};
 			approvalQueueService.getReceiptDetails($stateParams.agreementNo,$scope.requestObj.receiptNo).then(function(data){ 				
 				$scope.receiptDetails = data;
 				if($scope.receiptDetails.receiptDetail && $scope.receiptDetails.receiptDetail.workflow){
					$scope.receiptDetails.remarksData = utility.getApprovalsRemarks($scope.receiptDetails.receiptDetail.workflow,approvalQueueConstants.APPROVALSTATUS);
				}
 				$scope.customerInfo = approvalQueueService.getAgreementObj();
 				 				$scope.requestObj.isVishesh = ($scope.requestObj.receiptFor && ($scope.requestObj.receiptFor.toUpperCase() === 'VISHESHAGREEMENT' || $scope.requestObj.receiptFor.toUpperCase() === 'TRIPLOAN'));
 				$scope.requestObj.isReceiptFor = (!$scope.requestObj.isVishesh && $scope.requestObj.receiptFor && $scope.requestObj.receiptType === 'OD');
 				if($scope.requestObj.isVishesh || !$scope.receiptDetails.receiptDetail.receiptFor && $scope.requestObj.receiptType !== "IMD" && $scope.requestObj.receiptType !== "TA"){
 					$scope.customerInfo = utility.getCustomerInfo($scope.customerInfo);
 				}else if($scope.receiptDetails.receiptDetail.receiptFor ==='NonAgreement'){
 					$scope.customerInfo.agreementStatus = $scope.receiptDetails.receiptDetail.receiptFor === "NonAgreement" ? 'NA': 'C';
					$scope.customerInfo.productGroup = $scope.requestObj.productGroup;
 				}
 				$scope.customerInfo.productType = !$scope.customerInfo.productGroup ? "VF" : $scope.customerInfo.productGroup;
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 				if($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus){
 					$scope.receiptDetails.rejectedObj = _.findWhere($scope.receiptDetails.receiptDetail.workflow,{workStatus:$scope.requestObj.approvalDetails.currentStatus});
 				}
 			});
 		}
 		init();
 		
 		$scope.viewOtherAgreements = function(){
 			$modal.open({
				templateUrl: 'app/collections/approvals/approvalQueue/partials/agreementSelection.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.data = {};
					$scope.data.totalRecords = [];
					if(data.agreementNos.length){
						_.each(data.agreementNos,function(item){						
							var obj = {};
							var refNo = _.where(data.chargeDetails,{referenceNo:item});
							var amt = _.pluck(refNo, 'amount');
							var sum = _.reduce(amt, function(memo, num){ return memo + num; }, 0);
							obj.agreementNo = item;
							obj.amount = sum;
							$scope.data.totalRecords.push(obj);
						});
					}
					$scope.close = function(){
						$modalInstance.dismiss();
					};
				}],
				size : 'sm',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return {
	                    	agreementNos : $scope.receiptDetails ? $scope.receiptDetails.receiptDetail.agreementNos : [],
	                    	chargeDetails : $scope.panCardDetails ? $scope.panCardDetails.receiptDetail.chargeDetails : [],		
	                    	isViewOnly : true
	                    };
	                }
				}
			});
		};
		
 		$scope.handleRequest = function(reqType){
 			if(reqType === 'REJECTED' && !$scope.requestBody.remarks){
 				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
 			}
			$scope.requestBody.status = reqType;
			$scope.requestBody.majorVersion = $scope.requestObj.majorVersion;
			$scope.requestBody.minorVersion = $scope.requestObj.minorVersion;
			$scope.requestBody.receiptNo = $scope.receiptDetails.receiptDetail.receiptNo;
			$scope.requestBody.actionID = $scope.requestObj.approvalDetails.actionID;
			$scope.requestBody.branchID = $scope.requestObj.branchId;
			if(reqType === 'ESCALATE'){
				$scope.requestBody.actionID = $scope.requestObj.selectedManager;
				$scope.requestBody.levelChange = true;
				$scope.requestBody.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
			}
			approvalQueueService.handleRequest($scope.requestBody,'BACKDATEDRECEIPT').then(function(data){
				if(data){
					var successString = "";
					if(reqType === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+reqType.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
			});	
		};
		
		$scope.getNextlevelMgrs = function(){
			approvalQueueService.getNextlevelMgrs($stateParams.requestType,$scope.requestObj.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.requestObj.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
 	};

 	approvalQueue.controller('receiptController',['$scope','$modal','$stateParams','approvalQueueService','lazyModuleLoader','dialogService','$globalScope','messageBus',receiptController]);
	return receiptController;
});