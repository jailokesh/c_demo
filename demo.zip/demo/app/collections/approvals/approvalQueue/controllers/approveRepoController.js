/* Date : 29-Mar-2017
Modified by : Saranya Sankar R
Modification details : CR- Book Request Approvals */

define(['require','approvalQueue', 'constants','collectionConstants','utility','approvalQueueConstants'], function(r,approvalQueue,constants,collectionConstants,utility,approvalQueueConstants) {
'use strict';

 	var approveRepoController = function($scope,$stateParams,approvalQueueService,dialogService,lazyModuleLoader,$globalScope,messageBus,$rootScope){
 		$scope.nonEmpAgentInfo = approvalQueueService.getSelectedRequest();
 		$scope.nonEmpAgentInfo.branchName = approvalQueueService.getBranchName($scope.nonEmpAgentInfo.branchId);
 		$scope.isPending = $stateParams.reqStatus === 'PENDING'?true:false;
 		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
 		$scope.requestType = $stateParams.requestType;
 		$scope.actionId = $scope.nonEmpAgentInfo.approvalDetails.actionID;
 		$scope.dispatcheTo = approvalQueueConstants.PARTYTYPE;
 		$scope.submitFlag = false;
 		var agreementInfo = approvalQueueService.getAgreementObj();
 		$scope.dropDownValues = {};
 		$scope.nonEmpAgentInfo.chargeConstants=collectionConstants.MARKING_LMS_CHARGES;
 		
 		var initController = function(){
 			$scope.dropDownValues.isReadOnly = ($stateParams.reqStatus.toUpperCase() !== 'PENDING');
 	 		if(agreementInfo && agreementInfo.agreementNo){
 	 			$scope.customerInfo = utility.getCustomerInfo(agreementInfo);
 	 			$scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
 	 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 	 		}
 		};
 		initController();
 		$scope.setInScope = function (name, signed_doc) {
			$scope[name] = signed_doc;
		};
 		var getNonEmpanelledAgents = function(){
 			approvalQueueService.getNonEmpanelledAgents($stateParams).then(function(response){
 				$scope.nonEmpAgentInfo.nonEmpAgentDetails = response ? response[0]:{};
 				$scope.nonEmpAgentInfo.nonEmpAgentDetails.repoDesc = _.findWhere(collectionConstants.NOTICE_MANAGEMENT_CONSTANTS.REPO_TYPES, {value : $scope.nonEmpAgentInfo.nonEmpAgentDetails.repoType});
 				if($scope.nonEmpAgentInfo.nonEmpAgentDetails.expenseDetails){
	  				for (var i = 0; i < $scope.nonEmpAgentInfo.nonEmpAgentDetails.expenseDetails.length; i++) {
	 					$scope.nonEmpAgentInfo.nonEmpAgentDetails.expenseDetails[i].chargeDesc = _.findWhere($scope.nonEmpAgentInfo.chargeConstants,{chargeID:$scope.nonEmpAgentInfo.nonEmpAgentDetails.expenseDetails[i].chargeID}).chargeDescription;
	 				}
  				}
  				var _role = _.without(_.pluck($scope.nonEmpAgentInfo.nonEmpAgentDetails.vehicleDetail, 'entryType'),'REPO_AGENT','YARD_MANAGER');
  				$scope.nonEmpAgentInfo.vehicleDocuments=_.findWhere($scope.nonEmpAgentInfo.nonEmpAgentDetails.vehicleDetail,{'entryType':_role[0]});
  				$scope.nonEmpAgentInfo.vehicleImageCheck=Object.keys($scope.nonEmpAgentInfo.vehicleDocuments.vehicleImageRef).length>0 && $scope.nonEmpAgentInfo.vehicleDocuments.vehicleImageRef.imagePathReferences;
  				$scope.nonEmpAgentInfo.fcImageCheck=Object.keys($scope.nonEmpAgentInfo.vehicleDocuments.fintnessCertificateImageRef).length>0 && $scope.nonEmpAgentInfo.vehicleDocuments.fintnessCertificateImageRef.imagePathReferences;
  				if($scope.nonEmpAgentInfo.nonEmpAgentDetails && $scope.nonEmpAgentInfo.nonEmpAgentDetails.workflow){
					var workflow = _.where($scope.nonEmpAgentInfo.nonEmpAgentDetails.workflow,{requestType:$scope.requestType}); 
 					$scope.nonEmpAgentInfo.nonEmpAgentDetails.remarksData = utility.getApprovalsRemarks(workflow,approvalQueueConstants.APPROVALSTATUS); 					
 				}
 				
 				
 			});
 		};
 		getNonEmpanelledAgents();

 		$scope.handleRequest = function(reqStatus){
 			if(reqStatus === 'REJECTED' && !$scope.nonEmpAgentInfo.nonEmpAgentDetails.remarks){
 				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
 				return;
 			}
 			
 			var postObj =  {
				 agreementNo : $scope.nonEmpAgentInfo.nonEmpAgentDetails.agreementNo,
				 status : reqStatus,
				 actionID : $scope.actionId,
				 initiatorID :$scope.nonEmpAgentInfo.approvalDetails.initiatedBy.userID,
				 remarks: $scope.nonEmpAgentInfo.nonEmpAgentDetails.remarks,
				 majorVersion :$scope.nonEmpAgentInfo.nonEmpAgentDetails.majorVersion,
				 minorVersion : $scope.nonEmpAgentInfo.nonEmpAgentDetails.minorVersion,
				 branchId : $scope.nonEmpAgentInfo.branchId,
				 seizureCharge : $scope.nonEmpAgentInfo.nonEmpAgentDetails.yardDetail.seizureExpense
 		    };
 			if(reqStatus === 'ESCALATE'){
 				postObj.actionID = $scope.nonEmpAgentInfo.selectedManager;
 				postObj.levelChange = true;
 				postObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.nonEmpAgentInfo.approvalDetails.nextLevelAction];
 				postObj.remarks = $scope.nonEmpAgentInfo.nonEmpAgentDetails.remarks ? nonEmpAgentInfo.nonEmpAgentDetails.remarks : '';
			}
 			if($scope.nonEmpAgentInfo.approvalDetails.originalStatus === 'REJECTED'){
 				if(reqStatus === 'REJECTED'){
 					postObj.status = $scope.nonEmpAgentInfo.approvalDetails.nextLevelAction=='RECOMMEND'?'RECOMMENDED':'APPROVED';
 				}
 				else{
 					postObj.status = 'REJECTED';
 				}
 			}
 			approvalQueueService.approveNonEmpanelledAgents(postObj,reqStatus).then(function(data){
 				if(data){
					var successString = "";
					if(reqStatus === 'ESCALATE'){
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}
					else{
						successString = "Request is "+postObj.status.toLowerCase()+" successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function(){},function(){
						approvalQueueService.updateInitiatedQueue(true);
					});
				}
				else{
					approvalQueueService.updateInitiatedQueue();
				}
 			});
 		};
 		
 		$scope.getNextlevelMgrs = function(){
 			var checkIndex = _.findLastIndex($scope.nonEmpAgentInfo.nonEmpAgentDetails.workflow,{requestType:'NONEMPANELLEDAGENT'});
			if( checkIndex.workStatus=='APPROVED' || checkIndex.workStatus=='REJECTED'){
				dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.REQUEST_HANDLED);
				return;
			} 			
			approvalQueueService.getNextlevelMgrs($scope.requestType,$scope.nonEmpAgentInfo.approvalDetails.actionID).then(function(data){
				if(data){
					if(!data.length){
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					}
					else{
						approvalQueueService.openUserPopup(data);
			 			messageBus.onMsg("UPDATE_MANAGER",function(event,data){
			 				$scope.nonEmpAgentInfo.selectedManager = data;
			 				$scope.handleRequest('ESCALATE');
			 			},$scope);
					}
				}
			});
 		};
	 	$scope.reInitiate = function(agreementNo){
	 		$rootScope.isClickedViaMenu = false;
			lazyModuleLoader.loadState('collections.repoMarking',{agreementNo : agreementNo});
	 	};	
 	};

 	approvalQueue.controller('approveRepoController',['$scope','$stateParams','approvalQueueService','dialogService','lazyModuleLoader','$globalScope','messageBus','$rootScope',approveRepoController]);
	return approveRepoController;
});