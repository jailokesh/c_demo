define([ 'require', 'approvalQueue', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility', 'approvalQueueConstants' ], function(r, approvalQueue, constants, DatePickerConfig, collectionConstants, utility, approvalQueueConstants) {
	'use strict';

	var shortfallWaiverController = function($scope, $modal, $stateParams, approvalQueueService, dialogService, lazyModuleLoader, $globalScope, messageBus,$rootScope) {
		$scope.requestTypes = collectionConstants.REQUEST_TYPES;
		$scope.isPending = $stateParams.reqStatus === 'PENDING' ? true : false;
		$scope.isInitiated = ($stateParams.reqStatus === 'INITIATED');
		$scope.requestObj = approvalQueueService.getSelectedRequest();
		$scope.waiverInfo = {};
		$scope.linkedAgrNos = [];
		
		var agreementInfo = approvalQueueService.getAgreementObj();
		var getWaiverDetails = function() {
			approvalQueueService.getWaiverDetails($scope.requestObj, $stateParams.agreementNo).then(function(response) {
				if (response && response.length) {
					$scope.waiverInfo = response[0];
					$scope.payMode = response[0].payDetails[0].payMode;
					$scope.installmentCount = response[0].payDetails[0].paySplitUp.length;
					$scope.paySplitUp = response[0].payDetails[0].paySplitUp;
					$scope.chargeDetails = response[0].chargeDetails[0];
					$scope.childAgreements = agreementInfo.childAgreements;
					$scope.shortfallDetails = agreementInfo.shortfallDetails;
					$scope.shortfallDetails.settlementAgreed = response[0].settlementAgreed;
					var legalDetails = {};
					var netWorking;
					var currentBVLoss = 0;
					var currentBalance = 0;
					var chargeDetails = response[0].chargeDetails[0];
					if(parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount) > 0){
						currentBVLoss = parseInt(agreementInfo.shortfallDetails.currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount);
						currentBalance = (parseInt(currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentShortfallCollected);

						//netWorking = parseInt(currentBalance) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount);
						netWorking = (parseInt(currentBalance) <= 0) ? 0 : parseInt(currentBalance);
						legalDetails = {
						currentBVLoss : parseInt(agreementInfo.shortfallDetails.currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount),
						currentAVLoss : parseInt(agreementInfo.shortfallDetails.currentAVLoss) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount),
						currentShortfallDue : (parseInt(agreementInfo.shortfallDetails.currentAVLoss) + parseInt(agreementInfo.shortfallDetails.currentInterestAmount)) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount),
						noticeAmount : parseInt(agreementInfo.shortfallDetails.shortfallNoticeAmount) - parseInt(agreementInfo.shortfallDetails.currentApprovedWaiverAmount)						
						};
					}else{
						currentBVLoss = parseInt(agreementInfo.shortfallDetails.currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentPaidAmount);
						currentBalance = (parseInt(currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt(agreementInfo.shortfallDetails.currentShortfallCollected);

						netWorking = parseInt(agreementInfo.shortfallDetails.currentBVLoss) - (parseInt(agreementInfo.shortfallDetails.currentPaidAmount) + parseInt(response[0].chargeDetails[0].waiverAmount));
						legalDetails = {
							currentBVLoss : parseInt(agreementInfo.shortfallDetails.currentBVLoss),
							currentAVLoss : parseInt(agreementInfo.shortfallDetails.currentAVLoss),
							currentShortfallDue : (parseInt(agreementInfo.shortfallDetails.currentAVLoss) + parseInt(agreementInfo.shortfallDetails.currentInterestAmount)),	
							noticeAmount : parseInt(agreementInfo.shortfallDetails.shortfallNoticeAmount)
						};						
					}	

					var actuvalBVLoss,actuvalAVLoss,shortfallNoticeAmount,shortfallDue,waivedShortfallDue,actuvalBVLossPercent,actualAVLossPercent,
						shortfallNoticePercent,shortfallDuePercent,networking,settlementAgreed,bvWaiverAmount,avWaiverAmount,
						shortfallDueWaiverAmt,sNoticeWaiverAmt,payDetails,totalAmt = 0;
					actuvalBVLoss = parseInt(agreementInfo.shortfallDetails.currentBVLoss);
					actuvalAVLoss = parseInt(agreementInfo.shortfallDetails.currentAVLoss);
					shortfallNoticeAmount = (parseInt(agreementInfo.shortfallDetails.shortfallNoticeAmount) <= 0) ? 0 : agreementInfo.shortfallDetails.shortfallNoticeAmount;
					shortfallDue =  ((parseInt(agreementInfo.shortfallDetails.currentAVLoss) + parseInt(agreementInfo.shortfallDetails.currentInterestAmount)) <= 0) ? 0 : (parseInt(agreementInfo.shortfallDetails.currentAVLoss) + parseInt(agreementInfo.shortfallDetails.currentInterestAmount));
					if($scope.chargeDetails && $scope.chargeDetails.chargeID == 'Shortfall Due'){
						shortfallDue = chargeDetails.actualAmount  ? chargeDetails.actualAmount : shortfallDue;
						agreementInfo.shortfallDetails.currentInterestAmount = (parseInt(shortfallDue) - parseInt(actuvalAVLoss));
					}

					bvWaiverAmount = parseInt(actuvalBVLoss) - parseInt($scope.shortfallDetails.settlementAgreed);
					avWaiverAmount = parseInt(actuvalAVLoss) - parseInt($scope.shortfallDetails.settlementAgreed);
					sNoticeWaiverAmt = parseInt(shortfallNoticeAmount) - parseInt($scope.shortfallDetails.settlementAgreed);
					shortfallDueWaiverAmt = parseInt(shortfallDue) - parseInt($scope.shortfallDetails.settlementAgreed);

					//Percentage calculation
					 actuvalBVLossPercent = (actuvalBVLoss > 0)? roundOffValue(bvWaiverAmount, actuvalBVLoss) : roundOffValue(bvWaiverAmount, 0);
					actuvalBVLossPercent = actuvalBVLossPercent.actualVal ? actuvalBVLossPercent.actualVal : 0;
					actualAVLossPercent = (actuvalAVLoss > 0)? roundOffValue(avWaiverAmount, actuvalAVLoss) : roundOffValue(avWaiverAmount, 0);
					actualAVLossPercent = actualAVLossPercent.actualVal ? actualAVLossPercent.actualVal : 0;
					shortfallNoticePercent = (shortfallNoticeAmount > 0)? roundOffValue(sNoticeWaiverAmt, shortfallNoticeAmount) : roundOffValue(sNoticeWaiverAmt, 0);
					shortfallNoticePercent = shortfallNoticePercent.actualVal ? shortfallNoticePercent.actualVal : 0;
					shortfallDuePercent = (shortfallDue > 0)? roundOffValue(shortfallDueWaiverAmt, shortfallDue) : roundOffValue(shortfallDueWaiverAmt, 0);
					shortfallDuePercent = shortfallDuePercent.actualVal ? shortfallDuePercent.actualVal : 0;

					 networking = (parseInt($scope.shortfallDetails.settlementAgreed) <= 0) ? 0 : (parseInt($scope.shortfallDetails.settlementAgreed) -(agreementInfo.shortfallDetails.currentShortfallCollected ? parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) : 0))
					if (parseInt(networking) <= 0) {
						networking = 0;
					}
					$scope.legalDetails = [{
						chargeType : 'BV Loss',
						actualLoss : (parseInt(agreementInfo.shortfallDetails.currentBVLoss) <= 0) ? 0 : agreementInfo.shortfallDetails.currentBVLoss,
						settlementAgreed : $scope.shortfallDetails.settlementAgreed,
						shortfallCollected : (parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : agreementInfo.shortfallDetails.currentShortfallCollected,
						breakupDetails: {
							'Installment': agreementInfo.shortfallDetails.otherDetails.installment,
							'POS': agreementInfo.shortfallDetails.otherDetails.POS,
							'Seizure Charges': agreementInfo.shortfallDetails.otherDetails.seizureCharges,
							'Parking Charges': agreementInfo.shortfallDetails.otherDetails.parkingCharges,
							'Legal Charges': agreementInfo.shortfallDetails.otherDetails.legalCharges,
							'Open Payable Advice (-)': agreementInfo.shortfallDetails.otherDetails.openPayAdvise,
							'Sale Price (-)': agreementInfo.shortfallDetails.otherDetails.salePrice,
							'Total' : agreementInfo.shortfallDetails.currentBVLoss
						},
						waiverCharge: true,
						waiverAmount : bvWaiverAmount > 0 ? bvWaiverAmount : 0,
						percentage : parseInt(actuvalBVLossPercent) > 0 ? actuvalBVLossPercent : '0.00',
						netWorking : networking
					}, {
						chargeType : 'AV Loss',
						actualLoss : (parseInt(agreementInfo.shortfallDetails.currentAVLoss) <= 0) ? 0 : agreementInfo.shortfallDetails.currentAVLoss,
						settlementAgreed : $scope.shortfallDetails.settlementAgreed,
						shortfallCollected : (parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0 ) ? 0 : agreementInfo.shortfallDetails.currentShortfallCollected,
						breakupDetails: {
							'Installment': agreementInfo.shortfallDetails.otherDetails.installment,
							'POS': agreementInfo.shortfallDetails.otherDetails.POS,
							'Seizure Charges': agreementInfo.shortfallDetails.otherDetails.seizureCharges,
							'Parking Charges': agreementInfo.shortfallDetails.otherDetails.parkingCharges,
							'Legal Charges': agreementInfo.shortfallDetails.otherDetails.legalCharges,
							'OverDue Charges': agreementInfo.shortfallDetails.otherDetails.overDueCharges,
							'Prepayment Penalty': agreementInfo.shortfallDetails.otherDetails.prepaymentPenalty,
							'Interest On Termination': agreementInfo.shortfallDetails.otherDetails.terminationInt,
							'Other Receivable Advice(FVC, RPDC Charges etc.)': agreementInfo.shortfallDetails.otherDetails.otherReceivableAdvise,
							'Open Payable Advice (-)': agreementInfo.shortfallDetails.otherDetails.openPayAdvise,
							'Sale Price (-)': agreementInfo.shortfallDetails.otherDetails.salePrice,
							'Total' : agreementInfo.shortfallDetails.currentAVLoss
						},
						waiverAmount :  avWaiverAmount > 0 ? avWaiverAmount : 0,
						percentage: parseInt(actualAVLossPercent) > 0 ? actualAVLossPercent : '0.00',
						netWorking : networking
					}, {
						chargeType : 'Shortfall Notice',
						actualLoss : (parseInt(agreementInfo.shortfallDetails.shortfallNoticeAmount) <= 0) ? 0 : agreementInfo.shortfallDetails.shortfallNoticeAmount ,
						settlementAgreed : $scope.shortfallDetails.settlementAgreed,
						shortfallCollected : (parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : agreementInfo.shortfallDetails.currentShortfallCollected,
						waiverAmount :  sNoticeWaiverAmt > 0 ? sNoticeWaiverAmt : 0,
						percentage: parseInt(shortfallNoticePercent) > 0 ? shortfallNoticePercent : '0.00',
						netWorking : networking
					}, {
						chargeType : 'Shortfall Due',
						actualLoss : shortfallDue,
						settlementAgreed : $scope.shortfallDetails.settlementAgreed	,
						shortfallCollected : (parseInt(agreementInfo.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : agreementInfo.shortfallDetails.currentShortfallCollected,
						breakupDetails: {
							'AV Loss': (parseInt(agreementInfo.shortfallDetails.currentAVLoss) <= 0) ? 0 : agreementInfo.shortfallDetails.currentAVLoss,
							'Interest': agreementInfo.shortfallDetails.currentInterestAmount,
							'Total' : shortfallDue
						},
						waiverAmount :  shortfallDueWaiverAmt > 0 ? shortfallDueWaiverAmt : 0,
						percentage : parseInt(shortfallDuePercent) > 0 ? shortfallDuePercent : '0.00',
						netWorking : networking
					}];


					if ($scope.waiverInfo.workflow) {
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.workflow, approvalQueueConstants.APPROVALSTATUS);					
					} else if ($scope.waiverInfo.foreCloseLADetails && $scope.waiverInfo.foreCloseLADetails.workflow) {
						$scope.waiverInfo.remarksData = utility.getApprovalsRemarks($scope.waiverInfo.foreCloseLADetails.workflow, approvalQueueConstants.APPROVALSTATUS);
					}
					$scope.waiverInfo.initObj = _.findWhere($scope.waiverInfo.workflow, {
						workStatus : 'INITIATED'
					});
					
					if ($scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.currentStatus) {
						$scope.waiverInfo.rejectedObj = _.findWhere($scope.waiverInfo.workflow, {
							workStatus : $scope.requestObj.approvalDetails.currentStatus
						});
						$scope.waiverInfo.rejObj = _.findWhere($scope.waiverInfo.workflow, {
							workStatus : 'REJECTED'
						});						
					}

					$scope.isRejected = $scope.waiverInfo.rejObj ? true : false;
					$scope.reInitiatFlag = $scope.requestObj.approvalDetails && $scope.requestObj.approvalDetails.initiatedBy&& ($scope.requestObj.approvalDetails.initiatedBy.userID === $rootScope.identity.userID);
				}
			});
		};
		var roundOffValue = function (dividend, divisor) {
			if (!parseInt(dividend)) {
				return '0';
			}
			var roundedVal = ((parseInt(dividend) / parseInt(divisor)) * 100);
			roundedVal = roundedVal.toFixed(2);
			return {
				displayVal: (roundedVal !== '0.00' && !parseInt(roundedVal)) ? '< 1%' : roundedVal + '%',
				actualVal: roundedVal
			};
		};
		function init() {
			$scope.customerInfo = utility.getCustomerInfo(approvalQueueService.getAgreementObj());
            $scope.customerInfo.branchName = approvalQueueService.getBranchName($scope.customerInfo.branchID);
            $scope.customerInfo.allocatedBranchName = approvalQueueService.getBranchName($scope.customerInfo.lmsBranchID);
			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
				status : $scope.customerInfo.agreementStatus
			});
			if($scope.requestObj.requestType !== 'FORECLOSURELA'){
				approvalQueueService.getUserAgreementList($stateParams.agreementNo, $scope.customerInfo.APPLICANT.cifID).then(function(data) {
					$scope.linkedAgrNos = data;
					var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos, {
						agreementNo : $stateParams.agreementNo
					}), 1);
					selectedAgr[0].isDefault = false;
					$scope.linkedAgrNos.unshift(selectedAgr[0]);
				});
			}
			getWaiverDetails();
		}
		init();

			/* popupModal for breakupDetails */ 
			$scope.openModal = function (option, otherDetails, actualAmount) {
					$modal.open({
						templateUrl: 'app/collections/approvals/initiateRequest/partials/shortfallWaiverPopup.html',
						controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {

							$scope.data = option;
							$scope.breakupDetails = otherDetails;

							actualAmount = (actualAmount == '' || actualAmount == 'undefined' || actualAmount == undefined) ? 0 : actualAmount;
							if(actualAmount){
							var currentBVLoss = 0;
							var currentBalance = 0;

								$scope.breakupDetails.waiverAmount = actualAmount;
								
								if(parseInt(otherDetails.currentApprovedWaiverAmount) > 0){
									currentBVLoss = parseInt(otherDetails.currentBVLoss) - parseInt(otherDetails.currentApprovedWaiverAmount);
									currentBalance = (parseInt(currentBVLoss) <= 0) ? 0 : parseInt(currentBVLoss);																		
									$scope.breakupDetails.agreedAmount = parseInt(currentBalance) - parseInt(otherDetails.currentPaidAmount);
								}else{
									currentBVLoss = parseInt(otherDetails.currentBVLoss) - parseInt(otherDetails.currentPaidAmount);
									currentBalance = (parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected);									
									$scope.breakupDetails.agreedAmount = parseInt(otherDetails.currentBVLoss) - (parseInt(otherDetails.currentPaidAmount) + parseInt(actualAmount));
								}
								$scope.breakupDetails.agreedAmount = (parseInt($scope.breakupDetails.agreedAmount) < 0) ? 0 : $scope.breakupDetails.agreedAmount;
							}

							$scope.close = function () {
								$modalInstance.dismiss();
							};
						}],
						size: 'md',
						backdrop: 'static',
						windowClass: 'modal-custom',
						resolve: {

						}
					});
				}

		$scope.showAgreementPopup = function(){
			$modal.open({
				templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.data = {};
					$scope.data.isViewOnly = data.isViewOnly;
					$scope.data.totalRecords = data.agreementNos;
					$scope.data.productType = data.productType;
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.saveHandler = function(){
						$modalInstance.dismiss();
					};
					$scope.paginationHandler = function(pageNo){
						var startLen = $scope.data.recordPerPage * (pageNo-1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function(){
						$modalInstance.dismiss();
					};
				}],
				size : 'md',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
						return {
							agreementNos : $scope.linkedAgrNos,
							isViewOnly : true,
							productType :$scope.customerInfo.productGroup
						};
					}
				}
			});
		};
		$scope.showChildAgreements = function(childAgreements) {
			$modal.open({
				templateUrl : 'app/collections/eReceipt/receipting/partials/popup/viewChildAgreements.html',
				controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
					$scope.childAgreements = childAgreements ? childAgreements : [];
					$scope.close = function() {
						$modalInstance.close();
					};
					$scope.okHandler = function() {
						$scope.close();
					};
				} ],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};

		$scope.handleRequest = function(reqType,reInit) {
			if (reqType === 'REJECTED' && !$scope.waiverInfo.rejectionReason) {
				dialogService.showAlert('Error', "Error", "Enter the reason for rejection");
				return;
			}
			var reqObj = { };
			
			var reqObj = {
				status : reqType,
				branchID : $scope.requestObj.branchId,
				agreementNos : $scope.waiverInfo.agreementNos,
				receiptNo : $scope.waiverInfo.receiptNo,
				waiverType : $scope.waiverInfo.waiverType,
				justification : $scope.waiverInfo.justification,
				customerBackground : $scope.waiverInfo.customerBackground,
				chargeDetails : approvalQueueService.getWaiverCharges(),
				majorVersion : $scope.waiverInfo.majorVersion,
				minorVersion : $scope.waiverInfo.minorVersion,
				requestID : $scope.waiverInfo.requestID,
				remarks : $scope.waiverInfo.rejectionReason,
				collectionType : $scope.waiverInfo.collectionType,
				payDetails: $scope.waiverInfo.payDetails
			};
			
			var approvalService;
			if ($scope.requestObj.requestType == 'FORECLOSURELA') {
				approvalService = 'FORECLOSURELA';
				reqObj = {
					status : reqType,
					branchID : $scope.requestObj.branchId,
					agreementNo : $scope.waiverInfo.foreCloseLADetails.agreementNo,
					majorVersion : $scope.waiverInfo.foreCloseLADetails.majorVersion,
					minorVersion : $scope.waiverInfo.foreCloseLADetails.minorVersion,
					requestType : $scope.waiverInfo.foreCloseLADetails.requestType,
					remarks : $scope.waiverInfo.rejectionReason,
					requestID : $scope.requestObj.requestID,
					LAType : $scope.waiverInfo.foreCloseLADetails.LAType
				};
			} else {
				approvalService = 'WAIVER';
			}
			
			if (reqType === 'ESCALATE') {
				reqObj.actionID = $scope.requestObj.selectedManager;
				reqObj.requestID =  $scope.requestObj.requestID;
				reqObj.levelChange = true;
				reqObj.status = collectionConstants.NEXT_LEVEL_ACTIONS[$scope.requestObj.approvalDetails.nextLevelAction];
				reqObj.remarks = $scope.waiverInfo.initObj ? $scope.waiverInfo.initObj.comments : '';
			}else{
				reqObj.actionID = $scope.requestObj.approvalDetails.actionID;
			}
			
			approvalQueueService.handleRequest(reqObj, approvalService).then(function(data) {
				if (data) {
					var successString = "";
					if (reqType === 'ESCALATE') {
						successString = collectionConstants.SUCCESS_MSG.NEXT_LEVEL_ESCALATION;
					}else if(reInit){
						successString = "Shortfall Waiver Re-Initiated successfully";
					} else {
						successString = "Shortfall Waiver " + reqType.toLowerCase() + " successfully";
					}
					dialogService.showAlert('Success', "Success", successString).result.then(function() {
					}, function() {
						approvalQueueService.updateInitiatedQueue(true);
					});
				} else {
					approvalQueueService.updateInitiatedQueue();
				}
			});
		};
		
		var escalateFn;
		$scope.getNextlevelMgrs = function() {
			var queryParams = {
				requestID : $scope.requestObj.requestID
			};	
			/*
			if ($stateParams.requestType === 'FORECLOSURELA') {
				queryParams.type = $scope.waiverInfo.foreCloseLADetails.LAType;
			} else if ($stateParams.requestType === 'FORECLOSURE' || $stateParams.requestType === 'NORMAL') {
				queryParams.requestID = $scope.requestObj.requestID;
			}*/
			
			approvalQueueService.getNextlevelMgrs($stateParams.requestType, $scope.requestObj.approvalDetails.actionID, '', queryParams).then(function(data) {
				if (data) {
					if (!data.length) {
						dialogService.showAlert('Message', "Message", collectionConstants.ERROR_MSG.NEXT_LEVEL_MANAGERS);
					} else {
						approvalQueueService.openUserPopup(data);
						if (escalateFn) {
							escalateFn();
						}
						escalateFn = messageBus.onMsg("UPDATE_MANAGER", function(event, data) {
							$scope.requestObj.selectedManager = data;
							$scope.handleRequest('ESCALATE');
						}, $scope);
					}
				}
			});
		};

	};

	approvalQueue.controller('shortfallWaiverController', [ '$scope', '$modal', '$stateParams', 'approvalQueueService', 'dialogService', 'lazyModuleLoader', '$globalScope', 'messageBus','$rootScope', shortfallWaiverController ]);
	return shortfallWaiverController;
});