/* Date : 10-Mar-2017
Modified by : Saranya Sankar R
Modification details : CR- Book Request Approvals */

define(['require','approvalQueue','approvalQueueConstants','collectionServiceURLs','utility','collectionConstants','constants'],function(r,approvalQueue,constants,collectionServiceURL,utility,collectionConstants,constant){
'use strict';
	
	var approvalQueueService = function($q,$rootScope,restProxy,$stateParams,masterService,repoMasterService,$modal,$globalScope,dialogService,environmentConfig){
		
		var branchNames = [];
		var selectedBranch = getCookie('selectedBranch');
		var limit = constants.PAGINATION_CONFIG.TEN_RECORD_PER_PAGE;
		var convertDate = function(isoString){
			if(!isoString){
				return;
			}
			var localDate = new Date(isoString);
			var date = localDate.getDate();
			date = date<10?('0'+date):date;
			var month = localDate.getMonth()+1;
			month = month<10?('0'+month):month;
			return date+'-'+month+'-'+(localDate.getFullYear());
		};
		
		var getValFromObj = function(str,item){
			var label,value;
			label = str.split('.');
			value = item[label[0]];
			if ((item.requestType == "SHORTFALLWAIVER" || item.requestType == "LEGALCASE") && label && label.length > 2 && label[1] && label[1] == "pendingWith" && label[2] && Object.prototype.toString.call(value[label[1]]) === '[object Array]') {
				value = (value && value[label[1]] && value[label[1]].length && value[label[1]][0][label[2]]) ? value[label[1]][0][label[2]] : '';
			} else {
				for (var k = 1; k < label.length; k++) {
					value = value ? value[label[k]] : '';
				}
				return value;
			}
		};
		var isReqRejected;
		var loginDetails = function (queryObj) {
			queryObj = queryObj || {};
			switch ($rootScope.identity.hierarchyName.toUpperCase()) {
				case 'TELLER':
					queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				case 'BRM':
					queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				case 'ARM':
					queryObj.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					break;
				case 'ALM':
					queryObj.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					break;	
				case 'RRM':
					queryObj.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					break;
				case 'RLM':
					queryObj.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					break;	
				case 'ZRM':
					queryObj.zoneID = JSON.parse(getCookie('selectedBranch')).ZoneID;
					break;
				default:
					queryObj.branchID = JSON.parse(getCookie('selectedBranch')).branchID;					
					break;
			}
			return queryObj;
		};
		var getValuesFromConstants = function(menu,item){
			for(var i=0;i<menu.length;i++){
				if(menu[i].label.toUpperCase() == "PENDING WITH"){
					continue;
				}
				if(typeof menu[i].value === 'object'){
					var result = '';
					for(var j=0;j<menu[i].value.length;j++){
						var submenus = menu[i].value[j];
						var selectedval = getValFromObj(submenus,item);
						result += result ? '/ '+selectedval : selectedval;
					}
					menu[i].value = result;
				} else {
					menu[i].value = getValFromObj(menu[i].value, item);
				}
				menu[i].value = menu[i].isDate ? convertDate(menu[i].value) : menu[i].value;
				if(menu[i].label === 'Branch' && menu[i].value){
					var branch = _.findWhere(branchNames,{branchID : menu[i].value});
					menu[i].value = branch ? branch.branchDesc : '';
				}
				if(menu[i].label === 'Status' && !menu[i].value){
					menu[i].value = 'INITIATED';
				}
				if(isReqRejected){
					menu[i].label = menu[i].label.replace(/Approved/g,'Rejected');
				}
			}
		};
		
		var getAllDetails = function(data,reqObj){
			_.each(data.data,function(item){
				if(!reqObj.hasOwnProperty(item.requestType)){
					return;
				}
				item.mainRow = angular.copy(reqObj[item.requestType].mainRow);
				item.subRow = angular.copy(reqObj[item.requestType].subRow);
				item.reqLabel = reqObj[item.requestType].reqLabel;
				if(item.approvalDetails){
					if(item.approvalDetails.currentStatus === 'REJECTED' && item.approvalDetails.pendingWith  && item.approvalDetails.pendingWith.userID){
						item.approvalDetails.currentStatus = 'INITIATED';
						item.approvalDetails.originalStatus = 'REJECTED';
						item.approvalDetails.initiatedBy = angular.copy(item.approvalDetails.approvedBy);
						item.approvalDetails.initiatedOn = angular.copy(item.approvalDetails.approvedOn);
						delete item.approvalDetails.approvedBy;
						delete item.approvalDetails.approvedOn;
					}
					isReqRejected = item.approvalDetails.currentStatus === 'REJECTED';
					item.rowclass = item.approvalDetails.currentStatus === 'APPROVED' ? 'req_approved' : item.approvalDetails.currentStatus === 'RECOMMENDED' ? 'req_recommended' : item.approvalDetails.currentStatus === 'REJECTED' ? 'req_rejected' : '';
				}
				if ((item.receiptType === 'IMD' && item.productType === 'VF') || (item.receiptType === 'INS' && !item.agreementNo)) {
					item.mainRow[0] = {label: 'Lead ID.', value: 'payerID'};
				} else if (item.receiptType === 'IMD' && item.productType !== 'VF') {
					item.appID = item.applicationNos[0];
					item.mainRow[0] = {label: 'Application ID', value: 'appID'};
				} else if (item.receiptType === 'NonAgreement') {
					item.payerName = item.payerName.toUpperCase(); 
					item.mainRow[0] = {label:'Reference No.',value:'payerID'};
					item.mainRow[1].value = 'payerName';
				}
				// apply currency formatter
				switch(item.requestType){
					case 'FORECLOSURE':
					case 'NORMAL':
						item.approvalDetails.waiverAmount = utility.currencyFormatter(item.approvalDetails.waiverAmount);
						break;
					case 'ORANGECUSTOMER':
					case 'REPO':
					case 'SURRENDERCUSTOMER':
					case 'LEGALCASE':
					case 'DOCUMENTWAIVER':
						item.totalODAmount = utility.currencyFormatter(item.totalODAmount);
						break;
					case 'CASHTENLAKHS':
					case 'RTGS':
					case 'POS':
					case 'PANCARD':
					case 'RECEIPTCANCELLATION':
					case 'RECEIPTMODIFICATION':
					case 'BACKDATEDRECEIPT':
						item.receiptAmount = utility.currencyFormatter(item.receiptAmount);
						break;
					case 'EXCESSSHORTFALL':
						item.excessAmount = utility.currencyFormatter(item.excessAmount);
						break;
					case 'SURRENDEREXPENSE':
						item.totalExpenseAmount = utility.currencyFormatter(item.totalExpenseAmount);
						break;
					case 'SALEAPPROVAL':
					case 'SALERELEASELETTER':
					case 'REPORELEASELETTER':
						item.highestSaleQuoteAmt = utility.currencyFormatter(item.highestSaleQuoteAmt);
						break;
					case 'FORECLOSUREHEHL':
						item.foreClosureAmount = utility.currencyFormatter(item.foreClosureAmount);
						break;
					case 'LEGALCOMPLIANCE':
					case 'LEGALAPPEAL':
						item.complianceAmount = utility.currencyFormatter(item.complianceAmount);
						break;
					case 'BACKDATEDCHALLANING':
						item.challanReceiptAmount = utility.currencyFormatter(item.challanReceiptAmount);
						break;
					case 'REPOMARKINGLMS':
					case 'REPOWRONGMARKING':
					case 'NONEMPANELLEDAGENT':
						item.seizureCharge = utility.currencyFormatter(item.seizureCharge);
						break;	
				}
				
				if(item.receiptType == 'TA') {
					item.mainRow[1].label = 'Dealer Name';
				}
				if(item.requestType == 'BACKDATEDRECEIPT' && item.receiptType == 'NonAgreement' || item.receiptType == 'TA'){
					item.customerName = item.payerName;
				}
				if(item.requestType === 'RTGS'){
					if(item.receiptFor && item.receiptFor.toUpperCase() == 'VISHESHAGREEMENT'){
						item.reqLabel = "Vishesh RTGS Receipt"
					}else if(item.receiptFor && item.receiptFor.toUpperCase() == 'TRIPLOAN'){
						item.reqLabel = "Trip RTGS Receipt";
					}else if(item.receiptType == 'TA'){
						item.reqLabel = "Dealer RTGS Receipt";
					}else if(item.receiptType == 'IMD'){
						item.reqLabel = "IMD RTGS Receipt";
					}
				}
				if(item.receiptFor && (item.receiptFor.toUpperCase() === 'VISHESHAGREEMENT' || item.receiptFor.toUpperCase() === 'TRIPLOAN') && (item.requestType === 'PANCARD' || item.requestType === 'ORANGECUSTOMER' || item.requestType === 'RECEIPTMODIFICATION' || item.requestType === 'LMSCANCELLATIONRECEIPT' || item.requestType === 'BACKDATEDRECEIPT' || item.requestType === 'RECEIPTCANCELLATION' )){
					item.mainRow[0].label = item.receiptFor.toUpperCase() === 'VISHESHAGREEMENT' ? 'Vishesh Loan ID' : 'Trip Loan No';
				}
				if (item.requestType === 'BACKDATEDRECEIPT' && item.receiptType === 'NonAgreement') {
					item.customerName = item.payerName;
				}
				getValuesFromConstants(item.mainRow,item);
				getValuesFromConstants(item.subRow,item);
			});
			return data;
		};
		
		this.getSaleRefundDetails = function (agreementNo, receiptNo) {
			collectionServiceURL.legalServices.GET_SALE_REFUND.queryParams = {
				'agreementNo': agreementNo,
				'receiptNo': receiptNo
			};
			return restProxy.get(collectionServiceURL.legalServices.GET_SALE_REFUND).then(function (data) {
				return data.data;
			});
		};

		this.initiateSaleRefundRequest = function (reqBody) {
			collectionServiceURL.approvalServices.SALEREFUND_APPROVAL.urlParams = {};
			return restProxy.save('POST', collectionServiceURL.approvalServices.SALEREFUND_APPROVAL, reqBody, '', {
				userbranch: JSON.parse(getCookie('selectedBranch')).branchID
			}).then(function (data) {
				return data.data;
			});
		};
		this.getBranchName = function(branchID){
			var branchObj = _.findWhere(branchNames,{branchID:branchID});
			return branchObj ? branchObj.branchDesc : '';
		};
		this.documentWavierRequest = function(queryObj){
             return restProxy.save('put',collectionServiceURL.repoServices.DOCUMENT_WAIVER_REQUEST,queryObj).then(function (data) {
                if(data.status === "success"){
                    return data;
                }
            });
        };
		this.getQueueDetails =  function(queryObj,reqStatus){
			if(queryObj.fromdate && queryObj.todate){
				queryObj.fromdate = utility.formDateString(new Date(queryObj.fromdate));
				queryObj.todate = utility.formDateString(new Date(queryObj.todate));
			}
			var url = collectionServiceURL.approvalServices[reqStatus+'_APPROVAL_DETAILS'];
			url.queryParams = queryObj;
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				if(data && data.meta && data.meta.hasOwnProperty('totalCount')){
					_.each(data.data, function(item){
						item.SectionName='';
						if(item.legalSections.length>=1){
							item.SectionName = item.legalSections[0].replace(/_/g, " ");
						}
					});
					if(!branchNames.length){
						return masterService.getBranches().then(function(branchdata){
							if(branchdata && branchdata.length){
								branchNames = branchdata;
							}
							data = getAllDetails(data,constants[reqStatus+'_QUEUE']);
							return data;
						});
					} else {
						data = getAllDetails(data, constants[reqStatus + '_QUEUE']);
						return data;
					}
				} else if (data && data.data && !data.data.length) {
					data.meta = {totalCount: 0};
					return data;
				} else {
					return $q.reject(data);
				}
			});
		};
		
		var agreemntDetails = {};
		var waiverCharges = [];
		this.getWaiverCharges = function(){
			return waiverCharges;
		};
		
		this.getWaiverDetails =  function(requestObj,agreementNo){			
    		if(requestObj.requestType == 'FORECLOSURELA'){
    			collectionServiceURL.approvalServices.WAIVER_DETAILS.urlParams = {type:'foreclosurela'};
    			collectionServiceURL.approvalServices.WAIVER_DETAILS.queryParams = {agreementNo:agreementNo};    			
 			}else if(requestObj.requestType == 'DOCUMENTWAIVER'){
 				collectionServiceURL.approvalServices.WAIVER_DETAILS.urlParams = {type:'documentwaiver'};
				collectionServiceURL.approvalServices.WAIVER_DETAILS.queryParams = {agreementNo:agreementNo};
 			}else{
 				collectionServiceURL.approvalServices.WAIVER_DETAILS.urlParams = {type:'waiver'};
 				collectionServiceURL.approvalServices.WAIVER_DETAILS.queryParams = {requestID:requestObj.requestID};
 			}		
			return restProxy.get(collectionServiceURL.approvalServices.WAIVER_DETAILS).then(function(data){
				if(data.data && data.data.length && data.data[0].chargeDetails){
					waiverCharges = angular.copy(data.data[0].chargeDetails);
					var percent ;
					var total = {
						chargeType: 'TOTAL',
						actualAmount: 0,
						waiverAmount: 0,
						netWorking: 0,
						percentage: 0
					};
					_.each(data.data[0].chargeDetails,function(item){
						item.netWorking = item.actualAmount-item.waiverAmount;
						percent = ((parseInt(item.waiverAmount)/parseInt(item.actualAmount))*100);
						percent = percent.toFixed(2);
						item.percentage = percent !== '0.00' && !parseInt(percent) ? '< 1%' : percent+'%';
						if(item.chargeType && item.chargeType.toUpperCase() === 'EXCESS REFUNDS'){
							total.actualAmount -= item.actualAmount;
							total.waiverAmount -= item.waiverAmount;
						}else{
							total.actualAmount += item.actualAmount;
							total.waiverAmount += item.waiverAmount;
						}
						if(item.chargeID === collectionConstants.CHARGE_IDS.FOUR_PERCENT_POS){
							item.chargeType = '4% POS';
						}else if(item.chargeID === collectionConstants.CHARGE_IDS.EXCESS  && data.data[0].waiverType != 'Normal'){
							item.chargeType = 'POS';
						}
					});
					percent = ((parseInt(total.waiverAmount)/parseInt(total.actualAmount))*100);
					percent = percent.toFixed(2);
					total.percentage = !parseInt(percent) ? '< 1%' : percent+'%';
					total.netWorking = total.actualAmount-total.waiverAmount;	
					data.data[0].chargeDetails.push(total);
				}
				return data.data;
			});
		};
		
		this.getPanCardUnavailabilityDetails = function(agrNo,queueObj){
			var url = '';
			if(queueObj.requestType==='PANCARD'){
				url = collectionServiceURL.approvalServices.PAN_CARD_UNAVAILABILITY;
			}else if(queueObj.requestType==='CASHTENLAKHS'){
				url = collectionServiceURL.approvalServices.CASH_TEN_LAKHS;
			}else if(queueObj.requestType==='RTGS'){
				url = collectionServiceURL.approvalServices.RTGS;
			}else if(queueObj.requestType==='POS'){
				url = collectionServiceURL.approvalServices.POS;
			}else if(queueObj.requestType === 'RECEIPTMODIFICATION'){
				url = collectionServiceURL.approvalServices.RECEIPTMODIFICATION;
			}else if(queueObj.requestType === 'LMSCANCELLATIONRECEIPT'){
				url = collectionServiceURL.approvalServices.LMS_CANCELLATION_RECEIPT;
			}else{
				url = collectionServiceURL.approvalServices.RECEIPT_CANCEL;
			}
			url.queryParams = {
				agreementNo: queueObj.receiptFor === "ClosedAgreement" ? '' : agrNo, // agreement No won't be send for closed cases 
				receiptNo: queueObj.receiptNo
			};
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data.data;
			});
		};

		this.handleReceiptRequest = function(reqType,reqObj){
			var url = collectionServiceURL.approvalServices[reqType+'_APPROVAL'];
			url.queryParams = {};
			url.urlParams = {};
			return restProxy.save('POST',url,reqObj,'',{userbranch:JSON.parse(getCookie('selectedBranch')).branchID}).then(function(data){
				return data.data;
			});
		};
		this.handleRequest = function(reqObj,reqType){
			var url = '';
			var method = (reqType == 'RESENDOTP') ? 'PUT' : 'POST';
			if(reqObj.rejectionReason){
				reqObj.remarks = reqObj.rejectionReason;
				delete reqObj.rejectionReason;
			}
			if(reqType === 'REPORELEASELETTER'){
				url = collectionServiceURL.approvalServices.REPO_RELEASE_LETTER;
			}else if(reqType === 'SALERELEASELETTER'){
				url = collectionServiceURL.approvalServices.SALE_RELEASE_LETTER;
			}else{
				url = collectionServiceURL.approvalServices[reqType+'_APPROVAL'];
			}
			url.queryParams = {};
			url.urlParams = {};
			return restProxy.save(method,url,reqObj,'',{userbranch:JSON.parse(getCookie('selectedBranch')).branchID}).then(function(data){
				return data.data;
			});
		};

		var setAgreementDetails = function(details){
			details.APPLICANT = details.applicantDetails = _.findWhere(details.partyDetails,{"partyType":"A"});
			if(details.APPLICANT){
				details.name = (details.APPLICANT.firstName) ? details.APPLICANT.firstName + ' ' : '';
				details.name += (details.APPLICANT.middleName) ? details.APPLICANT.middleName + ' ' : '';
				details.name += (details.APPLICANT.lastName) ? details.APPLICANT.lastName + ' ' : '';
			}
			details.status = constant.STATUS;
			agreemntDetails = details;
		};

		this.getAgreementDetails = function(agrNo){
						
			collectionServiceURL.receiptingServices.ENTRY_FORM.queryParams = {
					agreementNos: agrNo,
					view :"receiptDetail",
					productGroup : selectedRequest.productGroup !== 'PL' ? '' : selectedRequest.productGroup
			};
			if(selectedRequest.productGroup == '' && (selectedRequest.requestType == 'DUPLICATEDOCUMENTREQUEST' || selectedRequest.requestType == 'LEGALCASE')){
				if(collectionServiceURL.receiptingServices.ENTRY_FORM && collectionServiceURL.receiptingServices.ENTRY_FORM.queryParams && collectionServiceURL.receiptingServices.ENTRY_FORM.queryParams.productGroup){
					collectionServiceURL.receiptingServices.ENTRY_FORM.queryParams.productGroup = "VF";
				}
				
			}
			collectionServiceURL.receiptingServices.ENTRY_FORM.urlParams = {};
			return restProxy.get(collectionServiceURL.receiptingServices.ENTRY_FORM).then(function(data){
				if(data && data.data && data.data.length){
					setAgreementDetails(data.data[0]);
					return data.data[0];
				} else {
					return [];
				}
			});
		};

		this.getReceiptDetails = function(argNo,receiptNo){
			collectionServiceURL.approvalServices.BACK_DATED_RECEIPTING.queryParams = {
				agreementNo:argNo,
				receiptNo:receiptNo
			};
			collectionServiceURL.approvalServices.BACK_DATED_RECEIPTING.urlParams = {};
			return restProxy.get(collectionServiceURL.approvalServices.BACK_DATED_RECEIPTING).then(function(data){
				if (data && data.data){
					return data.data[0];
				}else {
					return [];
				}
			});
		};

		this.getAgreementObj = function(){
			return agreemntDetails;
		};
		var selectedRequest = {};
		this.setSelectedRequest = function(reqObj){
			selectedRequest = reqObj;
		};
		this.getSelectedRequest = function(){
			return selectedRequest;
		};
		this.getLeadDetails = function(leadID,productType){
			var serviceConfig;
			if(productType === 'VF'){
				serviceConfig = collectionServiceURL.receiptingServices.SEARCH_RECEIPT_IMD; 
				serviceConfig.queryParams = {};
				serviceConfig.urlParams = {
						leadID : leadID
				};
			}else{
				serviceConfig = collectionServiceURL.receiptingServices.ENTRY_FORM_IMD_HEHL; 
				serviceConfig.urlParams = {
						app : 'applications',
						applicationID:leadID
				};
			}
			return restProxy.get(serviceConfig).then(function(data){
				if (data && data.data){
					if(productType !== 'VF' && data.data[0].loanDetail.propertyDetails && data.data[0].loanDetail.propertyDetails[0]){
						data.data[0].propertyDetailsAddress = utility.setAddress(data.data[0].loanDetail.propertyDetails[0].addressDetail);
					}
					setAgreementDetails(data.data[0]);
					return data.data[0];
				}else {
					return [];
				}
			});
		};
		this.getTAAgreementDetails = function(agreementNo){
			collectionServiceURL.receiptingServices.SEARCH_RECEIPTS.queryParams = {
				view : 'receiptDetailTA',
				agreementNos : agreementNo
			};
			collectionServiceURL.receiptingServices.SEARCH_RECEIPTS.urlParams = {};
			return restProxy.get(collectionServiceURL.receiptingServices.SEARCH_RECEIPTS).then(function(data){
				if (data && data.data){
					setAgreementDetails(data.data[0]);
					return data.data[0];
				}else {
					return [];
				}
			});
		};
		this.getReceiptBookReqs = function(reqType,approvalStatus){
			var url = {};
			if(reqType==='RECEIPTBOOKISSUANCE'){
				url = collectionServiceURL.approvalServices.RECEIPTBOOK_ISSUANCE;
			} else if (reqType === 'DAMAGEDRECEIPTBOOKS') {
				url = collectionServiceURL.approvalServices.RECEIPTBOOK_DAMAGED;
			} else if (reqType === 'RECEIPTBOOKRETENTION') {
				url = collectionServiceURL.approvalServices.RECEIPTBOOK_RETENTION;
			} else if (reqType === 'RECEIPTBOOKREQUEST') {
				url = collectionServiceURL.approvalServices.RECEIPTBOOK_REQUEST;
			}
			url.queryParams = { type:approvalStatus.toLowerCase() };
			url.urlParams = {};
			return restProxy.get(url).then(function(data){
				return data;
			});
		};
		this.postReceiptBookReq = function(reqObj,reqStatus,reqType,actionId,branchID){
			var reqArr = [];
			_.each(reqObj,function(book){
				if(book.isSelected){
					var bookReq = {
						status : reqStatus,
						actionID : actionId,
						branchID : branchID,
						majorVersion : book.majorVersion,
						minorVersion : book.minorVersion							
					};
					if(book.requestNo){
						bookReq.requestNo = book.requestNo;
					}
					if(book.receiptBookNo){
						bookReq.receiptBookNo = book.receiptBookNo;
					}
					if(book.remarks){
						bookReq.remarks = book.remarks;
					}
					reqArr.push(bookReq);
				}
			});
			if(reqStatus === 'ESCALATE'){
				reqArr[0].actionID = reqObj[0].actionId;
				reqArr[0].levelChange = true;
				reqArr[0].status =  reqObj[0].status;
			}
			var url = collectionServiceURL.approvalServices[reqType+'_APPROVAL'];
			url.queryParams = {};
			url.urlParams = {};
			return restProxy.save('POST',url,reqArr,'',{userbranch:JSON.parse(getCookie('selectedBranch')).branchID}).then(function(data){
				return data.data;
			});
		};
		this.getOrangeCustomer = function(argNo){
			collectionServiceURL.approvalServices.GET_ORANGE_CUSTOMER.queryParams = {
				agreementNo:argNo
			};
			collectionServiceURL.approvalServices.GET_ORANGE_CUSTOMER.urlParams = {};
			return restProxy.get(collectionServiceURL.approvalServices.GET_ORANGE_CUSTOMER).then(function(data){
				if (data && data.data){
					return data.data;
				}else {
					return {};
				}
			});
		};
		
		this.getDCRDetails = function(reportID){
			collectionServiceURL.approvalServices.GET_EOD_DCR.queryParams = {
				reportID:reportID
			};
			collectionServiceURL.approvalServices.GET_EOD_DCR.urlParams = {};
			return restProxy.get(collectionServiceURL.approvalServices.GET_EOD_DCR).then(function(data){
				if (data && data.data){
					return data.data;
				}else {
					return {};
				}
			});
		};
		
		this.getMemoUploadDetails = function(challanNo){
			collectionServiceURL.approvalServices.GET_MEMO_UPLOAD.queryParams = {
				challanNo:challanNo
			};
			collectionServiceURL.approvalServices.GET_MEMO_UPLOAD.urlParams = {};
			return restProxy.get(collectionServiceURL.approvalServices.GET_MEMO_UPLOAD).then(function(data){
				if (data && data.data){
					return data.data;
				}else {
					return {};
				}
			});
		};
		this.getBatchDetails = function(batchId,mode,product){
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams = {
					userrole:($rootScope.identity.hierarchyName),
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:mode,
					product:product
			};
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchId
			};
			return restProxy.get(collectionServiceURL.batchingServices.GET_BATCHDETAILS).then(function(data){
				return data.data;    					
			}); 
		};
		this.getRepoDetails = function(agreementNo,reqType,letterType){
			var url = {};
			if(reqType==='REPORELEASELETTER' || reqType==='REPO'||reqType==='SURRENDERCUSTOMER'||letterType==='REPO'){
				url = collectionServiceURL.repoServices.GET_AGREEMENTDETAILS;
				url.queryParams = {};
				url.urlParams = { agreementNo : agreementNo };
			} else if (reqType === 'SALERELEASELETTER' || reqType === 'SALEAPPROVAL' || letterType === 'SALE') {
				url = collectionServiceURL.repoServices.GET_SALE_QUEUE;
				url.queryParams = { view : 'saleDetails' };
				url.urlParams = { agreementNo : agreementNo };
			} else if (reqType === 'SURRENDEREXPENSE') {
				url = collectionServiceURL.approvalServices.GET_SURRENDER_EXPENSE;
				url.queryParams = { agreementNo : agreementNo };
				url.urlParams = {};
			}
			return restProxy.get(url).then(function(data){
				return data.data[0];
			});  
		};
		this.getProvisionDetails = function(agrNo,provisionAmt){
			var url = {};
			url = collectionServiceURL.repoServices.GET_SALE_QUEUE;
			url.queryParams = { view : 'calculateProvision',provisionAmount : provisionAmt };
			url.urlParams = { agreementNo : agrNo };
			return restProxy.get(url).then(function(data){
				return data.data[0];
			}); 
		};
		this.getRepoAgents = function(agreementNo){
			collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS.urlParams = { agreementNo : agreementNo };
			collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS.queryParams = {
					userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
					userrole : $rootScope.identity.hierarchyName
			};
			return restProxy.get(collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS).then(function(data){
				return data.data;
			});
		};
		
		this.getYardVendors = function(agreementNo){
			collectionServiceURL.repoServices.GET_SEIZUREDETAILS.urlParams = {
					agreementNo:agreementNo	
			};
			collectionServiceURL.repoServices.GET_SEIZUREDETAILS.queryParams = {
					view:"seizureDetails"	
			};
			return restProxy.get(collectionServiceURL.repoServices.GET_SEIZUREDETAILS).then(function(data){
				if(data.data && data.data[0]){
					return data.data[0];
				}else{
					return {};
				}
			});
		};
		
		this.getLegalInitiatedInfo = function(type, requestType){
			if(requestType == 'LEGALADVOCATECHANGE'){
				collectionServiceURL.approvalServices.GET_ADVOCATE_INITIATED_LEGAL_INFO.queryParams = {
					type: type ? type.toLowerCase() : "initiated"
				};
				return restProxy.get(collectionServiceURL.approvalServices.GET_ADVOCATE_INITIATED_LEGAL_INFO).then(function(data){
					return (data && data.data) ? data.data : [];
				});
			}else if(requestType == 'LEGALADVOCATEFEECHANGE'){
				collectionServiceURL.approvalServices.GET_LEGAL_ADVOCATE_FEE_CHANGE.queryParams = {
					type: type ? type.toLowerCase() : "initiated"
				};
				return restProxy.get(collectionServiceURL.approvalServices.GET_LEGAL_ADVOCATE_FEE_CHANGE).then(function(data){
					return (data && data.data) ? data.data : [];
				});
			}else if(requestType == 'LEGALAGREEMENTBLOCK'){
				collectionServiceURL.approvalServices.GET_AGREEMENTBLOCK_INITIATED_LEGAL_INFO.queryParams = {
					type: type ? type.toLowerCase() : "initiated"
				};
				return restProxy.get(collectionServiceURL.approvalServices.GET_AGREEMENTBLOCK_INITIATED_LEGAL_INFO).then(function(data){
					return (data && data.data) ? data.data : [];
				});
			} else{
				collectionServiceURL.approvalServices.GET_INITIATED_LEGAL_INFO.queryParams = {
					// agreementNo:agreementNo,
					// caseID:caseID
					type: type ? type.toLowerCase() : "initiated"
				};
				return restProxy.get(collectionServiceURL.approvalServices.GET_INITIATED_LEGAL_INFO).then(function(data){
					return (data && data.data) ? data.data : [];
				});
			}
		};
		
		
		this.getUserAgreementList = function(agreementNo,cifId,productType){
			collectionServiceURL.myCustomerServices.AGREEMENT_LIST.queryParams = {
				cifID: cifId,
				productGroup: productType
			};
			return restProxy.get(collectionServiceURL.myCustomerServices.AGREEMENT_LIST).then(function(data) {
				var agreementList = [];
				_.each(data.data, function(item) {
					if(item.agreementNo){
						agreementList.push({
							agreementNo: item.agreementNo,
							selected: false,
							vehicleNo: item.assetDetail ? item.assetDetail.lmsRegistrationNo : ''
						});
					}
				});
				return agreementList;
			});
		};
		
		this.approveRejectLegalCase = function(postObj){
			if(postObj[0].workflow[0].requestType === "LEGALADVOCATECHANGE") {
				return restProxy.save('POST',collectionServiceURL.approvalServices.ADVOCATE_INITIATE_LEGAL,postObj).then(function(data){
					return data.data;
				});
			}else if(postObj[0].workflow[0].requestType === "LEGALADVOCATEFEECHANGE") {
				return restProxy.save('POST',collectionServiceURL.approvalServices.INITIATE_LEGAL_ADVOCATE_FEE_CHANGE,postObj).then(function(data){
					return data.data;
				});
			}else if(postObj[0].workflow[0].requestType === "LEGALAGREEMNENTBLOCK") {
				return restProxy.save('POST',collectionServiceURL.approvalServices.AGREEMENTBLOCK_INITIATE_LEGAL,postObj).then(function(data){
					return data.data;
				});
			}else {
				return restProxy.save('POST',collectionServiceURL.approvalServices.INITIATE_LEGAL,postObj).then(function(data){
					return data.data;
				});
			}
		};
		
		
		this.getChallanDetails = function(challanID){
			collectionServiceURL.approvalServices.GET_BD_CHALLAN_DETAILS.queryParams = {challanNo:challanID};
			return restProxy.get(collectionServiceURL.approvalServices.GET_BD_CHALLAN_DETAILS).then(function(data) {
				return (data.data) ? data.data : $q.reject(data);
			});
		};
		
		this.viewReceipts = function(batchId,mode,product){
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.queryParams = {
					userbranch:JSON.parse(getCookie('selectedBranch')).branchID,
					mode:mode,
					product:product
			};
			collectionServiceURL.batchingServices.GET_BATCHDETAILS.urlParams = {
					batchID:batchId
			};
			return restProxy.get(collectionServiceURL.batchingServices.GET_BATCHDETAILS).then(function(data){
				return data.data;
			});  	
		};
		
		this.proccedRequest = function(postBody){
			return restProxy.save('POST',collectionServiceURL.approvalServices.POST_BD_CHALLAN,postBody).then(function(data){
				return data.data;
			});
		};
		this.getLegalCaseDetails = function(agreementNo,caseID,type){
			var queryParams = {
				agreementNo: agreementNo,
				caseID: caseID
			};
			if(type ==='LEGALCOMPLIANCE'){
				collectionServiceURL.approvalServices.GET_LEGAL_COMPLIANCE.queryParams = queryParams;
				return restProxy.get(collectionServiceURL.approvalServices.GET_LEGAL_COMPLIANCE).then(function(data){
					return data.data;
				});
			}else{
				collectionServiceURL.approvalServices.GET_LEGAL_APPEAL.queryParams = queryParams;
				return restProxy.get(collectionServiceURL.approvalServices.GET_LEGAL_APPEAL).then(function(data){
					return data.data;
				});
			}
		};
		this.updateLegalCompliance = function(postObj,legalType){
			if(legalType ==='LEGALCOMPLIANCE'){
				return restProxy.save('POST',collectionServiceURL.approvalServices.UPDATE_LEGAL_COMPLIANCE,postObj).then(function(data){
					return data.data;
				});
			}else{
				return restProxy.save('POST',collectionServiceURL.approvalServices.UPDATE_LEGAL_APPEAL,postObj).then(function(data){
					return data.data;
				});
			}
		};
		this.getForeclosureDetails = function(agrNo,requestNo){
			collectionServiceURL.approvalServices.FC_DETAILS.urlParams = {};
			collectionServiceURL.approvalServices.FC_DETAILS.queryParams = {
				agreementNo: agrNo,
				requestNo: requestNo
			};
			return restProxy.get(collectionServiceURL.approvalServices.FC_DETAILS).then(function(data){
				return data.data;
			});
		};
		this.getAddressDetails = function(thirdPartyID,requestID){
			collectionServiceURL.approvalServices.ADDRESS_DETAILS.urlParams = {};
			collectionServiceURL.approvalServices.ADDRESS_DETAILS.queryParams = {
				thirdPartyID: thirdPartyID,
				requestID: requestID
			};
			return restProxy.get(collectionServiceURL.approvalServices.ADDRESS_DETAILS).then(function(data){
				return data.data;
			});
		};
		this.getNextlevelMgrs = function(requestType,actionID,agrStatus,requestObj,legalSection){
			collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.urlParams = {requestType:requestType.toLowerCase()};
			collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.queryParams={};
			if(requestObj){
				collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.queryParams = requestObj;
			}
			if(agrStatus){
				collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.queryParams.agreementStatus = agrStatus;
			}
			if(legalSection){
				collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.queryParams.legalSections = legalSection;
			}
			collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS.queryParams.actionID = actionID;
			return restProxy.get(collectionServiceURL.approvalServices.NEXTLEVEL_MANAGERS).then(function(data){
				return data.data;
			});
		};
		this.openUserPopup = function(users){
			$modal.open({
                templateUrl: 'app/collections/approvals/approvalQueue/partials/selectUser.html',
                controller: ['$scope','messageBus','$modalInstance','data',function($scope,messageBus,$modalInstance,data){
                	$scope.managers = data;
                	$scope.close = function(){
                		$modalInstance.close();
                	};
                	$scope.clickHandler = function(user){
                		messageBus.emitMsg("UPDATE_MANAGER",user);
                		$modalInstance.close();
                	};
                }],
                size: 'sm',
                backdrop : 'static',
                resolve : {
                	data : function(){
                		return users;
                	}
                }
            });
		};
		
		this.updateInitiatedQueue = function(reset){
			if(reset){
				this.pageFields.currentPage = 1;
				this.pageFields.offset = 1;
			}
			$globalScope.gotoPreviousPage();
		};
		
		this.getCholaBranches = function() {
			if (branchNames && branchNames.length > 0) {
				return $q.when(branchNames);
			}
			return masterService.getBranches().then(function(data) {
				branchNames = data;
				return data;
			});
		};
		
		this.getCholaBranchesByZone = function(){
			collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.urlParams = {};
			if($rootScope.identity.headerLabel === "Zone"){
				collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.queryParams = {
					view: "getBranch",
					zoneID: JSON.parse(getCookie('selectedBranch')).ZoneID
				};
				return restProxy.get(collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE).then(function(data){
					return data.data;
				});
			}else{
				var queryParams = {masterType: 'Branch,Area,Region,Zone'};
				switch ($rootScope.identity.headerLabel) {
				case 'Area':
					queryParams.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					queryParams.masterType = "Area,Region,Zone";
					break;
				case 'Region':
					queryParams.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					queryParams.masterType = "Region,Zone";
					break;
				default:
					queryParams.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				}
				return masterService.getZoneFromBranch(queryParams).then(function(data) {
					if(data && data.data && data.data.Zone && data.data.Zone[0] && data.data.Zone[0].ZoneID){
						collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.queryParams = {
							view: "getBranch",
							zoneID: data.data.Zone[0].ZoneID
						};
					return restProxy.get(collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE).then(function(data){
						return data.data;
					});
					}
				});
			}
			
		};
		
		this.getLegalDetails = function(caseID, type) {
			if(type === 'LEGALREOPENCASE'){
				collectionServiceURL.approvalServices.LEGAL_REOPEN.urlParams = {};
				collectionServiceURL.approvalServices.LEGAL_REOPEN.queryParams = {caseID:caseID};
				return restProxy.get(collectionServiceURL.approvalServices.LEGAL_REOPEN).then(function(data){
					return data.data;
				});

			}else {
				collectionServiceURL.approvalServices.LEGAL_WITHDRAWAL.urlParams = {};
				collectionServiceURL.approvalServices.LEGAL_WITHDRAWAL.queryParams = {caseID:caseID};
				return restProxy.get(collectionServiceURL.approvalServices.LEGAL_WITHDRAWAL).then(function(data){
					return data.data;
				});
		    }
		};
		
		this.getLegalChildCase = function(caseID) {
			collectionServiceURL.approvalServices.LEGAL_CHILD_CASE.urlParams = {};
			collectionServiceURL.approvalServices.LEGAL_CHILD_CASE.queryParams = {caseID:caseID};
			return restProxy.get(collectionServiceURL.approvalServices.LEGAL_CHILD_CASE).then(function(data){
				return data.data;
			});
		};
		
		this.getLegalAgreementDetails = function(agreementNo,cifID,count){
			collectionServiceURL.legalServices.CORPORATE_CASE.queryParams = {
				agreementNo: agreementNo,
				view: 'agreementDetail'
			};
			return restProxy.get(collectionServiceURL.legalServices.CORPORATE_CASE).then(function(data) {
				var legalDetails = data.data;
				if(legalDetails){
					var _message = '',noOfCase;
					if(legalDetails.cholaFiledCase.length > 0){
						noOfCase = legalDetails.cholaFiledCase.length > 1 ? ' cases have been' : ' case has been';
						_message = '<div class="pad-btm-5"> '+legalDetails.cholaFiledCase.length+ noOfCase+' filed against this customer. </div>';
						_.each(legalDetails.cholaFiledCase,function(caseNo){
							_message += '<div>'+caseNo+'</div>';
						});
					}
					if(legalDetails.customerFieldCase.length > 0){
						noOfCase = legalDetails.customerFieldCase.length > 1 ? ' cases have been' : ' case has been';
						_message += '<div class="pad-btm-5 pad-tp"> ' + legalDetails.customerFieldCase.length + noOfCase + ' filed by this customer against CHOLA. </br>';
						_.each(legalDetails.customerFieldCase,function(caseNo){
							_message += '<div>'+caseNo+'</div>';
						});
					}
					
					if(count > 0){
						noOfCase = count > 1 ? ' There are ' : ' There is ';
						_message += '<div class="pad-btm-5 pad-tp"> ' + noOfCase + count + ' connected agreements under the CIF ID ('+cifID+') for the same customer </br>';
					}
					if(_message){
						dialogService.showAlert(constant.ERROR_HEADER.alert, constant.ERROR_HEADER.alert, _message,true);
					}
				}
			});
		};
		
		/** Method to get agreement information based on agreementNo */
		this.getAgreementCases = function(agreementNo, caseID) {
			var agreementDetails;
			if (!agreementNo) {
				agreementNo = stageQData.workflow.length ? stageQData.workflow[0].agreementNos[0] : '';
			}
			collectionServiceURL.legalServices.GET_AGREEMENT_CASE.urlParams = {
				agreementNo : agreementNo
			};
			collectionServiceURL.legalServices.GET_AGREEMENT_CASE.queryParams = {
				caseID : caseID
			};
			return restProxy.get(collectionServiceURL.legalServices.GET_AGREEMENT_CASE).then(function(data) {
				if(data.data && data.data[0]){
					if(data.data[0].bucketTrend && data.data[0].bucketTrend.length > 0){
						data.data[0].bucketTrend = utility.handleDelequency(true,data.data[0].bucketTrend,collectionConstants.NON_DELEQUENCY_DATA);
					}else{
						data.data[0].bucketTrend = utility.handleDelequency(false,[],collectionConstants.NON_DELEQUENCY_DATA);
					}
					agreementDetails =  data.data[0];
					return data.data[0];
				}
				
				return $q.reject(agreementDetails); 
			});
		};
		
		this.getStockList = function(offset,productType,branchID) {
			var searchObj = {
					branchID:branchID,
					offset:(((offset-1)*limit)+1),
					limit:limit,
					product:(productType && productType !== "") ? productType : $rootScope.productType,
					type:'branch'
				};
			collectionServiceURL.receiptBookManagementServices.GET_BOOK_DETAILS.queryParams = searchObj;
			return restProxy.get(collectionServiceURL.receiptBookManagementServices.GET_BOOK_DETAILS).then(function(data){
				return data;
			});
		};
		
		this.getDuplicateDispatchLetters = function(agreementNo,letterType,dispatchedTo) {
			var queryParams = {
					agreementNo:agreementNo,
					letterType : letterType,
					dispatchedTo :dispatchedTo
			};
			collectionServiceURL.approvalServices.NOTICE_MANAGEMENT_DUPLICATELETTER.urlParams = {};
			collectionServiceURL.approvalServices.NOTICE_MANAGEMENT_DUPLICATELETTER.queryParams = queryParams;
			return restProxy.get(collectionServiceURL.approvalServices.NOTICE_MANAGEMENT_DUPLICATELETTER).then(function(data){
				return data.data;
			});
		};
		
		this.approveRejectNM = function(postObj){
			return restProxy.save('POST',collectionServiceURL.approvalServices.NOTICE_MANAGEMENT_APPROVAL,postObj).then(function(data){
				return data.data;
			});
		};
		this.getNonEmpanelledAgents = function(params) {
			var queryParams = {
				type : params.reqStatus.toLowerCase(),
				agreementNo : params.agreementNo
			};
			collectionServiceURL.approvalServices.REPO_NONEMPANELLED_AGENT.urlParams = {};
			collectionServiceURL.approvalServices.REPO_NONEMPANELLED_AGENT.queryParams = queryParams;
			return restProxy.get(collectionServiceURL.approvalServices.REPO_NONEMPANELLED_AGENT).then(function(data){
				return data.data;
			});
		};
		
		this.approveNonEmpanelledAgents = function(postObj,reqStatus,actionID){				
			var reqArr = [postObj];
			return restProxy.save('POST',collectionServiceURL.approvalServices.REPO_NONEMPANELLED_AGENT_APPROVAL,reqArr).then(function(data){
				return data.data;
			});
		};
		this.getMarkingLMSCaseDetails = function(type,agreementNumber,url) {
			var queryParams = {
					type:type.toLowerCase(),
					agreementNo:agreementNumber
			};
			collectionServiceURL.approvalServices.GET_REPO_LMS_CASE_DETAILS.EDS=environmentConfig.baseURL+'/approvals/detail/'+url;
			collectionServiceURL.approvalServices.GET_REPO_LMS_CASE_DETAILS.urlParams = {};
			collectionServiceURL.approvalServices.GET_REPO_LMS_CASE_DETAILS.queryParams = queryParams;
			return restProxy.get(collectionServiceURL.approvalServices.GET_REPO_LMS_CASE_DETAILS).then(function(data){
				return data.data;
			});
		};
		this.docWaiverRequest = function (data){
			return restProxy.save('put',collectionServiceURL.repoServices.DOCUMENT_WAIVER_REQUEST,data).then(function (data) {
                return data;
            });
		}
		this.updateLead = function(receiptDetail,loanDetails){
			var chargeDetails = [], chargesToSave = [] , loanData = [],chargeData;

								_.each(loanDetails ,function(loanItem){
									_.each(receiptDetail.chargeDetails, function(charge) {
										if(loanItem.loanID === charge.referenceNo){
										var _chargObj = _.findWhere(loanItem.chargeDetails, {
											chargeTypeID : charge.chargeID
										});
										chargeData = {
											chargeDetailID : _chargObj.chargeDetailID,
											chargeAmount :_chargObj.chargeAmount,
											chargeTypeID :_chargObj.chargeTypeID,
											isDeductible :_chargObj.isDeductible,
											receiptNos :[receiptDetail.receiptNo]
										}
										chargeDetails.push(chargeData);
									}
								});
									loanData.push({
											loanID : loanItem.loanID,
											chargeDetails : chargeDetails
										});
								});
									
									chargesToSave = {
										leadID : receiptDetail.payerID,
										type : "receipt",
										loanDetails : loanData
									}

						collectionServiceURL.receiptingServices.UPDATE_LEAD.queryParams = {};
						collectionServiceURL.receiptingServices.UPDATE_LEAD.urlParams.leadID = receiptDetail.payerID;
						var serviceURL = collectionServiceURL.receiptingServices.UPDATE_LEAD;
						return restProxy.save('PUT', serviceURL, chargesToSave);
		};

		this.getStandByTellerDetails = function(reqObj) {
			var queryParams = {
				branchID : reqObj.branchId,
				tellerID : reqObj.tellerID,
				uID : reqObj.uID
			};
			collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_STANDBYTELLER.urlParams = {};
			collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_STANDBYTELLER.queryParams = queryParams;
			return restProxy.get(collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_STANDBYTELLER).then(function(data){
				if(data.data)
				return data.data[0];
			});
		};
		this.getZoneFromBrAreaRgnID = function(){
			var queryObj = loginDetails(queryObj);
			var config = {
	            EDS : "collectionsapi/getZoneDetails",
	            isEPS : false
	        };
	         config.queryParams = queryObj;
			return restProxy.get(config).then(function(data){	
				return data.data;
			});
		};
		this.filterLegalCases = function (requestObj) {			
			collectionServiceURL.noticeManagementServices.REPO_FILTER.queryParams = requestObj;
			return restProxy.get(collectionServiceURL.noticeManagementServices.REPO_FILTER).then(function (data) {
				if (data.status === "success"){
					return data.data;
				}
				else
					return [];
			});
		};
		this.getVehicleGroup = function () {
			return restProxy.get(collectionServiceURL.noticeManagementServices.GET_VEHICLE_GROUP).then(function (data) {
				if (data.data) {
					// vehicleGroupList = data.data;
					data.data.unshift({
						leapSubCategoryID: "0",
						subCategoryDesc: "All"
					});
					_.each(data.data, function (item) {
						item.selected = false;
					});
				}
				return data.data;
			});
		};
		this.getNativeTellerDetails = function(reqObj) {
			var queryParams = {
				branchID : reqObj.branchId,
				tellerID : reqObj.tellerID,
				uID : reqObj.uID
			};
			collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_NATIVETELLER.urlParams = {};
			collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_NATIVETELLER.queryParams = queryParams;
			return restProxy.get(collectionServiceURL.approvalServices.GET_INITIATED_APPROVAL_NATIVETELLER).then(function(data){
				if(data.data)
				return data.data[0];
			});
		};
		this.getDocumentsDetails = function(reqNo,caseID){
			collectionServiceURL.approvalServices.GET_DOCUMENTS_REQUESTED.queryParams ={'requestNo':reqNo,'caseID':caseID}; 
			return restProxy.get(collectionServiceURL.approvalServices.GET_DOCUMENTS_REQUESTED).then(function (data) {
				if (data.data) {
					return data.data;
				}				
			});
		};
		this.approveRequestedDocuments = function(postObj,reqStatus,actionID){				
			var reqArr = [postObj];
			return restProxy.save('POST',collectionServiceURL.approvalServices.APPROVE_REQUESTED_DOCUMENTS,reqArr).then(function(data){
				return data.data;
			});
		};
		this.getUserDataMapping = function() {
			return repoMasterService.getGlobalMasterData().then(function(data){
				if(data){
					return data;
				}else{
					return repoMasterService.getMasterData().then(function(data){
						return data;
					});	
				}
			});		
		};
		this.getLegalEPDetails = function(agreementNo) {
			collectionServiceURL.approvalServices.LEGAL_EP_HOLD.urlParams = {};
			collectionServiceURL.approvalServices.LEGAL_EP_HOLD.queryParams = {agreementNo:agreementNo};
			return restProxy.get(collectionServiceURL.approvalServices.LEGAL_EP_HOLD).then(function(data){
				return data.data;
			});
		};
	};
	approvalQueue.service('approvalQueueService',['$q','$rootScope','restProxy','$stateParams','masterService','repoMasterService','$modal','$globalScope','dialogService','environmentConfig',approvalQueueService]);
	return approvalQueueService;
});
