define([], function() {

	'use strict';
   require.config({
   		 paths: {
    	  'collectionsApp':'app/collections/collections',
    	  'approvalQueue':'app/collections/approvals/approvalQueue/approvalQueue',
    	  'approvalQueueService':'app/collections/approvals/approvalQueue/services/approvalQueueService',
    	  'approvalQueueController':'app/collections/approvals/approvalQueue/controllers/approvalQueueController',
    	  'approvalQueueConstants':'app/collections/approvals/approvalQueue/approvalQueueConstants',
    	  'approvalQueueResolver':'app/collections/approvals/approvalQueue/resolvers/approvalQueueResolver',
    	  'approvalRequestController':'app/collections/approvals/approvalQueue/controllers/approvalRequestController',
		  'advocateApprovalRequestController':'app/collections/approvals/approvalQueue/controllers/advocateApprovalRequestController',
		  'advocateApprovalRequestFeeController':'app/collections/approvals/approvalQueue/controllers/advocateApprovalRequestFeeController',
		  'agreementBlockApprovalRequestController':'app/collections/approvals/approvalQueue/controllers/agreementBlockApprovalRequestController',
		  'waiverController':'app/collections/approvals/approvalQueue/controllers/waiverController',
    	  'receiptBookController':'app/collections/approvals/approvalQueue/controllers/receiptBookController',
    	  'panCardController':'app/collections/approvals/approvalQueue/controllers/panCardController',
    	  'orangeCustomerController':'app/collections/approvals/approvalQueue/controllers/orangeCustomerController',
    	  'repoRequestController':'app/collections/approvals/approvalQueue/controllers/repoRequestController',
    	  'receiptController':'app/collections/approvals/approvalQueue/controllers/receiptController',
    	  'approveLegalRequest':'app/collections/approvals/approvalQueue/controllers/approveLegalRequest',
    	  'approveLegalWithdrawal':'app/collections/approvals/approvalQueue/controllers/approveLegalWithdrawal',
		  'approveLegalChildCase':'app/collections/approvals/approvalQueue/controllers/approveLegalChildCase',
		  'approveLegalReopenCase':'app/collections/approvals/approvalQueue/controllers/approveLegalReopenCase',
    	  'approveLegalCompController':'app/collections/approvals/approvalQueue/controllers/approveLegalComp',
    	  'approveBDChallanRequest':'app/collections/approvals/approvalQueue/controllers/approveBDChallanRequest',
    	  'approveFCHEHLController':'app/collections/approvals/approvalQueue/controllers/approveFCHEHLController',
    	  'thirdPartyAddressController':'app/collections/approvals/approvalQueue/controllers/thirdPartyAddressApproval',
          'approvalRepoMarkingController':'app/collections/approvals/approvalQueue/controllers/approvalRepoMarkingController',
    	  'approveNMController':'app/collections/approvals/approvalQueue/controllers/approveNMController',
    	  'approveRepoController':'app/collections/approvals/approvalQueue/controllers/approveRepoController',
          'selectLocController' : 'app/collections/approvals/approvalQueue/controllers/selectLocController',
          'legalRequestController':'app/collections/approvals/approvalQueue/controllers/legalRequestController',
          'advocateLegalRequestController':'app/collections/approvals/approvalQueue/controllers/advocateLegalRequestController',
		  'advocateFeeLegalRequestController':'app/collections/approvals/approvalQueue/controllers/advocateFeeLegalRequestController',
		  'agreementBlockLegalRequestController':'app/collections/approvals/approvalQueue/controllers/agreementBlockLegalRequestController',
		  'sharedPackage' : 'app/common/shared/package',
    	  'legalConstants' : 'app/collections/legal/legalConstants',
		  'approveStandByTellerController' : 'app/collections/approvals/approvalQueue/controllers/approveStandByTellerController',
		  'approveNativeTellerController' : 'app/collections/approvals/approvalQueue/controllers/approveNativeTellerController',
          'sharedPackage' : 'app/common/shared/package',
    	  'legalConstants' : 'app/collections/legal/legalConstants',
		  'shortfallWaiverController':'app/collections/approvals/approvalQueue/controllers/shortfallWaiverController',
		  'saleRefundApprovalController':'app/collections/approvals/approvalQueue/controllers/saleRefundApprovalController',
          'documentWaiverController':'app/collections/approvals/approvalQueue/controllers/documentWaiverController',
          'approveLegalEPController':'app/collections/approvals/approvalQueue/controllers/approveLegalEPController',
          'duplicateDocRequestController':'app/collections/approvals/approvalQueue/controllers/duplicateDocRequest'
    	},
    	shim:{
    		'approvalQueue':['angular','angular-ui-router','approvalQueueResolver','approvalQueueConstants'],
    		'approvalQueueService':['approvalQueue'],
    		'approvalQueueController':['approvalQueueService'],
    		'approvalRequestController':['approvalQueueService'],
    		'advocateApprovalRequestController':['approvalQueueService'],
    		'agreementBlockApprovalRequestController':['approvalQueueService'],
    		'waiverController':['approvalQueueService'],
    		'panCardController':['approvalQueueService'],
    		'receiptController':['approvalQueueService'],
    		'receiptBookController':['approvalQueueService'],
    		'orangeCustomerController':['approvalQueueService'],
    		'repoRequestController':['approvalQueueService'],
    		'approveBDChallanRequest':['approvalQueueService'],
    		'approveLegalCompController':['approvalQueueService'],
    		'approveFCHEHLController':['approvalQueueService'],
    		'thirdPartyAddressController':['approvalQueueService'],
    		'approveLegalWithdrawal':['approvalQueueService'],
			'approveLegalChildCase':['approvalQueueService'],
			'approveLegalReopenCase':['approvalQueueService'],
    		'approveNMController':['approvalQueueService'],
            'approvalRepoMarkingController':['approvalQueueService'],
            'approveRepoController':['approvalQueueService'],
            'selectLocController':['approvalQueueService'],
            'legalRequestController':['approvalQueueService'],
            'advocateLegalRequestController':['approvalQueueService'],
            'agreementBlockLegalRequestController':['approvalQueueService'],
			'approveStandByTellerController':['approvalQueueService'],
			'approveNativeTellerController':['approvalQueueService'],
            'documentWaiverController':['approvalQueueService'],
			'shortfallWaiverController':['approvalQueueService'],
			'saleRefundApprovalController':['approvalQueueService'],
            'approveLegalEPController':['approvalQueueService'],
			'advocateApprovalRequestFeeController':['approvalQueueService'],
			'advocateFeeLegalRequestController':['approvalQueueService'],
            'duplicateDocRequestController':['approvalQueueService']
    	}
   });

   return function(callback){
	   requirejs([ 'sharedPackage','legalConstants' ], function(commonPackageLoader,legalConstants) {
			commonPackageLoader(function() {
				requirejs([ 'approvalQueueController','approvalRequestController','advocateApprovalRequestController','agreementBlockApprovalRequestController','waiverController','panCardController', 'receiptController','receiptBookController','orangeCustomerController','repoRequestController','approveLegalRequest', 'approveBDChallanRequest','approveLegalCompController','approveFCHEHLController','thirdPartyAddressController', 'approveLegalWithdrawal','approveLegalChildCase','approveLegalReopenCase','approveNMController','approvalRepoMarkingController', 'approveRepoController','selectLocController','legalRequestController','advocateLegalRequestController', 'agreementBlockLegalRequestController','approveStandByTellerController','approveNativeTellerController', 'documentWaiverController','approveLegalEPController','advocateApprovalRequestFeeController','advocateFeeLegalRequestController','duplicateDocRequestController','shortfallWaiverController','saleRefundApprovalController'],callback);
			});
		});
   };

});