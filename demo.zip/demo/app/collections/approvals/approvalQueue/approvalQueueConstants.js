/* Date : 29-Mar-2017
Modified by : Saranya Sankar R
Modification details : CR- Book Request Approvals */

define(['require', 'constants'], function(r, sharedConstants) {
    'use strict';
    var paginationConfig = sharedConstants.PAGINATION_CONFIG;
    
    var filter = [{
    	name : 'Normal Waiver',
    	id : 'NORMAL'
    },{
    	name : 'Stand by Teller',
    	id : 'STANDBYTELLER'
    },{
    	name : 'Native Teller',
    	id : 'NATIVETELLER'
    },{
    	name : 'Shortfall Waiver',
    	id : 'SHORTFALLWAIVER'
    },{
    	name : 'Sale Refund',
    	id : 'SALEREFUND'
    },{
    	name : 'Foreclosure Waiver',
    	id : 'FORECLOSURE'
    },{
    	name : 'Receipt Book Issuance',
    	id : 'RECEIPTBOOKISSUANCE'
    },{
    	name : 'Damaged Receipt Books',
    	id : 'DAMAGEDRECEIPTBOOKS'
    },{
    	name : 'PAN Card Unavailability',
    	id : 'PANCARD'
    },{
    	name : 'Back Dated Receipting',
    	id : 'BACKDATEDRECEIPT'
    },{
    	name : 'Receipt Cancellation',
    	id : 'RECEIPTCANCELLATION'
    },{
    	name : 'LMS Receipt Cancellation',
    	id : 'LMSCANCELLATIONRECEIPT'
    },{
    	name : 'Receipt Book Request',
    	id : 'RECEIPTBOOKREQUEST'
    },/*{
    	name : 'No Memo Upload',
    	id : 'NOMEMOUPLOAD'
    },{
    	name : 'Receipt Book Retention',
    	id : 'RECEIPTBOOKRETENTION'
    },*/{
    	name : 'Orange Customer Categorization',
    	id : 'ORANGECUSTOMER'
    },{
    	name : 'Cash Collection > 10 Lakhs',
    	id : 'CASHTENLAKHS'
    },{
    	name : 'EOD DCR',
    	id : 'EXCESSSHORTFALL'
    },{
    	name : 'Repo Initiation',
    	id : 'REPO'
    },{
    	name : 'Customer Surrender Approval',
    	id : 'SURRENDERCUSTOMER'
    },{
    	name : 'Surrender Expense Approval',
    	id : 'SURRENDEREXPENSE'
    },{
    	name : 'Repo Sale Request',
    	id : 'SALEAPPROVAL'
    },{
    	name : 'Legal Initiation',
    	id : 'LEGALCASE'
    },{
    	name : 'Back Dated Challaning',
    	id : 'BACKDATEDCHALLANING'
    },{
    	name : 'Release Letter',
    	id : 'REPORELEASELETTER,SALERELEASELETTER'
    },{
    	name : 'Foreclosure Request',
    	id : 'FORECLOSUREHEHL'
    },{
    	name : 'Foreclosure LA',
    	id : 'FORECLOSURELA'
    },{
    	name : 'Legal Compliance Request',
    	id : 'LEGALCOMPLIANCE'
    },{
    	name : 'Legal Appeal Request',
    	id : 'LEGALAPPEAL'
    },{
    	name : 'RTGS/POS Receipts',
    	id : 'RTGS,POS'
    }, {
    	name : 'Third Party Address Change',
    	id : 'THIRDPARTY'
    }, {
    	name : 'Legal Case Withdrawal',
    	id : 'LEGALWITHDRAWN'
    }, {
    	name : 'Legal Child Case',
    	id : 'LEGALCHILDCASE'
    },{
    	name : 'Receipt Modification',
    	id : 'RECEIPTMODIFICATION'
    }, {
    	name : 'Duplicate Letter Dispatch',
    	id : 'DUPLICATELETTERDISPATCH'
    },{
        name : 'Non Empanelled Agent / Seizure Charges',
        id : 'NONEMPANELLEDAGENT'
    },{
        name : 'Repo Marking LMS - Seizure/Towing Charges',
        id : 'REPOMARKINGLMS' 
    },{
        name : 'Wrong Repo Marking LMS',
        id : 'REPOWRONGMARKING' 
    },{
        name : 'Document Waiver',
        id : 'DOCUMENTWAIVER' 
    },{
        name : 'TA RTGS Receipts',
        id : 'DEALERRTGS'
    },{
        name : 'IMD RTGS Receipts',
        id : 'IMDRTGS'
    },{
        name : 'VISHESH RTGS Receipts',
        id : 'VISHESHRTGS'
    },{
        name : 'TRIP RTGS Receipts',
        id : 'TRIPRTGS'
    },{
        name : 'Legal Advocate Change',
        id : 'LEGALADVOCATECHANGE' 
    },{
        name : 'Legal Agreement Block',
        id : 'LEGALAGREEMENTBLOCK'
    },{
        name : 'Legal Agreement EP Hold',
        id : 'LEGALAGREEMENTEPHOLD'
    },{
        name : 'Legal Advocate Fee Change',
        id : 'LEGALADVOCATEFEECHANGE' 
    },{
        name : 'Duplicate Document Request',
        id : 'DUPLICATEDOCUMENTREQUEST' 
    },{
        name : 'Legal Re-Open Case',
        id : 'LEGALREOPENCASE'
    }
    ];
    
    var pendingReqs = {
    		NORMAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Normal Waiver'
    		},
    		STANDBYTELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Stand by Teller'
    		},	
    		NATIVETELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Native Teller'
    		},								
    		SHORTFALLWAIVER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Shortfall Waiver'
    		},
			SALEREFUND : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Sale Refund'
    		},									
    		FORECLOSURE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Foreclosure Waiver'
    		},
			FORECLOSURELA : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Foreclosure LA'
    		},
    		RECEIPTBOOKISSUANCE : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Receipt Book Issuance'
    		},
    		DAMAGEDRECEIPTBOOKS : {
    			mainRow : [{label:'Receipt Book No',value:'receiptBookNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			subRow : [],
    			reqLabel : 'Damaged Receipt Books'
    		},
    		PANCARD : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'PAN Card Unavailability'
    		},
    		BACKDATEDRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Cash Receipt Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Branch',value:'branchId'},{label:'Receipt Amt.',value:'receiptAmount'},
    			          {label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Back Dated Receipting'
    		},
    		RECEIPTCANCELLATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Receipt Cancellation'
    		},
			LMSCANCELLATIONRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'LMS Receipt Cancellation'
    		},
			RECEIPTMODIFICATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Receipt Modification'
    		},
    		/*NOMEMOUPLOAD : {
    			mainRow : [{label:'Challan No.',value:'physicalChallanNo'},{label:'Challan Date',value:'physicalChallanedDate',isDate:true},{label:'Fake Note Amt.',value:'fakeAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'No Memo Upload'
    		},
    		RECEIPTBOOKRETENTION : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Receipt Book No',value:'receiptBookNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Receipt Book Retention'
    		},*/
    		ORANGECUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Orange Customer Categorization'
    		},
    		CASHTENLAKHS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Cash Collection > 10 Lakhs'
    		},
    		EXCESSSHORTFALL : {
    			mainRow : [{label:'Cash Closure Date',value:'cashClosureDate',isDate:true},{label:'Excess/Shortfall Amt.',value:'excessOrShortfallAmount'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'EOD DCR'
    		},
    		REPO : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Repo Initiation'
    		},
    		SURRENDERCUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Surrender Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Customer Surrender Approval'
    		},
    		SURRENDEREXPENSE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total Expense Amt.',value:'totalExpenseAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Surrender Expense Approval'
    		},
    		SALEAPPROVAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Repo Sale Request'
    		},
    		LEGALCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Initiation'
    		},
    		BACKDATEDCHALLANING :{
    			mainRow : [{label:'Sys. Challan No.',value:'challanNo'},{label:'Challan Date',value:'challanDate',isDate:true},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Challan Amt.',value:'challanReceiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Back Dated Challaning'
    		},
    		REPORELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Repo Release Letter'
    		},
    		SALERELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Sale Release Letter'
    		},
    		FORECLOSUREHEHL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Foreclosure Amt.',value:'foreClosureAmount'}],
    			subRow : [{label:'Bucket',value:'bucket'},{label:'CFE Allocated To',value:'approvalDetails.initiatedBy.userName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Foreclosure Request'
    		},
    		LEGALCOMPLIANCE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Legal Compliance Request'
    		},
    		LEGALAPPEAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Legal Appeal Request'
    		},
    		RTGS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'RTGS Receipting'
    		},
			POS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'POS Receipting'
    		},
    		THIRDPARTY : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Third Party Address Change'
    		},
    		LEGALWITHDRAWN : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Legal Case Withdrawal'
    		},
    		LEGALCHILDCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Parent Case ID',value:'parentCaseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Legal Child Case'
    		},
    		RECEIPTBOOKREQUEST : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Receipt Book Request'
    		},
    		DUPLICATELETTERDISPATCH : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			reqLabel : 'Duplicate Letter Dispatch'
    		},
            NONEMPANELLEDAGENT : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Seizure Charge',value:'seizureCharge'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Non Empanelled Agent / Seizure Charges'
            },
            REPOMARKINGLMS :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Seizure Charge',value:'seizureCharge'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Repo Marking in LMS - Seizure/Towing Charges'
            },
            REPOWRONGMARKING :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Seizure Charge',value:'seizureCharge'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Wrong Repo Marking in LMS'
            },
            DOCUMENTWAIVER :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Document Waiver'
            },
            LEGALREOPENCASE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
                subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Legal Reopen Case'
            },
            LEGALADVOCATECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Advocate Change'
            },
            LEGALADVOCATEFEECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Advocate Fee Change'
            },
            LEGALAGREEMENTBLOCK : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Agreement Block'
            },
            LEGALAGREEMENTEPHOLD : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Branch',value:'branchId'},{label:'Legal Sections',value:'section'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Legal Agreement EP Hold'
            },
            DUPLICATEDOCUMENTREQUEST: {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Requested Document',value:'documentsReq.0'}],
                subRow : [{label:'Request No.',value:'requestNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
                reqLabel : 'Duplicate Document Request'
            }
            
    	};
    
    var initiatedReqs = {
    		NORMAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Normal Waiver'
    		},
    		STANDBYTELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Stand by Teller'
    		},	
    		NATIVETELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Native Teller'
    		},							
    		SHORTFALLWAIVER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Shortfall Waiver'
    		},		
    		SALEREFUND : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Sale Refund'
    		},							
    		FORECLOSURE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure Waiver'
    		},
			FORECLOSURELA : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure LA'
    		},
    		RECEIPTBOOKISSUANCE : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Issuance'
    		},
    		DAMAGEDRECEIPTBOOKS : {
    			mainRow : [{label:'Receipt Book No',value:'receiptBookNo'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Damaged Receipt Books'
    		},
    		PANCARD : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'PAN Card Unavailability'
    		},
    		BACKDATEDRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Cash Receipt Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Branch',value:'branchId'},{label:'Receipt Amt.',value:'receiptAmount'},
    			           {label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Back Dated Receipting'
    		},
    		RECEIPTCANCELLATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Cancellation'
    		},
			LMSCANCELLATIONRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'LMS Receipt Cancellation'
    		},
			RECEIPTMODIFICATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Modification'
    		},
    		/*NOMEMOUPLOAD : {
    			mainRow : [{label:'Challan No.',value:'physicalChallanNo'},{label:'Challan Date',value:'physicalChallanedDate',isDate:true},{label:'Fake Note Amt.',value:'fakeAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'No Memo Upload'
    		},
    		RECEIPTBOOKRETENTION : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Receipt Book No.',value:'receiptBookNo'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			subRow : [{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Retention'
    		},*/
    		ORANGECUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Orange Customer Categorization'
    		},
    		CASHTENLAKHS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Receipt Amt. requested',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Cash Collection > 10 lakhs'
    		},
    		EXCESSSHORTFALL : {
    			mainRow : [{label:'Cash Closure Date',value:'cashClosureDate',isDate:true},{label:'Excess/Shortfall Amt.',value:'excessOrShortfallAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			subRow : [{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'EOD DCR'
    		},
    		REPO : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Initiation'
    		},
    		SURRENDERCUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Surrender Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Customer Surrender Approval'
    		},
    		SURRENDEREXPENSE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total Expense Amt.',value:'totalExpenseAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Surrender Expense Approval'
    		},
    		SALEAPPROVAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Sale Request'
    		},
    		LEGALCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Initiation'
    		},
    		BACKDATEDCHALLANING : {
    			mainRow : [{label:'Sys. Challan No.',value:'challanNo'},{label:'Challan Date',value:'challanDate',isDate:true},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Challan Amt.',value:'challanReceiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Back Dated Challaning'
    		},
    		REPORELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Release Letter'
    		},
    		SALERELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Sale Release Letter'
    		},
    		FORECLOSUREHEHL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Foreclosure Amt.',value:'foreClosureAmount'}],
    			subRow : [{label:'Bucket',value:'bucket'},{label:'CFE Allocated To',value:'approvalDetails.initiatedBy.userName'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure Request'
    		},
    		LEGALCOMPLIANCE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Compliance Request'
    		},
    		LEGALAPPEAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Appeal Request'
    		},
    		RTGS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Receipt Amt. requested',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'RTGS Receipting'
    		},
			POS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Receipt Amt. requested',value:'receiptAmount'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'POS Receipting'
    		},
    		THIRDPARTY : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Third Party Address Change'
    		},
    		LEGALWITHDRAWN : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Case Withdrawal'
    		},
    		LEGALCHILDCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Parent Case ID',value:'parentCaseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Child Case'
    		},
    		RECEIPTBOOKREQUEST : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Request'
    		},
    		DUPLICATELETTERDISPATCH : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Duplicate Letter Dispatch'
    		},
            NONEMPANELLEDAGENT : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Non Empanelled Agent / Seizure Charges'
            },
            REPOMARKINGLMS :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Repo Marking in LMS - Seizure/Towing Charges'
            },
            REPOWRONGMARKING :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Wrong Repo Marking in LMS'
            },
            DOCUMENTWAIVER :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
                subRow : [{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Document Waiver'
            },
            LEGALREOPENCASE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
                subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Legal Reopen Case'
            },
            LEGALADVOCATECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Advocate Change'
            },
            LEGALADVOCATEFEECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Advocate Fee Change'
            },
            LEGALAGREEMENTBLOCK : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Agreement Block'
            },
            LEGALAGREEMENTEPHOLD : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Branch',value:'branchId'},{label:'Legal Sections',value:'section'}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Legal Agreement EP Hold'
            },
            DUPLICATEDOCUMENTREQUEST: {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Requested Document',value:'documentsReq.0'}],
                subRow : [{label:'Request No.',value:'requestNo'},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']},{label:'Status',value:'approvalDetails.currentStatus'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Duplicate Document Request'
            }
    	};
    
    var approvedReqs = {
    		NORMAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Normal Waiver'
    		},
    		STANDBYTELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Stand by Teller'
    		},	
    		NATIVETELLER : {
    			mainRow : [{label:'Teller ID',value:'tellerID'},{label:'From Date',value:'fromDate',isDate:true},{label:'To Date',value:'toDate',isDate:true}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Validity Days', value : 'validityDays'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Native Teller'
    		},							
    		SHORTFALLWAIVER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Shortfall Waiver'
    		},	
    		SALEREFUND : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Pending with',value:['approvalDetails.pendingWith.userID','approvalDetails.pendingWith.userName']}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Sale Refund'
    		},							
    		FORECLOSURE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Waiver Amt.',value:'approvalDetails.waiverAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure Waiver'
    		},
			FORECLOSURELA : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure LA'
    		},
    		RECEIPTBOOKISSUANCE : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Issuance'
    		},
    		DAMAGEDRECEIPTBOOKS : {
    			mainRow : [{label:'Receipt Book No',value:'receiptBookNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true}],
    			subRow : [{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Damaged Receipt Books'
    		},
    		PANCARD : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'PAN Card Unavailability'
    		},
    		BACKDATEDRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Cash Receipt Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Branch',value:'branchId'},{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Back Dated Receipting'
    		},
    		RECEIPTCANCELLATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Cancellation'
    		},
			LMSCANCELLATIONRECEIPT : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'LMS Receipt Cancellation'
    		},
			RECEIPTMODIFICATION : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt No.',value:'receiptNo'}],
    			subRow : [{label:'Receipt Amt.',value:'receiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Modification'
    		},
    		/*NOMEMOUPLOAD : {
    			mainRow : [{label:'Challan No.',value:'physicalChallanNo'},{label:'Challan Date',value:'physicalChallanedDate',isDate:true},{label:'Fake Note Amt.',value:'fakeAmount'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'No Memo Upload'
    		},
    		RECEIPTBOOKRETENTION : {
    			mainRow : [{label:'Requested By',value :['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Receipt Book No.',value:'receiptBookNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Retention'
    		},*/
    		ORANGECUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Orange Customer Categorization'
    		},
    		CASHTENLAKHS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Cash Collection > 10 lakhs'
    		},
    		EXCESSSHORTFALL : {
    			mainRow : [{label:'Cash Closure Date',value:'cashClosureDate',isDate:true},{label:'Excess/Shortfall Amt.',value:'excessOrShortfallAmount'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'EOD DCR'
    		},
    		REPO : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Initiation'
    		},
    		SURRENDERCUSTOMER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total OD Amt.',value:'totalODAmount'}],
    			subRow : [{label:'Surrender Date',value:'approvalDetails.initiatedOn',isDate:true},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Customer Surrender Approval'
    		},
    		SURRENDEREXPENSE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Total Expense Amt.',value:'totalExpenseAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Surrender Expense Approval'
    		},
    		SALEAPPROVAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Sale Request'
    		},
    		LEGALCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Initiation'
    		},
    		BACKDATEDCHALLANING :{
    			mainRow : [{label:'Sys. Challan No.',value:'challanNo'},{label:'Challan Date',value:'challanDate',isDate:true},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Challan Amount',value:'challanReceiptAmount'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Back Dated Challaning'
    		},
    		REPORELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Repo Release Letter'
    		},
    		SALERELEASELETTER : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Highest Sale Quote Amt.',value:'highestSaleQuoteAmt'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Sale Release Letter'
    		},
    		FORECLOSUREHEHL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Foreclosure Amt.',value:'foreClosureAmount'}],
    			subRow : [{label:'Bucket',value:'bucket'},{label:'CFE Allocated To',value:'approvalDetails.initiatedBy.userName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Foreclosure Request'
    		},
    		LEGALCOMPLIANCE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Compliance Request'
    		},
    		LEGALAPPEAL : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Compliance Amt.',value:'complianceAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Appeal Request'
    		},
    		RTGS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'RTGS Receipting'
    		},
			POS : {
    			mainRow : [{label:'Receipt No.',value:'receiptNo'},{label:'Customer Name',value:'customerName'},{label:'Receipt Amt. requested',value:'receiptAmount'}],
    			subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'POS Receipting'
    		},
			THIRDPARTY : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Branch',value:'branchId'}],
    			subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Third Party Address Change'
    		},
    		LEGALWITHDRAWN : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Case Withdrawal'
    		},
    		LEGALCHILDCASE : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Parent Case ID',value:'parentCaseID'},{label:'Customer Name',value:'customerName'}],
    			subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Legal Child Case'
    		},
    		RECEIPTBOOKREQUEST : {
    			mainRow : [{label:'Requested By',value:['approvalDetails.requestedBy','approvalDetails.requestedName']},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Receipt Book Request'
    		},
    		DUPLICATELETTERDISPATCH : {
    			mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
    			subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
    			reqLabel : 'Duplicate Letter Dispatch'
    		},
            NONEMPANELLEDAGENT : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Non Empanelled Agent / Seizure Charges'
            },
            REPOMARKINGLMS :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Repo Marking in LMS - Seizure/Towing Charges'
            },
            REPOWRONGMARKING :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Seizure Charge',value:'seizureCharge'},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Wrong Repo Marking in LMS'
            },
            DOCUMENTWAIVER :{
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']}],
                subRow : [{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Document Waiver'
            },
            LEGALREOPENCASE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Customer Name',value:'customerName'}],
                subRow : [{label:'Section',value:"legalSections.0"},{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Legal Reopen Case'
            },
            LEGALADVOCATECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Adovacte Change'
            },
            LEGALADVOCATEFEECHANGE : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Adovacte Fee Change'
            },
            LEGALAGREEMENTBLOCK : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Customer Name',value:'customerName'},{label:'Legal Sections',value:'SectionName'}],
                subRow : [{label:'Branch',value:'branchId'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Agreement Block'
            },
            LEGALAGREEMENTEPHOLD : {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Branch',value:'branchId'},{label:'Legal Sections',value:'section'}],
                subRow : [{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true},{label:'History',value:'workflow'}],
                reqLabel : 'Legal Agreement EP Hold'
            },
            DUPLICATEDOCUMENTREQUEST: {
                mainRow : [{label:'Agreement No.',value:'agreementNo'},{label:'Case ID',value:'caseID'},{label:'Requested Document',value:'documentsReq.0'}],
                subRow : [{label:'Request No.',value:'requestNo'},{label:'Initiated By',value:['approvalDetails.initiatedBy.userID','approvalDetails.initiatedBy.userName']},{label:'Initiated On',value:'approvalDetails.initiatedOn',isDate:true},{label:'Approved By',value:['approvalDetails.approvedBy.userID','approvalDetails.approvedBy.userName']},{label:'Approved On',value:'approvalDetails.approvedOn',isDate:true}],
                reqLabel : 'Duplicate Document Request'
            }
    	};
        var approvalStatus = {
        		INITIATED : "INITIATED",
        		RECOMMENDED :"RECOMMENDED",
        		APPROVED:"APPROVED",
        		REJECTED :"REJECTED"
        };
        var partyType = {
                'A': 'Customer',
                'G': 'Guarantor',
                'C': 'Co-Applicant',
            };
    return {      
        PENDING_QUEUE : pendingReqs,
        INITIATED_QUEUE : initiatedReqs,
        APPROVED_QUEUE : approvedReqs,
        PAGINATION_CONFIG:paginationConfig,
        FILTER : filter,
        APPROVALSTATUS:approvalStatus,
        PARTYTYPE :partyType
    };
});
