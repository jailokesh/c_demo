define(['require', 'initiateRequest', 'DatePickerConfig', 'collectionConstants', 'utility'], function (r, initiateRequest, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var standByTellerController = function ($scope, $rootScope, $state, $modal, $stateParams, initiateRequestService, dialogService, repoMasterService) {

		var DateTime = new Date();
		var getZones;
		var identity
		$scope.dataType = {};
		$scope.data = {};	
		$scope.requestBody = {};

		var getDateDifference = function(a, b) {
			var one_day = 1000 * 60 * 60 * 24;
			var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
			var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

			return Math.floor((utc2 - utc1) / one_day);
		};
		$scope.data.toDate = new DatePickerConfig({
			value: "",
			minDate: DateTime,
			readonly: true,
			DateTime: DateTime,			
			onchange:function(val){
				if(!$scope.requestBody.fromDate && (parseInt($scope.requestBody.validityDays) >= 0)){
					$scope.data.fromDate.minDate = new Date(new Date(val).setDate( new Date(val).getDate() - parseInt($scope.requestBody.validityDays) ));
					$scope.requestBody.validityDays = utility.dateDifference($scope.requestBody.fromDate, val) + 1;
				}else if($scope.requestBody.fromDate){
					$scope.requestBody.validityDays = utility.dateDifference($scope.requestBody.fromDate, val) + 1;
				}else if(parseInt($scope.requestBody.validityDays) >= 0){
					dialogService.showAlert('Error', "Error!", "Please enter from date to proceed further");
					return;										
				}
			}
		});
							
		$scope.data.fromDate = new DatePickerConfig({ 
			value: "",
			minDate: DateTime,
			readonly: true,
			DateTime: DateTime,			
			onchange:function(val){
				$scope.data.toDate.minDate = val;
				if(parseInt($scope.requestBody.validityDays) >= 0){
					$scope.data.toDate.dateValue = new Date(new Date(val).setDate( new Date(val).getDate() + parseInt($scope.requestBody.validityDays) - 1 ));
					$scope.data.toDate.setDateVal($scope.data.toDate.dateValue);
					$scope.requestBody.toDate = $scope.data.toDate.dateValue;
				}									
				if($scope.requestBody.toDate){
					$scope.requestBody.validityDays = utility.dateDifference(val, $scope.requestBody.toDate) + 1;
				}									
			}
		});
		var initiateReqBody = function(){
			$scope.requestBody = {
				mobileNumber : '',
				branchID : identity.selectedBranch.branchID
			};
			$scope.data.toDate.value = $scope.data.fromDate.value = '';
		};

		var getTellerDetails = function(branchID){
			initiateRequestService.getTellerDetails(branchID).then(function (response) {
				if (response && response.length) {
					$scope.requestBody.branchID = branchID;
					$scope.requestBody.tellerID = response[0].userID;
					$scope.requestBody.tellerName = response[0].userName;
					$scope.requestBody.standByTellerID = response[0].standByTellerID;
					$scope.requestBody.mobileNumber = identity.mobileNo;
				}else{
					initiateReqBody();
				}
			});
		};

		function init(){					
			identity = $rootScope.identity;
			$scope.data.hierarchyName = identity.hierarchyName;
			initiateReqBody();
			$scope.data.geoDetail = utility.getGeoAccess($scope.data.hierarchyName);
			$scope.dropDownValues = repoMasterService.setDropDownValues();
			initiateRequestService.getUserDataMapping().then(function(data){
				getZones = data;
				$scope.dropDownValues.branchDetails = repoMasterService.setDefaultValues($scope.data.hierarchyName, getZones);
				if($scope.data.geoDetail.isBranchAccess && !$scope.data.geoDetail.isAreaAccess && !$scope.data.geoDetail.isRegionAccess && !$scope.data.geoDetail.isZoneAccess){
					getTellerDetails($scope.dropDownValues.branchDetails.branchID);	
				}
			});	
		};
		init();				

		$scope.calculateDate = function(validityDays){
			if($scope.requestBody.fromDate){
				$scope.data.toDate.value = $scope.data.toDate.dateValue = new Date(new Date($scope.requestBody.fromDate).setDate( new Date($scope.requestBody.fromDate).getDate() + parseInt(validityDays) - 1 ));
				$scope.data.toDate.setDateVal($scope.data.toDate.dateValue);						
			}			
		}
		
		$scope.changeHandler = function (type,ID,keyID,sKeyID,tKeyID) {		
			$scope.data.fromDate.value = '';
			$scope.data.toDate.value = '';						
			_.each($scope.requestBody,function(item){ item = ''; });				
			$scope.data.reqObj={};
			if(ID){
				$scope.dropDownValues.branchDetails = repoMasterService.changeHandler(type, ID, getZones, $scope.dropDownValues.branchDetails);
				if(type === 'branchID'){
					getTellerDetails(ID);
				}
				$scope.data.reqObj[type] = $scope.dropDownValues.branchDetails[type];
			}else{
				$scope.data.reqObj[keyID] = $scope.dropDownValues.branchDetails[keyID];
				$scope.dropDownValues.branchDetails[sKeyID]='';
				$scope.dropDownValues.branchDetails[tKeyID]='';
			}	
		};

		$scope.initiateRequest = function () {
			dialogService.confirm(collectionConstants.REPO_MSG.CONFIRM, collectionConstants.REPO_MSG.CONFIRM,'Registered Mobile Number is '+ $scope.requestBody.mobileNumber +' and OTP will received in mentioned number. You still want to continue ok or cancel').result.then(function(){
				initiateRequestService.initiateStandByTeller($scope.requestBody);
			},function(){});						
		};

		$scope.resetAll = function () {
			initiateReqBody();
			$scope.initiate_standByTeller.resetFormValidation(true);
			$scope.dropDownValues.branchDetails.branchID = '';
		};
	};
	initiateRequest.controller('standByTellerController', ['$scope', '$rootScope', '$state', '$modal', '$stateParams', 'initiateRequestService', 'dialogService', 'repoMasterService', standByTellerController]);
	return standByTellerController;
});
