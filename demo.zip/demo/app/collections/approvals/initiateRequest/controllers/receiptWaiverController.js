define([ 'require', 'initiateRequest', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility' ], function(r, initiateRequest, constants, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var receiptWaiverController = function($scope, $state, $modal, $stateParams, initiateRequestService, dialogService, lazyModuleLoader, messageBus) {
		$scope.requestBody = {};
		$scope.linkedAgrNos = [];
		$scope.data = {
			waiverType : $stateParams.reqType
		};
		var getLinkedAgrs = function() {
			initiateRequestService.getUserAgreementList($scope.agreementNo, $scope.customerInfo.APPLICANT.cifID).then(function(data) {
				$scope.linkedAgrNos = data;
				var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos, {
					agreementNo : $scope.agreementNo
				}), 1);
				selectedAgr[0].isDefault = false;
				$scope.linkedAgrNos.unshift(selectedAgr[0]);
			});
		};

		var showSimulatePopup = function() {
			dialogService.showCustomDialog('app/collections/eReceipt/receipting/partials/popup/simulationPopup.html', [ '$scope', '$modalInstance', function($scope,$modalInstance) {
				$scope.data = {
						tillDate : new DatePickerConfig({
				        	value: '',
				        	readonly:true,
				        	minDate:new Date(),
				        	minErrorMsg : "Interest till Date cannot be less than current date"
						}) 
					};
					$scope.simulateHandler = function() {
			            $modalInstance.close($scope.data.tillDate);
			        };

			        $scope.close = function() {
			            $modalInstance.dismiss();
			        };

				}], {}, function(result) {
				if (result.status === "success") {
					initiateRequestService.simulateForeclosure($scope.customerInfo.agreementNo, new Date(result.data.dateValue)).then(function(simulateData) {
						var initiateRequestObj = {};
						initiateRequestObj.simulateData = simulateData;
						$scope.customerInfo.expenseDetails = initiateRequestService.setChargeDetails(simulateData.foreClosureCharges);
						// Foreclosure net receivable validation added like receipting module
						var _excess,_amount;
						var _sum = _.reduce(initiateRequestObj.expenseDetails, function(memo, item) {
							if(item.chargeID !== '20002'){
								_amount = Number(item.chargeAmount);
							}else{
								_amount = 0;
							}
							return Number(memo) + _amount;
						}, 0);
						_excess = _.findWhere(initiateRequestObj.expenseDetails,{"chargeID": "20002"});
						if(_excess){
							_sum -= _excess.chargeAmount;
						}
						if(initiateRequestObj.simulateData.waiveOffAmount){
							_sum -= initiateRequestObj.simulateData.waiveOffAmount;
						}
						if(_sum !== initiateRequestObj.simulateData.amountCollected){
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.FC_NET_NOT_MATCH);
							return;
						}
						
						if (simulateData.getForeClosureLA.linkedAgreements && simulateData.getForeClosureLA.linkedAgreements.length) {
							initiateRequestObj.request = 'WAIVER';
							initiateRequestObj.agreementList = simulateData.getForeClosureLA.linkedAgreements;
							if (simulateData.getForeClosureLA.linkedAgreements.length) {
								$scope.linkedAgrNos = angular.copy(simulateData.getForeClosureLA.linkedAgreements);
								var vNo = $scope.customerInfo.assetDetail ? $scope.customerInfo.assetDetail.lmsRegistrationNo : '';
								$scope.linkedAgrNos.unshift({
									agreementNo : simulateData.agreementNo,
									vehicleNumber : vNo
								});
							}
							messageBus.onMsg('CANCEL_FC_WAIVER', function(event, data) {
								$scope.data.noRecords = true;
								$scope.customerInfo = '';
							});
							initiateRequestService.showLinkedAgreements(initiateRequestObj);
						}
						$scope.data.noRecords = false;
					});
				}else{
					$scope.data.noRecords = true;
					$scope.customerInfo = '';
				}
			}, 'sm', 'modal-custom', true);
		};

		$scope.fetchAgrDetails = function(agreementNo) {
			if (!agreementNo) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (agreementNo.length < collectionConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
			$scope.data.chequeFlag = false;
			initiateRequestService.getCaseDetails(agreementNo, $stateParams.reqType).then(function(response) {
				$scope.customerInfo = '';
				if (response && response.length) {
					var responseObj = response[0], chequeFlag;
					if(responseObj.productCode === 'VISHESH' || responseObj.productCode === 'TRIP'){
						if($stateParams.reqType === 'foreclosureWaiver'){
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.FOR_WAIVER_NA_VISHESH);
							return;
						}else{
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.WAIVER_NA_VISHESH);
							return;
						}
						
					}
					var foreclosureReceipt = _.findWhere(responseObj.foreClosure, {
						receiptType : "FORECLOSURE"
					});
					if (foreclosureReceipt) {
						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.RECEIPT_FORECLOSED + ". Cannot initiate waiver request");
						return;
					}

					if (responseObj.agreementStatus === "C" || responseObj.agreementStatus === "X") {
						var status = responseObj.agreementStatus == "C" ? 'Closed' : 'Cancelled';
						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, "This agreement is " + status + ". Cannot initiate waiver request.");
						return;
					}

					if (responseObj.productGroup === 'VF') {
						if (responseObj.waiverRequestStatus === 'WAIVER-INITIATED' || responseObj.waiverRequestStatus === 'WAIVER-RECOMMENDED' || responseObj.waiverRequestStatus === 'WAIVER-ESCALATED') {
							dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.FC_WAIVER_PEDNING_APP);
							return;
						} else if (responseObj.waiverRequestStatus === 'FORECLOSURE-INITIATED' || responseObj.waiverRequestStatus === 'FORECLOSURE-RECOMMENDED' || responseObj.waiverRequestStatus === 'FORECLOSURE-ESCALATED') {
							dialogService.showAlert(constants.ERROR_HEADER.message, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.LA_APPROVAL_PEDNING_APP);
							return;
						}
					}

					if ($scope.data.waiverType.toUpperCase() === 'FORECLOSUREWAIVER') {
						_.each(responseObj.lastThreeChequeInformation, function(item) {
							if (item.instrumentDetail.status && item.instrumentDetail.status.toUpperCase() === "PENDING") {
								$scope.data.chequeFlag = true;
							}
						});
						if ($scope.data.chequeFlag) {
							dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning, collectionConstants.ERROR_MSG.CHEQUE_PENDING);
							return;
						}
					}
					$scope.requestBody = {};
					$scope.customerInfo = utility.getCustomerInfo(response[0]);
					if ($stateParams.reqType === 'foreclosureWaiver' && responseObj.productGroup === 'VF') {
						$scope.customerInfo.expenseDetails = [];
						showSimulatePopup();
					} else {
						getLinkedAgrs();
						$scope.data.noRecords = false;
					}
					$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
						status : $scope.customerInfo.agreementStatus
					});
					$scope.customerInfo.branchName = initiateRequestService.getBranchName($scope.customerInfo.branchID);
					
				} else {
					$scope.customerInfo = '';
					$scope.data.noRecords = true;
				}
			});
		};

		var roundOffValue = function(dividend, divisor) {
			if (!parseInt(dividend)) {
				return '0';
			}
			var roundedVal = ((parseInt(dividend) / parseInt(divisor)) * 100);
			roundedVal = roundedVal.toFixed(2);
			return {
				displayVal : (roundedVal !== '0.00' && !parseInt(roundedVal)) ? '< 1%' : roundedVal + '%',
				actualVal : roundedVal
			};
		};

		$scope.computePercent = function(charge) {
			if (parseInt(charge.waiverAmount) > charge.actualAmount) {
				dialogService.showAlert('Error', "Error!", "Waiver Amount cannot be greater than the due amount!");
				charge.waiverAmount = charge.actualAmount;
			}
			var _obj = roundOffValue(charge.waiverAmount, charge.actualAmount);
			charge.percentage = charge.waiverAmount ? _obj.displayVal : 0;
			charge.actualPercentage = _obj.actualVal;

			charge.netWorking = charge.waiverAmount ? charge.actualAmount - charge.waiverAmount : charge.actualAmount;
			var total = $scope.customerInfo.expenseDetails[$scope.customerInfo.expenseDetails.length - 1];
			total.waiverAmount = 0;
			for (var index = 0; index < $scope.customerInfo.expenseDetails.length - 1; index++) {
				total.waiverAmount += $scope.customerInfo.expenseDetails[index].waiverAmount ? parseInt($scope.customerInfo.expenseDetails[index].waiverAmount) : 0;
			}
			_obj = roundOffValue(total.waiverAmount, total.actualAmount);
			total.percentage = total.waiverAmount ? _obj.displayVal : 0;
			total.netWorking = total.waiverAmount ? (total.actualAmount - total.waiverAmount) : total.netWorking;
		};

		$scope.initiateRequest = function() {
			$scope.data.showError = ($scope.data.waiverType.toUpperCase() == 'NORMALWAIVER' && !$scope.requestBody.collectionType);
			if (!$scope.data.showError) {
				$scope.requestBody.agreementNos = [ $scope.customerInfo.agreementNo ];
				$scope.requestBody.receiptNo = $scope.customerInfo.receiptNo;
				$scope.requestBody.waiverType = collectionConstants.APPROVALS_INIT_PAGE[$stateParams.reqType].requestType;
				$scope.requestBody.status = constants.REQUEST_STATUS.INITIATED.toUpperCase();
				$scope.requestBody.branchID = $scope.customerInfo.branchID;
				$scope.requestBody.chargeDetails = [];
				_.each($scope.customerInfo.expenseDetails, function(charge) {
					if (charge.receiptChargeType !== 'TOTAL' && (($stateParams.reqType.toUpperCase() === 'FORECLOSUREWAIVER' && $scope.customerInfo.productGroup === 'VF') || charge.waiverAmount)) {
						var chargeObj = _.findWhere($scope.requestBody.chargeDetails,{chargeID : charge.chargeID}); //checking if charge is already present in the array.
						if(chargeObj){
							chargeObj.actualAmount += parseInt(charge.actualAmount);
							chargeObj.waiverAmount += parseInt(charge.waiverAmount);
							var roundedVal = ((parseInt(chargeObj.waiverAmount) / parseInt(chargeObj.actualAmount)) * 100);
							chargeObj.waiverPercentage = Number(roundedVal.toFixed(2));
						}else{
							chargeObj = {};
							chargeObj.chargeID = charge.chargeID;
							chargeObj.actualAmount = parseInt(charge.actualAmount);
							chargeObj.waiverAmount = parseInt(charge.waiverAmount);
							chargeObj.waiverPercentage = Number(charge.actualPercentage) || 0;
							$scope.requestBody.chargeDetails.push(chargeObj);
						}
					}
				});
				if (initiateRequestService.foreclosureLADetails) {
					$scope.requestBody.foreClosureLADetails = initiateRequestService.foreclosureLADetails;
					$scope.requestBody.foreClosureLADetails.productGroup = $scope.customerInfo.productGroup;
				}

				if (!$scope.requestBody.chargeDetails.length) {
					dialogService.showAlert('Error', "Error!", "Cannot initate request for zero waiver amount!");
					return;
				}
				initiateRequestService.initiateRequest($scope.requestBody).then(function(response) {
					if (response && response.DataInserted) {
						dialogService.showAlert('Success', "Success!", "Waiver request initiated successfully!").result.then(function() {
						}, function() {
							$scope.goToQueue();
						});
					}
				});
			}
		};

		$scope.resetAll = function() {
			$scope.requestBody.customerBackground = $scope.requestBody.justification = $scope.requestBody.remarks = '';
			_.each($scope.customerInfo.expenseDetails, function(charge) {
				charge.waiverAmount = 0;
				charge.percentage = 0;
				charge.netWorking = charge.actualAmount;
			});
		};

		$scope.goToQueue = function() {
			lazyModuleLoader.loadState('collections.approvalQueue');
		};

		$scope.showAgreementPopup = function() {
			$modal.open({
				templateUrl : 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller : [ '$scope', 'data', '$modalInstance', function($scope, data, $modalInstance) {
					$scope.data = data;
					$scope.data.totalRecords = data.agreementNos;
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.saveHandler = function() {
						$modalInstance.dismiss();
					};
					$scope.paginationHandler = function(pageNo) {
						var startLen = $scope.data.recordPerPage * (pageNo - 1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage * (pageNo - 1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen, endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function() {
						$modalInstance.dismiss();
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							agreementNos : $scope.linkedAgrNos,
							isViewOnly : true,
							productType : $scope.customerInfo.productGroup
						};
					}
				}
			});
		};

		/*
		 * $scope.viewLinkedAgreements = function(){ if(linkedAgrNos.length) {
		 * showAgreementPopup(); return; } };
		 */

		$scope.foucsHandler = function(item) {
			if (parseInt(item.waiverAmount) === 0) {
				item.waiverAmount = '';
			}
		};
	};
	initiateRequest.controller('receiptWaiverController', [ '$scope', '$state', '$modal', '$stateParams', 'initiateRequestService', 'dialogService', 'lazyModuleLoader', 'messageBus', receiptWaiverController ]);
	return receiptWaiverController;
});
define([ 'require', 'initiateRequest', 'constants', 'DatePickerConfig' ], function(r, initiateRequest, constants, DatePickerConfig) {
	var appSimulationPopupController = function($scope, data, $modalInstance) {
		$scope.data = {
			tillDate : new DatePickerConfig({
				value : '',
				readonly : true,
				minDate : new Date(),
				minErrorMsg : "Interest till Date cannot be less than current date"
			})
		};
		$scope.simulateHandler = function() {
			$modalInstance.close($scope.data.tillDate);
		};

		$scope.close = function() {
			$modalInstance.dismiss();
		};

	};
	initiateRequest.controller('appSimulationPopupController', [ '$scope', 'data', '$modalInstance', appSimulationPopupController ]);
	return appSimulationPopupController;
});