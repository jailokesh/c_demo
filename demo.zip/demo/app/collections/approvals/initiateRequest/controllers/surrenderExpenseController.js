define(['require','initiateRequest', 'constants','DatePickerConfig','collectionConstants','utility'], function(r,initiateRequest,constants,DatePickerConfig,collectionConstants,utility) {
'use strict';

 	var surrenderExpenseController = function($scope,$modal,$state,$stateParams,initiateRequestService,dialogService,lazyModuleLoader){
 		$scope.requestBody = {};
 		$scope.linkedAgrNos = [];
 		var fetchYardVendors = function(agreementNo){
 			initiateRequestService.getYardVendors(agreementNo).then(function(yardResponse){
				if(yardResponse && Object.keys(yardResponse).length){
						$scope.repoDetailInfo.yardInfo = yardResponse;
						$scope.noRecords = false;
				}
				else{
					$scope.repoDetailInfo.yardInfo = {};
				}
			});
 		};
 		
 		var fetchRepoAgents = function(agreementNo){
 			initiateRequestService.getRepoAgents(agreementNo).then(function(agentResponse){
				if(agentResponse && agentResponse.length){
					$scope.repoDetailInfo.repoAgents = agentResponse;
					$scope.noRecords = false;
					fetchYardVendors(agreementNo);
				}
				else{
					$scope.repoDetailInfo.repoAgents = [];
				}
			});
 		};
 		
 		var fetchRepoDetails = function(agreementNo){
 			$scope.requestBody.expenseDetails = initiateRequestService.getExpenseModel().expenseDetails;
 			initiateRequestService.getRepoDetails(agreementNo).then(function(response) {
 				if(response && Object.keys(response).length){
 					$scope.repoDetailInfo = response;
 					$scope.repoDetailInfo.applicantDetails =  _.findWhere($scope.repoDetailInfo.partyDetails,{"partyType":"A"});
 					$scope.noRecords = false;
 					fetchRepoAgents(agreementNo);
 				}
 				else{
 					$scope.repoDetailInfo = '';
 					$scope.noRecords = true;
 				}
  			});
 		};
 		$scope.repoDate = new DatePickerConfig({    		 	
			value:new Date(),
			maxDate:new Date(),
			readonly: true
		});	
 		
 		var getLinkedAgrs = function(){
 			initiateRequestService.getUserAgreementList($scope.agreementNo,$scope.customerInfo.APPLICANT.cifID).then(function(data) {
 				$scope.linkedAgrNos = data;
 				var selectedAgr = $scope.linkedAgrNos.splice(_.findIndex($scope.linkedAgrNos,{agreementNo:$scope.agreementNo}),1);
 				selectedAgr[0].isDefault = false;
 				$scope.linkedAgrNos.unshift(selectedAgr[0]);
			});
 		};
 		
 		$scope.fetchAgrDetails = function(agreementNo){
 			if(!agreementNo){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			}else if(agreementNo.length < collectionConstants.SEARCH_LIMIT){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT+ " Characters to Search !");
				return;
			}
 			initiateRequestService.getCaseDetails(agreementNo).then(function(response) {
 				if(response && response.length){
 					if(response[0].productGroup === 'VF'){
 						if(response[0].productCode === 'VISHESH' || response[0].productCode === 'TRIP'){
							dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.SURRENDER_NA_VISHESH);
							return;
						}
 						$scope.customerInfo = utility.getCustomerInfo(response[0]);
 	 		 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 	 					$scope.customerInfo.branchName = initiateRequestService.getBranchName($scope.customerInfo.branchID);
 	 					$scope.noRecords = false;
 	 					fetchRepoDetails(agreementNo);
 	 					getLinkedAgrs();
 					}
 					else{
 						dialogService.showAlert('Error', "Error", "Surrender Expense initiation can be done only for VF agreements");
 		 				return;
 					}
 				}
 				else{
 					$scope.customerInfo = '';
 					$scope.noRecords = true;
 				}
  			});
 		};
 		
 		 		
 		$scope.initiateRequest = function(){
 			var isExpensePresent = false;
 			_.each($scope.requestBody.expenseDetails,function(item){
 				if(item.amountPaid){
 					item.amountPaid = parseInt(item.amountPaid);
 					isExpensePresent = true;
 				}
 			});
 			if(!$scope.requestBody.totalSurrenderExpense&&!isExpensePresent){
 				dialogService.showAlert('Error', "Error!", "Please enter valid expense amount");
 				return;
 			}
			$scope.requestBody.agreementNo = $scope.customerInfo.agreementNo;
			$scope.requestBody.status = constants.REQUEST_STATUS.INITIATED.toUpperCase();
			$scope.requestBody.parkingYardID = $scope.repoDetailInfo.yardInfo?$scope.repoDetailInfo.yardInfo.yardVendorDetails.vendorID:'';
			$scope.requestBody.majorVersion = $scope.repoDetailInfo.majorVersion;
			$scope.requestBody.minorVersion = $scope.repoDetailInfo.minorVersion;
			$scope.requestBody.repoDate = new Date($scope.requestBody.repoDate).toISOString();
			$scope.requestBody.branchID = $scope.customerInfo.branchID;
			initiateRequestService.initiateRepoExpense([$scope.requestBody]).then(function(response) {
 				if(response && ( response.DataInserted || Object.keys(response).length )){
 					dialogService.showAlert('Success', "Success!", "Request initiated successfully!").result.then(function(){},function(){
						$scope.goToQueue();
					});
 				}
 				else{
 					dialogService.showAlert('Error', "Error!", "Error during initiation!").result.then(function(){},function(){
						$scope.goToQueue();
					});
 				}
 			});
 		};
		
 		$scope.goToQueue = function(){
 			lazyModuleLoader.loadState('collections.approvalQueue');
 		}; 		
 		
 		$scope.showAgreementPopup = function(){
 			$modal.open({
				templateUrl: 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller: ['$scope','data','$modalInstance',function($scope,data,$modalInstance){
					$scope.data = {};
					$scope.data.isViewOnly = data.isViewOnly;
					$scope.data.totalRecords = data.agreementNos;
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.saveHandler = function(){
						$modalInstance.dismiss();
					};
					$scope.paginationHandler = function(pageNo){
						var startLen = $scope.data.recordPerPage * (pageNo-1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage*(pageNo-1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen,endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function(){
						$modalInstance.dismiss();
					};
				}],
				size : 'md',
				backdrop : 'static' ,
				windowClass : 'modal-custom',
				resolve: {
					data: function() {
	                    return {
	                    	agreementNos : $scope.linkedAgrNos,
	                    	isViewOnly : true,
							productType :$scope.customerInfo.productGroup
	                    };
	                }
				}
			});
 		};
 		
 		/*$scope.viewLinkedAgreements = function(){
 			if(linkedAgrNos.length) {
 				showAgreementPopup();
 				return;
 			}
 		};*/
 	};
 	initiateRequest.controller('surrenderExpenseController',['$scope','$modal','$state','$stateParams','initiateRequestService','dialogService','lazyModuleLoader',surrenderExpenseController]);
	return surrenderExpenseController;
});