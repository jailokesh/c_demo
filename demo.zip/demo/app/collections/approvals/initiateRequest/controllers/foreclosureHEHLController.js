define(['require','initiateRequest', 'constants','DatePickerConfig','collectionConstants','utility'], function(r,initiateRequest,constants,DatePickerConfig,collectionConstants,utility) {
'use strict';

 	var foreclosureHEHLController = function($scope,$globalScope,$sce,$modal,$state,$stateParams,initiateRequestService,dialogService,lazyModuleLoader){
 		$scope.requestBody = {
 				paymentType : 'Bank Transfer'
 		};
 		$scope.categoryDetails = _.findWhere($globalScope.imageCategories,{subCategory:'Foreclosure Request letter'});
 		$scope.requestDate = new DatePickerConfig({    		 	
			value:new Date(),
			maxDate:new Date()
		});	
 		$scope.data = {};
 		$scope.fetchAgrDetails = function(agreementNo){
 			if(!agreementNo){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			}else if(agreementNo.length < collectionConstants.SEARCH_LIMIT){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT+ " Characters to Search !");
				return;
			}
 			$scope.data.chequeFlag = false;
 			initiateRequestService.getCaseDetails(agreementNo).then(function(response) {
 				$scope.customerInfo = '';
 				if(response && response.length){
 					if(response[0].agreementStatus === "C"){
 						dialogService.showAlert('Error', "Message", "Cannot initiate foreclosure request, this agreement has been closed already");
						return;
 					}
 					if(response[0].productGroup === 'HE' || response[0].productGroup === 'HL'){
 						var responseObj = response[0],chequeFlag;
 						_.each(responseObj.lastThreeChequeInformation, function(item) {
 							if (item.instrumentDetail.status && item.instrumentDetail.status.toUpperCase() === "PENDING") {
 								$scope.data.chequeFlag = true;
 							}
 						});
 						if($scope.data.chequeFlag){
 	 						dialogService.showAlert('Error', "Message", "One or more cheques are with status Pending. Foreclosure cannot be initiated.");
 	 						return;
 						}
 						var foreclosureObj  = responseObj.foreClosureRequestDetail[responseObj.foreClosureRequestDetail.length-1];
 						if(foreclosureObj){
 							try{
	 							var workFlowObj = foreclosureObj.workflow[foreclosureObj.workflow.length-1];
	 							if(workFlowObj.workStatus === 'INITIATED' || workFlowObj.workStatus === 'RECOMMENDED' || foreclosureObj.isForeclosureLetterValid){
		 							dialogService.showAlert('Error', "Message", "Foreclosure request has been initiated already for this agreement.");
		 							return;
	 							}
 							}catch(e){
 								console.log("error.." + e);
 							}
 						}
 						var foreclosureReceipt = _.findWhere(responseObj.foreClosure,{receiptType: "FORECLOSURE"});
 						if(foreclosureReceipt){
 							dialogService.showAlert('Error', "Message", "Foreclosure has been done already for this agreement.");
 							return;
 						}
 						$scope.customerInfo = utility.getCustomerInfo(response[0]);
 	 		 			$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 						$scope.customerInfo.branchName = initiateRequestService.getBranchName($scope.customerInfo.branchID);
 						
 						
 	 					$scope.data.noRecords = false;
 					}
 					else{
 						dialogService.showAlert('Error', "Error", "Foreclosure initiation can be done only for HE/HL agreements");
 		 				return;
 					}
 				}
 				else{
 					$scope.customerInfo = '';
 					$scope.data.noRecords = true;
 				}
  			});
 		};
 		
 		$scope.generateLetter = function(){
 			var reqObj = {
 					loanType : $scope.customerInfo.productGroup,
 					paymentMode : $scope.requestBody.paymentType
 			};
 			initiateRequestService.getLetterPreview($scope.agreementNo,reqObj).then(function(response) {
 				if(response && response.length){
 					$modal.open({
		                templateUrl: 'app/collections/approvals/initiateRequest/partials/printPreview.html',
		                controller: ['$scope','$modalInstance','data',function($scope,$modalInstance,data){
		                	$scope.data = data;		            		
		            		$scope.close = function(){
		            			dialogService.confirm(collectionConstants.REPO_MSG.CONFIRM, collectionConstants.REPO_MSG.CONFIRM,collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function(){
		            				$modalInstance.dismiss();
		            			},function(){});
		            		};
		                }],
		                size: 'lg',
		                backdrop : 'static' ,
						resolve: {
		                    data: function() {
		                        return {
		                        	letterObj : {
		                        		name : 'Foreclosure Requisition Letter'
		                        	},
		                        	letter : $sce.trustAsHtml(response[0].htmlContent)
		                        };
		                    }
		                }
		            });
 				}
 			});
 		};
 		 		
 		$scope.initiateRequest = function(){
 			
 			if(!$scope.requestBody.requestLetter || !$scope.requestBody.requestLetter.imagePathReferences.length){
 				dialogService.showAlert('Error', "Error", "Please upload foreclosure letter");
	 			return;
 			}
			$scope.requestBody.agreementNo = $scope.customerInfo.agreementNo;
			//$scope.requestBody.status = constants.REQUEST_STATUS.INITIATED.toUpperCase();
			//$scope.requestBody.majorVersion = $scope.repoDetailInfo.majorVersion;
			//$scope.requestBody.minorVersion = $scope.repoDetailInfo.minorVersion;
			$scope.requestBody.requestDate = new Date($scope.requestBody.requestDate).toISOString();
			initiateRequestService.initiateForeclosure($scope.requestBody).then(function(response) {
 				if(response && ( response.DataInserted || Object.keys(response).length )){
 					dialogService.showAlert('Success', "Success!", "Request initiated successfully!").result.then(function(){},function(){
						$scope.goToQueue();
					});
 				}/*
 				else{
 					dialogService.showAlert('Error', "Error!", "Error during initiation!").result.then(function(){},function(){
						$scope.goToQueue();
					});
 				}*/
 			});
 		};
		
 		$scope.goToQueue = function(){
 			lazyModuleLoader.loadState('collections.approvalQueue');
 		}; 		
 	};
 	initiateRequest.controller('foreclosureHEHLController',['$scope','$globalScope','$sce','$modal','$state','$stateParams','initiateRequestService','dialogService','lazyModuleLoader',foreclosureHEHLController]);
	return foreclosureHEHLController;
});