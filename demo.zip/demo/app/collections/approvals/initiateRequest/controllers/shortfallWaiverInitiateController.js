define(['require', 'initiateRequest', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility'], function (r, initiateRequest, constants, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var shortfallWaiverInitiateController = function ($scope, $state, $modal, $stateParams,initiateRequestService, dialogService, lazyModuleLoader, messageBus, $timeout) {
		$scope.otsStatus = true;
		$scope.requestBody = {};
		$scope.linkedAgrNos = [];
		$scope.data = {
			waiverType: $stateParams.reqType
		};

		var DateTime = new Date();
		$scope.waiverPayData = {
			part: [],
			full: {}
		};

		$scope.bvLoss = {
			actualAmount: 0,
			waiverAmount: 0,
			netWorking: 0,
			percentage: 0
		};


		//$scope.bvLoss.waiverAmount = 7000;
		$scope.payModeStatus = false;
		$scope.partPayment = false;
		$scope.waiverFullSettlement = false;

		$scope.waiverPayData.full = {
			installId: "",
			modeOfPay: "cash",
			installAmount: "",
			installDate: "",
			dateTimeField: new DatePickerConfig({
				value: DateTime,
				minDate: DateTime,
				readonly: true,
				DateTime: DateTime
			})
		};

		$scope.checkWaiverAmount = function (payMode, index) {
			if ($scope.bvLoss.waiverAmount == "" || $scope.bvLoss.waiverAmount == 0) {
				// dialogService.showAlert('Error', "Error!", "Enter the waiver amount to proceed further payment!");
				if (payMode == 'fullpmt') {
					$scope.waiverPayData.full.installAmount = 0;
				} else {
					$scope.waiverPayData.part[index].installAmount = 0;
				}
			}
		}

		$scope.payMode = function (mode) {
			$scope.paymentMode = mode;
			if (mode === 'partpmt') {
				$scope.partPayment = true;
				$scope.fullPayment = false;
				$scope.noOfInstall = $scope.waiverPayData.part.length;           
			} else {
				$scope.fullPayment = true;
				$scope.partPayment = false;
			}
		};
		$scope.selectCheckBox = function (chargeType,check) {
			_.each($scope.legalDetails,function(item){
				if(check && (item.chargeType == chargeType)){
					item.disableChargeType = false;
					item.selected = true;
                    $scope.bvLoss.actualAmount = parseInt(item.actualLoss);
                    $scope.selectedChargeType = item.chargeType;
				}else{
					item.disableChargeType = true;
					item.selected = false;
                }
			});
		};
		$scope.showDefaultCheckBox = function(checkbox){
			_.each($scope.legalDetails,function(item){
				if(item.waiverCharge){
					item.selected = true;
				}
			});
		}
		var validateWaiverAmount = function (index) {

			var total = 0;
			if ($scope.waiverPayData.part.length < 3) {
				total = $scope.waiverPayData.part[0].installAmount;
			} else {
				for (var i = 0; i < $scope.waiverPayData.part.length - 1; i++) {
					total = +total + +$scope.waiverPayData.part[i].installAmount;
				}

				 /*
				 total = $scope.waiverPayData.part.reduce((s, f) => {
							return parseInt(f.installAmount) + parseInt(s); // return the sum of the accumulator and the current time. (as the the new accumulator)
					     }, 0);
				 */		 
			}

			$scope.bvlossActual = $scope.bvLoss.netWorking - total;
			$scope.waiverPayData.part[$scope.waiverPayData.part.length - 1].installAmount = $scope.bvlossActual;

			if ($scope.bvlossActual < 0) {
				dialogService.showAlert('Warning', "Warning!", "Installment Amount cannot be greater than the Agreed Amount!");
				$scope.waiverPayData.part[index].installAmount = 0;
				validateWaiverAmount();
			}

		}


		$scope.validateWaiverAmount = function (amount, index) {

			if ($scope.bvLoss.waiverAmount != "" && $scope.bvLoss.waiverAmount != 0) {

				if ($scope.paymentMode == 'partpmt') {
					if ($scope.bvLoss.netWorking < amount) {
						dialogService.showAlert('Warning', "Warning!", "Installment Amount cannot be greater than the Agreed Amount!");
						$scope.waiverPayData.part[index].installAmount = 0;
						validateWaiverAmount(index);
					} else if ($scope.bvlossActual > amount && $scope.waiverPayData.part.length - 1 == index) {
						dialogService.showAlert('Warning', "Warning!", "The sum of Installment Amount should match the Agreed Amount!");
						validateWaiverAmount(index);
					} else {
						validateWaiverAmount(index);
					}

				} else {

					if ($scope.bvLoss.netWorking < amount) {
						dialogService.showAlert('Warning', "Warning!", "Amount cannot be greater than the Agreed Amount!");
						$scope.waiverPayData.full.installAmount = $scope.bvLoss.netWorking;
					} else if ($scope.bvLoss.netWorking > amount) {
						dialogService.showAlert('Warning', "Warning!", "Enter the valid Agreed Amount!");
						$scope.waiverPayData.full.installAmount = $scope.bvLoss.netWorking;
					}

				}

			}
		}

		$scope.changeDate = function (dateVal, index) {			
			var count = 1;			
			//var dateVal = new Date($scope.waiverPayData.part[index].dateTimeField.DateTime);
			for (var i = index; i < $scope.waiverPayData.part.length - 1; i++) {
				$scope.waiverPayData.part[i + 1].dateTimeField = new DatePickerConfig({
					value: "",
					minDate: new Date().setFullYear(dateVal.getFullYear(), dateVal.getMonth(), dateVal.getDate() + count),
					readonly: true,
					DateTime: new Date().setFullYear(dateVal.getFullYear(), dateVal.getMonth(), dateVal.getDate() + count)
				});
				count++;
			}				
		}

		$scope.partPayDetails = function (total) {

			if (total > 1) {
				$scope.payModeStatus = true;
			} else {
				$scope.payModeStatus = false;
			}

			var CurrentDate = new Date();

			/* remove splitups for part payment */
			if ($scope.waiverPayData.part.length > total) {

				var removeNos = $scope.waiverPayData.part.length - total;
				$scope.waiverPayData.part[$scope.waiverPayData.part.length - 2].installAmount = $scope.waiverPayData.part[$scope.waiverPayData.part.length - 1].installAmount;
				$scope.waiverPayData.part.splice(total, removeNos);

				/* add splitups for part payment */
			} else {
				var count = 1;
				for (var i = $scope.waiverPayData.part.length; i < total; i++) {

					if (i < 1) {
						$scope.waiverPayData.part[i] = {
							installId: 1,
							modeOfPay: "cash",
							installAmount: "",
							installDate: "",
							dateTimeField: new DatePickerConfig({
								value: DateTime,
								minDate: DateTime,
								readonly: true,
								DateTime: DateTime
							})
						};
					} else {

						var prevDate = (new Date($scope.waiverPayData.part[i - 1].dateTimeField.DateTime) == "Invalid Date") ? new Date($scope.waiverPayData.part[i - 1].installDate) : new Date($scope.waiverPayData.part[i - 1].dateTimeField.DateTime);
						$scope.waiverPayData.part[i] = {
							installId: i + 1,
							modeOfPay: "cash",
							installAmount: "",
							installDate: "",
							dateTimeField: new DatePickerConfig({
								value: "",
								minDate: new Date(new Date().setFullYear(prevDate.getFullYear(), prevDate.getMonth(), prevDate.getDate() + count)),
								readonly: true,
								DateTime: new Date(new Date().setFullYear(prevDate.getFullYear(), prevDate.getMonth(), prevDate.getDate() + count))
							})
						};
						count++;
					}

				}
			}

		}


		/* popupModal for breakupDetails */
		$scope.openModal = function (option, otherDetails, actualAmount) {
			$modal.open({
				templateUrl: 'app/collections/approvals/initiateRequest/partials/shortfallWaiverPopup.html',
				controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {

					$scope.data = option;
					$scope.breakupDetails = otherDetails;

					actualAmount = (actualAmount == '' || actualAmount == 'undefined' || actualAmount == undefined) ? 0 : actualAmount;
					if(actualAmount){

					var currentBVLoss = parseInt(otherDetails.currentBVLoss) - parseInt(otherDetails.currentPaidAmount);
					var currentBalance = (parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt(otherDetails.currentShortfallCollected);

						$scope.breakupDetails.waiverAmount = actualAmount;			
						/*if(parseInt(otherDetails.currentApprovedWaiverAmount) > 0){
							$scope.breakupDetails.agreedAmount = parseInt(currentBalance) - (parseInt(otherDetails.currentApprovedWaiverAmount) + parseInt(actualAmount));
						}else{
							$scope.breakupDetails.agreedAmount = parseInt(otherDetails.currentBVLoss) - (parseInt(otherDetails.currentPaidAmount) + parseInt(actualAmount));
						}*/

                        $scope.breakupDetails.agreedAmount = parseInt(otherDetails.currentBVLoss) - parseInt(actualAmount);

                        $scope.breakupDetails.agreedAmount = (parseInt($scope.breakupDetails.agreedAmount) < 0) ? 0 : $scope.breakupDetails.agreedAmount;
					}

					$scope.close = function () {
						$modalInstance.dismiss();
					};
				}],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		}

		$scope.fetchAgrDetails = function (agreementNo) {

			if (!agreementNo) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (agreementNo.length < collectionConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}

			$scope.data.chequeFlag = false;
			$scope.bvLoss.waiverAmount = '';
			$scope.bvLoss.percentage = '';
			$scope.bvLoss.netWorking = '';
			initiateRequestService.getCaseDetails(agreementNo, $stateParams.reqType).then(function (response) {

				$scope.customerInfo = '';
				if (response && response.length) {
					if (response[0].isProfit) {
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.IS_PROFIT_AGR_CHECK + " " +agreementNo);
						return;
					}
					if (response[0] && response[0].isShortfall) {
						$scope.shortfallDetails = response[0].shortfallDetails;
						$scope.childAgreements = response[0].childAgreements.length ? response[0].childAgreements : [];
						if (response[0] && response[0].isParent) {

						var legalDetails = {};

						if (response[0] && response[0])
							if (parseInt(response[0].shortfallDetails.currentApprovedWaiverAmount) > 0) {
								legalDetails = {
									currentBVLoss: parseInt(response[0].shortfallDetails.currentBVLoss) - parseInt(response[0].shortfallDetails.currentApprovedWaiverAmount),
									currentAVLoss: parseInt(response[0].shortfallDetails.currentAVLoss) - parseInt(response[0].shortfallDetails.currentApprovedWaiverAmount),
									noticeAmount: parseInt(response[0].shortfallDetails.shortfallNoticeAmount) - parseInt(response[0].shortfallDetails.currentApprovedWaiverAmount),
									currentShortfallDue: (parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount)) - parseInt(response[0].shortfallDetails.currentApprovedWaiverAmount)
								};
							} else {
								legalDetails = {
									currentBVLoss: parseInt(response[0].shortfallDetails.currentBVLoss),
									currentAVLoss: parseInt(response[0].shortfallDetails.currentAVLoss),
									noticeAmount: parseInt(response[0].shortfallDetails.shortfallNoticeAmount),
									currentShortfallDue: (parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount))
								};
							}
						var shortfallDue = parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount);
						$scope.data.shortfallDue = shortfallDue;
						var networking =  parseInt(shortfallDue) - parseInt(response[0].shortfallDetails.currentShortfallCollected);
						$scope.bvLoss.netWorking = networking > 0 ? networking : 0;

						if(response[0] && response[0].getPendingShortfallWaiver.length){
							var settlementAgreed = response[0].getPendingShortfallWaiver[0].settlementAgreed;
							if(settlementAgreed){
								$scope.bvLoss.netWorking = parseInt(settlementAgreed) - parseInt(response[0].shortfallDetails.currentShortfallCollected);
							}
						}

						$scope.legalDetails = [{
							chargeType: 'BV Loss',
							actualLoss: (parseInt(response[0].shortfallDetails.currentBVLoss) <= 0) ? 0 : response[0].shortfallDetails.currentBVLoss,
							settlementAgreed: settlementAgreed ? settlementAgreed : shortfallDue,
							shortfallCollected: (parseInt(response[0].shortfallDetails.currentShortfallCollected) <= 0) ? 0 : response[0].shortfallDetails.currentShortfallCollected,
							breakupDetails: {
								'Installment': response[0].shortfallDetails.otherDetails.installment,
								'POS': response[0].shortfallDetails.otherDetails.POS,
								'Seizure Charges': response[0].shortfallDetails.otherDetails.seizureCharges,
								'Parking Charges': response[0].shortfallDetails.otherDetails.parkingCharges,
								'Legal Charges': response[0].shortfallDetails.otherDetails.legalCharges,
								'Open Payable Advice (-)': response[0].shortfallDetails.otherDetails.openPayAdvise,
								'Sale Price (-)': response[0].shortfallDetails.otherDetails.salePrice,
								'Total': response[0].shortfallDetails.currentBVLoss
							},
							waiverCharge: true,
							disableChargeType: true,
						}, {
							chargeType: 'AV Loss',
							actualLoss: (parseInt(response[0].shortfallDetails.currentAVLoss) <= 0) ? 0 : response[0].shortfallDetails.currentAVLoss,
							settlementAgreed: settlementAgreed ? settlementAgreed : shortfallDue,
							shortfallCollected: (parseInt(response[0].shortfallDetails.currentShortfallCollected) <= 0) ? 0 : response[0].shortfallDetails.currentShortfallCollected,
							breakupDetails: {
								'Installment': response[0].shortfallDetails.otherDetails.installment,
								'POS': response[0].shortfallDetails.otherDetails.POS,
								'Seizure Charges': response[0].shortfallDetails.otherDetails.seizureCharges,
								'Parking Charges': response[0].shortfallDetails.otherDetails.parkingCharges,
								'Legal Charges': response[0].shortfallDetails.otherDetails.legalCharges,
								'OverDue Charges': response[0].shortfallDetails.otherDetails.overDueCharges,
								'Prepayment Penalty': response[0].shortfallDetails.otherDetails.prepaymentPenalty,
								'Interest On Termination': response[0].shortfallDetails.otherDetails.terminationInt,
								'Other Receivable Advice(FVC, RPDC Charges etc.)': response[0].shortfallDetails.otherDetails.otherReceivableAdvise,
								'Open Payable Advice (-)': response[0].shortfallDetails.otherDetails.openPayAdvise,
								'Sale Price (-)': response[0].shortfallDetails.otherDetails.salePrice,
								'Total': response[0].shortfallDetails.currentAVLoss,
							},
							disableChargeType: true
						}, {
							chargeType: 'Shortfall Notice',
							actualLoss: (parseInt(response[0].shortfallDetails.shortfallNoticeAmount) <= 0) ? 0 : response[0].shortfallDetails.shortfallNoticeAmount,
							settlementAgreed: settlementAgreed ? settlementAgreed : shortfallDue,
							shortfallCollected: (parseInt(response[0].shortfallDetails.currentShortfallCollected) <= 0) ? 0 : response[0].shortfallDetails.currentShortfallCollected,
							disableChargeType: true
						}, {
							chargeType: 'Shortfall Due',
							actualLoss: ((parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount)) <= 0) ? 0 : (parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount)),
							settlementAgreed: settlementAgreed ? settlementAgreed : shortfallDue,
							shortfallCollected: (parseInt(response[0].shortfallDetails.currentShortfallCollected) <= 0) ? 0 : response[0].shortfallDetails.currentShortfallCollected,
							breakupDetails: {
								'AV Loss': (parseInt(response[0].shortfallDetails.currentAVLoss) <= 0) ? 0 : response[0].shortfallDetails.currentAVLoss,
								'Till Date Interest': parseInt(response[0].shortfallDetails.currentInterestAmount),
								'Total': (parseInt(response[0].shortfallDetails.currentAVLoss) + parseInt(response[0].shortfallDetails.currentInterestAmount))
							},
							selected : true,
							disableChargeType: false,
                            netWorking : networking

						}];

						$scope.partPayDetails(2);
						$scope.noOfInstall = 2;
						/*if (response[0].shortfallDetails.currentBVLoss <= 0) {
                            $scope.bvLoss.actualAmount = $scope.bvLoss.netWorking = 0;
                        } else {
                            $scope.bvLoss.actualAmount = response[0].shortfallDetails.currentBVLoss;
                            $scope.data.actualAmount = response[0].shortfallDetails.currentBVLoss;
                        }*/

						var responseObj = response[0],
							chequeFlag;

						$scope.requestBody = {};
						$scope.customerInfo = utility.getCustomerInfo(response[0]);

						$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
							status: $scope.customerInfo.agreementStatus
						});
						initiateRequestService.getCholaBranches().then(function (branches) {
							try {
								$scope.customerInfo.branchName = _.findWhere(branches, {
									branchID: $scope.customerInfo.branchID
								}).branchDesc;
								$scope.customerInfo.allocatedBranchName = _.findWhere(branches, {
									branchID: $scope.customerInfo.lmsBranchID
								}).branchDesc;
							} catch (error) {
								return;
							}
						});

					} else {
							if(response[0].parentAgreementNo){
								dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Child/Topup agreements are not allowed for shortfall waiver, please try again with parent agreement "+response[0].parentAgreementNo);
							}else{
								dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Child/Topup agreements are not allowed for shortfall waiver, please try again with parent agreement.")
							}
							return;
						}
				}else {
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, "Shortfall is not marked for this agreement!");
						return;
					}


				
				} else {
					$scope.customerInfo = '';
					$scope.data.noRecords = true;
					dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
					return;
				}
			});
		};

		$scope.showChildAgreements = function(childAgreements) {
			$modal.open({
				templateUrl : 'app/collections/eReceipt/receipting/partials/popup/viewChildAgreements.html',
				controller : [ '$scope', '$modalInstance', function($scope, $modalInstance) {
					$scope.childAgreements = childAgreements ? childAgreements : [];
					$scope.close = function() {
						$modalInstance.close();
					};
					$scope.okHandler = function() {
						$scope.close();
					};
				} ],
				size: 'md',
				backdrop: 'static',
				windowClass: 'modal-custom',
				resolve: {

				}
			});
		};

		var roundOffValue = function (dividend, divisor) {
			if (!parseInt(dividend)) {
				return '0';
			}
			var roundedVal = ((parseInt(dividend) / parseInt(divisor)) * 100);
			roundedVal = roundedVal.toFixed(2);
			return {
				displayVal: (roundedVal !== '0.00' && !parseInt(roundedVal)) ? '< 1%' : roundedVal + '%',
				actualVal: roundedVal
			};
		};
		$scope.onKeyDown = function(keyCode,settleMentAgreed){
			if(keyCode == 48 && settleMentAgreed == 0){
				return false;
			}
		};
		$scope.computePercent = function (settlementAgreed) {
            var shortfallDueAmount,waiverAmount;
            _.each($scope.legalDetails,function(item){
                if(item.selected) {
                        $scope.shortfallDetails.settlementAgreed = parseInt(item.settlementAgreed);
                        waiverAmount= parseInt(item.actualLoss) - parseInt($scope.shortfallDetails.settlementAgreed);
                        $scope.bvLoss.actualAmount = parseInt(item.actualLoss);
                        $scope.selectedChargeType = item.chargeType;
                        $scope.bvLoss.waiverAmount = waiverAmount > 0 ? waiverAmount : 0;
                    }
                if(item.chargeType == 'Shortfall Due'){
                    shortfallDueAmount = item.actualLoss;
                }
            });

              if(shortfallDueAmount < settlementAgreed){
                     dialogService.showAlert('Error', "Error!", "Cannot initiate request for more than shortfall due!");
                  _.each($scope.legalDetails,function(item){
                      item.settlementAgreed = '';
                      item.percentage = 0;
                      item.waiverAmount = 0;
                  })
                        $scope.bvLoss.netWorking = 0;
                    return;
                }
            _.each($scope.legalDetails,function (oneItem) {

				oneItem.waiverAmount = parseInt(oneItem.actualLoss)- parseInt($scope.shortfallDetails.settlementAgreed);

                var roundOffObj = roundOffValue(oneItem.waiverAmount, oneItem.actualLoss);
                oneItem.percentage = roundOffObj.actualVal ? roundOffObj.actualVal : 0;

                oneItem.settlementAgreed =  $scope.shortfallDetails.settlementAgreed;
                if(oneItem.settlementAgreed){
                    $scope.bvLoss.netWorking = parseInt(oneItem.settlementAgreed) - (oneItem.shortfallCollected ? parseInt(oneItem.shortfallCollected) : 0);
                }
                if(oneItem.waiverCharge){
                    $scope.bvLoss.percentage = oneItem.percentage > 0 ? oneItem.percentage : 0;
				}

                if( !$scope.shortfallDetails.settlementAgreed){
                    $scope.bvLoss.netWorking = oneItem.waiverAmount = 0;
                }
            });


			$scope.waiverPayData.full.installAmount = $scope.bvLoss.netWorking;

			if ($scope.waiverPayData.full.installAmount <= 0) {
				$scope.waiverFullSettlement = true;
				$scope.waiverPayData.full.installAmount = 0;
				$scope.payMode('fullpmt');
				// angular.element('#fullpmt').triggerHandler('click');
				$scope.paymentMode = 'fullpmt';
			} else {
				$scope.waiverFullSettlement = false;
			}

			if (parseInt($scope.bvLoss.netWorking) <= 0) {
				$scope.bvLoss.netWorking = 0;
			}

			$scope.bvlossActual = $scope.bvLoss.netWorking;

		};

		$scope.initiateRequest = function () {
			$scope.data.showError = ($scope.data.waiverType.toUpperCase() == 'NORMALWAIVER' && !$scope.requestBody.collectionType);
			if (!$scope.data.showError) {
				$scope.requestBody.agreementNos = [$scope.customerInfo.agreementNo];
				$scope.requestBody.receiptNo = $scope.customerInfo.receiptNo;
				//$scope.requestBody.waiverType = collectionConstants.APPROVALS_INIT_PAGE[$stateParams.reqType].requestType;
				$scope.requestBody.waiverType = 'ShortfallWaiver';
				$scope.requestBody.status = constants.REQUEST_STATUS.INITIATED.toUpperCase();
				$scope.requestBody.branchID = $scope.customerInfo.branchID;
				$scope.requestBody.collectionType = $scope.paymentMode;
				$scope.requestBody.chargeDetails = [];
				$scope.requestBody.payDetails = [];
				$scope.requestBody.chargeID = '110526';
				var payObj = {};
				var splitUpObj;

				var chargeObj = {};
				chargeObj.chargeID = $scope.selectedChargeType ? $scope.selectedChargeType : 'Shortfall Due';
				chargeObj.actualAmount = $scope.bvLoss.actualAmount ? parseInt($scope.bvLoss.actualAmount) : $scope.data.shortfallDue;
				chargeObj.waiverAmount = $scope.bvLoss.waiverAmount ?  parseInt($scope.bvLoss.waiverAmount) : 0;
				chargeObj.waiverPercentage = $scope.bvLoss.percentage;
				$scope.requestBody.chargeDetails.push(chargeObj);

				var totalPay = 0;

				if ($scope.paymentMode == 'partpmt') {

					if (_.findWhere($scope.waiverPayData.part, {
							'installDate': ""
						})) {
						dialogService.showAlert('Error', "Error!", "Cannot initate request for empty or invalid date!");
						return;
					}

					if ($scope.noOfInstall <= 1) {
						dialogService.showAlert('Error', "Error!", "Cannot initate request for single installment!");
						return;
					}

					if ($scope.noOfInstall >= 25) {
						dialogService.showAlert('Error', "Error!", "Cannot initate request for more than 24 installment!");
						return;
					}

					payObj.paySplitUp = [];
					payObj.payMode = $scope.paymentMode;
					payObj.installmentCount = $scope.waiverPayData.part.length;

					/*if ($scope.waiverPayData.part.find(function (charge) {
							return charge.installAmount <= 0;
						}))*/
						/*dialogService.showAlert('Error', "Error!", "Cannot initate request for zero amount in installment!");
						return;*/

					_.each($scope.waiverPayData.part, function (charge) {
						splitUpObj = {};
						splitUpObj.installmentNo = parseInt(charge.installId);
						splitUpObj.payAmount = parseInt(charge.installAmount);
						splitUpObj.payDate = charge.installDate;
						splitUpObj.paymentMode = charge.modeOfPay;
						//splitUpObj.comments = charge.comments;
						payObj.paySplitUp.push(splitUpObj);
						totalPay = parseInt(totalPay) + parseInt(charge.installAmount);
					});

					$scope.requestBody.payDetails.push(payObj);

				} else {
					splitUpObj = {};
					payObj.paySplitUp = [];
					payObj.payMode = $scope.paymentMode;
					payObj.installmentCount = 1;
					splitUpObj.installmentNo = 1;
					splitUpObj.payAmount = parseInt($scope.waiverPayData.full.installAmount);
					splitUpObj.payDate = $scope.waiverPayData.full.date;
					splitUpObj.paymentMode = $scope.waiverPayData.full.modeOfPay;
					//splitUpObj.comments = charge.comments;
					payObj.paySplitUp.push(splitUpObj);
					totalPay = parseInt($scope.waiverPayData.full.installAmount);
					$scope.requestBody.payDetails.push(payObj);
				}


			var currentBVLoss = parseInt($scope.shortfallDetails.currentBVLoss) - parseInt($scope.shortfallDetails.currentPaidAmount);
			var currentBalance = (parseInt(currentBVLoss) - parseInt($scope.shortfallDetails.currentShortfallCollected) <= 0) ? 0 : parseInt(currentBVLoss) - parseInt($scope.shortfallDetails.currentShortfallCollected);


				if ($scope.waiverPayData.full.date == "") {
					dialogService.showAlert('Error', "Error!", "Cannot initate request for empty or invalid date!");
					return;
				}

				/*if (!$scope.bvLoss.waiverAmount || !$scope.requestBody.chargeDetails.length && currentBalance > 0) {
					dialogService.showAlert('Error', "Error!", "Cannot initate request for zero waiver amount!");
					return;
				}*/

				if ($scope.bvLoss.netWorking != 0 && (totalPay != $scope.bvLoss.netWorking || totalPay == "" || totalPay == 0)) {
					dialogService.showAlert('Error', "Error!", "Cannot initate request enter full payment amount!");
					validateWaiverAmount();
					return;
				}


				initiateRequestService.initiateRequest($scope.requestBody).then(function (response) {
					if (response && response.DataInserted) {
						dialogService.showAlert('Success', "Success!", "Shortfall Waiver request initiated successfully!").result.then(function () {}, function () {
							$scope.goToQueue();
						});
					}
				});

			}
		};

		$scope.goToQueue = function() {
			lazyModuleLoader.loadState('collections.approvalQueue');
		};

		$scope.resetAll = function () {
			$scope.requestBody.customerBackground = $scope.requestBody.justification = $scope.requestBody.remarks = '';
			$scope.waiverPayData.part = [];
			$scope.waiverPayData.full = {
				installId: "",
				modeOfPay: "cash",
				installAmount: "",
				installDate: "",
				dateTimeField: new DatePickerConfig({
					value: "",
					minDate: DateTime,
					readonly: true,
					DateTime: DateTime
				})
			};

			$scope.bvLoss = {
				actualAmount: $scope.data.actualAmount,
				waiverAmount: 0,
				netWorking: 0,
				percentage: 0
			};


			$scope.partPayDetails(2);
			$scope.noOfInstall = 2;
			changeValue();
		};

		var changeValue = function() {
			var e = document.getElementById("noOfInstall").value = 2;
			e.value = 2;
			var $e = angular.element(e);
			$e.triggerHandler('input');
		}

		$scope.foucsHandler = function (item) {
			if (parseInt(item.waiverAmount) === 0) {
				item.waiverAmount = '';
			}
		};


	};
	initiateRequest.controller('shortfallWaiverInitiateController', ['$scope', '$state', '$modal', '$stateParams', 'initiateRequestService', 'dialogService', 'lazyModuleLoader', 'messageBus', '$timeout', shortfallWaiverInitiateController]);
	return shortfallWaiverInitiateController;
});
