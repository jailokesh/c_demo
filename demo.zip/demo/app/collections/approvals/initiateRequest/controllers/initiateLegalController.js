define([ 'require', 'initiateRequest', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility','legalConstants' ], function(r, initiateRequest, constants, DatePickerConfig, collectionConstants, utility,legalConstants) {
	'use strict';

	var initiateLegalController = function($scope, $state, $stateParams, initiateRequestService, dialogService, lazyModuleLoader, $modal, messageBus) {
		$scope.requestBody = {};
		$scope.financeStatus = constants.STATUS;
		$scope.allStatus = constants.AGREEMENT_STATUS;
		$scope.dropDownValues = {};
		var defaultAgreement,bucketTrend;
		 $scope.availability ={borrower:false,coApplicant:false,guarantor:false,vehicle:false,property:false,isAvailable:false};
		 var getAvailability = function(questionnaire){
			$scope.availability.borrower =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.borowerID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.borowerID}).response ==='Yes')?true:false;
			$scope.availability.coApplicant =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.coApplicantID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.coApplicantID}).response ==='Yes')?true:false;
			$scope.availability.guarantor =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.guarantorID}) &&_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.guarantorID}).response ==='Yes')?true:false;
			$scope.availability.vehicle =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.vehicleID}) && _.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.vehicleID}).response ==='Yes')?true:false;
			$scope.availability.property =  (_.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.propertyID}) && _.findWhere(questionnaire,{question:collectionConstants.LEGAL_AVAILABILITY_CONFIG.propertyID}).response ==='Yes')?true:false;
		};
		var fetchLegalDetails = function(agreementNo,cifID,count){
			initiateRequestService.getLegalDetails(agreementNo,cifID,count).then(function(legalData){
				bucketTrend = legalData.bucketTrend;
				if(legalData.questionnaire && legalData.questionnaire.length){
					getAvailability(legalData.questionnaire);
				}else{
					$scope.availability.isAvailable = true;
			 }
			});
			
		};
		$scope.fetchAgrDetails = function(agreementNo) {
			if (!agreementNo) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (agreementNo.length < legalConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + legalConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
			initiateRequestService.getCaseDetails(agreementNo).then(function(response) {
				$scope.dropDownValues.caseFiledAt = [ {
					'name' : 'HO LEGAL'
				} ];
				$scope.dropDownValues.docLabel = 'Select Section';
				$scope.dropDownValues.isOtherCase = false;
				if (response && response.length) {
					if(response[0].productGroup === 'PL'){
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.LEGAL_NA_PL);
						return;
					}else if(response[0].productCode === 'VISHESH'  || response[0].productCode === 'TRIP'){
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.LEGAL_NA_VISHESH);
						return;
					}
					$scope.customerInfo = utility.getCustomerInfo(response[0]);
					$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS, {
						status : $scope.customerInfo.agreementStatus
					}); 
					$scope.applicantType = _.indexBy($scope.customerInfo.partyDetails, 'partyType');
					$scope.customerInfo.branchName = initiateRequestService.getBranchName($scope.customerInfo.branchID);
					$scope.requestBody.agreementNos = [ agreementNo ];
					$scope.noRecords = false;
					$scope.dropDownValues.userAgreements = [];
					// Listing legal sections based on product type
					if ($scope.customerInfo.productGroup === 'HE' || $scope.customerInfo.productGroup === 'HL') {
						$scope.dropDownValues.sections = angular.copy(legalConstants.LEGAL_VALUES.SECTIONS_HEHL);
					} else {
						$scope.dropDownValues.sections = angular.copy(legalConstants.LEGAL_VALUES.SECTIONS);
					}
					// Uncheck the selected legal sections
					if ($scope.dropDownValues.sections) {
						_.each($scope.dropDownValues.sections, function(section) {
							section.selected = false;
						});
					}
					
					$scope.customerInfo.totalOD = $scope.customerInfo.totalEMIODAmount + $scope.customerInfo.totalAFCODAmount + $scope.customerInfo.totalCBCODAmount + $scope.customerInfo.totalFVCODAmount+ $scope.customerInfo.totalOtherOD;
					$scope.customerInfo.grossValue = $scope.customerInfo.totalEMIODAmount + $scope.customerInfo.futurePrincipalAmount;
			        if ($scope.customerInfo.grossValue) {
			        	$scope.customerInfo.grossValue = Math.round($scope.customerInfo.grossValue);
			        }

					initiateRequestService.getUserAgreementList(agreementNo, $scope.customerInfo.APPLICANT.cifID,$scope.customerInfo.productGroup).then(function(data) {
						$scope.dropDownValues.agreementList = angular.copy(data);
						fetchLegalDetails(agreementNo,$scope.customerInfo.APPLICANT.cifID,$scope.dropDownValues.agreementList.length-1);
						$scope.dropDownValues.userAgreements = _.where($scope.dropDownValues.agreementList, {
							selected : true
						});
						defaultAgreement = $scope.dropDownValues.agreementList[0];
						$scope.dropDownValues.agreementList.shift();
					});
					
					initiateRequestService.getCholaBranches().then(function(branches) {
						try {
							var name = _.findWhere(branches, {
								branchID : $scope.customerInfo.branchID
							}).branchDesc;
							$scope.dropDownValues.caseFiledAt.push({
								name : name
							});
						} catch (error) {
							return;
						}
					});
				} else {
					$scope.customerInfo = '';
					$scope.noRecords = true;
				}
				initiateRequestService.getCholaBranchesByZone().then(function(zoneBranches){
 					try{
 						 zoneBranches = zoneBranches;
 						_.each(zoneBranches,function(item){
 							$scope.dropDownValues.caseFiledAt.push({
								name : item.branchDesc
							});
 						});
 					}catch(error){
 						return;
 					}
 					
 				});
			});
			messageBus.onMsg("UPDATE_SELECTED_AGREEMENTS", function(event, data) {
				$scope.dropDownValues.userAgreements = data;
				$scope.dropDownValues.userAgreements.unshift(defaultAgreement);
			}, $scope);
		};
		
		$scope.removeItem = function(index, item) {
			$scope.dropDownValues.userAgreements.splice(index, 1);
			_.findWhere($scope.dropDownValues.agreementList, {
				agreementNo : item.agreementNo
			}).selected = false;
		};
		$scope.dropDownValues.docLabel = 'Select Section';
		$scope.changeHandler = function(item) {
			$scope.dropDownValues.selectedSections = [];
			_.each($scope.dropDownValues.sections, function(section) {
				if (section.selected) {
					$scope.dropDownValues.selectedSections.push(section);
				}
			});
			if ((/OTHERS/ig).test(item.key)) {
				$scope.dropDownValues.isOtherCase = item.selected;
			}
			$scope.dropDownValues.docLabel = ($scope.dropDownValues.selectedSections.length === 0) ? 'Select Section' : ($scope.dropDownValues.selectedSections.length === 1) ? $scope.dropDownValues.selectedSections[0].label : $scope.dropDownValues.selectedSections.length + ' Cases';
		};

		$scope.openPopUp = function() {
			$modal.open({
				templateUrl : 'app/collections/approvals/initiateRequest/partials/agreementSelection.html',
				controller : [ '$scope', 'data', '$modal', '$modalInstance', 'messageBus', function($scope, data, $modal, $modalInstance, messageBus) {
					$scope.data = {};
					$scope.data.productType = data.productType;
					$scope.data.totalRecords = data.data;
					$scope.data.currentPage = 1;
					$scope.data.recordPerPage = 5;
					$scope.isInitiation = data.isInitiation;
					$scope.saveHandler = function() {
						messageBus.emitMsg("UPDATE_SELECTED_AGREEMENTS", _.where($scope.data.totalRecords, {
							selected : true
						}));
						$scope.close();
					};
					$scope.paginationHandler = function(pageNo) {
						var startLen = $scope.data.recordPerPage * (pageNo - 1);
						var endLen = $scope.data.recordPerPage + ($scope.data.recordPerPage * (pageNo - 1));
						$scope.data.paginationList = $scope.data.totalRecords.slice(startLen, endLen);
					};
					$scope.paginationHandler(1);
					$scope.close = function() {
						$modalInstance.dismiss();
					};
					$scope.selectCheckbox = function(item){
						if(item.selected){
							initiateRequestService.getLegalDetails(item.agreementNo);
						}
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							data : $scope.dropDownValues.agreementList,
							isInitiation : true,
							productType :$scope.customerInfo.productGroup
						};
					}
				}
			});
		};

		$scope.initiateLegal = function() {
			if (!$scope.dropDownValues.userAgreements || $scope.dropDownValues.userAgreements.length === 0) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NO_AGREEMENT_SELECTED);
				return;
			}
			$scope.requestBody.legalSections = _.pluck($scope.dropDownValues.selectedSections, 'value');
			/*if(!$scope.requestBody.legalSections || !$scope.requestBody.legalSections.length){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, collectionConstants.ERROR_MSG.NO_SECTION_SELECTED);
				return;
			}*/
			$scope.requestBody.status = "INITIATED";
			$scope.requestBody.productGroup = $scope.customerInfo.productGroup;
			$scope.requestBody.agreementNos = _.pluck($scope.dropDownValues.userAgreements, 'agreementNo');
			$scope.requestBody.agreementStatus = $scope.customerInfo.agreementStatus;
			$scope.requestBody.branchID = $scope.customerInfo.branchID;
			if ($scope.requestBody.legalSections.indexOf('Others') > -1) {
				$scope.requestBody.legalSections.pop();
				$scope.requestBody.legalSections.push($scope.dropDownValues.otherCase);
			}
			initiateRequestService.initiateLegal($scope.requestBody).then(function(response) {
				if (response) {
					dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING, collectionConstants.POPUP_HEADER.SUCCESS_STRING, collectionConstants.ERROR_MSG.LEGAL_CASE_INITIATED).result.then(function() {
					}, function() {
						$scope.goToQueue();
					});
				}
			});
		};

		$scope.goToQueue = function() {
			lazyModuleLoader.loadState('collections.approvalQueue');
		};
		/** Bucket trend pop-up */
		$scope.bucketPop = function() {
			$modal.open({
				templateUrl : 'app/collections/legal/documentsQueue/partials/bucketTrendPopup.html',
				controller : [ '$scope', '$modalInstance', 'data', function($scope, $modalInstance, data) {
					$scope.agreementBuckets = data.bucketTrends;
					$scope.close = function() {
						$modalInstance.close();
					};
				} ],
				size : 'md',
				backdrop : 'static',
				windowClass : 'modal-custom',
				resolve : {
					data : function() {
						return {
							bucketTrends : bucketTrend
						};
					}
				}
			});
		};
	};
	initiateRequest.controller('initiateLegalController', [ '$scope', '$state', '$stateParams', 'initiateRequestService', 'dialogService', 'lazyModuleLoader', '$modal', 'messageBus', initiateLegalController ]);
	return initiateLegalController;
});