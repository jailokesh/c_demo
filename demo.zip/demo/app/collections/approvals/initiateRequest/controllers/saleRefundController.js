define([ 'require', 'initiateRequest', 'constants', 'DatePickerConfig', 'collectionConstants', 'utility' ], function(r, initiateRequest, constants, DatePickerConfig, collectionConstants, utility) {
	'use strict';

	var saleRefundController = function($scope, $state, $modal, $stateParams, initiateRequestService, dialogService, lazyModuleLoader, messageBus, masterService) {
		$scope.requestBody = {};
		$scope.linkedAgrNos = [];
        var paginationObj,manualReceiptInfo = {};
		var searchResponse = [];
		var reInitiate = false;
		$scope.searchParams={
			branchName: JSON.parse(getCookie('selectedBranch')).branchID,
			searchBy:'',
			searchKey:'',
			receiptNo:'',
			receiptDate:'',
			limit :  10
		};
		$scope.value = {
			exclude : collectionConstants.CHARGES_EXCLUDE
		};
		$scope.value.accountTypes = collectionConstants.ACCOUNT_TYPES;
		$scope.rePayBankDetails = {};
		
		$scope.search = 'agreementNo';
		$scope.placeHolder = 'AGREEMENT NO';
        
            $scope.pagination = {maxSize:constants.PAGINATION_CONFIG.MAX_SIZE_TEN,totalRecord:0,currentPage:1,offsetlast:constants.PAGINATION_CONFIG.MAX_SIZE_TEN,offset:1};
			$scope.tableResult = [];
			paginationObj = initiateRequestService.getPageValues();
            $scope.pagination.prevPageNo = $scope.pagination.currentPage = 1;


		$scope.searchHandler = function(data){
			$scope.refundReceiptDetails = data;
			$scope.buyerAgreementDetails = false;
			$scope.receiptDetails = true;			
		}	

		$scope.bodyContent = function(search){
			var arr = search.split(/(?=[A-Z])/);	
			$scope.agreementNo = "";		
			$scope.placeHolder = arr.join(" ");
			$scope.buyerAgreementDetails = false;
			$scope.receiptDetails = false;
			$scope.noRecords = false;
			resetBankDetails();
			setDefaultValues();	
			$scope.value.disableBank = false;
			$scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType = '';
			$scope.requestBody.remarks = '';
		}

		$scope.cancel = function(){
			lazyModuleLoader.loadState('collections.approvalQueue');	
		}

			var resetBankDetails = function(value) {
				$scope.rpdcSubmitModel.pddAcknowledgement[value] = $scope.rpdcSubmitModel.pddAcknowledgement.bankID = '';
				$scope.value.bank = '';
				$scope.bankList = initiateRequestService.bankNames;
				$scope.branchList = [];
			};

			var getBankBranchDetails = function(type,isIfsc) {
				if (type === 'ifsc' && !invalidIFSC) {
					if(!collectionConstants.REGULAR_EXPRESSION.IFSC_CODE.test($scope.rpdcSubmitModel.pddAcknowledgement.ifsCode)){
						dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.INVALID_IFSC);
						invalidIFSC = true;
						return;
					}
					masterService.getBankIdFromIFSC($scope.rpdcSubmitModel.pddAcknowledgement.ifsCode, 'BankBranch').then(function(data) {
						if (!data || data.length === 0 || !data[0].bankID) {
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.INVALID_IFSC);
							resetBankDetails('micrCode');
							$scope.value.disableBank = false;
							invalidIFSC = true;
							return;
						}
						var item = data[0];
						$scope.branchList = [ item ];
						$scope.rpdcSubmitModel.pddAcknowledgement.bankID = item.bankID;
						$scope.rpdcSubmitModel.pddAcknowledgement.bBranchID = item.bBranchID;
						$scope.rpdcSubmitModel.pddAcknowledgement.micrCode = item.micrCode;
						getPDCBankName(item.bankID, item.cityID);
						invalidIFSC = false;
						invalidMICR = false;
						$scope.value.disableBank = isIfsc ? false : true;
					});
				} else if (type === 'micr' && !invalidMICR) {
					masterService.getBankIdFromMICR($scope.rpdcSubmitModel.pddAcknowledgement.micrCode, 'BankBranch').then(function(data) {
						if (!data || data.length === 0) {
							invalidMICR = true;
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.INVALID_MICR);
							return;
						}
						var item = data[0];
						$scope.branchList = [ item ];
						$scope.rpdcSubmitModel.pddAcknowledgement.ifsCode = (!item.ifsCode) ? '' : item.ifsCode;
						$scope.rpdcSubmitModel.pddAcknowledgement.bankID = item.bankID;
						$scope.rpdcSubmitModel.pddAcknowledgement.bBranchID = item.bBranchID;
						getPDCBankName(item.bankID, item.cityID);
						invalidMICR = false;
						invalidIFSC = false;
						$scope.value.disableBank = true;
					});
				} else if (type === 'bank' || type === 'repay') {
					if ($scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType === 'SI') {
						$scope.bankList = initiateRequestService.bankNames;
						$scope.value.bank = _findWhere($scope.bankList, {
							bankID : '002'
						});
						$scope.rpdcSubmitModel.pddAcknowledgement.bankID = '002';
					}
					if ($scope.rpdcSubmitModel.pddAcknowledgement.bankID) {
						masterService.getBankBranches($scope.rpdcSubmitModel.pddAcknowledgement.bankID).then(function(data) {
							$scope.branchList = data;
						});
					}
				}
			};

			var setDefaultValues = function() {

				if (initiateRequestService.bankNames.length === 0) {
					masterService.getPDCBank().then(function(data) {
						$scope.bankList = data;
						initiateRequestService.bankNames = data;
						var bankObj = _.findWhere($scope.bankList, {
							bankID : $scope.rePayBankDetails.bankID
						});
						$scope.rePayBankDetails.bankName = (bankObj) ? bankObj.name : '';
					});
				} else {
					$scope.bankList = initiateRequestService.bankNames;
				}

				$scope.rpdcSubmitModel = { };
				$scope.value.bank = '';

                    $scope.rpdcSubmitModel.pddAcknowledgement = {
                        ifsCode : '',
                        accountNo : '',
                        bBranchID : '',
                        isDisabled : false,
                        pddAcknowledgementType : '',
                        bank : ''
                    }

			};
			setDefaultValues();		
				
			var modifiedField;
			var getPDCBankName = function(bankID, cityID) {
				masterService.getMasters("PdcBank", {
					bankID : bankID,
					cityID : cityID
				}).then(function(banks) {
					$scope.bankList = banks;
					$scope.value.bank = banks[0];
				});
			};

			var invalidIFSC, invalidMICR, isAgreedSwap, swapOptionFunction, popUpType;
			$scope.showPopup = function(item, value,isIfsc) {
				var isValid = false;
				modifiedField = value;
				if (value === 'bank') {
					$scope.rpdcSubmitModel.pddAcknowledgement.bankID = $scope.value.bank.bankID;
					item.bankID = $scope.rpdcSubmitModel.pddAcknowledgement.bankID;
					isValid = ($scope.rePayBankDetails.bankID !== item.bankID);
					getBankBranchDetails(value);
				} else if (value === 'branch' && $scope.rePayBankDetails.branchID !== item.bBranchID) {
					var branchObj = _.findWhere($scope.branchList, {
						bBranchID : item.bBranchID
					}) || {};
					item.ifsCode = (!branchObj.ifsCode) ? '' : branchObj.ifsCode;
					item.micrCode = (!branchObj.micrCode) ? '' : branchObj.micrCode;
					invalidMICR = invalidIFSC = false;
					isValid = true;
				} else if (value === "ifsc") {
					if (item.ifsCode) {
						if (item.ifsCode && item.ifsCode.length < 11) {
							resetBankDetails('micrCode');
							$scope.value.disableBank = false;
							invalidIFSC = true;
							dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.message, collectionConstants.ERROR_MSG.INVALID_IFSC);						
						} else {
							invalidIFSC = false;
							getBankBranchDetails(value,isIfsc);
						}
					} else {
						resetBankDetails('micrCode');
						$scope.value.disableBank = invalidIFSC = false;
						return;
					}
				}
			};


		 $scope.fetchAgrDetails = function(agreementNo, search) {

			if (!agreementNo) {
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			} else if (agreementNo.length < collectionConstants.SEARCH_LIMIT) {
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT + " Characters to Search !");
				return;
			}
          
			var queryParams = {};

            if(search == 'buyerId'){
				queryParams.payerId = agreementNo;
            }else if(search == 'agreementNo' || search == undefined){
				queryParams.agreementNo = agreementNo;				     
            }else if(search == 'receiptNo'){
				queryParams.receiptNo = agreementNo;
			}

			paginationObj = {};
			$scope.searchParams.offset = ($scope.searchParams.searchBy.type === 'imd' || $scope.searchParams.searchBy.type === 'ins-lead') ? ((($scope.pagination.currentPage-1)*$scope.searchParams.limit)+1) : $scope.pagination.currentPage;
			$scope.searchParams.limit = 10;		
			initiateRequestService.getSaleRefundDetails(queryParams).then(function(data) {

				if (data && data.length) {

					$scope.noRecords = false;
					if(search != 'buyerId'){
							$scope.refundReceiptDetails = data[0];
					}	

					if(search != 'buyerId'){
						$scope.receiptDetails = false;
						$scope.buyerAgreementDetails = true;
						// $scope.receiptDetails = true;
						// $scope.buyerAgreementDetails = false;
					}else{
						$scope.receiptDetails = false;
						$scope.buyerAgreementDetails = true;
					}

                } else {
					$scope.noRecords = true;
				}
				if ($scope.refundReceiptDetails && $scope.refundReceiptDetails.workflow) {
						if($scope.refundReceiptDetails.workflow.length>0){
							if($scope.refundReceiptDetails.workflow[$scope.refundReceiptDetails.workflow.length-1].workStatus && $scope.refundReceiptDetails.workflow[$scope.refundReceiptDetails.workflow.length-1].workStatus == "REJECTED" && $scope.refundReceiptDetails.workflow[$scope.refundReceiptDetails.workflow.length-1].requestType && $scope.refundReceiptDetails.workflow[$scope.refundReceiptDetails.workflow.length-1].requestType.toUpperCase() =="SALEREFUND"){
								reInitiate = true;
							}
						}
					}
                if($scope.refundReceiptDetails && $scope.refundReceiptDetails.accountDetails){
                    $scope.rpdcSubmitModel.pddAcknowledgement.accountNo = $scope.refundReceiptDetails.accountDetails.accountNo;
                    $scope.rpdcSubmitModel.pddAcknowledgement.ifsCode = $scope.refundReceiptDetails.accountDetails.ifscCode;
					$scope.rpdcSubmitModel.pddAcknowledgement.accountType = $scope.refundReceiptDetails.accountDetails.accountType;
                    $scope.refundReceiptDetails.accountDetails.ifsCode = $scope.refundReceiptDetails.accountDetails.ifscCode;
                    $scope.showPopup($scope.refundReceiptDetails.accountDetails,'ifsc',true);
                    var sortedWorkflow = _.sortBy($scope.refundReceiptDetails.workflow, function(o) { return -new Date(o.workDoneDate); });

                    var initiatedRemarks = _.findWhere(sortedWorkflow,{	workStatus :"INITIATED",requestType :"SALEREFUND"
					})
					if(initiatedRemarks && initiatedRemarks.comments){
                    	$scope.requestBody.remarks = initiatedRemarks.comments;
                    }	
                }
			
				$scope.pagination.totalRecord = paginationObj.totalRecord = data ? data.length :0;
				$scope.pagination.offsetlast = (($scope.pagination.offset+$scope.pagination.maxSize)>$scope.pagination.totalRecord) ? $scope.pagination.totalRecord : $scope.pagination.offset+($scope.pagination.maxSize-1);
				if ($scope.pagination.totalRecord) {
					searchResponse = data;
					$scope.tableResult = paginationObj.data = data.slice(0, 10);
					$scope.pagination.productType = $scope.tableResult[0].productGroup;
					if($scope.searchParams.searchBy.type === 'imd' && !$scope.searchParams.searchBy.product){
						$scope.pagination.isHEAgreement = false;
					}else{
						$scope.pagination.isHEAgreement = ($scope.pagination.productType !== "VF"); 
					}
					paginationObj.pagination = $scope.pagination;
					initiateRequestService.setSearchResults($scope.tableResult);
				}else{
					$scope.tableResult = [];
				}
			});

            initiateRequestService.setPageValues(paginationObj);    
			resetBankDetails();
			setDefaultValues();	
			$scope.value.disableBank = false;
			$scope.rpdcSubmitModel.pddAcknowledgement.pddAcknowledgementType = '';
			$scope.requestBody.remarks = '';						        
		};
        if($stateParams.reqType == 'saleRefund' && $stateParams.agreementNo){
            $scope.agreementNo = $stateParams.agreementNo;
            $scope.fetchAgrDetails($scope.agreementNo, 'agreementNo');
        }
		$scope.initiateRequest = function() {	

				$scope.requestBody.agreementNo = $scope.refundReceiptDetails.agreementNos[0];
				$scope.requestBody.receiptNo = $scope.refundReceiptDetails.receiptNo;
				$scope.requestBody.branchID = $scope.refundReceiptDetails.branchID;
				$scope.requestBody.majorVersion = $scope.refundReceiptDetails.majorVersion;
				$scope.requestBody.minorVersion = $scope.refundReceiptDetails.minorVersion;		
				$scope.requestBody.status = 'INITIATED';
				$scope.requestBody.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
				$scope.requestBody.productType =  $scope.refundReceiptDetails.productType;
				$scope.requestBody.buyerID =  $scope.refundReceiptDetails.payerID;
				$scope.requestBody.buyerName =  $scope.refundReceiptDetails.buyerName;
				$scope.requestBody.amountPaid =  $scope.refundReceiptDetails.amountPaid;

				$scope.requestBody.accountDetails = {
					accountNo : $scope.rpdcSubmitModel.pddAcknowledgement.accountNo,
					accountType : $scope.rpdcSubmitModel.pddAcknowledgement.accountType,
					ifscCode : $scope.rpdcSubmitModel.pddAcknowledgement.ifsCode,
					bankID : $scope.value.bank.bankID,
					bankBranchID : $scope.rpdcSubmitModel.pddAcknowledgement.bBranchID					
				};

				initiateRequestService.initiateSaleRefundRequest($scope.requestBody).then(function(response) {
					if (response && response.status == "success") {
						if(reInitiate){
							dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.SALE_REFUND_REINITIATE_REQUEST).result.then(function(){},function(){
									$scope.goToQueue();
							});
						} else{
							dialogService.showAlert(constants.ERROR_HEADER.success, constants.ERROR_HEADER.success, collectionConstants.SUCCESS_MSG.SALE_REFUND_APPROVAL_REQUEST).result.then(function(){},function(){
									$scope.goToQueue();
							});
						}
					}else{
						$scope.goToQueue();
					}
				});

		};


		var getSearchResults = function(pageNum){
			paginationObj = {};
			$scope.searchParams.offset = ($scope.searchParams.searchBy.type === 'imd' || $scope.searchParams.searchBy.type === 'ins-lead') ? ((($scope.pagination.currentPage-1)*$scope.searchParams.limit)+1) : $scope.pagination.currentPage;
			$scope.searchParams.limit = 10;		
			var data = searchResponse;

			//var startingNum = pageNum-1;

				$scope.pagination.totalRecord = paginationObj.totalRecord = data.length;
				$scope.pagination.offsetlast = (($scope.pagination.offset+$scope.pagination.maxSize)>$scope.pagination.totalRecord) ? $scope.pagination.totalRecord : $scope.pagination.offset+($scope.pagination.maxSize-1);
				if ($scope.pagination.totalRecord) {
					$scope.tableResult = paginationObj.data = data.slice((pageNum-1)*10, pageNum*10);
					paginationObj.pagination = $scope.pagination;
					initiateRequestService.setSearchResults($scope.tableResult);
				}else{
					$scope.tableResult = [];
				}


            initiateRequestService.setPageValues(paginationObj);   
		};


		$scope.paginationHandler = function(pageNum,agreementNo) {
			if(true){
				$scope.searchParams.searchKey = agreementNo;
				$scope.pagination.prevPageNo = $scope.pagination.currentPage = pageNum;
				$scope.pagination.offset = ((($scope.pagination.currentPage-1)*$scope.pagination.maxSize)+1);
				getSearchResults(pageNum);
			}else{
				$scope.pagination.currentPage = $scope.pagination.prevPageNo;
			}
		};

        
		$scope.resetAll = function() {
			$scope.requestBody.remarks = '';
		};

		$scope.goToQueue = function() {
			lazyModuleLoader.loadState('collections.approvalQueue');
		};

		/*
		 * $scope.viewLinkedAgreements = function(){ if(linkedAgrNos.length) {
		 * showAgreementPopup(); return; } };
		 */

		$scope.foucsHandler = function(item) {
			if (parseInt(item.waiverAmount) === 0) {
				item.waiverAmount = '';
			}
		};


	};
	initiateRequest.controller('saleRefundController', [ '$scope', '$state', '$modal', '$stateParams', 'initiateRequestService', 'dialogService', 'lazyModuleLoader', 'messageBus', 'masterService', saleRefundController ]);
	return saleRefundController;
});
