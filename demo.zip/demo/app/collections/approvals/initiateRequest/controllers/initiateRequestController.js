define(['require','initiateRequest','collectionConstants'], function(r,initiateRequest,collectionConstants) {
'use strict';

 	var initiateRequestController = function($scope,$state,$stateParams){
 		$state.$current.data.headerText = collectionConstants.APPROVALS_INIT_PAGE[$stateParams.reqType].headerText;
 		$scope.pageSrc = 'app/collections/approvals/initiateRequest/partials/'+collectionConstants.APPROVALS_INIT_PAGE[$stateParams.reqType].pageName+'.html';
 	};
 	initiateRequest.controller('initiateRequestController',['$scope','$state','$stateParams',initiateRequestController]);
	return initiateRequestController;
});