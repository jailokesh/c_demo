define(['require','initiateRequest', 'constants','DatePickerConfig','collectionConstants','utility'], function(r,initiateRequest,constants,DatePickerConfig,collectionConstants,utility) {
'use strict';

 	var legalComplianceController = function($scope,$state,$stateParams,initiateRequestService,dialogService,lazyModuleLoader,$modal){ 		
 		$scope.allStatus = constants.AGREEMENT_STATUS;
 		$scope.dropDownValues = {};
 		$scope.dropDownValues.isInitiate = true;
 		$scope.fetchAgrDetails = function(caseID){
 			if(!caseID){
				dialogService.showAlert(constants.ERROR_HEADER.error, constants.ERROR_HEADER.error, collectionConstants.ERROR_MSG.VALID_SEARCH);
				return;
			}else if(caseID.length < collectionConstants.SEARCH_LIMIT){
				dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, "Please Enter Atleast " + collectionConstants.SEARCH_LIMIT+ " Characters to Search !");
				return;
			}
 			$scope.requestBody = {agreementNos:[]};
 			initiateRequestService.getLegalCaseDetails(caseID,$scope.legalType).then(function(response) {
 				if(response && response.length){
 					$scope.legalDetails = response[0];
 					if($scope.legalDetails.legalData.workflow[0] && $scope.legalDetails.legalData.workflow[0].workStatus !== 'REJECTED'){
 						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning,(($scope.legalType.charAt(0).toUpperCase() + $scope.legalType.slice(1).toLowerCase()) + collectionConstants.ERROR_MSG.LEGAL_COMP_DONE +" for caseID "+caseID+"!")).result.then(function(){},function(){
            				$scope.dropDownValues.isInitiate = true;
 							$scope.caseID = "";
 							$modalInstance.dismiss();
            			});
 					}else if($scope.legalDetails.legalData.workflow[0] && $scope.legalDetails.legalData.workflow[0].workStatus === 'CASECLOSED'){
 						dialogService.showAlert(constants.ERROR_HEADER.warning, constants.ERROR_HEADER.warning,collectionConstants.ERROR_MSG.CASE_CLOSED).result.then(function(){},function(){
 							$scope.caseID = "";
 							$scope.dropDownValues.isInitiate = false;
 						});
 					}else{
 						$scope.dropDownValues.isInitiate = false;
 					}
 					$scope.customerInfo = utility.getCustomerInfo(angular.copy($scope.legalDetails.caseDetail));
	 		 		$scope.customerInfo.agrstatus = _.findWhere(collectionConstants.AGREEMENTSTATUS,{status:$scope.customerInfo.agreementStatus});
 					/*$scope.legalDetails.applicantDetails =  _.findWhere($scope.legalDetails.caseDetail.partyDetails,{"partyType":"A"});
 					if($scope.legalDetails.applicantDetails){
 						$scope.legalDetails.applicantDetails.name = $scope.legalDetails.applicantDetails.firstName + ' ';
 						$scope.legalDetails.applicantDetails.name += (!$scope.legalDetails.applicantDetails.middleName) ? '' : $scope.legalDetails.applicantDetails.middleName+ ' ';
 						$scope.legalDetails.applicantDetails.name += (!$scope.legalDetails.applicantDetails.lastName) ? '' : $scope.legalDetails.applicantDetails.lastName;
 					}*/
 					$scope.noRecords = false;
 				}else{
 					$scope.legalDetails = '';
 					$scope.dropDownValues.isInitiate = true;
 					$scope.noRecords = true;
 				}
 				
  			});
 			
 	
 		};
 		$scope.selectOptions = function(){
			$modal.open({
                templateUrl: 'app/collections/approvals/approvalQueue/partials/selectLegalTypePopup.html',
                controller: ['$scope','$modalInstance','dialogService','lazyModuleLoader',function($scope,$modalInstance,dialogService,lazyModuleLoader){
                	$scope.initiateType='';
             		$scope.close = function(){
            			dialogService.confirm(collectionConstants.POPUP_HEADER.CONFIRM_STRING, collectionConstants.POPUP_HEADER.CONFIRM_STRING,collectionConstants.ERROR_MSG.CLOSE_CONFIRMATION).result.then(function(){
            				$modalInstance.dismiss();
            			},function(){});
            		};
            		
            		$scope.goToInitiate = function(type){
            			$scope.$parent.legalType = type;
            			$modalInstance.dismiss();
            		};
                }],
                backdrop : 'static',
                size : 'sm'
            });
		};
		
		$scope.selectOptions();
		$scope.calculateNetAmount = function(waiverAmount,amountToBePaid){
			$scope.requestBody.complianceAppeal.netLoss = parseInt(waiverAmount) + parseInt(amountToBePaid);
		};
 		$scope.initiateLegalCompliance = function(requestBody){
 			requestBody.agreementNos.push($scope.legalDetails.caseDetail.agreementNo);
 			requestBody.status = "INITIATED";
 			requestBody.productGroup = $scope.legalDetails.caseDetail.productGroup;
 			requestBody.caseID = $scope.caseID;
 			requestBody.complianceAppeal.complianceAmount = requestBody.complianceAppeal.amountToBePaid;
 			requestBody.majorVersion = $scope.legalDetails.legalData.majorVersion;
 			requestBody.minorVersion = $scope.legalDetails.legalData.minorVersion;
 			requestBody.branchID = $scope.legalDetails.caseDetail.branchID;
 			initiateRequestService.initiateLegalCompliance(requestBody,$scope.legalType).then(function(response) {
 				if(response){
	 				dialogService.showAlert(collectionConstants.POPUP_HEADER.SUCCESS_STRING, collectionConstants.POPUP_HEADER.SUCCESS_STRING, $scope.legalType + collectionConstants.ERROR_MSG.LEGAL_COMPL_INITIATED).result.then(function(){},
	 				function(){$scope.goToQueue();});
 				}
 			});
 		};
 		
 		$scope.goToQueue = function(){
 			lazyModuleLoader.loadState('collections.approvalQueue');
 		}; 		
 	};
 	initiateRequest.controller('legalComplianceController',['$scope','$state','$stateParams','initiateRequestService','dialogService','lazyModuleLoader','$modal',legalComplianceController]);
	return legalComplianceController;
});