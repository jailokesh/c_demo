define([], function() {
	'use strict';
	return {
		getZones : [ '$q', '$stateParams' ,'initiateRequestService', function($q, $stateParams, initiateRequestService) {
			if($stateParams.reqType === 'standByTeller'){
				return initiateRequestService.getUserDataMapping().then(function(data){
					return $q.when(data);
				});	
			}else{
				return $q.reject();
			}
		} ]	
	};
});