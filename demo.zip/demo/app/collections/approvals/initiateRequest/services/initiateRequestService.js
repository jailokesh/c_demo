define([ 'require', 'initiateRequest', 'collectionServiceURLs', 'expenseModel', 'constants', 'collectionConstants','utility', 'receiptModel' ], function(r, initiateRequest, collectionServiceURL, ExpenseModel, constants, collectionConstants,utility, Receipt) {
	'use strict';

	var initiateRequestService = function($rootScope, restProxy, $stateParams, masterService, $q, dialogService,$modal, repoMasterService, $globalScope) {
		var branchNames = [];
		var serviceObj = this;
		this.locations = {
			branchDetails : {}
		};			
		var receipt = new Receipt();
var searchResults = [];
		this.bankNames = [];
			this.getSaleRefundDetails = function(queryParams) {
				collectionServiceURL.legalServices.GET_SALE_REFUND_INITIATE.queryParams = queryParams;
				return restProxy.get(collectionServiceURL.legalServices.GET_SALE_REFUND_INITIATE).then(function(data) {	
					return data.data;
				});			
			};

			this.getSearchResults = function() {
				return searchResults;
			};

			this.setSearchResults = function(value) {
				searchResults = value;
			};


			var pageDetails;
			this.setPageValues = function(value) {
				pageDetails = value;
			};
			this.getPageValues = function() {
				return pageDetails;
			};
		
		this.getCaseDetails = function(agrNo, waiverType) {
			collectionServiceURL.receiptingServices.SEARCH_RECEIPTS.queryParams = {
				view : 'receiptDetail',
				agreementNos : agrNo,
				productGroup : 'waiver' // this is for PL agreements
			};
			// getCholaBranches();
			serviceObj.foreclosureLADetails = '';
			return restProxy.get(collectionServiceURL.receiptingServices.SEARCH_RECEIPTS).then(function(data) {
				if (data.data && data.data.length && (waiverType !== 'foreclosureWaiver' || data.data[0].productGroup !== 'VF')) {
					var total = {
						receiptChargeType : 'TOTAL',
						actualAmount : 0,
						waiverAmount : 0,
						percentage : 0,
						netWorking : 0
					};
					if (waiverType === 'foreclosureWaiver') {
						data.data[0].expenseDetails.push({
							chargeAmount : data.data[0].futurePrincipalAmount,
							paidAmount : 0,
							chargeID : collectionConstants.CHARGE_IDS.EXCESS,
							receiptChargeType : 'POS'
						});
						data.data[0].expenseDetails.push({
							chargeAmount : Math.round(data.data[0].futurePrincipalAmount * collectionConstants.OTHERS.FC_POS_PERCENTAGE),
							paidAmount : 0,
							chargeID : collectionConstants.CHARGE_IDS.FOUR_PERCENT_POS,
							receiptChargeType : collectionConstants.OTHERS.FC_POS_PERCENTAGE*100+'% POS'
						});
					}
					for (var i = 0; i < data.data[0].expenseDetails.length;) {
						var item = data.data[0].expenseDetails[i];
						var differenceAmt = Math.round(Number(item.chargeAmount) - Number(item.paidAmount));
						if (differenceAmt < 1) {
							data.data[0].expenseDetails.splice(i, 1);
							continue;
						}
						item.netWorking = item.actualAmount = differenceAmt > 0 ? differenceAmt : 0;
						item.waiverAmount = item.percentage = 0;
						total.actualAmount += item.actualAmount;
						total.netWorking += item.netWorking;
						i++;
					}
					data.data[0].expenseDetails.push(total);
				}
				return data.data;
			});
		};

		this.initiateSaleRefundRequest = function(reqBody){
			collectionServiceURL.approvalServices.SALEREFUND_APPROVAL.urlParams = { };	
			return restProxy.save('POST', collectionServiceURL.approvalServices.SALEREFUND_APPROVAL, reqBody, '', {
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			}).then(function(data) {
				return data;
			});
		};
		this.getUserAgreementList = function(agreementNo, cifId,productType) {
			collectionServiceURL.myCustomerServices.AGREEMENT_LIST.queryParams = {
				cifID : cifId,
				productGroup : productType
			};
			return restProxy.get(collectionServiceURL.myCustomerServices.AGREEMENT_LIST).then(function(data) {
				var agreementList = [], firstObject;
				_.each(data.data, function(item) {
					if (item.agreementNo && item.agreementNo !== agreementNo) {
						agreementList.push({
							agreementNo : item.agreementNo,
							selected : false,
							vehicleNo : productType === 'VF'? item.assetDetail.lmsRegistrationNo :  item.propertyDetails && item.propertyDetails[0] ? item.propertyDetails[0].propertyTitle : ''
						});
					} else if (item.agreementNo === agreementNo) {
						firstObject = {
							agreementNo : item.agreementNo,
							selected : true,
							vehicleNo : productType === 'VF'? item.assetDetail.lmsRegistrationNo : item.propertyDetails && item.propertyDetails[0] ? item.propertyDetails[0].propertyTitle : '',
							isDefault : true
						};
					}

				});
				agreementList.unshift(firstObject);
				return agreementList;
			});
		};

		this.getCholaBranches = function() {
			if (branchNames && branchNames.length > 0) {
				return $q.when(branchNames);
			}
			return masterService.getBranches().then(function(data) {
				branchNames = data;
				return data;
			});
		};

		this.getBranchList = function() {
			return branchNames;
		};

		this.getBranchName = function(branchID) {
			var branchObj = _.findWhere(branchNames, {
				branchID : branchID
			});
			if (branchObj) {
				return branchObj.branchDesc;
			} else {
				return '';
			}
		};	

		this.initiateStandByTeller = function(queryParams) {			
			var validateMobile = receipt.validators.mobileNo(queryParams.mobileNumber);
			if(validateMobile.status != "success")
			return;
			var reqBody = {
				branchID : queryParams.branchID,
				fromDate : dateFormater(queryParams.fromDate),
				mobileNumber : queryParams.mobileNumber,
				remarks : queryParams.remarks,
				tellerID : queryParams.tellerID,
				toDate : dateFormater(queryParams.toDate),
				validityDays :queryParams.validityDays,
				standByTellerID : queryParams.standByTellerID
			};			
			collectionServiceURL.approvalServices.INITIATE_STAND_BY_TELLER.urlParams = {};
			return restProxy.save('POST', collectionServiceURL.approvalServices.INITIATE_STAND_BY_TELLER, reqBody).then(function(data) {
				if(data){
					$globalScope.gotoPreviousPage();
				}
			});
		};	
		this.getTellerDetails = function(branchID) {
			collectionServiceURL.approvalServices.INITIATE_STAND_BY_TELLER.urlParams = {};
			collectionServiceURL.approvalServices.GET_TELLER_DETAILS.queryParams = {
				branchID : branchID
			};
			return restProxy.get(collectionServiceURL.approvalServices.GET_TELLER_DETAILS).then(function(data) {
				return data.data;
			});
		};					
		this.initiateRequest = function(reqBody) {
			collectionServiceURL.approvalServices.WAIVER_APPROVAL.urlParams = {};
			return restProxy.save('POST', collectionServiceURL.approvalServices.WAIVER_APPROVAL, reqBody, '', {
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			}).then(function(data) {
				return data.data;
			});
		};

		this.initiateLegal = function(postObj) {
			return restProxy.save('POST', collectionServiceURL.approvalServices.INITIATE_LEGAL, postObj).then(function(data) {
				return data.data;
			});
		};

		this.getRepoDetails = function(agreementNo) {
			collectionServiceURL.approvalServices.GET_SURRENDER_EXPENSE.urlParams = {};
			collectionServiceURL.approvalServices.GET_SURRENDER_EXPENSE.queryParams = {
				agreementNo : agreementNo
			};
			return restProxy.get(collectionServiceURL.approvalServices.GET_SURRENDER_EXPENSE).then(function(data) {
				return data.data[0];
			});
		};

		this.getRepoAgents = function(agreementNo) {
			collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS.urlParams = {
				agreementNo : agreementNo
			};
			collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS.queryParams = {
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID,
				userrole : $rootScope.identity.hierarchyName
			};
			return restProxy.get(collectionServiceURL.repoServices.ALLOCATE_REPOAGENTS).then(function(data) {
				return data.data;
			});
		};

		this.getYardVendors = function(agreementNo) {
			collectionServiceURL.repoServices.GET_SEIZUREDETAILS.urlParams = {
				agreementNo : agreementNo
			};
			collectionServiceURL.repoServices.GET_SEIZUREDETAILS.queryParams = {
				view : "seizureDetails"
			};
			return restProxy.get(collectionServiceURL.repoServices.GET_SEIZUREDETAILS).then(function(data) {
				if (data.data && data.data[0]) {
					return data.data[0];
				} else {
					return {};
				}
			});
		};
		this.getExpenseModel = function() {
			return new ExpenseModel();
		};
		this.initiateRepoExpense = function(reqObj) {
			collectionServiceURL.approvalServices.SURRENDEREXPENSE_APPROVAL.urlParams = {};
			collectionServiceURL.approvalServices.SURRENDEREXPENSE_APPROVAL.queryParams = {};
			return restProxy.save('POST', collectionServiceURL.approvalServices.SURRENDEREXPENSE_APPROVAL, reqObj).then(function(data) {
				if (data && data.data) {
					return data.data;
				} else {
					return {};
				}
			});
		};

		this.initiateLegalCompliance = function(postObj, legalType) {
			if (legalType === 'compliance') {
				return restProxy.save('POST', collectionServiceURL.approvalServices.UPDATE_LEGAL_COMPLIANCE, postObj).then(function(data) {
					return data.data;
				});
			} else {
				return restProxy.save('POST', collectionServiceURL.approvalServices.UPDATE_LEGAL_APPEAL, postObj).then(function(data) {
					return data.data;
				});
			}

		};

		this.getLegalCaseDetails = function(caseID, legalType) {
			var queryParams = {
				caseID : caseID
			};
			if (legalType === 'compliance') {
				collectionServiceURL.approvalServices.GET_LEGAL_COMPLIANCE.queryParams = queryParams;
				return restProxy.get(collectionServiceURL.approvalServices.GET_LEGAL_COMPLIANCE).then(function(data) {
					return data.data;
				});
			} else {
				collectionServiceURL.approvalServices.GET_LEGAL_APPEAL.queryParams = queryParams;
				return restProxy.get(collectionServiceURL.approvalServices.GET_LEGAL_APPEAL).then(function(data) {
					return data.data;
				});
			}

		};
		this.initiateForeclosure = function(reqObj) {
			collectionServiceURL.approvalServices.FORECLOSURE_INITIATION.urlParams = {};
			collectionServiceURL.approvalServices.FORECLOSURE_INITIATION.queryParams = {
				userbranch : JSON.parse(getCookie('selectedBranch')).branchID
			};
			return restProxy.save('POST', collectionServiceURL.approvalServices.FORECLOSURE_INITIATION, reqObj).then(function(data) {
				if (data && data.data) {
					return data.data;
				} else {
					return {};
				}
			});
		};

		this.getLetterPreview = function(agreementNo, reqObj) {
			collectionServiceURL.approvalServices.FORECLOSURE_LETTER.urlParams = {};
			collectionServiceURL.approvalServices.FORECLOSURE_LETTER.queryParams = {};
			collectionServiceURL.approvalServices.FORECLOSURE_LETTER.EDS = 'collectionsapi/foreclosureDetails/' + agreementNo + '/preview';
			return restProxy.save('POST', collectionServiceURL.approvalServices.FORECLOSURE_LETTER, reqObj).then(function(data) {
				if (data && data.data) {
					return data.data;
				} else {
					return {};
				}
			});
		};
		
		this.getLegalDetails = function(agreementNo,cifID,count){
			collectionServiceURL.legalServices.CORPORATE_CASE.queryParams = {agreementNo : agreementNo,view : 'agreementDetail'};
			return restProxy.get(collectionServiceURL.legalServices.CORPORATE_CASE).then(function(data) {
				var legalDetails = data.data;
				if(legalDetails){
					var _message = '',noOfCase;
					if(legalDetails.cholaFiledCase.length > 0){
						noOfCase = legalDetails.cholaFiledCase.length > 1 ? ' cases have been' : ' case has been';
						_message = '<div class="pad-btm-5"> '+legalDetails.cholaFiledCase.length+ noOfCase+' filed against this customer. </div>';
						_.each(legalDetails.cholaFiledCase,function(caseNo){
							_message += '<div>'+caseNo+'</div>';
						});
					}
					if(legalDetails.customerFieldCase.length > 0){
						noOfCase = legalDetails.customerFieldCase.length > 1 ? ' cases have been' : ' case has been';
						_message += '<div class="pad-btm-5 pad-tp"> ' + legalDetails.customerFieldCase.length + noOfCase + ' filed by this customer against CHOLA. </br>';
						_.each(legalDetails.customerFieldCase,function(caseNo){
							_message += '<div>'+caseNo+'</div>';
						});
					}
					
					if(count > 0){
						noOfCase = count > 1 ? ' There are ' : ' There is ';
						_message += '<div class="pad-btm-5 pad-tp"> ' + noOfCase + count + ' connected agreements under the CIF ID ('+cifID+') for the same customer </br>';
					}
					if(legalDetails.agreementBucketTrend && legalDetails.agreementBucketTrend.length > 0){
						legalDetails.bucketTrend = utility.handleDelequency(true,legalDetails.agreementBucketTrend,collectionConstants.NON_DELEQUENCY_DATA);
					}else{
						legalDetails.bucketTrend = utility.handleDelequency(false,[],collectionConstants.NON_DELEQUENCY_DATA);
					}
					if(_message){
						dialogService.showAlert(constants.ERROR_HEADER.alert, constants.ERROR_HEADER.alert, _message,true);
					}
					return legalDetails;
				}
			});
		};
		
		this.getCholaBranchesByZone = function(){
			collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.urlParams = {};
			if($rootScope.identity.headerLabel === "Zone"){
				collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.queryParams = {view:"getBranch",zoneID:JSON.parse(getCookie('selectedBranch')).ZoneID};
				return restProxy.get(collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE).then(function(data){
					return data.data;
				});
			}else{
				var queryParams = {masterType: 'Branch,Area,Region,Zone'};
				switch ($rootScope.identity.headerLabel) {
				case 'Area':
					queryParams.areaID = JSON.parse(getCookie('selectedBranch')).areaID;
					queryParams.masterType = "Area,Region,Zone";
					break;
				case 'Region':
					queryParams.regionID = JSON.parse(getCookie('selectedBranch')).regionID;
					queryParams.masterType = "Region,Zone";
					break;
				default:
					queryParams.branchID = JSON.parse(getCookie('selectedBranch')).branchID;
					break;
				}
				
				return masterService.getZoneFromBranch(queryParams).then(function(data) {
					if(data && data.data && data.data.Zone && data.data.Zone[0] && data.data.Zone[0].ZoneID){
					collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE.queryParams = {view:"getBranch",zoneID:data.data.Zone[0].ZoneID};
					return restProxy.get(collectionServiceURL.approvalServices.BRANCHES_FROM_ZONE).then(function(data){
						return data.data;
					});
					}
				});
			}
		};
		
		var dateFormater = function(dateVal) {
			if(!dateVal){
				return '';
			}
			if(typeof dateVal === 'string'){
				var dateArr = dateVal.split('/');
				dateVal = dateArr[2]+'/'+dateArr[1]+'/'+dateArr[0];
			}
			var date = new Date(dateVal); 
			var yyyy = date.getFullYear().toString();
			var mm = (date.getMonth() + 1).toString();
			var dd = date.getDate().toString();
			return yyyy + '-' + (mm[1] ? mm : "0" + mm[0]) + '-' + (dd[1] ? dd : "0" + dd[0]);
		};
		this.setChargeDetails = function(_expenseDetails){
			var i, charge, differenceAmt,expenseDetails=[];
			var total = {
				receiptChargeType : 'TOTAL',
				actualAmount : 0,
				waiverAmount : 0,
				percentage : 0,
				netWorking : 0
			};
			for (i = _expenseDetails.length - 1; i >= 0; i--) {
				charge = _expenseDetails[i];
				charge.waiverAmount = charge.waiverAmount ? charge.waiverAmount : 0;
				differenceAmt = Math.round(Number(charge.chargeAmount) - Number(charge.paidAmount)); 
				charge.netWorking = charge.actualAmount = differenceAmt > 0 ? differenceAmt : 0;
				charge.waiverAmount = charge.percentage = 0;
				if(charge.receiptChargeType && charge.receiptChargeType.toUpperCase() !== "EXCESS REFUNDS"){
					total.actualAmount += charge.actualAmount;
					total.netWorking += charge.netWorking;
				}else{
					total.actualAmount -= charge.actualAmount;
					total.netWorking -= charge.netWorking;
				}
				if (charge.actualAmount <= 0) {
					_expenseDetails.splice(i, 1);
				}
			}
			_expenseDetails.push(total);
			return _expenseDetails;
		};
		
		this.simulateForeclosure = function(agreementNo,tillDate){
			collectionServiceURL.receiptingServices.SIMULATE_FORECLOSURE.urlParams = {agreementNo:agreementNo};
			collectionServiceURL.receiptingServices.SIMULATE_FORECLOSURE.queryParams = {fcDate:dateFormater(tillDate),type:'summary'};
			return restProxy.get(collectionServiceURL.receiptingServices.SIMULATE_FORECLOSURE).then(function(data){
				var returnObj = (data.data && data.data[0]) ?  data.data[0] : $q.reject(data); 
				returnObj.totalDueDetails = _.sortBy(returnObj.totalDueDetails, function(o) { return -new Date(o.charge_dueDate); });
				return returnObj;
			});
		};
		
		this.showNonPaymentsPopUp = function(_details){
			$modal.open({
                templateUrl: 'app/collections/eReceipt/receipting/partials/popup/NonPaymentAgreements.html',
                controller: ['$scope','$modalInstance','data','initiateRequestService','messageBus',function($scope,$modalInstance,data,initiateRequestService,messageBus){
                	var agreementListWithOD = [];
                	_.each(data.data.agreementList,function(agreement){
                		if(agreement.totalEMIODAmount > 0 || agreement.otherOD > 0){
                			agreementListWithOD.push(agreement);
                		}
                	});
                	$scope.pagination = {
                		maxSize : 5,
                		totalRecord : agreementListWithOD.length,
                		currentPage : 1,
                		enteredCount : 0
                	};
                	var _count = 0;
                	$scope.splicRow = function(currentPage){
                		var _cp = (currentPage-1) * $scope.pagination.maxSize;
                		$scope.pagination.data = agreementListWithOD.slice(_cp,_cp+$scope.pagination.maxSize);
                	};
                	$scope.splicRow(1);
                	$scope.blurHandler = function(){
                		_count = 0;
                		_.each(agreementListWithOD,function(list){
                			if(list.reason && list.reason.trim()){
                				_count ++;
                			}
                		});
                		$scope.pagination.enteredCount = _count;
                	};
                	
                	$scope.isAllSelected = function(value){
                		_.each(agreementListWithOD,function(list){
                			list.selected = value;
                		});
                		$scope.pagination.isAnyOneSelected = _.findWhere(agreementListWithOD,{selected : true});
                	};
                	
                	$scope.okHandler = function(reason){
                		_count = 0;
                		_.each(agreementListWithOD,function(list){
                			list.reason = list.selected ? reason : list.reason; 
                			if(list.reason && list.reason.trim()){
                				_count ++;
                			}
                		});
                		$scope.pagination.isAnyOneSelected = _.findWhere(agreementListWithOD,{selected : true});
                		$scope.pagination.enteredCount = _count;
                	};
                	
                	$scope.close = function(){
                		messageBus.emitMsg('CANCEL_FC_WAIVER');
						$modalInstance.close();
                	};
                	
                	$scope.selectHandler = function(_isSelected){
                		var isSelected = _isSelected;
                		if(isSelected){
                			for(var i=0;i<agreementListWithOD.length;i++){
                				if(!agreementListWithOD[i].selected){
                					isSelected = false;
                					break;
                				}
                			}
                		}
                		$scope.pagination.isAnyOneSelected = _.findWhere(agreementListWithOD,{selected : true});
                		$scope.pagination.allSelected = isSelected;
                	};
                	
                	$scope.proceedHandler = function(){
                		$scope.pagination.agreementWithOD = [];
                		_.each(agreementListWithOD,function(_agreement){
                			$scope.pagination.agreementWithOD.push({agreementNo : _agreement.agreementNo,reason : _agreement.reason});
                		});
                		serviceObj.foreclosureLADetails = {
            					linkedAgreements : $scope.pagination.agreementWithOD,
            					agreementNo : _details.simulateData.agreementNo,
            					justification : $scope.pagination.reason,
            					branchID : JSON.parse(getCookie('selectedBranch')).branchID,
            					requestType: "WAIVER",
            					productGroup: $scope.pagination.productType
            			};
                		$modalInstance.close();
                	};
                	$modalInstance.result.then(function(){},function(){messageBus.emitMsg('CANCEL_FC_WAIVER');});
                }],
                size: 'lg',
                backdrop : 'static' ,
				resolve: {
                    data: function() {
                        return {
                        	data : _details
                        };
                    }
                }
            });
		};
		
		this.showLinkedAgreements = function(_details){
			$modal.open({
                templateUrl: 'app/collections/eReceipt/receipting/partials/popup/LinkeAgreements.html',
                controller: ['$scope','$modalInstance','data','initiateRequestService','messageBus',function($scope,$modalInstance,data,initiateRequestService,messageBus){
                	$scope.agreements = data.data.agreementList;
					$scope.primayAgrNo = data.data.simulateData;
                	$scope.close = function(){
                		$modalInstance.close();
						messageBus.emitMsg('CANCEL_FC_WAIVER');
                	};
                	$scope.okHandler = function(){
                		$modalInstance.close();
                		initiateRequestService.showNonPaymentsPopUp(data.data);
                	};
                	$modalInstance.result.then(function(){},function(){messageBus.emitMsg('CANCEL_FC_WAIVER');});
                }],
                size: 'md',
                backdrop : 'static' ,
				resolve: {
                    data: function() {
                        return {
                        	data : _details
                        };
                    }
                }
            });
		};
		this.getUserDataMapping = function() {
			return repoMasterService.getGlobalMasterData().then(function(data){
				if(data){
					return data;
				}else{
					return repoMasterService.getMasterData().then(function(data){
						return data;
					});	
				}
			});		
		};		
	};
	initiateRequest.service('initiateRequestService', [ '$rootScope', 'restProxy', '$stateParams', 'masterService', '$q', 'dialogService','$modal','repoMasterService', '$globalScope', initiateRequestService ]);
	return initiateRequestService;
});
