define([], function() {

	'use strict';
   require.config({
   		 paths: {
    	  'collectionsApp':'app/collections/collections',
    	  'initiateRequest':'app/collections/approvals/initiateRequest/initiateRequest',
    	  'initiateRequestService':'app/collections/approvals/initiateRequest/services/initiateRequestService',
    	  'initiateRequestController':'app/collections/approvals/initiateRequest/controllers/initiateRequestController',
    	  'receiptWaiverController':'app/collections/approvals/initiateRequest/controllers/receiptWaiverController',
    	  'surrenderExpenseController':'app/collections/approvals/initiateRequest/controllers/surrenderExpenseController',
    	  'initiateLegalController':'app/collections/approvals/initiateRequest/controllers/initiateLegalController',
    	  'legalComplianceController':'app/collections/approvals/initiateRequest/controllers/legalComplianceController',
    	  'foreclosureHEHLController':'app/collections/approvals/initiateRequest/controllers/foreclosureHEHLController',
		  //'standByTellerController':'app/collections/approvals/initiateRequest/controllers/standByTellerController',
    	  'sharedPackage' : 'app/common/shared/package',
    	  'legalConstants' : 'app/collections/legal/legalConstants',
		  'shortfallWaiverInitiateController':'app/collections/approvals/initiateRequest/controllers/shortfallWaiverInitiateController',
		  'saleRefundController':'app/collections/approvals/initiateRequest/controllers/saleRefundController',
    	  //'masterLegalConstants':'app/collections/legal/masterLegalConstants'
          'initiateRequestResolver' : 'app/collections/approvals/initiateRequest/resolvers/initiateRequestResolver'  	  
    	},
    	shim:{
    		'initiateRequest':['angular','angular-ui-router'],
    		'initiateRequestService':['initiateRequest'],
    		'initiateRequestController':['initiateRequestService'],
    		'receiptWaiverController':['initiateRequestService'],
    		'surrenderExpenseController':['initiateRequestService'],
    		'initiateLegalController':['initiateRequestService'],
    		'legalComplianceController':['initiateRequestService'],
			//'standByTellerController':['initiateRequest', 'initiateRequestService'],
    		'foreclosureHEHLController':['initiateRequestService'],
			'saleRefundController':['initiateRequestService']
    		//'legalConstants':['masterLegalConstants']
    	} 


   });

   return function(callback){
	   requirejs([ 'sharedPackage','legalConstants' ], function(commonPackageLoader,legalConstants) {
			commonPackageLoader(function() {
				requirejs([ 'initiateRequestController','receiptWaiverController','surrenderExpenseController','initiateLegalController','legalComplianceController','foreclosureHEHLController','shortfallWaiverInitiateController','saleRefundController'],callback);
			});
		});
   };

});