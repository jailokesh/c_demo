define(['require','collectionsApp','initiateRequestResolver'],function(require,collectionsApp,initiateRequestResolver){
   'use strict';
	/**
	* Contains the batching routing information.
	* Create and return the batching module.
	*/	
	var baseViewUrl = 'app/collections/approvals/initiateRequest/'; 
	var app = angular.module('initiateRequest',['ui.router','collections']);
   
	var initiateRequest = {
		name : 'collections.initiateRequest',
		url : '/initiateRequest/:reqType',
		views : {
			'mainContent' : {
				templateUrl : baseViewUrl+'initiateRequest.html',
				controller : 'initiateRequestController'
			}
		},
		data : {'headerText':'Approval - Initiate Request',
				'backState':'collections.approvalQueue'
		}
	};
    var reInitiateRequest = {
        name : 'collections.reInitiateRequest',
        url : '/initiateRequest/:reqType/:agreementNo',
        views : {
            'mainContent' : {
                templateUrl : baseViewUrl+'initiateRequest.html',
                controller : 'initiateRequestController'
            }
        },
        data : {'headerText':'Approval - Initiate Request',
            'backState':'collections.approvalQueue'
        }
    };
	/**
	* Contains the batching configuration details.
	*/
	var initiateRequestConfiguration = function($stateProvider,$urlRouterProvider){
		$stateProvider.state(initiateRequest).state(reInitiateRequest);
	};
   
	app.config(['$stateProvider', '$urlRouterProvider', initiateRequestConfiguration]);
	return app;
});
